import Vue from "vue";
import VueRouter, { RouteConfig } from "vue-router";

Vue.use(VueRouter);

const routes: Array<RouteConfig> = [
  {
    path: "/document-upload-portal",
    name: "DocumentPortalSplash",
    component: () => import(`../components/tenant-specific/${process.env.VUE_APP_TENANT}/DocumentPortalSplash.vue`)
  },
  {
    path: "/email-landing-splash",
    name: "EmailLandingSplash",
    component: () => import(`../components/tenant-specific/${process.env.VUE_APP_TENANT}/EmailLandingSplash.vue`)
  },
  {
    path: "/application-complete",
    name: "ApplicationComplete",
    component: () => import(`../components/tenant-specific/${process.env.VUE_APP_TENANT}/ApplicationComplete.vue`)
  },
  {
    path: "/document-upload-portal/capture/:applicationId",
    name: "DocumentPortalCapture",
    component: () => import(`../components/tenant-specific/${process.env.VUE_APP_TENANT}/Capture.vue`)
  },
  {
    path: "/document-upload-portal/verification/:applicationId/:sessionId",
    name: "DocumentPortalVerification",
    component: () => import(`../components/tenant-specific/${process.env.VUE_APP_TENANT}/DocumentPortalVerification.vue`)
  },
  {
    path: "/document-upload-portal/completed/:applicationId?",
    name: "DocumentPortalCompletion",
    component: () => import(`../components/tenant-specific/${process.env.VUE_APP_TENANT}/DocumentPortalCompletion.vue`)
  },
  {
    path: "/",
    name: "Onboarding",    
    component: () => import("../layouts/blank-layout/Blanklayout.vue"),
    children: [
      {
        path: "/register/:CUREF?",
        name: "home",
        component: () => import(`../components/tenant-specific/${process.env.VUE_APP_TENANT}/OnboardingPortalSplash.vue`)        
      },
      {
        path: "/:CUREF?",
        name: "apply",
        component: () => import(`../components/tenant-specific/${process.env.VUE_APP_TENANT}/Onboarding.vue`)
      }
    ],
  },
  {
    path: "*",
    name: "Invalid",
    redirect: "/",
  },
];

const router = new VueRouter({
 // mode: "history",
  base: process.env.BASE_URL,
  routes,
});

export default router;
