<template>
  <v-app>
    <v-content style="margin: 0 auto; width: 100%">
      <v-container fluid ma-0 pa-0 fill-height class="d-flex justify-center">
        <router-view />
      </v-container>
    </v-content>
  </v-app>
</template>

<script>
export default {
  name: "Blanklayout"
};
</script>
