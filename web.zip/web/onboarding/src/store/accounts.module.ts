import {Module, Mutation, VuexModule} from "vuex-module-decorators";
import {AccountType, AuthResponse, SummaryData, Wallet, WalletData} from "@/types/dashboard.types";
import store from "@/store/index";

class AccountsModuleHelpers
{
    /**
     * This function is combining wallet data and account data and linking them together to support the UX functionality
     * @param summaryData : the summary data sent down from the middle tier post login
     * @private
     */
    public static buildWallets(summaryData: SummaryData): Wallet[]
    {
        const wallets = new Array<Wallet>();
        summaryData.wallets.forEach( walletData => {
                const linkedAccount = summaryData.accounts.find( acc => acc.accountId == walletData.linkedToAccount);
                if (linkedAccount) {
                    const newWallet = new Wallet(walletData, linkedAccount);
                    wallets.push(newWallet);
                }
            }
        );
        return wallets;
    }

}



@Module({ name: 'accountsModule', store: store })
export default class AccountsModule extends VuexModule {

    // #region State
    _wallets: Wallet[] = new Array<Wallet>();
    _currentSummary: Wallet|any = {};

    // #endregion

    // #region Getters

    /**
     * computed value - note we return a function not the value
     * get the accountHolders -
     */
    get accountHolders() {
        return () => {
            this._currentSummary.accountHoldersText();
        }
    }

    /**
     * computed - returns wallets
     */
    get wallets(): Wallet[] {
        return this._wallets;
    }

    get walletsCount(): number {
        return this._wallets ? this._wallets.length : 0;
    }
    /**
     * returns the currently selected wallet
     */
    get selectedWallet()
    {
        return () => this._currentSummary;
    }


    /**
     * Processes the authentication response
     * Selected the active current account ranked as sole, then joint then first wallet
     * @param authResponse
     */
    @Mutation
    setAuthResponse(authResponse: AuthResponse)
    {
        this._wallets = AccountsModuleHelpers.buildWallets(authResponse.summaryData);
        console.log(JSON.stringify(this._wallets));
        if (this._wallets.length > 0) {
            const currentAccount = this._wallets.find( w => (w.account.accountType === AccountType.current));
            if (currentAccount) {
                this._currentSummary = currentAccount;
            } else {
                const jointAccount = this._wallets.find( w => (w.account.accountType === AccountType.joint));
                if (jointAccount) {
                    this._currentSummary = jointAccount;
                } else
                {
                    this._currentSummary = this._wallets[0];
                }
            }
        }
    }



    /**
     * set the selected wallet - called by the UX - this is reactive
     * @param wallet
     */
    @Mutation
    setSelectedWallet(wallet: Wallet)
    {
        if (this._currentSummary !== wallet) {
            this._currentSummary = wallet;
        }
    }

}
