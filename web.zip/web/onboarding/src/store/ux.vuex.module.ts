import {Module, VuexModule, Mutation, Action} from 'vuex-module-decorators'

@Module
export default class UxVuexModule extends VuexModule {
    sidebarDrawer = null
    customiserDrawer = false
    sidebarColour = "#1d2228" //Change Sidebar Color || 'white', | "#2b2b2b" | "rgb(44, 59, 164)" | "rgb(96, 44, 164)" | "rgb(151, 210, 219)" | "rgb(77, 86, 100)"
    sidebarBg = ""
    navbarColour = "white"
    horizontalLayout= false // Horizontal layout

    @Mutation setSidebarDrawer(payload: any) { this.sidebarDrawer = payload }
    @Mutation setCustomiserDrawer(value: boolean) { this.customiserDrawer = value }
    @Mutation setSidebarColour(value: string) { this.sidebarColour = value }
    @Mutation setNavbarColour(value: string) { this.navbarColour = value }
    @Mutation setHorizontalLayout(value: boolean) { this.horizontalLayout = value }
}
