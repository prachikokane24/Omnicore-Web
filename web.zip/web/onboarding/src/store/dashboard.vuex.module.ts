import {Module, VuexModule, Mutation, Action} from 'vuex-module-decorators'


@Module
export default class DashboardVuexModule extends VuexModule {

    /*
    @Mutation setLoggedInUser(payload: any) { this.sidebarDrawer = payload }
    @Mutation setCustomiserDrawer(value: boolean) { this.customiserDrawer = value }
    @Mutation setSidebarColour(value: string) { this.sidebarColour = value }
    @Mutation setNavbarColour(value: string) { this.navbarColour = value }
    @Mutation setHorizontalLayout(value: boolean) { this.horizontalLayout = value }
     */

    @Action
    async someAction() {
        //const wheels = await get(wheelStore)
        //this.context.commit('addWheel', wheels)

    }

}
