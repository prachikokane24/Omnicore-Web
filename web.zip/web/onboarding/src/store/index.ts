import Vue from "vue";
import Vuex from "vuex";
import {RuntimeConfig} from "@/omnicore-lib/src/config/runtimeConfig";
import DashboardVuexModule from "@/store/dashboard.vuex.module";
import UxVuexModule from "@/store/ux.vuex.module";
import AccountsModule from "@/store/accounts.module";

Vue.use(Vuex);

const localDashboardVuexModule = DashboardVuexModule;
const localUxVuexModule = UxVuexModule;
const localAccountsModule = AccountsModule;

function makeStore() {
  return new Vuex.Store({
    state: {
    },
    modules: {
      dashboard: localDashboardVuexModule,
      ux: localUxVuexModule,
      accounts: localAccountsModule,
    },
    actions: {},
    getters: {},
  });
}

const store = makeStore();

export default store;
