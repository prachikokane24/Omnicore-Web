<script lang="ts">

import { Prop } from "vue-property-decorator";
import Vue from "vue";
import Component from "vue-class-component";
import EventBus from "./eventBus.js";

@Component
export default class BaseStep extends Vue {
  @Prop() readonly stepIndex?: number;
  @Prop() readonly stepError?: string;
  debug = false;
  static eventBus = EventBus

  emit(channel, data: any = undefined) {
    if (this.debug) {
      console.log(`BaseStep::Emitting [${channel}]`);
    }
    BaseStep.eventBus.$emit(channel, data);
  }

  on(channel, func: (data: any) => void) {
    if (this.debug) {
      console.log(`BaseStep::Subscribing [${channel}]`);
    }
    BaseStep.eventBus.$on(channel, func);
  }

  //
  // Field validation
  isValid = false;
  get valid() {
    return this.isValid;
  }
  set valid(val) {
    this.isValid = val;
    if (this.debug) {
      console.log(`Firing canprogressupdated for step ${this.stepIndex}: ${this.isValid}`);
    }
    this.$emit("stepstatusupdated", this.isValid, this.stepIndex);
  }

  goNext() {
    this.$emit("gonext");
  }

  goPrevious() {
    this.$emit("goprevious");
  }

  flowCompleted() {
      console.log(`Firing flowCompleted`);
    this.$emit("flowCompleted");
  }

  get mandatoryFieldNote() {
    return "* Mandatory field";
  }
}

</script>
