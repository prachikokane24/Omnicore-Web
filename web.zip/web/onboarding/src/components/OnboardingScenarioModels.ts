export enum SectionStatus {
    Todo = "Todo",
    InProgress = "InProgress",
    Done = "Done"
}

export class Section {
    name?: string;
    status: SectionStatus = SectionStatus.Todo;
    steps?: OnboardingApplicationStepSetup[];
    isVisible = true;

    constructor(name: string, steps: Array<OnboardingApplicationStepSetup>, isVisible = true) {
        this.name = name;
        this.steps = steps;
        this.isVisible = isVisible;
    }
}

export enum OnboardingApplicationStepStatus {
    Todo = "Todo",
    InProgress = "InProgress",
    Done = "Done"
}

export class OnboardingApplicationStepSetup {
    public readonly idx: number;
    public readonly content: any;
    public status = OnboardingApplicationStepStatus.Todo;
    public name = "";
    public isValid = false;
    public isFinal = false;
    public getNextStepId = () => this.idx + 1;
    public canReturn = true;
    public errorMessage = "";
    
    constructor(idx: number, name: string, content: any, isFinal = false, getNextStepId: any = undefined, canReturn = true) {
        this.idx = idx;
        this.name = name;
        this.content = content;
        this.isFinal = isFinal;
        this.getNextStepId = getNextStepId || this.getNextStepId;
        this.canReturn = canReturn;
    }
}

export class Scenario {
    name = "";
    flow: Section[];
    constructor(name: string, flow: Section[]) {
        this.name = name;
        this.flow = flow;
    }
}

export class ScenarioFactoryEntry {
    code = "";
    isDefault = false;
    create: () => Scenario;
    constructor(code: string, create: () => Scenario, isDefault = false) {
        this.code = code;
        this.create = create;
        this.isDefault = isDefault;
    }
}

export default class OnboardingScenarioFactory {
    scenarioFactories: ScenarioFactoryEntry[] = [];

    register(scenarioFactoryEntry: ScenarioFactoryEntry) {
        if (this.scenarioFactories.find(s => s.code === scenarioFactoryEntry.code)) {
            throw new Error(`Cannot register scenario with code '${scenarioFactoryEntry.code}' because one with the same name is already registered`)
        }

        if (scenarioFactoryEntry.isDefault && this.scenarioFactories.find(s => s.isDefault)) {
            throw new Error(`Cannot register more than one default scenario`)
        }

        this.scenarioFactories.push(scenarioFactoryEntry);
    }

    create(scenarioCode: string, useDefaultCodeNotFound = true): Scenario {
        if (!scenarioCode) {
            if (useDefaultCodeNotFound) {
                const scenarioFactoryEntry = this.scenarioFactories.find(s => s.isDefault);
                if (!scenarioFactoryEntry) {
                    throw new Error(`No code provided and cannot find a default factory`)
                }
                else {
                    return scenarioFactoryEntry.create();
                }
            } else {
                throw new Error(`No code provided`)
            }
        } else {
            const scenarioFactoryEntry = this.scenarioFactories.find(s => s.code === scenarioCode);
            if (!scenarioFactoryEntry) {
                throw new Error(`No scenario factory found for code '${scenarioCode}'`);
            } else {
                return scenarioFactoryEntry!.create();
            }
        }
    }
}


   