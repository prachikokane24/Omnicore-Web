import moment, { Moment } from "moment";

export default class DefaultValidationRules {
  static FieldIsRequiredDefaultMessage = "Please ensure you do not leave this field empty.";

  //common regex patterns
  static TownNameRegex = "^[A-Za-z-'\\.\\s]+$";

  // each rule must return true if the content is valid
  // and false or a string if this is not the case

  static isRequired = (v) =>
    (v !== undefined && !/^\s*$/.test(v)) ||
    DefaultValidationRules.FieldIsRequiredDefaultMessage;

  static isRequiredCustom(message) { 
    return (v) => (v !== undefined && !/^\s*$/.test(v)) || message;
  }

  static checkboxRequired = (v) => v !== undefined || "A choice is required.";

  static mustBeTrue(message) {
    return (v) => {
      return v === true || message;
    };
  }

  static isUkPostCode = (v) => {
    const re = /^([Gg][Ii][Rr] 0[Aa]{2})|((([A-Za-z][0-9]{1,2})|(([A-Za-z][A-Ha-hJ-Yj-y][0-9]{1,2})|(([A-Za-z][0-9][A-Za-z])|([A-Za-z][A-Ha-hJ-Yj-y][0-9][A-Za-z]?))))\s?[0-9][A-Za-z]{2})$/;
    return re.test(v) || "Please provide a valid UK postcode.";
  };

  static isValidName(isRequired = true) {
    return (v) => {
      if (!isRequired && v.length === 0) { 
        return true; 
      }
      const re = /^[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'’-]+$/u;
      return (
        re.test(v) || "Please review invalid characters and try again."
      );
    };    
  }

  static textLenWithin(min, max, isRequired = true) {
    return (v) => {
      if (!isRequired && v.length === 0) { 
        return true; 
      }

      if (min === 0 && (v === undefined || v === "")) {
        return true;
      }

      return (
        (v && v.trim().length >= min && v.trim().length <= max) ||
        `Please keep to a minimum of ${min} and maximum of ${max} characters.`
      );
    };
  }

  static isEmailAddress = (v) => {
    const re = /^(?!.*\.\.)(^[^.][^@\s]*@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+)$/gm;
    return re.test(v) || "Please ensure you have provided a valid email address.";
  };

  static checkSpaces = (v) => {
    if (v && v.trim().length != v.length) {
      return "Please remove any leading and trailing spaces.";
    }
    return true;
  };

  static mustBeWithinAge(
    minAge?: number,
    maxAge?: number,
    dateFormat = "DD/MM/YYYY",
    message = "Please ensure the date is not before your date of birth or in the future."
  ) {
    return (v) => {
      if (minAge !== undefined && minAge < 0) {
        throw Error("MinAge must be positive.");
      }

      if (maxAge !== undefined && maxAge < 0) {
        throw Error("MaxAge must be positive.");
      }

      let result = true;
      const dv = moment(v, dateFormat, true);
      if (!dv.isValid()) return `Please ensure the date provided is valid and follows the ${dateFormat.toLowerCase()} convention.`;

      const diffDuration = moment.duration(moment().diff(dv));
      const age = diffDuration.years();
      const months = diffDuration.months();
      const days = diffDuration.days();

      if (minAge !== undefined) {
        result = result && age >= minAge;
        if (!result && age < minAge) {
          message = `Sorry, you must be at least ${minAge} years old to create an account.`;
        }
      }

      if (maxAge !== undefined) {
        if (age > maxAge || (age === maxAge && (months > 0 || days > 0))) {
          result = false;
          message = `Sorry, the maximum age for an applicant is ${maxAge} Years old.`;
        }
      }
      return result || message;
    };
  }

  static dateMustBeWithin(
    dateFrom?: number | Moment | (() => Moment),
    dateTo?: number | Moment | (() => Moment),
    dateFormat?: string,
    message = "The date is not within the allowed range"
  ) {
    return (v) => {
      let result = true;
      const dv = moment(v, dateFormat, true);
      if (!dv.isValid()) return `Please ensure the date provided is valid and follows the ${ dateFormat?.toLowerCase() } convention.`;

      if (dateFrom !== undefined) {
        let df: number | Moment;
        if (typeof dateFrom === "function") {
          df = dateFrom();
        } else {
          df = dateFrom instanceof moment ? dateFrom : moment(dateFrom);
        }
        result = result && dv >= df;
      }

      if (dateTo !== undefined) {
        let dt: number | Moment;
        if (typeof dateTo === "function") {
          dt = dateTo();
        } else {
          dt = dateTo instanceof moment ? dateTo : moment(dateTo);
        }
        result = result && dv <= dt;
      }

      return result || message;
    };
  }

  static isValidDate(fmt) {
    return (v) => moment(v, fmt).isValid() || `Please ensure the date provided is valid and follows the ${ fmt.toLowerCase() } convention.`;
  }

  static isSame(reference, message?: string) {
    return (v) => v === reference() || message || "Must be the same";
  }

  static isNotSame(reference, message?: string) {
    return (v) => v !== reference() || message || "Must not be the same";
  }

  static isPhoneNumber = (v) => {
    const re = /^[\d]{10,11}$/;
    return (
      re.test(v) || "Please keep to a minimum of 10 and maximum of 11 numbers."
    );
  };

  static isUkDomesticPhoneNumber = (v) => {
    const re = /^[\d]{9,11}$/;
    return (
      v === undefined ||
      re.test(v) ||
      "Please keep to a minimum of 9 and maximum of 11 numbers."
    );
  };


  static isValidNationalInsuranceNumber = (v) => {
    const re = /^[A-Za-z]{2}[0-9]{6}[A-Za-z]{1}$/;
    return (
      re.test(v) ||
      "Please ensure your national insurance number is in the correct format."
    );
  };

  static mustBePositiveNumber(label?: string) {
    return (v) => {
      let value = v;
      const message = `Please ensure ${label} is a positive number.`;
      if (typeof v === "string") {
        if (v === "") {
          return message;
        }

        value = Number(v);
      }
      return value >= 0 || message;
    };
  }

  static mustNotBeGreaterThan(max) {
    return (v) => {
      if (max === 0 && (v === undefined || v === "")) {
        return true;
      }

      const value = Number(v);

      if (value >= 0 && value <= max)
        return true;

      return `Please ensure the amount provided does not exceed £${max}.`;
    };
  }

  static mustBeNotMoreThanTwoDecimalPoints = (v) => {

    if (v === undefined || Math.floor(v) === v) return true;

    if (v.toString().split(".").length > 1 && v.toString().split(".")[1].length > 2)
      return "Please ensure you do not provide more than two decimal places.";

    return true;
  };

  static validPin = (v) => {
    const value = v;
    let isValid = true;
    let message = "Please avoid using sequential numbers e.g 1234 or 0987.";
    const forward = [
      "0123",
      "1234",
      "2345",
      "3456",
      "4567",
      "5678",
      "6789",
      "7890",
      "8901",
      "9012",
    ];
    const reverse = [
      "3210",
      "4321",
      "5432",
      "6543",
      "7654",
      "8765",
      "9876",
      "0987",
      "1098",
      "2109",
    ];
    const con = [
      "000",
      "111",
      "222",
      "333",
      "444",
      "555",
      "666",
      "777",
      "888",
      "999",
    ];

    if (reverse.includes(value) || forward.includes(value)) {
      isValid = false;
    }

    if (con.includes(value) || con.includes(value.substring(1)) || con.includes(value.substring(0, value.length - 1))) {
      isValid = false;
      message = "Please avoid using three concurrent numbers e.g 1110.";
    }

    if (value.length !== 4) {
      isValid = false;
      message = "Please ensure you provide 4 numbers.";
    }
    return isValid || message;
  };
}
