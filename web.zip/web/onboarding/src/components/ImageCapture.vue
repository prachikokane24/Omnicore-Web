<template>
    <v-container>
        <v-container v-if="showWarning && !hasError && !isCaptured">
            <v-alert type="warning">To continue you must grant the page access to use the camera, otherwise you will be unable to proceed.</v-alert>
        </v-container>

        <div :class="overlayClass" class="centerize" v-observe-visibility="visibilityChanged">
            <video ref="video" @canplay="initCanvas" playsinline v-show="capturing" v-if="!isCaptured"></video>
            <canvas ref="canvas" style="display:none"></canvas>
            <img :src="imageSrc" v-show="!capturing" />
        </div>

        <v-container class="centerize">
            <v-row v-if="hasMessage() && !showWarning && !isCaptured">{{ message }}</v-row>
            <v-row v-if="isCaptured">Image has been submitted, please click proceed to continue.</v-row>  
        </v-container>
        
        <v-container class="centerize" v-if="!isCaptured">
            <v-row v-if="capturing && !showWarning">
                <v-btn
                    v-if="resetButton"
                    @click="reset()"
                    class="secondary"
                    large
                    rounded>
                    Reset
                </v-btn>
                <v-spacer v-if="resetButton" />
                <v-btn
                    @click="captureImage()"
                    class="primary"
                    large
                    rounded>
                    Capture
                </v-btn>
            </v-row>
            <v-row v-if="!capturing">
                <v-btn
                    @click="reCapture()"
                    class="secondary"
                    large
                    rounded>
                    Retake
                </v-btn>
                <v-spacer v-if="shouldShowSubmit()" />
                <v-btn
                    v-if="shouldShowSubmit()"
                    @click="submit()"
                    :loading="isPerformingUpload"
                    class="primary"
                    large
                    rounded>
                    Save
                </v-btn>
            </v-row>
        </v-container>
    </v-container>
</template>

<script lang="ts">

import Component from "vue-class-component";
import Vue from "vue";
import { Model, Prop } from "vue-property-decorator";
import { omnicore } from "@/omnicore-lib";

@Component
export default class ImageCapture extends Vue {
    @Prop({ required: true }) isCaptured?: boolean;
    @Prop({ required: true }) applicationId?: string;
    @Prop({ required: true }) isPerformingUpload?: boolean;
    @Prop() resetButton?: string;
    @Prop() isSelfie?: boolean;
    @Prop() overlayClass?: string;
    @Prop() message?: string;
    @Prop() maxSize?: number;
    @Prop() showSubmit?: boolean;

    video: any;
    canvas: any;
    imageSrc = "";
    capturing = true;
    showWarning = false;
    contactCentreTelephone = "";
    selectedFile: any = null;
    hasError = false;

    mounted() {
        this.video = this.$refs.video;
        this.canvas = this.$refs.canvas;
        this.contactCentreTelephone = omnicore().contactCentreTelephone;
    }

    hasMessage() {
        return this.message && this.message.length !== 0;  
    } 

    shouldShowSubmit() {
        return this.showSubmit === undefined || this.showSubmit;
    }

    initCanvas() {
        this.canvas.setAttribute('height', this.video.videoHeight);
        this.canvas.setAttribute('width', this.video.videoWidth);
    }

    visibilityChanged (isVisible: boolean, entry: any) {
        if (isVisible) {
            this.startCapture();
        }
    }

    startCapture() {
        const warningTimeout = setTimeout(() => this.showWarning = true, 200);
        navigator.mediaDevices.getUserMedia({ video: {facingMode:  this.isSelfie? 'user':'environment'}, audio: false })
            .then(stream => {
                clearTimeout(warningTimeout);    
                this.showWarning = false;
                if (this.video) {
                    this.video.srcObject = stream;
                    this.video.play();
                }
                this.$emit("clearError");
            })
            .catch(error => {
                this.showWarning = false;
                this.hasError = true;
                this.$emit("error", `The page is unable to access the camera. You'll need to update your browser settings, if unsure please call our contact centre on ${this.contactCentreTelephone}`);
            });
    }

    captureImage() {
        const context = this.canvas.getContext('2d');
        context.drawImage(this.video, 0, 0, this.video.videoWidth, this.video.videoHeight);
        this.imageSrc = this.canvas.toDataURL();

        this.urltoFile(this.imageSrc, `photo-${this.applicationId}-${new Date().getTime()}`)
            .then(photo => {
                if (this.maxSize && photo.size > this.maxSize) {
                    this.$emit('error', `The captured image is too large. The maximum image size for an upload is ${this.maxSize}Mb.`);
                }
                else {
                    this.capturing = false;
                    this.hasError = false;
                    this.$emit("clearError");
                    this.$emit("update", true, photo);
                }
            });
    }

    reCapture() {
        this.capturing = true;
        this.$emit("update", false, null);
    }

    urltoFile(url: string, filename: string): Promise<File> {
        return (fetch(url)
            .then(function(res){return res.arrayBuffer();})
            .then(function(buf){return new File([buf], filename,{type:"image/png"});})
        );
    }

    submit() {
        this.$emit('submit');
    }

    reset() {
        this.$emit('reset');
    }
}
</script>

<style lang="scss" scoped>
.selfie-overlay {
    clip-path: ellipse(200px 230px at 50% 50%) !important;
}

.document-overlay{
    clip-path: inset(-12px) !important;
}

.centerize {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    text-align: center;
}

.video-container {
    background-color: #ddd;
}

.video-container button {
    background: #5B2298;
    border: 1px solid #5B2298;
    box-sizing: border-box;
    border-radius: 8px;
    margin: 0 10px;
}

.spacer { margin: 0 25px; }

.action-btn {
    border-radius: 30px !important;
    background: #5B2298 !important;
    color: #fff;
}

@media only screen and (max-width: 600px) {
    .selfie-overlay {
        clip-path: ellipse(110px 150px at 50% 50%) !important;
    }

    .v-alert { font-size: 14px; }
    .action-btn { 
        font-size: 11px;
        width: 200px;
        margin-bottom: 20px;
    }
    
    .spacer { margin: 0 5px; }
}

</style>