<template>
  <v-stepper
    v-model="stepIdx"  
    ref="stepperContainer"
    id="stepperContent"
    :class="{
            'vstepper elevation-0': stepIdx !== 1,
            'vstepper-noheight elevation-0': stepIdx === 1,
          }" >
    <v-stepper-header elevation="0" class="sticky white elevation-0">
      <slot name="header" />
    </v-stepper-header>
    <v-stepper-items
      class="step-card elevation-0"
      elevation="0"
      id="componentContainer"
    >
      <v-stepper-content
        data-id="stepperContent"
        class="v-stepper-content"
        v-for="{ idx, step } in stepsSequence()"
        :step="idx"
        :key="idx"
      >
        <v-card class="step-component-card" outlined>
          <component
            :stepIndex="idx"
            :stepError="stepError"
            v-model="application"
            v-bind:is="step"
            @stepstatusupdated="stepCompleted"
            @flowCompleted="flowCompleted"
            @gonext="goNext"
            @goprevious="goPrevious"
          />
        </v-card>
      </v-stepper-content>
    </v-stepper-items>
    <v-container class="footer white">
      <v-btn
        data-id="onboarding_left_button"
        @click="goPrevious()"
        class="btn v-btn v-btn--has-bg theme--light v-size--large step-nav"
        v-if="stepIdx > 1 && !isApplicationCompleted"
        :disabled="canPrevious"
      >
        <v-icon>mdi-arrow-left</v-icon>Previous </v-btn
      ><v-spacer />
      <v-btn
        data-id="onboarding_right_button"
        @click="goNext()"
        class="btn v-btn v-btn--has-bg theme--light v-size--large step-nav"
        :disabled="!steps[stepIdx - 1].isValid || stepIdx >= steps.length"
        v-if="
          stepIdx < steps.length &&
            !isApplicationCompleted &&
            !steps[stepIdx - 1].isFinal
        "
      >
        {{  "Next"  }}<v-icon>mdi-arrow-right</v-icon>
      </v-btn>
      <v-btn
        v-if="steps[stepIdx - 1].isFinal"
        data-id="onboarding_submit_button"
        @click="goNext()"
        class="btn v-btn v-btn--has-bg theme--light v-size--large step-nav"
        :disabled="!steps[stepIdx - 1].isValid">
        {{  "Submit"  }}<v-icon>mdi-arrow-right</v-icon>
      </v-btn>    </v-container>
    <div class="centerize block mb-6 text-body-1">
      The Vox Money account and card are issued by Omnio EMI Limited (OEL), which is a principal member of Visa and authorised by the Financial Conduct Authority under the Electronic Money Regulations 2011 (Firm reference 900123) with its registered office at Clerks Court, 18-20 Farringdon Lane, London, England, EC1R 3AU.
    </div>
  </v-stepper>
</template>

<script lang="ts">
//#region module imports

import Vue from "vue";
import Component from "vue-class-component";
import { Inject, Model, Prop } from "vue-property-decorator";
import {
  ApplicationStatuses,
  OnboardingApplication
} from "@/types/onboarding.types";
import {
  OnboardingApplicationStepSetup,
  OnboardingApplicationStepStatus,
  Scenario
} from "./OnboardingScenarioModels";
import EventBus from "./eventBus.js";
import MbsOnboardingContainer from "./OnboardingContainer";
import { OneTimePasswordStatus } from "@/services/OTPService";
import { omnicore } from "@/omnicore-lib";
//#endregion

@Component
export default class OnboardingBase extends Vue {
  // CAREFUL: IT SEEMS THAT PROP INITIALIZATION CAUSES THE PARENT PROP INJECTION
  // DOES NOT WORK
  @Prop() readonly scenario?: Scenario;
  @Model() application?: OnboardingApplication;
  @Inject() container?: MbsOnboardingContainer;

  //
  // Fields
  stepIdx = 1;
  stepError = "";
  debug = true;
  canProgress = false;
  canPrevious = false;
  isApplicationCompleted = false;
  steps?: Array<OnboardingApplicationStepSetup>;
  stepsSequence = () => {
    const res = this.steps!.map(s => ({
      idx: this.steps!.indexOf(s) + 1,
      step: s.content
    }));
    return res;
  };

  constructor() {
    super();
    this.steps = this.scenario?.flow.flatMap(
      section => section.steps as OnboardingApplicationStepSetup[]
    );
    console.log(`Scenario: found ${this.steps?.length} steps`);
  }

  mounted(){
    if(this.stepIdx - 1 === 0)
    {
      this.scrollToTop();
    }    
  }

  // events
  updateOverallProgress() {
    this.$emit("progressupdated", {
      currentStep: this.steps![this.stepIdx - 1]
    });
  }

  stepCompleted = (newVal, sidx) => {
    if (this.steps === undefined) return;

    this.steps[sidx - 1].isValid = newVal;

    if (this.debug) {
      console.log(
        `Step [${sidx}]: isValid=${this.steps[sidx - 1].isValid}, isComplete=${
          this.steps[sidx - 1].status
        }`
      );
    }

    this.updateOverallProgress();
  };

  flowCompleted() {
    console.log(`Flow completed, disabling progress`);
    this.canProgress = false;
    this.canPrevious = false;
    this.isApplicationCompleted = true;
    this.$emit("flowCompleted"); // bubble this up to parent
  }

  // actions
  goNext() {
    if (this.steps === undefined) return;

    const idx = this.stepIdx - 1;

    if (this.debug) {
      console.log(`Step ${idx} before: ${this.steps[idx].status}`);
    }

    if (this.steps[idx].isValid) {
      const newStepIdx = this.steps[idx].getNextStepId() + 1;
      const stepIdx = Math.min(newStepIdx, this.steps!.length);

      if (this.steps[stepIdx - 1].name === "CustomerAuth") {
        this.sendCode(this.steps[idx]);

        if (this.steps[idx].errorMessage !== '') {
          this.stepError = this.steps[idx].errorMessage;
          return;
        }
      }
      this.stepIdx = stepIdx;
      this.steps[idx].status = OnboardingApplicationStepStatus.Done;

      if (this.debug) {
        console.log(`Step ${idx} after: ${this.steps[idx].status}`);
      }


      if (
        this.steps[this.stepIdx - 1].status ===
        OnboardingApplicationStepStatus.Todo
      )
        this.steps[this.stepIdx - 1].status =
          OnboardingApplicationStepStatus.InProgress;

      if (this.debug) {
        console.log(
          `GoNext: Moving to step [${this.steps[this.stepIdx - 1].name}]`
        );
      }
  
      EventBus.$emit('gonext', this.steps[idx]);
      this.updateOverallProgress();
      this.scrollToTop();
    }
  }

  goPrevious() {
    if (this.steps === undefined) return;

    this.stepIdx = Math.max(this.stepIdx - 1, 1);
    console.log(
      `GoPrevious: Moving to step [${this.steps[this.stepIdx - 1].name}]`
    );
    this.updateOverallProgress();
    this.scrollToTop();
  }

  scrollToTop() {
    window.scroll(0,0);
  }
  
  sendCode(step: OnboardingApplicationStepSetup): void {
    // call OTP Provider here
    this.container?.OTPService.sendOTP(this.application?.primaryApplicant?.contactDetails.mobilePhoneNumber || "")
      .then(response => {
        if (response.status === OneTimePasswordStatus.FailureOnOTPCreation) {
          step.errorMessage = `Failed to send the code to your mobile phone; please check your mobile phone number and retry.`;
          return;
        }

        omnicore().localCache.put(
          `OnboardingApplication-Otp-${this.application?.primaryApplicant?.contactDetails.mobilePhoneNumber}`, response.sessionId, 3600);
      })
      .catch(error => {
        step.errorMessage = `Failed to send the code to your mobile phone; please retry. Error: ${error}`;
      });
  }
}
</script>

<style scoped>

.centerize {
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
}

.vstepper {  
  border: 0px;
  box-shadow: 0;
  width: 100%;
  height:100%;
  overflow: visible;
  display: flex;
  flex-direction: column;  
}
.vstepper-noheight {
  
  border: 0px;
  box-shadow: 0;
  width: 100%;
  overflow: visible;
  display: flex;
  flex-direction: column;
}

.step-card {  
  width: 100%;  
  overflow-y: auto;
  overflow-x: hidden;    
}

.v-sheet--outlined {
  border: 0px !important;
}

.step-component-card {
  padding-left: 5px;
  padding-right: 5px;
  border: 0px;
}

.footer {  
  display: flex;
  padding: 0px;
  padding-bottom:20px;
  flex: none;
}

.sticky {
  position: sticky;
  top: 0;
  z-index: 1;
}

.v-stepper__step {
  padding: 5px;
}

.v-stepper__header {
  height: initial !important;
  flex: none;
}

.v-stepper-content {
  padding: 10px;
  max-width: 610px;
  margin: 0 auto;
}

.stepper-section {
  border: 2px black;
  padding: 12px;
  background-color: #9a9c9c;
  border-radius: 16px;
  color: white;

  align-items: center;
  display: inline-flex;
  font-size: 14px;
  height: 32px;
  margin-left: 5px;
  margin-top: 5px;
  margin-bottom: 5px;
}

button.step-nav {
  background-color: var(--v-secondary-base) !important;
  border: 2px solid var(--v-secondary-base);
  color: #fff;
}

button.step-nav:hover {
  background-color: var(--v-primary-base) !important;
  border: 2px solid var(--v-primary-base);
  color: #fff;
}

button.step-nav.v-btn--disabled {
  border: none !important;
}
</style>