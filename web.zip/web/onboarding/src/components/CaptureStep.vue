<template>
  <div />
</template>
<script lang="ts">

import Component from "vue-class-component";
import { Inject } from "vue-property-decorator";
import { omnicore } from "@/omnicore-lib";
import { ApplicantKycStatus, KycChallengeDocumentCategory, KycReviewStatus, OnboardingApplication } from "@/types/onboarding.types";
import BaseStep from "./BaseStep.vue";
import { DocumentCategoryUpload, DocumentUpload, DocumentType } from "./OnboardingModelsBase";
import MbsOnboardingContainer from "./OnboardingContainer";
import { DocumentUploadOutcome, KycDocumentInfo } from "@/services/OnboardingApplicationService";
import { OnboardingDocumentUploadRequest } from "@/services/OnboardingDocumentService";
import Observer from 'intersection-observer';
@Component
export default class CaptureStep extends BaseStep {
  @Inject() container?: MbsOnboardingContainer;

  application?: OnboardingApplication;
  applicationId = "";
  hasError = false;
  errorMessage = "";
  isPerformingUpload = false;
  isInUploadPhase = false;
  isCaptured = false;
  docUploads: DocumentCategoryUpload[] = [];
  contactCentreTelephone = "";
  isUploadSuccessful = false;
  readonly httpBadRequest = 400;
  readonly  incorrectMimeTypeError =
 `The upload file format is not acceptable.  
  Acceptable image types are:- Image file types: 
  .jpg, .jpeg, .png, .pdf 
  For video (only video selfie):   .mp4, .ogg, .webm
  Please resubmit, using an acceptable version.`;

  translationMap = {
    // address
    utilityBill: "Utility Bill",
    solicitorsLetter: "Solicitors Letter",
    councilTaxBill: "Council Tax Bill",
    letterFromNHS: "National Health Service (NHS) Letter",
    letterFromProbationOfficer: "Letter From Probation Officer",
    other: "Other",
    bankStatement: "Bank Statement",
    tenancyAgreement: "Tenancy Agreement",
    hmrcLetter: "HMRC Letter",
    benefitOrDWPLetter: "Benefit/DWP letter",
    collegeOrUniversityLetter: "College/University Letter",
    studentLoanOrGrantLetter: "Student Loan/Grant Letter",
    letterFromCareHome: "Letter from Care Home",
    ukDrivingLicence: "UK Driving Licence",
    courtOrder: "Court Order",

    // identity
    birthCertificate: "Birth Certificate",
    drivingLicence: "Driving Licence",
    identityCard: "National Identity Card",
    nhsLetter: "NHS Letter",
    passport: "Passport",
    ukArmedForcesIdCard: "UK Armed Forces ID Card",
    europeanIdentityCard: "European ID Card",
    northenIrelandElectoraIdCard: "Northern Ireland Electoral Identity Card",
    ukResidencePermit: "UK Residence Permit",
    dwpPensionLetter: "DWP Pension Letter",
    benefitsOrDwpLetter: "Benefits/DWP Letter",
    paperOldStyleDrivingLicence: "Paper Old-Style Driving Licence",

    // photo
    selfie: "Selfie",
    videoSelfie: "Video Selfie",

    // representation
    powerofAttorney: "Power of Attorney",

    // residence
    residenceVisa: "Residence Visa",
    residenceCard: "Residence Card",

    // source of income
    taxReturn: "Tax Return",
    payslip: "Payslip",
    bankStatementIncome: "Bank Statement (Income)",
    employmentIncome: "Employment Income",
    loanAgreement: "Loan Agreement",
    benefits: "Benefits",
    savings: "Savings",
    savingsAccountStatement: "Savings Account Statement",
    letterConfirmingSalary: "A Letter From Employer Confirming Salary",

    // wealth
    inheritanceDeeds: "Inheritance Deeds",
    contractPropertySale: "Contract Property Sale",
    contractofSaleofShares: "Contract of Sale of Shares",
    dividendDistribution: "Dividend Distribution",
    shareHoldingCertificate: "Share Holding Certificate",
    bankStatementWealth: "Bank Statement (Wealth)"
  };

  mounted() {
    this.applicationId = this.$route.params.applicationId.toString();
    this.application = omnicore().localCache.get<OnboardingApplication>(`OnboardingApplication-${this.applicationId}`);
    this.contactCentreTelephone = omnicore().contactCentreTelephone;
    
    if (!this.application) {
      this.showError("No application detected");
    } else {
      this.docUploads = this.getDocumentsToUpload(this.application);
    }
  }

  clearError() {
    this.hasError = false;
    this.errorMessage = '';
  }

  showError(message: string) {
    this.hasError = true;
    this.errorMessage = message;
  }

  getDocUpload(type: string) {
    if (this.application && this.proceedWithCapture()) {
      return this.docUploads.find(du => du.name === type);
    }
  }

  getDocumentsToUpload(application: OnboardingApplication) {
    if (omnicore().localCache.hasKey(`DocumentCategoryUploads-${this.applicationId}`)) {
      return omnicore().localCache.get<DocumentCategoryUpload[]>(`DocumentCategoryUploads-${this.applicationId}`);
    } else {
      const docUploads = application!.primaryApplicant!.kycChallenge!.requiredDocuments!.map(
        k => {
          const dcu = new DocumentCategoryUpload();
          dcu.name = k.type ?? "unknown";
          for (let i = 0; i < (k.numberRequired ?? 0); i++) {
            dcu.uploads?.push(new DocumentUpload());
          }

          dcu.types = k.documents?.map(t => {
            // the following is there because of the (told to be necessary) complicated
            // structure of documents
            let type = "";
            switch (k.type) {
              case "address":
                type = t.address ?? "";
                break;
              case "identity":
                type = t.identity ?? "";
                break;
              case "representation":
                type = t.representation ?? "";
                break;
              case "residence":
                type = t.residence ?? "";
                break;
              case "sourceOfIncome":
                type = t.sourceOfIncome ?? "";
                break;
              case "sourceOfWealth":
                type = t.sourceOfWealth ?? "";
                break;
              case "photo":
                type = t.photo ?? "";
                break;
              default:
                throw new Error(`Unhandled document type '${k.type}'`);
            }

            const dt = new DocumentType();
            dt.id = t.id ?? "unknown";
            dt.type = type;
            dt.translatedType = this.translateType(type);
            return dt;
          }) ?? [];

          return dcu;
        }
      );
      omnicore().localCache.put<DocumentCategoryUpload[]>(`DocumentCategoryUploads-${this.applicationId}`, docUploads, 3600);
      return docUploads;
    }
  }

  proceedWithCapture(): boolean {
    if (this.application!.primaryApplicant === undefined ||
        this.application!.primaryApplicant!.kycChallenge === undefined) {
      return false;
    }

    switch (this.application!.primaryApplicant!.kycChallenge!.status) {
      case ApplicantKycStatus.Success:
        this.showError(
          "Your application has already been approved, there is no need to provide extra documents"
        );
        return false;

      case ApplicantKycStatus.Failed:
        this.showError(
          "Unfortunately your application has been rejected, there is no need to provide extra documents"
        );
        return false;

      case ApplicantKycStatus.InReview:
        return true;

      default:
        this.showError(
          `Unhandled applicant KYC status '${
            this.application!.primaryApplicant!.kycChallenge!.status
          }'`
        );
        return false;
    }
  }

  documentCategoryToUpload(requiredDocumentCategory: KycChallengeDocumentCategory): DocumentCategoryUpload | undefined {
    try {
      if (requiredDocumentCategory && requiredDocumentCategory.documents && requiredDocumentCategory.documents.length !== 0) {
        const dcu = new DocumentCategoryUpload();
        dcu.name = requiredDocumentCategory.type ?? "unknown";

        for (let i = 0; i < (requiredDocumentCategory.numberRequired ?? 0); i++) {
          dcu.uploads?.push(new DocumentUpload());
        }

        dcu.types = requiredDocumentCategory.documents.map(t => {
          // the following is there because of the (told to be necessary) complicated
          // structure of documents
          let type = "";
          switch (requiredDocumentCategory.type) {
            case "address":
              type = t.address ?? "";
              break;
            case "identity":
              type = t.identity ?? "";
              break;
            case "representation":
              type = t.representation ?? "";
              break;
            case "residence":
              type = t.residence ?? "";
              break;
            case "sourceOfIncome":
              type = t.sourceOfIncome ?? "";
              break;
            case "sourceOfWealth":
              type = t.sourceOfWealth ?? "";
              break;
            case "photo":
              type = t.photo ?? "";
              break;
            default:
              throw new Error(`Unhandled document type '${requiredDocumentCategory.type}'`);
          }

          const dt = new DocumentType();

          dt.id = t.id ?? "unknown";
          dt.type = type;
          dt.translatedType = this.translateType(type);

          return dt;
        }) ?? [];

        return dcu;
      } else {
        throw new Error("There are no required documents for this document type");
      }
    } catch(error) {
      this.showError(error.message);
      return;
    }
  }

  translateType(type: string): string {
    if (type in this.translationMap) {
      return this.translationMap[type];
    } else {
      return type;
    }
  }

  allDocumentsUploaded(): boolean {
    if (this.application?.primaryApplicant?.kycChallenge?.reviewStatus === KycReviewStatus.Initial) {
      return this.docUploads!.every(e => e.uploads!.every(f => f.docUploadStatus === "success"))
    } else {
      let result = true;
      this.docUploads.filter(du => du.uploads?.length !== 0)
          .forEach(du => {
            const hasUploads = du.uploads?.some(up => up!.id !== '' && up!.docUploadStatus === "success");
            if (!hasUploads) {
              result = false;
            }
          });
      return result;
    }
  }

  async handleSubmit() {
    this.isPerformingUpload = true;

    console.log("Uploading::Uploading docs");

    if (!this.allDocumentsUploaded()) {
      this.isCaptured = false;
      this.isPerformingUpload = false;
      this.errorMessage = "One or more documents failed to upload, please retry";
      this.hasError = true;
      return;
    }

    const appDocs = this.docUploads!.flatMap(e =>
      e.uploads!.filter(f => f.id !== '' && f.appStatus !== "success")
    ).map(f => new KycDocumentInfo(f.id, f.fileId));

    try {
      const fssResponse = await this.container?.ApplicationService.submitDocument(
        this.application!.primaryApplicant!.kycChallenge!.id,
        appDocs
      );

      const res = fssResponse!.applicantsOutcomes?.filter(
        ao => ao.kycChallengeId === this.application!.primaryApplicant!.kycChallenge!.id
      );

      if (res === undefined || res.length < 1) {
        throw new Error(`Unable to retrieve information about doc submission`);
      }

      const failedDocs = res.flatMap(r => r.documentOutcomes);
      const uploadDocs = this.docUploads!.flatMap(ud => ud.uploads);
      let hasErrors = false;
      
      failedDocs.forEach(fd => {
        const upload = uploadDocs.find(
          ud => ud?.fileId === fd?.secureDocumentStorageId
        );

        upload!.appStatus = fd?.outcome === DocumentUploadOutcome.Success ? "success" : "error";
        upload!.docUploadStatus = upload!.appStatus;

        if (upload!.appStatus === "error") {
          hasErrors = true;
        }
      });

      if (hasErrors) {
        throw new Error(
          `Some documents could not be updated properly in the application`
        );
      }

      this.flowCompleted();
      this.isCaptured = true;
    } catch (error) {
      this.errorMessage = "Failed to update the application with the uploaded documents";
      this.hasError = true;
      this.isCaptured = false;
    } finally {
      this.isPerformingUpload = false;
      if (this.isCaptured) {
        // making sure we dont have residual error message if it is all good after a retry
        this.errorMessage = "";
        this.hasError = false;
      }
    }
  }

  async uploadDocCategory(du): Promise<KycDocumentInfo[]> {
    this.isPerformingUpload = true;

    const toUpload = du.uploads?.filter(up => up.id !== '' && up.docUploadStatus !== "success") || [];

    return Promise.all(
      toUpload.map(async up => {
        up.docUploadStatus = "uploading";
        try {
          return await this.uploadFile(up);
        } catch (error) {
          console.log(`Failed to upload file: ${error}`);
          up.docUploadStatus = "error";
        } finally {
          this.isPerformingUpload = false;
        }
      })
    );
  }

  async uploadFile(upload: DocumentUpload): Promise < KycDocumentInfo | undefined > {
    const data = new FormData();
    const request = new OnboardingDocumentUploadRequest();
    data.append("file", upload.file);
    request.file = data;

    const response = await this.container?.OnboardingDocumentService.upload(request);

    switch (response!.statusCode) {

        case 400: {
            console.log(`Failed to upload doc: ${response!.errorCode}`);
            upload.docUploadStatus = "error";
            this.errorMessage = `Failed to upload some files (${response!.errorCode})`;
            if (response!.errorCode === "mime-type-not-accepted") {
                this.errorMessage = this.incorrectMimeTypeError;
            }
            break;
        }
        case 200:
        case 201: {
            console.log(`Successfully uploaded onboarding document`);
            upload.docUploadStatus = "success";
            upload.fileId = response!.fileId;
            omnicore().localCache.put < DocumentCategoryUpload[] > (`DocumentCategoryUploads-${this.applicationId}`, this.docUploads, 3600);
            this.isUploadSuccessful = true;
            return new KycDocumentInfo(upload.id, response!.fileId);
        }
        default: {
            upload.docUploadStatus = "error";
            console.log(`Failed to upload doc: ${response!.errorCode}`);
            this.errorMessage = `Failed to upload some files (${response!.errorCode})`;
            break;
        }
    }

    return undefined;
  }
  
  toBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        resolve((reader.result as string).split(','));
      };
      reader.onerror = error => reject(error);
    });
  }
}
</script>
