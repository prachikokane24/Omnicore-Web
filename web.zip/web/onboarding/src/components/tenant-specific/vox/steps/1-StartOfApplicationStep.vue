<template>
  <v-form v-model="valid">
    <grouping label="Account Type" v-if="accountTypes.length > 1">
      <v-select
        dense
        outlined
        data-id="account-type"
        :items="accountTypes"
        :item-text="item => item.text"
        :item-value="item => item.id"
        v-model="application.accountType"                 
        label="Choose Account Type"
        :rules="accountTypeValidationRules"
      />
    </grouping>
    <v-spacer />

    <grouping label="Your Residency">
      <v-container>
        <v-row><p>Are you a permanent UK resident?</p></v-row>
        <v-radio-group
          data-id="application-residency"
          v-model="application.primaryApplicant.residencyStatus.UkPermResident"
          :rules="[
            mustBeTrue('Unfortunately our current account is only available to UK residents.')
          ]"
          row
        >
          <v-radio
            label="Yes"
            data-id="application-residency-yes"
            change="applicationResidencyChanged()"
            :value="true"
          ></v-radio>
          <v-radio
            label="No"
            data-id="application-residency-no"
            change="applicationResidencyChanged()"
            :value="false"
          ></v-radio>
        </v-radio-group>
      </v-container>
    </grouping>
    <grouping label="Privacy Policy">
      <v-container>
        <v-row>
          <p>
            In order to proceed with your application, you must confirm that you
            have read and
            <a href="https://www.voxmoney.co.uk/privacy-policy/" target="_blank"
              >accepted our privacy policy</a
            >
          </p>
        </v-row>
        <v-row>
          <v-checkbox
            data-id="application-confirmreadpolicy"
            v-model="application.primaryApplicant.confirmReadPolicy"
            :rules="[mustBeTrue('Please confirm you have read and accepted our privacy policy to continue.')]"
            label="I confirm"
          />
        </v-row>
      </v-container>
    </grouping>
  </v-form>
</template>

<script lang="ts">
//  module imports
import { Inject, Model } from "vue-property-decorator";
import Component from "vue-class-component";
import {
  Applicant,
  AccountType,
  ApplicationType,
  OnboardingApplication
} from "@/types/onboarding.types";
import DefaultValidationRules from "../../../CommonValidationRules";
import BaseStep from "../../../BaseStep.vue";
import Grouping from "../../../Grouping.vue";

@Component({
  components: { Grouping }
})
export default class StartOfApplicationStep extends BaseStep {
  @Model() application?: OnboardingApplication; 

  mounted() {    
    if (
      this.application !== undefined &&
      this.application?.primaryApplicant === undefined
    ) {
      this.application.primaryApplicant = new Applicant();
    }
        
    this.application!.applicationType = ApplicationType.AdultSole;    
    this.application!.accountType = AccountType.eMoneyAccount;
  }

  applicationResidencyChanged() {
    this.application!.primaryApplicant!.residencyStatus!.UkOrEEANational = this.application!.primaryApplicant!.residencyStatus!.UkPermResident;
  }

  accountTypeValidationRules = [DefaultValidationRules.isRequired];
  mustBeTrue = DefaultValidationRules.mustBeTrue;

  isUKResident?: boolean;
  allApplicantsUkOrEEANationalsOrHaveIRL?: boolean;
  confirmInfoAccurate = false;
  
  accountTypes = [
    { text: "e-Money Account", id: AccountType.eMoneyAccount }
  ];
}
</script>