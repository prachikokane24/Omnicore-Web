<template>
  <grouping label="Confirm Your Phone Number">
    <v-container v-observe-visibility="visibilityChanged">
      <v-alert
        v-show="hasErrors"
        dense
        type="error"
        id="application-otp-invalidotpalert"
      >
        {{ errorMessage }}
      </v-alert>
      <v-alert
        type="info"
        dense
        id="application-otp-otpsendalert"
      >
        A 6-digit verification code has been sent to your phone number ending in {{ getNumberEnding() }}
      </v-alert>
      <v-container style="padding: 0px">
        <v-row class="otp-row">
          <v-text-field
            id="application-otp"
            ref="applicationOtp"
            class="otp-field"
            height="80px"
            label="Enter your 6-digit code"
            v-model="otp"
            :value="otp"
            v-mask="'######'"
            autofocus
            dense
            outlined            
          />
        </v-row>
      </v-container>
      <v-row v-show="showResendCode"> </v-row>
      <v-row
        class="action-div"
        style="padding: 10px"
      >
        <a
          id="application-primary-resendbtn"
          @click="sendCode"
          small
          class="resendcode-btn"
          v-if="showResendCode"
        >
          <b>Resend verification code</b>
        </a>
        <span v-else-if="isOtpSentSuccessfully" small class="resendcode-btn">
          <b>Resend verification code in ({{ counter }}s)</b>
        </span>
      </v-row>

      <v-row class="action-div">
        <v-btn
          id="application-primary-performaction"
          :loading="isBusy"
          x-large
          @click="performAction"
          class="action-btn primary"
        >
          {{ actionStage }}&nbsp;<v-icon>mdi-transfer-right</v-icon>
        </v-btn>
      </v-row>
    </v-container>
  </grouping>
</template>
 
<script lang="ts">
//  module imports
import Component from "vue-class-component";
import Grouping from "../../../Grouping.vue";
import BaseStep from "../../../BaseStep.vue";
import { OneTimePasswordStatus } from "@/services/OTPService";
import { Inject, Model, Watch } from "vue-property-decorator";
import { OnboardingApplication } from "@/types/onboarding.types";
import MbsOnboardingContainer from "../../../OnboardingContainer";
import { omnicore } from "@/omnicore-lib";

enum Stages {
  SendCode = "Send Code",
  VerifyCode = "Verify Code"
}

@Component({
  //  component dependencies
  components: {
    Grouping
  }
})
export default class SecureCustomerAuth extends BaseStep {
  @Model() application?: OnboardingApplication;
  @Inject() container?: MbsOnboardingContainer;

  readonly TimeBeforeCanResend = 1000 * 60;
  counter = 60;

  otp?: string = "";
  useOtpServiceMock = true;

  otpSessionId = "";
  isBusy = false;
  hasErrors = false;
  isOtpSentSuccessfully = true;
  showResendCode = false;
  canResend = false;
  actionStage = Stages.VerifyCode;
  errorMessage = ""; //

  constructor() {
    super();
    this.valid = false;
  }

 @Watch("counter")
  handleCounterChange() {
    if (this.counter === 0) {
      this.resetSendStage();
    }
  }
  
  visibilityChanged(isVisible: boolean, entry: any) {
    if (isVisible) {
      // N.B. Short delay required to allow putting value in cache to complete in previous step
      setTimeout(() => {
        this.otpSessionId = omnicore().localCache.get(
          `OnboardingApplication-Otp-${this.application?.primaryApplicant?.contactDetails.mobilePhoneNumber}`);
      }, 1000);
      this.countDownTimer();
    }
  }

  getNumberEnding(): string {
    return this.application?.primaryApplicant?.contactDetails?.mobilePhoneNumber
      ? this.application!.primaryApplicant!.contactDetails!.mobilePhoneNumber!
            .substring(this.application!.primaryApplicant!.contactDetails!.mobilePhoneNumber!.length - 4, this.application!.primaryApplicant!.contactDetails!.mobilePhoneNumber!.length)
        : '';
  }

  resetSendStage(): void {
    this.actionStage = Stages.SendCode;
    this.canResend = true;
    this.showResendCode = true;
    this.isOtpSentSuccessfully = false;
  }

  sendCode() {
    this.isBusy = true;
    this.showResendCode = false;
    this.otp = '';

    // call OTP Provider here
    this.container?.OTPService.sendOTP(
      this.application?.primaryApplicant?.contactDetails.mobilePhoneNumber || ""
    )
      .then(response => {
        if (response.status === OneTimePasswordStatus.FailureOnOTPCreation) {
          this.isBusy = false;
          this.hasErrors = true;
          this.errorMessage = `Failed to send the code to your mobile phone; please retry.`;
          this.resetSendStage();
          return;
        }

        this.otpSessionId = response.sessionId!;
        this.isBusy = false;
        this.hasErrors = false;
        this.actionStage = Stages.VerifyCode;
        this.canResend = false;
        this.showResendCode = false;
        this.isOtpSentSuccessfully = true;
        this.counter = 60;
        this.countDownTimer();
      })
      .catch(error => {
        this.isBusy = false;
        this.hasErrors = true;
        this.errorMessage = `Failed to send the code to your mobile phone; please retry. Error: ${error}`;
        this.resetSendStage();
      });
  }

  countDownTimer(): void {
    let timer;
    window.clearTimeout(timer);
    if (this.counter > 0) {
      timer = setTimeout(() => {
        this.counter -= 1;
        this.countDownTimer();
      }, 1000);
    }
  }

  verifyCode() {
    this.isBusy = true;
    this.container?.OTPService.verifyOTP(
      this.otpSessionId,
      this.application?.primaryApplicant?.contactDetails.mobilePhoneNumber ||
        "",
      this.otp || ""
    )
      .then(response => {
        if (response === OneTimePasswordStatus.Valid) {
          this.valid = true;
          this.hasErrors = false;
          this.showResendCode = false;
          omnicore().localCache.flush(`OnboardingApplication-Otp-${this.application?.primaryApplicant?.contactDetails.mobilePhoneNumber}`);
          this.goNext();
        } else {
          this.hasErrors = true;
          this.errorMessage = `Incorrect 6-digit code. Please try again.`;
        }
      })
      .catch(error => {
        this.hasErrors = true;
        this.errorMessage = `Failed to confirmed the One Time Passcode. Please check and try again. Error: ${error}`;
      })
      .finally(() => {
        this.isBusy = false;
      });
  }

  performAction() {
    this.isBusy = true;

    switch (this.actionStage) {
      case Stages.SendCode:
        this.sendCode();
        break;

      case Stages.VerifyCode:
        this.verifyCode();
        break;
    }
  }
}
</script>
<style >
.otp-row {
  max-width: 200px;
  margin: 0 auto;
}

.otp-field {
  width: 140px;
  font-size: 30px !important;
}

.otp-field input {
  font-size: 30px !important;
  letter-spacing: 10px;
  text-align: center;
  padding:0px;
}

.action-div {
  justify-content: center;
}

.action-btn {
  border-radius: 30px !important;
}
</style>