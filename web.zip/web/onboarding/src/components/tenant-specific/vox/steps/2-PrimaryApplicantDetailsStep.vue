<template>
  <v-form v-model="valid">
    <grouping label="Your Personal Details">
      <v-container>
        <v-row>
          <v-select
            data-id="application-primary-title"
            :items="applicantTitles"
            :item-text="item => item.text"
            :item-value="item => item.id"
            :rules="titleValidationRules"
            v-model="application.primaryApplicant.name.title"
            label="Title"
            dense
            outlined
          ></v-select>
        </v-row>
        <v-row>
          <v-text-field
            data-id="application-primary-current-firstname"
            label="First name"
            v-model="application.primaryApplicant.name.firstName"
            :rules="namesValidationRules"
            :maxLength="maxNameLength"
            dense
            outlined
          />
        </v-row>
        <v-row>
          <v-text-field
            data-id="application-primary-current-middlename"
            label="Middle name ( optional )"
            v-model="application.primaryApplicant.name.middleName"
            :rules="namesValidationRulesNotRequired"
            :maxLength="maxNameLength"
            dense
            outlined
          />
        </v-row>
        <v-row>
          <v-text-field
            data-id="application-primary-current-lastname"
            label="Surname"
            v-model="application.primaryApplicant.name.lastName"
            :rules="namesValidationRules"
            :maxLength="maxNameLength"
            dense
            outlined
          />
        </v-row>
        <p>Have you been known by any other names in the last three years?</p>
        <v-radio-group
          data-id="application-primary-hasbeenknownbyothernamelast3years"
          v-model="haveBeenKnownByAnotherNameInLastThreeYears"
          :rules="[v => v !== undefined || 'Please choose']"
          row
          dense
          @change="haveBeenKnownByAnotherNameInLastThreeYearsHandler"
        >
          <v-radio
            label="Yes"
            data-id="application-primary-hasbeenknownbyothernamelast3years-yes"
            :value="true"
          ></v-radio>
          <v-radio
            label="No"
            data-id="application-primary-hasbeenknownbyothernamelast3years-no"
            :value="false"
          ></v-radio>
        </v-radio-group>
        <p>Gender:</p>
        <v-radio-group
          data-id="application-primary-gender"
          v-model="application.primaryApplicant.gender"
          :rules="[v => v !== undefined || 'Please specify a gender']"
          row
          dense
        >
          <v-radio
            label="Male"
            data-id="application-primary-gender-male"
            value="Male"
          ></v-radio>
          <v-radio
            label="Female"
            data-id="application-primary-gender-female"
            value="Female"
          ></v-radio>
          <!-- <v-radio
            label="Non-Binary"
            data-id="application-primary-gender-nonbinary"
            value="NonBinary"
          ></v-radio> -->
        </v-radio-group>
        <v-row>
          <v-text-field
            data-id="application-primary-dob"
            label="Date of Birth (dd/mm/yyyy)"
            v-model="dateOfBirth"
            outlined
            v-mask="'##/##/####'"
            dense
            :rules="dateOfBirthRules"
          />
        </v-row>
        <v-row>
          <country-list
            :data-id="`application-primary-nationality-primary`"
            v-model="primaryNationality"
            ref="primaryNationality"
            topOfListCountry="GBR"
            label="Nationality"
            :displayNationality=true
            :rules="nationalityRules"
          />
        </v-row>
      </v-container>
    </grouping>

    <div ref="otherNameGroup" />
    <grouping label="Other names" v-if="showPreviousNames">
      <v-container>
        <v-row>
          <v-text-field
            data-id="application-primary-previous-firstname"
            label="First name"
            v-model="application.primaryApplicant.previousName.firstName"
            :rules="namesValidationRules"
            :minLength="2"
            :maxLength="maxNameLength"
            dense
            outlined
          />
        </v-row>
        <v-row>
          <v-text-field
            data-id="application-primary-previous-middlename"
            dense
            label="Middle name ( optional )"
            v-model="application.primaryApplicant.previousName.middleName"
            :rules="namesValidationRulesNotRequired"
            :minLength="2"
            :maxLength="maxNameLength"
            outlined
          />
        </v-row>
        <v-row>
          <v-text-field
            data-id="application-primary-previous-surname"
            label="Surname"
            v-model="application.primaryApplicant.previousName.lastName"
            :rules="namesValidationRules"
            :minLength="2"
            :maxLength="maxNameLength"
            dense
            outlined
          />
        </v-row>
      </v-container>
    </grouping>
  </v-form>
</template>

<script lang="ts">
//  module imports
import Component from "vue-class-component";
import { Model, Watch } from "vue-property-decorator";

import {
  Applicant,
  ApplicantCurrentTitle,
  Individual,
  OnboardingApplication
} from "@/types/onboarding.types";
import DefaultValidationRules from "../../../CommonValidationRules";
import CountryList from "../../../CountryList.vue";
import Grouping from "../../../Grouping.vue";
import BaseStep from "../../../BaseStep.vue";
import DatePicker from "../../../DatePicker.vue";
import moment from "moment";

@Component({
  components: {
    CountryList,
    Grouping,
    DatePicker
  }
})
export default class PrimaryApplicantDetailsStep extends BaseStep {
  @Model() application?: OnboardingApplication;
  applicantTitles: { text: string; id: string }[] = [];

  readonly maxNameLength = 20;
  readonly noDualNationalityValue = "NONE";
  primaryNationalityBuffer = "";
  secondaryNationalityBuffer = "";

  constructor() {
    super();

    if (
      this.application !== undefined &&
      this.application?.primaryApplicant !== undefined &&
      (this.application?.primaryApplicant?.additionalDetails.nationalities ===
        undefined ||
        this.application?.primaryApplicant?.additionalDetails.nationalities
          .length != 2)
    ) {
      this.application.primaryApplicant.additionalDetails.nationalities = [];
    }


    if (
      this.application !== undefined &&
      this.application?.primaryApplicant === undefined
    ) {
      this.application.primaryApplicant = new Applicant();
      const date = moment.utc(
        this.application.primaryApplicant.dateOfBirth,
        "YYYY-MM-DD"
      );
      if (date.isValid()) {
        this.dobBuffer = date.format("DD/MM/YYYY");
      }
    }

    this.applicantTitles = Object.keys(ApplicantCurrentTitle).map(x => ({
      text: ApplicantCurrentTitle[x],
      id: x
    }));
  }

  get primaryNationality(): string {
    return this.primaryNationalityBuffer;
  }
  set primaryNationality(countryIsoCode: string) {
    this.primaryNationalityBuffer = countryIsoCode;
    this.updateNationalities();
  }

  get secondNationality() {
    return this.secondaryNationalityBuffer;
  }
  set secondNationality(countryIsoCode: string) {
    this.secondaryNationalityBuffer = countryIsoCode;
    this.updateNationalities();
  }

  @Watch("primaryNationalityBuffer")
  async onPrimaryNationalityChanged() {
    await this.$nextTick();
    if (this.getSecondaryNationalityBuffer()) {
      (this.$refs.form as Vue & { validate: () => boolean }).validate();
    }
  }

  @Watch("secondaryNationalityBuffer")
  async onSecondayNationalityChanged() {
    await this.$nextTick();
    if (this.getPrimaryNationalityBuffer()) {
      (this.$refs.form as Vue & { validate: () => boolean }).validate();
    }
  }

  // required because the rule seems to be unable to retrieve the value
  // dynamically in any other way
  getPrimaryNationalityBuffer() {
    return this.primaryNationalityBuffer;
  }
  getSecondaryNationalityBuffer() {
    return this.secondaryNationalityBuffer;
  }

  updateNationalities() {
    this.application!.primaryApplicant!.additionalDetails.nationalities = [];
    if (
      this.primaryNationalityBuffer !== undefined &&
      this.primaryNationalityBuffer !== ""
    ) {
      this.application!.primaryApplicant!.additionalDetails.nationalities.push(
        this.primaryNationalityBuffer
      );
    }

    if (
      this.secondaryNationalityBuffer !== undefined &&
      this.secondaryNationalityBuffer !== "" &&
      this.secondaryNationalityBuffer !== this.noDualNationalityValue
    ) {
      this.application!.primaryApplicant!.additionalDetails.nationalities.push(
        this.secondaryNationalityBuffer
      );
    }
  }

  // Nationality validation rules
  nationalityRules = [
    DefaultValidationRules.isRequired,
    DefaultValidationRules.isNotSame(
      () => this.getSecondaryNationalityBuffer(),
      "Primary nationality cannot be the same as secondary"
    )
  ];
  dualNationalityRules = [
    DefaultValidationRules.isRequired,
    DefaultValidationRules.isNotSame(
      () => this.getPrimaryNationalityBuffer(),
      "Secondary nationality cannot be the same as primary"
    )
  ];

  //
  // Fields
  dobBuffer = "";
  haveBeenKnownByAnotherNameInLastThreeYears?: boolean = false;
  showPreviousNames = false; // this is used because Vue is not reactive to the model field for some reasons

  get dateOfBirth() {
    return this.dobBuffer;
  }
  set dateOfBirth(val) {
    this.dobBuffer = val;
    if (
      this.application !== undefined &&
      this.application.primaryApplicant !== undefined
    ) {
      const date = moment.utc(val, "DD/MM/YYYY", true);
      if (date.isValid()) {
        this.application.primaryApplicant.dateOfBirth = date.toISOString();
      }
    }
  }

  //
  // Rules
  titleValidationRules = [
    DefaultValidationRules.isRequiredCustom("Please select a title"),
    DefaultValidationRules.textLenWithin(2, this.maxNameLength)
  ];

  namesValidationRules = [
    DefaultValidationRules.isRequired,
    DefaultValidationRules.isValidName(true),
    DefaultValidationRules.textLenWithin(2, this.maxNameLength)
  ];
  namesValidationRulesNotRequired = [
    DefaultValidationRules.textLenWithin(2, this.maxNameLength, false),
    DefaultValidationRules.isValidName(false)
  ];
  defaultIsrequiedRule = DefaultValidationRules.isRequired;
  dateOfBirthRules = [
    DefaultValidationRules.isValidDate("DD/MM/YYYY"),
    DefaultValidationRules.mustBeWithinAge(
      18,
      120,
      "DD/MM/YYYY",
      "You must be at least 18 years old to create an account."
    ),
    DefaultValidationRules.isRequired
  ];

  haveBeenKnownByAnotherNameInLastThreeYearsHandler(value) {
    this.showPreviousNames =
      this.haveBeenKnownByAnotherNameInLastThreeYears || false;
    if (this.showPreviousNames) {
      this.$vuetify.goTo(this.$refs.otherNameGroup as HTMLElement, {
        container: "#componentContainer", // This references the container defined in the onboardingbase component. If missing, it doesnt scroll.
        duration: 600,
        offset: 0,
        easing: "easeInOutCubic"
      });
    }

    if (
      this.application !== null &&
      this.application?.primaryApplicant &&
      this.showPreviousNames
    )
      this.application.primaryApplicant.previousName = new Individual();
  }
}
</script>