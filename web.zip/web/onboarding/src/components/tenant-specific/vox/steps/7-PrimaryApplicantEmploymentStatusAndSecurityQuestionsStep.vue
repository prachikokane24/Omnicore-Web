<template>
  <v-form v-model="valid" autocomplete="off">
    <grouping label="Your Account Usage">
      <v-container> 
        <v-row>
          <v-select
            data-id="application-primary-accountusage"
            :items="accountUsages"
            :item-text="item => item.text"
            :item-value="item => item.id"
            :rules="[isRequiredRule('Please select what will you use this account for')]"
            v-model="application.primaryApplicant.employmentDetails.accountUsage"
            label="What will you use this account for?"
            dense
            outlined
            class="v-wrap"
          />
        </v-row>
        <v-row>
          <v-select
            data-id="application-primary-accountfundings"
            :items="accountFundings"
            :item-text="item => item.text"
            :item-value="item => item.id"
            :rules="[isRequiredRule('Please select how will this account be funded')]"
            v-model="application.primaryApplicant.employmentDetails.accountFunding"
            label="How will this account be funded?"
            dense
            outlined
            class="v-wrap"
          />
        </v-row>
        <v-row>
          <p>
            What is the estimated monthly amount you plan to deposit into this account?
          </p>
        </v-row>
        <v-row>
          <v-select 
            data-id="application-primary-estimatedMonthlydeposit"
            :items="estimatedMonthlyDeposits"
            :item-text="item => item.text"
            :item-value="item => item.id"
            :rules="[isRequiredRule('Please select estimated monthly deposit')]"
            v-model="application.primaryApplicant.employmentDetails.estimatedMonthlyDeposit"
            label="Estimated monthly deposit"
            dense
            outlined
            class="v-wrap"
          />
        </v-row>
      </v-container>
    </grouping>
    <div>
      <grouping label="Your Security Questions">
        <v-container>
          <v-row>
            <v-select
              :data-id="`application-primary-securityquestion-0`"
              :items="securityQuestion0" 
              :item-text="item => item.text"
              :item-value="item => item.id"
              v-model="application.primaryApplicant.securityQuestions[0].question"              
              :label="`Choose your first security question`"
              :rules="[questionShouldNotAlreadyUsed]"
              dense
              outlined
              @focus="filterOptions(0)"
              @change="updateUsedQuestions()"
              class="v-wrap"
            />
          </v-row>
          <v-row>
            <v-text-field
              :data-id="`application-primary-securityquestion-0-answer`"
              :label="`Answer to your first security question`"
              v-model="application.primaryApplicant.securityQuestions[0].answer"
              :rules="securityQuestionAnswerRule"
              :maxLength="maxSecurityQuestionAnswerLen"
              dense
              outlined
              autocomplete="off"
              type="text"
            />
          </v-row> 
          <v-row>
            <v-select
              :data-id="`application-primary-securityquestion-1`"
              :items="securityQuestion1" 
              :item-text="item => item.text"
              :item-value="item => item.id"
              v-model="application.primaryApplicant.securityQuestions[1].question"              
              :label="`Choose your second security question`"
              :rules="[questionShouldNotAlreadyUsed]"
              dense
              outlined
              @focus="filterOptions(1)"  
              @change="updateUsedQuestions()" 
              class="v-wrap"
            />
          </v-row>
          <v-row>
            <v-text-field
              :data-id="`application-primary-securityquestion-1-answer`"
              :label="`Answer to your second security question`"
              v-model="application.primaryApplicant.securityQuestions[1].answer"
              :rules="securityQuestionAnswerRule"
              :maxLength="maxSecurityQuestionAnswerLen"
              dense
              outlined
              autocomplete="off"
              type="text"
            />
          </v-row>          
          <v-row>
            <v-select
              :data-id="`application-primary-securityquestion-2`"
              :items="securityQuestion2" 
              :item-text="item => item.text"
              :item-value="item => item.id"
              v-model="application.primaryApplicant.securityQuestions[2].question"              
              :label="`Choose your third security question`"
              :rules="[questionShouldNotAlreadyUsed]"
              dense
              outlined
              @focus="filterOptions(2)" 
              @change="updateUsedQuestions()"             
              class="v-wrap"
            />
          </v-row>
          <v-row>
            <v-text-field
              :data-id="`application-primary-securityquestion-2-answer`"
              :label="`Answer to your third security question`"
              v-model="application.primaryApplicant.securityQuestions[2].answer"
              :rules="securityQuestionAnswerRule"
              :maxLength="maxSecurityQuestionAnswerLen"
              dense
              outlined
              autocomplete="off"
              type="text"
            />
          </v-row>          
        </v-container>
      </grouping>
      <grouping label="Telephone Security Code">
        <v-container>
          <v-row>
            <v-text-field
              data-id="application-primary-telephone-banking-pin"
              label="Select your 4-digit Telephone Security Code"
              :rules="[isRequiredRule('Please ensure you provide a 4-digit Telephone Security Code.'), mustBePositiveNumberRule('your 4-digit Telephone Security Code'), validPin]"
              v-model="application.primaryApplicant.pin"
              :type="showPin ? 'text' : 'password'"
              :append-icon="showPin ? 'mdi-eye' : 'mdi-eye-off'"
              @click:append="showPin = !showPin"
              autocomplete="username"
              maxLength="4"          
              dense
              outlined
            />
          </v-row>
          <v-row>
            <v-text-field
              data-id="application-primary-telephone-banking-pin-confirm"
              label="Confirm your 4-digit Telephone Security Code"          
               v-model="application.primaryApplicant.pinConfirm"             
              :type="showConfirmPin ? 'text' : 'password'"
              :append-icon="showConfirmPin ? 'mdi-eye' : 'mdi-eye-off'"
              @click:append="showConfirmPin = !showConfirmPin"
              :rules="[
                isRequiredRule('Please ensure you confirm your 4-digit Telephone Security Code.'),
                mustBePositiveNumberRule('your 4-digit Telephone Security Code'),
                mustMatch,
                validPin
              ]"
              maxLength="4"
              autocomplete="new-password"
              dense
              outlined
            />
          </v-row>
        </v-container>
      </grouping>
    </div>
  </v-form>
</template>

<script lang="ts">
//  module imports
import Component from "vue-class-component";
import { Model, Watch } from "vue-property-decorator";
import Grouping from "../../../Grouping.vue";
import BaseStep from "../../../BaseStep.vue";
import {
  ApplicantAccountFunding,
  ApplicantAccountUsage,
  OnboardingApplication,
  SecurityQuestion,
  SecurityQuestions,
} from "@/types/onboarding.types";
import DefaultValidationRules from "../../../CommonValidationRules";

@Component({
  //  component dependencies
  components: {
    Grouping
  }
})
export default class PrimaryApplicantEmploymentStatusAndSecurityQuestionsStep extends BaseStep {
  @Model() application?: OnboardingApplication;

  readonly showPin = false;
  readonly showConfirmPin = false;
  readonly nbSecurityQuestions = 3;
  readonly maxSecurityQuestionAnswerLen = 20;
  partnerId = "";

  mustNotMatchOtherAnswer = v => {
    const answers = this.application?.primaryApplicant?.securityQuestions
                        .map(sq => sq.answer?.replace(/[^a-zA-Z0-9]/g, '').toLowerCase())
                        .filter(a => a !== undefined && a !== null && a !== '');

    if (answers!.length >= 2) {
      const duplicates = answers!.some((v, i) => i !== answers!.indexOf(v));
      return !duplicates || 'Please ensure your security answers are kept varied and different.';
    }
    return;
  };
 
  isRequiredRule = DefaultValidationRules.isRequiredCustom;
  mustBePositiveNumberRule = DefaultValidationRules.mustBePositiveNumber;
  validPin = DefaultValidationRules.validPin;
 
  securityQuestionAnswerRule = [
    DefaultValidationRules.isRequiredCustom("Please ensure you provide an answer to this security question."),
    DefaultValidationRules.textLenWithin(2, this.maxSecurityQuestionAnswerLen),
    this.mustNotMatchOtherAnswer
  ];

  questionShouldNotAlreadyUsed = v => {
    const dups = this.application?.primaryApplicant?.securityQuestions.reduce(
      (a, sq) => (v === sq.question ? a + 1 : a),
      0
    );
    return dups == 1 || "You cannot use this question more than once.";
  };

  mustMatch = v => {
    if (
      this.application?.primaryApplicant?.pin ==
      this.application?.primaryApplicant?.pinConfirm
    )
      return;
    return "Please ensure your 4-digit Telephone Security Codes match.";
  };

  constructor() {
    super();
  
    if (
      this.application !== undefined &&
      this.application.primaryApplicant !== undefined &&
      this.application.primaryApplicant.securityQuestions === undefined)
     {
      this.application.primaryApplicant.pin = "";
      this.application.primaryApplicant.pinConfirm = "";
      this.application.primaryApplicant.securityQuestions = new Array<
        SecurityQuestion
      >(2);
      for (let i = 0; i < this.nbSecurityQuestions; i++) {
        this.application.primaryApplicant.securityQuestions[
          i
        ] = new SecurityQuestion();
      }
    }
  }

  mounted() {
    this.partnerId = this.$route.params.CUREF;
  }

  filterOptions(index) {
    switch(index)
    {
      case 0:
        this.securityQuestion0 = this.filterSecurityQuestion(this.securityQuestions,0);
        break;
      case 1:
        this.securityQuestion1 = this.filterSecurityQuestion(this.securityQuestions,1);
        break;
      case 2:
        this.securityQuestion2 = this.filterSecurityQuestion(this.securityQuestions,2);
        break;
    }     
  }

  filterSecurityQuestion(securityQuestions, questionIndex)
  {
    const currentSelection = this.application?.primaryApplicant?.securityQuestions[questionIndex].question;
    const filtered = securityQuestions.filter(item => {
      return !this.usedSecurityQuestions.includes(item.id) || item.id === currentSelection;
    });
  
    return filtered;
  }  

  updateUsedQuestions()
  {
    this.usedSecurityQuestions = new Array<SecurityQuestions>();
    this.application?.primaryApplicant?.securityQuestions.forEach( item => {
      if(item.question)
      {
        this.usedSecurityQuestions.push(item.question)
      }
    });    
  }

  estimatedMonthlyDeposits = [
    {id: 1000, text: "£0-1000"},
    {id: 2500, text: "£1001-2500"},
    {id: 5000, text: "£2501-5000"},
    {id: 7500, text: "£5001-7500"}
  ]
  
  accountFundings = [
    { id: ApplicantAccountFunding.SalaryWages, text: "Salary/Wages" },
    { id: ApplicantAccountFunding.Pension, text: "Pension" },
    { id: ApplicantAccountFunding.Benefits, text: "Benefits" },
    { id: ApplicantAccountFunding.StudentFunding, text: "Student funding" },
    { id: ApplicantAccountFunding.BusinessIncome, text: "Business income" },
    { id: ApplicantAccountFunding.Savings, text: "Savings" },
    { id: ApplicantAccountFunding.RentalIncome, text: "Rental income" },
    { id: ApplicantAccountFunding.Maintenance, text: "Maintenance" },
    { id: ApplicantAccountFunding.Other, text: "Other" }
  ];

  accountUsages = [
    { id: ApplicantAccountUsage.PayBills, text: "Paying bills" },
    { id: ApplicantAccountUsage.Saving, text: "Saving" },
    { id: ApplicantAccountUsage.MainAccount, text: "Main account" },
    { id: ApplicantAccountUsage.Benefits, text: "Benefits" },
    { id: ApplicantAccountUsage.HouseholdExpenditures, text: "Household expenditures" },
    { id: ApplicantAccountUsage.Other, text: "Other" },

  ];

  securityQuestions = [
    {
      id: SecurityQuestions.PrimarySchool,
      text: "What primary school did you attend?"
    },
    {
      id: SecurityQuestions.ChildhoodBestFriendName,
      text: "What was the name of your childhood best friend?"
    },
    {
      id: SecurityQuestions.WhenYoungerWhatDidYouWantToBe,
      text: "When you were younger, what did you want to be when you grew up?"
    },
    {
      id: SecurityQuestions.MotherMaidenName,
      text: "What is your mother's maiden name?"
    },
    {
      id: SecurityQuestions.FirstCarMake,
      text: "What was the make of your first car?"
    },
    {
      id: SecurityQuestions.FirstHolidayAbroadDestination,
      text: "What was the destination of your first holiday abroad?"
    },
    {
      id: SecurityQuestions.ManagerNameAtFirstJob,
      text: "What is the name of your manager at your first job?"
    }
  ];

  securityQuestion0 = this.securityQuestions;
  securityQuestion1 = this.securityQuestions;
  securityQuestion2 = this.securityQuestions;
  usedSecurityQuestions = new Array<SecurityQuestions>();
}
</script>
<style lang="scss" scoped>
.v-wrap {
  width: 0;
  white-space: nowrap;
  text-overflow: ellipsis;
}
</style>