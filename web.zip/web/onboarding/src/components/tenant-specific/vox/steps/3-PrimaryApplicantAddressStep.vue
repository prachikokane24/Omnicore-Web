<template>
  <v-form v-model="valid">
    <grouping label="Your Current Address">
      <v-container>
        <applicant-address
          v-model="application.primaryApplicant.currentAddress"
          dataIDPrefix="application-primary-currentaddress"
          @input="onPreviousAddress"
        />
        <v-row>
          <v-select
            dense
            outlined
            label="Year"
            class="year-select"
            min-width="100"
            :items="years"
            :rules="[isRequiredRule]"
            v-model="movedToAddressYear"
            @change="onYearChanged">
          </v-select>
          <v-select
            dense
            outlined
            label="Month"
            class="month-select"
            :items="months"
            :rules="[isRequiredRule, mustBeAfter('current')]"
            v-model="movedToAddressMonth"
            @change="onMonthChanged">
          </v-select>
        </v-row>
      </v-container>
    </grouping>
    <div ref="previousAddressGroup" />
    <grouping v-if="needsPreviousAddress" label="Previous Address">
      <v-container>
        <applicant-address
          v-model="application.primaryApplicant.previousAddress"
          dataIDPrefix="application-primary-previousaddress"
          @input="onPreviousAddress"
        />
        <v-row>
          <v-select
            dense
            outlined
            label="Year"
            class="year-select"
            :items="years"
            :rules="[isRequiredRule]"
            v-model="movedToPreviousAddressYear"
            @change="onYearChanged">
          </v-select>
          <v-select
            dense
            outlined
            label="Month"
            class="month-select"
            :items="months"
            :rules="[isRequiredRule, mustBeAfter('previous'), mustNotOverlap()]"
            @change="onPreviousMonthChanged">
          </v-select>
        </v-row>
      </v-container>
    </grouping>

    <v-container class="centerize">
      <v-row justify="center">
        <v-dialog v-model="dialog" persistent max-width="290">
          <v-card>
            <v-card-title class="text-h5 grey lighten-2">
              Duplicate address
            </v-card-title>
            <v-card-text>
              <p>This address matches the last address you entered.</p> 
              <p>Please supply the correct historic address to continue.</p>
            </v-card-text>
            <v-divider></v-divider>
            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn
                color="primary"
                text
                @click="dialog = false">
                Ok
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>
      </v-row>
    </v-container>

    <v-container v-if="error !== ''" class="errors">
      <v-alert type="error">{{ error }}</v-alert>
    </v-container>
    
  </v-form>
</template>

<script lang="ts">
//  module imports
import Component from "vue-class-component";
import { Model } from "vue-property-decorator";
import ApplicantAddress from "../../../ApplicantAddress.vue";
import Grouping from "../../../Grouping.vue";
import BaseStep from "../../../BaseStep.vue";
import DatePicker from "../../../DatePicker.vue";
import {
  CommonTypesV1Address,
  OnboardingApplication
} from "@/types/onboarding.types";
import DefaultValidationRules from "../../../CommonValidationRules";
import moment from "moment";

@Component({
  components: { ApplicantAddress, Grouping, DatePicker }
})
export default class PrimaryApplicantAddressDetailsStep extends BaseStep {
  @Model() application?: OnboardingApplication;

  dialog = false;
  error = '';
  monthsAndYears = [];
  months = [];
  movedToAddressMonth = 1;
  movedToAddressYear: number|null = null;
  movedToPreviousAddressYear: number|null = null;
  needsPreviousAddress = false;

  get years() {
    return Object.keys(this.monthsAndYears).reverse();
  }

  constructor() {
    super();
    if (
      this.application !== undefined &&
      this.application.primaryApplicant !== undefined
    ) {     
      this.application.primaryApplicant.currentAddress.country = "GBR";
    }
    
    this.monthsAndYears = this.getMonthsAndYears();

    BaseStep.eventBus.$on('gonext', this.onPreviousAddress);
  }  

  async onPreviousAddress(args: any) {
    if (args.name === 'PrimaryApplicantAddressDetails') {
      if (this.application!.primaryApplicant!.previousAddress) {
        
        this.valid = !(this.TrimSpecialCharacters(this.application!.primaryApplicant!.previousAddress!.building) === this.TrimSpecialCharacters(this.application!.primaryApplicant!.currentAddress.building)
            && this.TrimPostCode(this.application!.primaryApplicant!.previousAddress!.postalCode) === this.TrimPostCode(this.application!.primaryApplicant!.currentAddress.postalCode))
        
        if (!this.valid) {
          this.dialog = true;
        }
      }
    }
  }

  getMonthsAndYears(): any {
    const numYears = 120;
    const numMonths = numYears * 12;

    // Include current month...
    const start = moment().add(1, 'month');

    const months = Array.from({length: numMonths}, (_, i) => moment(start.subtract(1, 'months'))).reverse();

    return months.reduce((acc, m) => {
      const year = m.year();
      acc[year] = acc[year] || [];
      return {
        ...acc,
        [year]: [...acc[year], m.format('MMMM')]
      }
    }, {});
  }

  onYearChanged(val: string): void {
    this.months = this.monthsAndYears[val];
    const month = moment().month(this.movedToAddressMonth).format("MM");
    const daysInMonth = moment(`${this.movedToAddressYear}/${month}`, "YYYY/MM").daysInMonth();
    const date = moment.utc(`${daysInMonth}/${month}/${this.movedToAddressYear}`, "DD/MM/YYYY", true);
    if (date.isValid()) {
      this.checkIfPreviousAddressRequired(date.format("DD/MM/YYYY"));
    }
  }

  onMonthChanged(val: string): void {
    if (
      this.application !== undefined &&
      this.application.primaryApplicant !== undefined
    ) {
      const month = moment().month(val).format("MM");
      const daysInMonth = moment(`${this.movedToAddressYear}/${month}`, "YYYY/MM").daysInMonth();
      const date = moment.utc(`${daysInMonth}/${month}/${this.movedToAddressYear}`, "DD/MM/YYYY", true);
      if (date.isValid()) {
        this.application.primaryApplicant.currentAddress.movedToAddressOn = date.toISOString();
        this.checkIfPreviousAddressRequired(date.format("DD/MM/YYYY"));
      }
    }
  }

  onPreviousMonthChanged(val: number) {
    if (
      this.application !== undefined &&
      this.application.primaryApplicant !== undefined
    ) {
      const month = moment().month(val).format("MM");
      const daysInMonth = moment(`${this.movedToPreviousAddressYear}/${month}`, "YYYY/MM").daysInMonth();
      const date = moment.utc(`${daysInMonth}/${month}/${this.movedToPreviousAddressYear}`, "DD/MM/YYYY", true);
      if (date.isValid()) {
        this.application.primaryApplicant!.previousAddress!.movedToAddressOn = date.toISOString();
      }
    }
  }

  mustBeAfter(scope) {
    return val => {
      const movedDate = scope === 'current'
        ? this.application?.primaryApplicant?.currentAddress?.movedToAddressOn
        : this.application?.primaryApplicant?.previousAddress?.movedToAddressOn;

      return !moment(movedDate).isBefore(moment(this.application?.primaryApplicant?.dateOfBirth))
        || "Please ensure the date is not before your date of birth";
    }
  }
  
  mustNotOverlap() {
    return val => {
      const result = moment(this.application?.primaryApplicant?.previousAddress?.movedToAddressOn)
        .isSameOrBefore(moment(this.application?.primaryApplicant?.currentAddress?.movedToAddressOn));
      return result || "Please ensure current & previous dates do not overlap";
    }
  }

  TrimSpecialCharacters(input?){
    return input?.toLowerCase().replace(/^[^a-zA-Z0-9/s]+|[^a-zA-Z0-9/s]+$/gi, '');
  }

  TrimPostCode(input?){    
    return this.TrimSpecialCharacters(input).replace(/\s/g, '');
  }

  isRequiredRule = DefaultValidationRules.isRequired;

  checkIfPreviousAddressRequired(value) {
    const date = moment.utc(value, "DD/MM/YYYY", true);
    this.needsPreviousAddress = moment().diff(date, "years") < 3;
    if (this.needsPreviousAddress) {
      this.$vuetify.goTo(this.$refs.previousAddressGroup as HTMLElement, {
        container: "#componentContainer", // This references the container defined in the onboardingbase component. If missing, it doesnt scroll.
        duration: 600,
        offset: 0,
        easing: "easeInOutCubic"
      });

      if (this.application!.primaryApplicant!.previousAddress === undefined) {
        this.application!.primaryApplicant!.previousAddress = new CommonTypesV1Address();
        this.application!.primaryApplicant!.previousAddress.country = "GBR";
      }
    } else {
      this.application!.primaryApplicant!.previousAddress = undefined;
    }
  }
}
</script>

<style scoped>
.v-card__text { margin-top: 25px; }
.month-select { 
  margin-left: 20px;
  max-width: 160px; 
}
div.year-select { 
  max-width: 100px;
}

</style>
