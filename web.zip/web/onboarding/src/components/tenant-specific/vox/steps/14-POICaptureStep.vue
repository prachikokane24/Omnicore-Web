<template>
  <v-form ref="form">
    <v-container id="tips">
      <v-alert type="info">
        Checklist: <br/>
        <p>
          &#10004; When taking a selfie your face is within the frame and in focus <br/> 
          &#10004; Document photos are clear and text is readable <br/> 
          &#10004; Documents are valid and not expired <br />
          &#10004; Entire document is captured within the frame <br />
        </p>
      </v-alert>
     </v-container>

    <v-container v-if="hasError">
      <v-alert type="error">{{ errorMessage }}</v-alert>
    </v-container>

    <v-container v-show="isBusy" class="centerize">
      <v-row justify="center">
        <v-dialog v-model="isBusy" persistent max-width="290">
          <v-card>
            <v-card-text class="centerize">
              <v-progress-circular indeterminate color="primary" />
              <p>
                {{ busyMessage }}
              </p>
            </v-card-text>
          </v-card>
        </v-dialog>
      </v-row>
    </v-container>

    <v-container v-show="isValidating" class="centerize">
      <v-row justify="center">
        <v-dialog v-model="isValidating" persistent max-width="290">
          <v-card>
            <v-card-text class="centerize">
              <v-progress-circular indeterminate color="primary" />
              <p>Verifying Image.</p>
            </v-card-text>
          </v-card>
        </v-dialog>
      </v-row>
    </v-container>

    <v-container v-if="documentValidationStatus === null">
      <v-row class="form-field">
        <label for="document-type" v-if="$vuetify.breakpoint.smAndUp">
          Select the type of identity document you want to upload
        </label>
        <v-select
          id="document-type"
          label="Document Type"
          name="document-type"
          :items="documentTypes"
          :item-text="(item) => item.translatedType"
          :item-value="(item) => item.type"
          v-model="selectedDocumentType"
          v-on:change="updateData"
          :rules="[isRequiredRule]"
          dense
          outlined
          class="v-wrap colourise"
        />
      </v-row>

      <v-row class="form-field" v-if="showCountries">
        <label for="document-type-countryofbirth" v-if="$vuetify.breakpoint.smAndUp">
          Select the country that this document was issued in
        </label>
        <country-list
          id="document-type-countryofbirth"
          name="document-type-countryofbirth"
          v-model="selectedCountryISO"
          topOfListCountry="GBR"
          label="Country of Issue"
          :rules="[countryRequiredRule]"
          :displayGbOnly="displayGbCountryOnly()"
        />
      </v-row>
    </v-container>

      <document-capture
        v-if="!documentValidationStatus"
        v-model="firstDocumentCapture"
        ref="firstDocumentCapture"
        @clearError="clearError"
        @showError="showError"
        @submit="submit"
        @update="updateFirstDocumentSelected"
        :application-id="applicationId"
        :doc-upload="docUpload"
        :document-type="poiDocumentType"
        :is-captured="isCaptured"
        :is-performing-upload="isPerformingUpload"
        :is-two-sided="isTwoSided()"
        :selected-document-type="selectedDocumentType"
        :isCountrySelected="isCountrySelected()"
        sideMessage="FRONT SIDE"
        overlayClass="document-overlay"
      />

      <document-capture
        v-if="!documentValidationStatus && isTwoSided()"
        v-model="secondDocumentCapture"
        ref="secondDocumentCapture"
        @clearError="clearError"
        @showError="showError"
        @submit="submit"
        @update="updateSecondDocumentSelected"
        :application-id="applicationId"
        :doc-upload="docUpload"
        :document-type="poiDocumentType"
        :is-captured="isCaptured"
        :is-performing-upload="isPerformingUpload"
        :is-two-sided="isTwoSided()"
        :selected-document-type="selectedDocumentType"
        :isCountrySelected="isCountrySelected()"
        sideMessage="REAR SIDE"
        overlayClass="document-overlay"
      />
    

    <quality-check
      v-if="documentValidationStatus"
      v-model="firstDocumentCapture"
      @retake="clearQualityCheck"
      @review="upload"
      :is-performing-upload="isPerformingUpload"
      :status="documentValidationStatus"
      :passport="passportValidationResponse"
      :driving-licence="drivingLicenceValidationResponse"
      :identity-card="identityCardValidationResponse"
      :address="addressValidationResponse"
      :proTips="firstDocumentCapture.proTips"
      :validMessageText="this.validMessageText"
      :isDoubleSided="isTwoSidedCapture"   
      overlayClass="document-overlay"   
    />
  </v-form>
</template>

<script lang="ts">
import Component from "vue-class-component";
import {
  DocumentCategoryUpload,
  DocumentType,
  DocumentUpload,
} from "@/components/OnboardingModelsBase";
import HttpOnboardingApplicationService from "@/services/impl/HttpOnboardingApplicationService";
import MockOnboardingApplicationService from "@/services/impl/MockOnboardingApplicationService";
import OnboardingApplicationService, {
  DocumentValidationStatus,
  DrivingLicenceValidationResponse,
  IdentityCardValidationResponse,
  PassportValidationResponse,
  ProofOfAddressValidationResponse,
} from "@/services/OnboardingApplicationService";
import { KycChallengeDocumentCategory } from "@/types/onboarding.types";
import DefaultValidationRules from "../../../CommonValidationRules";
import CaptureStep from "../../../CaptureStep.vue";
import Grouping from "../../../Grouping.vue";
import DocumentCapture from "../../../DocumentCapture.vue";
import QualityCheck from "@/components/QualityCheck.vue";
import CountryList from "@/components/CountryList.vue";

@Component({
  components: {
    Grouping,
    CountryList,
    "document-capture": DocumentCapture,
    "quality-check": QualityCheck,
  },
})
export default class POICaptureStep extends CaptureStep {
  docUpload?: DocumentCategoryUpload = new DocumentCategoryUpload();
  documentTypes: DocumentType[] = [];
  selectedDocumentType = "";
  selectedCountryISO = "";
  poiDocumentType = "identity";
  requiredDocument?: KycChallengeDocumentCategory =
    new KycChallengeDocumentCategory();
  isRequiredRule = DefaultValidationRules.isRequired;
  applicationService: OnboardingApplicationService;
  passportValidationResponse?: PassportValidationResponse | null = null;
  drivingLicenceValidationResponse?: DrivingLicenceValidationResponse | null =
    null;
  identityCardValidationResponse?: IdentityCardValidationResponse | null = null;
  addressValidationResponse?: ProofOfAddressValidationResponse | null = null;
  busyMessage = "I'm busy...";
  isBusy = false;
  documentValidationStatus?: DocumentValidationStatus | null = null;
  showCountries = false;
  isValidating = false;
  isTwoSidedCapture = false;
  countryRequiredRule = DefaultValidationRules.isRequired;
  overlayClass = '';
  validMessageText = "Thank you for uploading your document. Please proceed to the next step.";

  firstDocumentCapture = {
    isDependantDocumentSelected: false,
    isFlipSide: false,
    file: null,
    imageSrc: "",
    dependantDocumentImageSrc: "",
    proTips: ['Ensure the image is not blurred.', 
        'Ensure the image fills the window fully.', 
        'Ensure the image is correctly oriented.', 
        'Ensure the document matches the image selected from the \'drop down\' list.',
        'Driving licences, UK Residence Permits & National Identity cards require both Front and Back to be captured.']
  };

  secondDocumentCapture = {
    isDependantDocumentSelected: false,
    isFlipSide: true,
    file: null,
    imageSrc: ""
  };

  constructor() {
    super();
    this.isUploadSuccessful = false;
    this.applicationService = new HttpOnboardingApplicationService();
  }

  mounted() {
    this.docUpload = this.getDocUpload(this.poiDocumentType);

    if (
      this.docUpload &&
      this.application?.primaryApplicant?.kycChallenge?.requiredDocuments
    ) {
      this.requiredDocument =
        this.application.primaryApplicant.kycChallenge.requiredDocuments.find(
          (doc) => doc.type === this.poiDocumentType
        );
      this.documentTypes = this.docUpload!.types;
    } else {
      this.$router.push(
        `/document-upload-portal?applicationId=${this.applicationId}`
      );
    }
  }

  displayGbCountryOnly(): boolean {
     return this.selectedDocumentType === "ukResidencePermit";
  }

  updateFirstDocumentSelected(val: boolean) {
    this.secondDocumentCapture.isDependantDocumentSelected = val;
  }

  updateSecondDocumentSelected(val: any) {
    this.firstDocumentCapture.isDependantDocumentSelected = val;
  }
  
  isTwoSided(): boolean {   
   return (
      this.selectedDocumentType === "drivingLicence" ||
      this.selectedDocumentType === "europeanIdentityCard" ||
      this.selectedDocumentType === "identityCard" ||
      this.selectedDocumentType === "ukArmedForcesIdCard" ||
      this.selectedDocumentType === "northenIrelandElectoraIdCard" ||
      this.selectedDocumentType === "ukResidencePermit" 
    );
  }

  hasCapturedBoth() {
    return (
      this.docUpload!.uploads!.filter((upload) => upload.file !== null)
        .length === 2
    );
  }

  reset() {
    console.log("reset");
  }

  updateData() {
    this.showCountries = true;
    this.isTwoSidedCapture = this.isTwoSided();
  }

  async submit() {
    const docType = this.docUpload!.types.find(
      (dt) => dt.type === this.selectedDocumentType
    );
  
    await this.toBase64(this.firstDocumentCapture.file)
      .then(async (result) => {
        const parts = result as Array<string>;
        this.firstDocumentCapture.imageSrc = parts.join(",");
        const first = parts[1];
        this.docUpload!.uploads![0].id = docType!.id;
        this.docUpload!.uploads![0].file = this.firstDocumentCapture.file;
        if (this.isTwoSided()) {
          await this.toBase64(this.secondDocumentCapture.file)
            .then(async (secondResult) => {
              const parts = secondResult as Array<string>;
              const second = parts[1];
              this.secondDocumentCapture.imageSrc = parts.join(",");
              this.firstDocumentCapture.dependantDocumentImageSrc =
                parts.join(",");

              if (this.docUpload!.uploads!.length === 1) {
                this.docUpload!.uploads!.push(new DocumentUpload());
              }

              this.docUpload!.uploads![1].id = docType!.id;
              this.docUpload!.uploads![1].file =
              this.secondDocumentCapture.file;
              await this.performQualityCheck(first, second);
              return;
            })
            .catch((error) => this.showError(error));
        } else await this.performQualityCheck(first);
      })
      .catch((error) => this.showError(error));
  }

  async performQualityCheck(firstDocument: any, secondDocument?: any) {
    try {
      this.isValidating = true;

      if (this.selectedDocumentType === "passport") {
        this.passportValidationResponse = await this.applicationService.validatePassport(firstDocument,this.selectedCountryISO);
        this.documentValidationStatus = this.passportValidationResponse.status;

      } else if (this.selectedDocumentType === "drivingLicence") {
        this.drivingLicenceValidationResponse = await this.applicationService.validateDrivingLicence(firstDocument, secondDocument as string,
            this.selectedCountryISO
          );
        this.documentValidationStatus = this.drivingLicenceValidationResponse.status;
      } else if (
        this.selectedDocumentType === "eeaIdentityCard" ||
        this.selectedDocumentType === "identityCard" ||
        this.selectedDocumentType === "europeanIdentityCard"
      ) {
        this.identityCardValidationResponse =
          await this.applicationService.validateIdentityCard(
            firstDocument,
            secondDocument as string,
            this.selectedCountryISO
          );
        this.documentValidationStatus = this.identityCardValidationResponse.status;
      } else {
        this.addressValidationResponse = await this.applicationService.validateProofOfAddress(firstDocument, this.selectedCountryISO, this.application!.id as string);
        this.documentValidationStatus = this.addressValidationResponse.status;
      }

      if (this.documentValidationStatus == DocumentValidationStatus.Valid) {
        await this.upload();
      }

      this.isValidating = false;
    } catch {
      this.showError(
        "There has been an issue with the image review. Please recapture the image to try again."
      );
      this.isValidating = false;
    }
  }

   isCountrySelected(): boolean {
       return  this.selectedCountryISO !== "";  
  }

  clearQualityCheck() {
    this.documentValidationStatus = null;
    this.passportValidationResponse = null;
    this.drivingLicenceValidationResponse = null;
    this.identityCardValidationResponse = null;
  }

  async upload() {
    await this.uploadDocCategory(this.docUpload);

    if (!this.hasError) {
      this.isCaptured = true;
      this.valid = true;
      this.documentValidationStatus = DocumentValidationStatus.Valid;

      if (this.allDocumentsUploaded()) {
        this.busyMessage = "Submitting documents."
        this.isBusy = true;
        // Briefly display QC valid before submitting. 
        setTimeout(async () => {
          await this.handleSubmit();
          this.isBusy = false;

          if (!this.hasError) {
            this.$router.push(`/document-upload-portal/completed`);
          } else {
            this.clearQualityCheck();
          }
        }, 1000);
      }
    }
  }
}
</script>

<style scoped>
form.v-form {
  background: #e2e2e2;
  border-radius: 25px;
}

form > .container > .row {
  margin-bottom: 0;
  margin-top: 25px;
  margin-left: auto;
  margin-right: auto;
  width: 60%;
}

form > .container > .row > label {
  font-weight: bold;
  margin: 10px 25px 0 0;
}
form > .container > .row > div.v-input {
  width: 60%;
}

.centerize {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
}

.centerize .row {
  padding-top: 10px;
  padding-bottom: 10px;
  display: i nherit !important;
}

.v-progress-circular {
  margin: 1rem;
}

.v-text-field--outlined > .v-input__control > .v-input__slot {
    background: #fff;
}

@media only screen and (max-width: 600px) {
  #tips { display: none; }
  #errors { font-size: 14px; }
  div.v-select { font-size: 11px; }

  div.v-select > div.v-input__control { background: #fff !important; }

  .upload-container .row > p {
      padding: 10px;
  }

  form > .container > .row {
      margin: auto;
      width: 90%;
  }
}
</style>