<template>
  <v-form ref="form">
    <v-container v-if="showWarning && !isUploadSuccessful">
      <v-alert type="warning">To continue you must grant the page access to use the camera, otherwise you will be unable to proceed.</v-alert>
    </v-container>
    
    <v-container id="tips">
      <v-alert type="info">
        Checklist: <br/>
        <p>
          &#10004; When taking a selfie your face is within the frame and in focus <br/> 
          &#10004; Document photos are clear and text is readable <br/> 
          &#10004; Documents are valid and not expired <br />
          &#10004; Entire document is captured within the frame <br />
        </p>
      </v-alert>
    </v-container>

    <v-container v-if="hasError" id="errors">
      <v-alert type="error">{{ errorMessage }}</v-alert>
    </v-container>
  
    <v-container v-show="isBusy" class="centerize">
      <v-row justify="center">
        <v-dialog v-model="isBusy" persistent max-width="290">
          <v-card>
            <v-card-text class="centerize">
              <v-progress-circular indeterminate color="primary" />
              <p>
                {{ busyMessage }}
              </p>
            </v-card-text>
          </v-card>
        </v-dialog>
      </v-row>
    </v-container>

    <v-container v-show="isValidating" class="centerize">
      <v-row justify="center">
        <v-dialog v-model="isValidating" persistent max-width="290">
          <v-card>
            <v-card-text class="centerize">
              <v-progress-circular indeterminate color="primary" />
              <p>
                Verifying Image.
              </p>
            </v-card-text>
          </v-card>
        </v-dialog>
      </v-row>
    </v-container>

    <image-capture
      v-if="!selfieValidationStatus"
      @clearError="clearError"
      @error="showError"
      @update="updateImageSelected"
      :application-id="applicationId"
      :is-captured="isCaptured"
      :is-performing-upload="isPerformingUpload"
      :max-size="size"
      :isSelfie="true"
      :showSubmit="false"
      overlayClass="selfie-overlay" />
      
    <quality-check
      v-if="selfieValidationStatus"
      v-model="documentCapture"
      @retake="clearQualityCheck"
      @review="goNext"
      :is-performing-upload="isPerformingUpload"
      :status="selfieValidationStatus"
      :selfie="qualityCheck"
      :proTips="documentCapture.proTips"
      overlayClass="selfie-overlay"
      :validMessageText="validMessageText"
      isDoubleSided=false />
  </v-form>
</template>

<script lang="ts">

import BaseStep from "@/components/BaseStep.vue";
import { DocumentCategoryUpload } from "@/components/OnboardingModelsBase";
import { OnboardingApplicationStepSetup } from "@/components/OnboardingScenarioModels";
import QualityCheck from "@/components/QualityCheck.vue";
import HttpOnboardingApplicationService from "@/services/impl/HttpOnboardingApplicationService";
import MockOnboardingApplicationService from "@/services/impl/MockOnboardingApplicationService";
import OnboardingApplicationService, { DocumentValidationStatus, SelfieValidationResponse } from "@/services/OnboardingApplicationService";
import { KycReviewStatus } from "@/types/onboarding.types";
import Component from "vue-class-component";
import CaptureStep from "../../../CaptureStep.vue";
import Grouping from "../../../Grouping.vue";
import ImageCapture from "../../../ImageCapture.vue"

@Component({
  components: {
    Grouping,
    'image-capture': ImageCapture,
    'quality-check': QualityCheck
  }
})
export default class SelfieCaptureStep extends CaptureStep {
  video: any;
  canvas: any;
  imageSrc = "";
  capturing = true;
  showWarning = false;
  docUpload?: DocumentCategoryUpload = new DocumentCategoryUpload();
  selfieDocumentType = "photo";
  selectedDocumentType = "selfie";
  maxSize = 10;
  size = 1024 * 1024 * this.maxSize;
  applicationService: OnboardingApplicationService;
  qualityCheck?: SelfieValidationResponse | null = null;
  selfieValidationStatus?: DocumentValidationStatus | null = null;
  busyMessage = "I'm busy...";
  isBusy = false;
  isValidating = false;
  selfie = true;
  overlayClass = '';
  validMessageText = "Thank you for providing your selfie, if you select Next you are unable to retake your selfie.";

  documentCapture = {
    imageSrc: "",
    proTips: [
      ' Please ensure your face is clearly visible',
      'Please ensure your face is centered within the frame', 
      'Please ensure your photo is in focus', 
      'Try adjusting your distance from the camera'
    ]
  }

  constructor() {
    super();
    this.applicationService = new HttpOnboardingApplicationService();
    BaseStep.eventBus.$on('gonext', (step: OnboardingApplicationStepSetup): void => {
      if (step.name === 'SelfieCapture') {
        this.upload();
      }
    });
  }

  mounted() {
    this.video = this.$refs.video;
    this.canvas = this.$refs.canvas;
    this.docUpload = this.getDocUpload(this.selfieDocumentType);
    
    if (this.docUpload) {
      console.log(this.docUpload);
    } else {
      this.$router.push(`/document-upload-portal?applicationId=${this.applicationId}`);
    }
  }

  async updateImageSelected(val: boolean, image: any) {
    this.docUpload!.uploads![0].file = image;

    const docType = this.docUpload!.types.find(dt => dt.type === this.selectedDocumentType);

    await this.toBase64(this.docUpload!.uploads![0].file)
              .then(async result => {
                const parts = result as Array<string>;
                this.documentCapture.imageSrc = parts.join(',');
                const first = parts[1];
                this.docUpload!.uploads![0].id = docType!.id;
                this.performQualityCheck(first);
              }).catch(error => this.showError(error));
  }

  async performQualityCheck(image: string) {
    try {
      this.isCaptured = true;
      this.isValidating = true;
      this.qualityCheck = await this.applicationService.validateSelfie(image);
      this.selfieValidationStatus = this.qualityCheck.status;
      this.isValidating = false;

      if (this.selfieValidationStatus === DocumentValidationStatus.Valid) {
        this.valid = true;

        if (this.application?.primaryApplicant?.kycChallenge?.reviewStatus === KycReviewStatus.Additional) {
          const timeout = setTimeout(() => {
            this.upload();
            clearTimeout(timeout);
          }, 200);
        }
      }
    } catch {
      this.showError('There has been an issue with the image review. Please recapture the image to try again.');
      this.isValidating = false;
    }
  }

  clearQualityCheck() {
    this.qualityCheck = null;
    this.selfieValidationStatus = null;
    this.valid = false;
    this.isCaptured = false;
  }

  async upload() {
    await this.uploadDocCategory(this.docUpload); 

    if (!this.hasError) {
      if (this.allDocumentsUploaded()) {
        this.complete();
      }
    }
  }

  async complete() {
    this.busyMessage = "Submitting photo.";
    this.isBusy = true;
    // Briefly display QC valid before submitting. 
    setTimeout(async () => {
      await this.handleSubmit();
      this.isBusy = false;

      if (!this.hasError) {
        this.$router.push(`/document-upload-portal/completed`);
      } else {
        this.clearQualityCheck();
      }
    }, 1000);
  }
}
</script>

<style lang="scss" scoped>
  .v-progress-circular {
    margin: 1rem;
  }

@media only screen and (min-width: 768px) {

  form.v-form {
    background: #E2E2E2;
    border-radius: 25px;
  }

  .centerize {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    text-align: center;
  }

  .centerize .row {
    padding-top: 10px;
    padding-bottom: 10px;
    display: inherit !important;
  }

  .action-btn {
    border-radius: 30px !important;
    background: #5B2298 !important;
    color: #fff;
  }

  .video-container {
    background-color: #ddd;
  }

  .video-container button {
    background: #5B2298;
    border: 1px solid #5B2298;
    box-sizing: border-box;
    border-radius: 8px;
  }

  .spacer { margin: 0 25px; }
}

@media only screen and (max-width: 600px) {
  #tips { display: none; }

  #errors { font-size: 14px; }

  .v-dialog p { float: right; margin-top: 20px; width: 75%; }
}
</style>