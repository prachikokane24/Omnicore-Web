<template>
  <v-form v-model="valid">
    <grouping label="Your Contact Details">
      <v-container>
        <v-alert
          v-show="stepError !== ''"
          dense
          type="error"
          id="application-otp-invalidotpalert">
          {{ stepError }} 
        </v-alert>
        <v-row>
          <v-text-field
            data-id="application-primary-emailaddress"
            label="Email Address"
            ref="emailAddress"
            v-model="application.primaryApplicant.contactDetails.emailAddress"
            :value="application.primaryApplicant.contactDetails.emailAddress"
            :rules="emailValidationRules"
            :maxLength="maxEmailLen"
            :loading="isLoading"
            dense
            outlined
          >
            <template #append>
              <v-icon medium color="success" v-if="validRegisteredEmail">
                mdi-check-circle
              </v-icon>
            </template>
          </v-text-field>
        </v-row>
        <v-row>
          <v-text-field @paste.prevent
            data-id="application-primary-emailaddresscheck"
            label="Confirm Email"
            ref="confirmEmailAddress"
            v-model="
              application.primaryApplicant.contactDetails.confirmEmailAddress
            "
            :value="
              application.primaryApplicant.contactDetails.confirmEmailAddress
            "
            :rules="confirmEmailValidationRules"
            :maxLength="maxEmailLen"
            :loading="isLoading"
            dense
            outlined
          >
            <template #append>
              <v-icon medium color="success" v-if="validRegisteredEmail">
                mdi-check-circle
              </v-icon>
            </template>
          </v-text-field>
        </v-row>
        <v-row>
          <v-text-field
            data-id="application-primary-mobilephone"
            id="application-primary-mobilephone"
            label="Mobile Telephone"
            v-model="mobilePhoneNumber"
            :value="mobilePhoneNumber"
            :rules="mobilePhoneNumberValidationRules"
            :maxLength="maxMobilePhoneLen"
           
            prefix="+44"
            v-mask="'###########'"
            dense
            outlined           
          />
        </v-row>
      </v-container>
    </grouping>
  </v-form>
</template>
 
<script lang="ts">
//  module imports
import Component from "vue-class-component";
import { Inject, Model, Prop, Watch } from "vue-property-decorator";
import DefaultValidationRules from "../../../CommonValidationRules";
import Grouping from "../../../Grouping.vue";
import BaseStep from "../../../BaseStep.vue";
import { OnboardingApplication } from "@/types/onboarding.types";
import HttpOnboardingApplicationService from "@/services/impl/HttpOnboardingApplicationService";
import OnboardingApplicationService from "@/services/OnboardingApplicationService";
import { CommonUtil }  from "@/utils/common"
import MockOnboardingApplicationService from "@/services/impl/MockOnboardingApplicationService";
import { OnboardingApplicationStepSetup } from "@/components/OnboardingScenarioModels";

@Component({
  //  component dependencies
  components: {
    Grouping
  }
})
export default class PrimaryApplicantContactDetailsStep extends BaseStep {
  @Model() application?: OnboardingApplication;
  
  readonly maxEmailLen = 50;
  readonly maxMobilePhoneLen = 11;
  
  validRegisteredEmail = false;
  isLoading = false;
  mobilePhoneNumberBuffer?: string = undefined;
    
  applicationService: OnboardingApplicationService;

  check(v, field): boolean {
    if (!field) return true;
    return v === field;
  }

  constructor() {
    super();

    // if (process.env.NODE_ENV !== "production") {
      //  this.applicationService = new MockOnboardingApplicationService();
       //} else {
      this.applicationService = new HttpOnboardingApplicationService();
    //}    
   
    if (
      this.application !== undefined &&
      this.application.primaryApplicant !== undefined
    ) {
      this.mobilePhoneNumberBuffer = this.application.primaryApplicant.contactDetails.mobilePhoneNumber;
    }
  }
  
  telephoneInputFilter =  (value) => {return /^\d*$/.test(value); }

  limitInputToDigits(e){
    //function based upon https://jsfiddle.net/KarmaProd/tgn9d1uL/4/
    if (this.telephoneInputFilter(e.target.value)) {
      e.target.oldValue = e.target.value;
    }else if (Object.prototype.hasOwnProperty.call(e.target, "oldValue")){
      e.target.value = e.target.oldValue
    }else{
      e.target.value = "";
    }
  }
  
  setInputFilter(textbox, filter) {
    ["input", "keydown", "keyup", "mousedown", "mouseup", "select", "contextmenu", "drop", "focusout"].forEach(function(event) {
      textbox.addEventListener(event, filter);
    })
  }

  removeInputFilter(textbox, filter){
     ["input", "keydown", "keyup", "mousedown", "mouseup", "select", "contextmenu", "drop", "focusout"].forEach(function(event) {
        textbox.removeEventListener(event, filter);
    });
  }

  async mounted() {
    this.setInputFilter(
      document.getElementById("application-primary-mobilephone"), 
      this.limitInputToDigits 
    );
    this.setInputFilter(
      document.getElementById("application-primary-homephone"), 
      this.limitInputToDigits 
    );
  }
  
  async unmounted(){
    this.removeInputFilter(document.getElementById("application-primary-mobilephone"),this.limitInputToDigits);
    this.removeInputFilter(document.getElementById("application-primary-homephone"),this.limitInputToDigits);
  }

  @Watch("application.primaryApplicant.contactDetails.emailAddress")
  async onEmailAddressChanged() {
    await this.$nextTick();
    if (
      this.application?.primaryApplicant?.contactDetails?.confirmEmailAddress
    ) {
      (this.$refs.confirmEmailAddress as Vue & {
        validate: () => boolean;
      }).validate();
    }
  }

  @Watch("application.primaryApplicant.contactDetails.confirmEmailAddress")
  async onConfirmEmailAddress() {
    await this.$nextTick();
    if (this.application?.primaryApplicant?.contactDetails.emailAddress) {
      (this.$refs.emailAddress as Vue & {
        validate: () => boolean;
      }).validate()
        ? this.checkRegisteredEmail()
        : null;
    }
  }

  async checkRegisteredEmail() {
    console.log("Check");
    this.isLoading = true;
    this.validRegisteredEmail = false;
    
    try {
     
     const response  = await this.applicationService.emailCheck(this.application?.primaryApplicant?.contactDetails.emailAddress!);     
     this.validRegisteredEmail = !response.exists;      
     
    } catch (e) {
      console.log(e);
    } finally {
      this.isLoading = false;
    }
  }

  confirmEmailAddressesAreSame(v, field): boolean {
    if (!field) return true;
    return v === field;
  }

  confirmEmailIsUnique(): boolean {
    return this.validRegisteredEmail;
  } 
   
  get mobilePhoneNumber(): string | undefined {
    return this.mobilePhoneNumberBuffer;
  }
  set mobilePhoneNumber(val: string | undefined) {
    const newVal = CommonUtil.trimLeadingZero(val!);
    this.mobilePhoneNumberBuffer = newVal;
    this.application!.primaryApplicant!.contactDetails.mobilePhoneNumber = `+44${newVal}`;
  }

  emailValidationRules = [
    DefaultValidationRules.checkSpaces,
    DefaultValidationRules.isEmailAddress,
    DefaultValidationRules.textLenWithin(5, this.maxEmailLen),
    v =>
      this.confirmEmailAddressesAreSame(
        v?.toLowerCase(),
        this.application?.primaryApplicant?.contactDetails.confirmEmailAddress?.toLowerCase()
      ) || "Please ensure your emails match."
  ];
  
   get confirmEmailValidationRules() {
    return [
      DefaultValidationRules.checkSpaces,
      DefaultValidationRules.isEmailAddress,
      DefaultValidationRules.textLenWithin(5, this.maxEmailLen),
      v =>
        v?.toLowerCase() === this.application?.primaryApplicant?.contactDetails.emailAddress?.toLowerCase() ||
        "Please ensure your emails match.",
      this.validRegisteredEmail === true ||
        this.isLoading === true ||
        "We are unable to register an account at this time. Please contact customer services."
    ];
  }

  mobilePhoneNumberValidationRules = [
    DefaultValidationRules.isRequiredCustom('Please ensure you have provided a mobile phone number.'), 
    DefaultValidationRules.isPhoneNumber
  ];
}
</script>
