<template>
  <v-form v-model="valid">
    <grouping label="Citizenship">
      <v-container>
        <tax-details-list
          dataIDPrefix="application-primary-citizenshipTaxDetails"
          v-model="application.primaryApplicant.citizenshipTaxDetails"
          mode="citizen"
          :rules="citizenValidationRules"
        />
      </v-container>
    </grouping>

    <grouping label="Residency">
      <v-container>
        <tax-details-list
          dataIDPrefix="application-primary-residencyTaxDetails"
          v-model="application.primaryApplicant.residencyTaxDetails"
          mode="resident"
          :rules="residencyTaxDetailsValidationRules"
        />
      </v-container>
    </grouping>

    <grouping label="Citizenship & Residency Declaration">
      <v-container>
        <v-row>
          <p>
            Declaration: Please read and confirm agreement of the below statements <br>
            * I acknowledge that the information contained in this form and information regarding 
            Reportable Account(s) held by me may be provided to UK tax authorities and exchanged 
            with tax authorities of another country or countries in which I may be tax resident, 
            in accordance with inter-governmental agreements to exchange financial account information. <br>
            * I certify that I am the account holder (or am authorised to sign for the account holder) 
            of all the account(s) to which this form relates. <br>
            * I declare that all statements made on this self-certification form are complete and correct, 
            to the best of my knowledge and belief. <br>
            * I agree to advise the Society within 30 days of any change in circumstances which affects my 
            tax residency status (or that of the individual named in this application) or causes the 
            information to become incorrect. I will also provide the Society with a suitably updated 
            self-certification within 30 days of such a change.
          </p>
        </v-row>
        <v-row>
          <v-checkbox
            data-id="application-primary-confirmInfoAccurate"
            v-model="application.confirmCitizenAndResidencyDeclaration"
            label="I confirm"
            :rules="[mustBeTrueRule]"
            dense
          />
        </v-row>
      </v-container>
    </grouping>
  </v-form>
</template>

<script lang="ts">
//  module imports
import Component from "vue-class-component";
import { Model } from "vue-property-decorator";

import TaxDetailsList from "../../../TaxDetailsList.vue";
import Grouping from "../../../Grouping.vue";
import BaseStep from "../../../BaseStep.vue";
import { OnboardingApplication } from "@/types/onboarding.types";
import DefaultValidationRules from "../../../CommonValidationRules";

@Component({
  //  component dependencies
  components: {
    TaxDetailsList,
    Grouping,
  },
})
export default class PrimaryApplicantCitizenshipAndResidencyStep extends BaseStep {
  @Model() application?: OnboardingApplication;

  citizenValidationRules = [DefaultValidationRules.isRequired];
  residencyTaxDetailsValidationRules = [DefaultValidationRules.isRequired];
  mustBeTrueRule = DefaultValidationRules.mustBeTrue("Please confirm you have read and accepted the declaration");
}
</script>