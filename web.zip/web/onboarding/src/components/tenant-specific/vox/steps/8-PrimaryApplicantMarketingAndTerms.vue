<template>
  <v-form v-model="valid">
    <v-container style="padding: 0px">
      <grouping label="Your Marketing Preferences">
        <v-container>
          <v-row>
            Would you like to be informed on new features, services, rewards and cashback partners? 
            Choose your marketing communication preferences from the options below:
          </v-row>
          <v-row>
            <v-checkbox
              v-bind:false-value=true
              v-bind:true-value=false
              v-model="application.primaryApplicant.marketingPreferences.disableSMS"
              label="SMS"
              dense
              data-id="application-primary-marketing-disablesms"
            />
            <v-spacer />
            <v-checkbox
              v-bind:false-value=true
              v-bind:true-value=false
              v-model="application.primaryApplicant.marketingPreferences.disableEmail"
              label="Email"
              dense
              data-id="application-primary-marketing-disableemail"
            />
            <v-spacer />
            <v-checkbox
            v-bind:false-value=true
              v-bind:true-value=false
              v-model="application.primaryApplicant.marketingPreferences.disableTelephone"
              label="Telephone"
              dense
              data-id="application-primary-marketing-disablephone"
            />
            <v-spacer />
            <v-checkbox
              v-bind:false-value=true
              v-bind:true-value=false
              v-model="application.primaryApplicant.marketingPreferences.disablePost"
              label="Post"
              dense
              data-id="application-primary-marketing-disablepost"
            />
          </v-row>
          <v-row>
            Whilst we will adhere to your chosen marketing communication preferences we will continue to provide you with 
            regulatory information and service communications.
          </v-row>
        </v-container>
      </grouping>
      <grouping label="Fraud Prevention Agencies">
        <v-container>
          <v-row>
            <p>
              The personal information we have collected from you will be shared 
              with fraud prevention agencies who will use it to prevent fraud 
              and money laundering and to verify your identity. If fraud is 
              detected, you could be refused certain services, finance or 
              employment. Further details of how your information will be used 
              by us and these fraud prevention agencies, and your data 
              protection rights, can be found by 
              <a href="https://www.cifas.org.uk/fpn" target="_blank">
                Fair Processing Notices for Cifas' Databases | Cifas
              </a>
            </p>
          </v-row>
        </v-container>
      </grouping>
      <grouping label="Legal Acceptance">
        <v-container>
          <v-row> I have read and agreed to the following: </v-row>
          <v-row>
            <v-checkbox
              v-model="application.primaryApplicant.agreeMECurrentAccTAndCs"
              dense
              data-id="application-primary-agreemecurrentacctandcs"
              :rules="[mustBeTrueRule]"
            >
              <template v-slot:label>
                <div>
                  Account Terms and Conditions
                  <template>
                    <a target="_blank" href="https://www.voxmoney.co.uk/terms-conditions/" @click.stop v-on="on">
                      (view)
                    </a>
                  </template>
                </div>
              </template>
            </v-checkbox>
          </v-row>
          <v-row>
            <v-checkbox
              v-model="application.primaryApplicant.agreePrivacyPolicy"
              dense
              data-id="application-primary-agreeprivacypolicy"
              :rules="[mustBeTrueRule]"
            >
              <template v-slot:label>
                <div>
                  Privacy Policy
                  <template>
                    <a
                      target="_blank"
                      href="https://www.voxmoney.co.uk/privacy-policy/"
                      @click.stop
                      v-on="on"
                    >
                      (view)
                    </a>
                  </template>
                </div>
              </template>
            </v-checkbox>
          </v-row>
          <v-row>
            <v-checkbox
              v-model="application.primaryApplicant.agreeFeeInformationDocument"
              dense
              data-id="application-primary-agreekeyinfodoc"
              :rules="[mustBeTrueRule]"
            >
              <template v-slot:label>
                <div>
                  Fee Information Document
                  <template color="primary">
                    <a target="_blank" href="https://www.voxmoney.co.uk/fee_information_document_vox_money.pdf" @click.stop v-on="on">
                      (view)
                    </a>
                  </template>
                </div>
              </template>
            </v-checkbox>
          </v-row>
        </v-container>
      </grouping>
    </v-container>
    <v-container v-show="!isApplicationSubmitted && isBusy" class="centerize">
      <v-row justify="center">
        <v-dialog
          v-model="isBusy"
          persistent
          max-width="290">
          <v-card>
          <v-card-text class="text-center">
            <v-progress-circular
              indeterminate
              color="primary" />
            <p>
              Please wait as we process your details.
            </p>
            <p>
              Do not close the browser window.
            </p>
          </v-card-text>
          </v-card>
        </v-dialog>
      </v-row>
    </v-container>
  </v-form>
</template>

<script lang="ts">
//  module imports
import Component from "vue-class-component";
import { Inject, Model } from "vue-property-decorator";
import Grouping from "../../../Grouping.vue";
import BaseStep from "../../../BaseStep.vue";
import { ApplicantKycStatus, ApplicationStatuses, OnboardingApplication } from "@/types/onboarding.types";
import DefaultValidationRules from "../../../CommonValidationRules";
import MbsOnboardingContainer from "@/components/OnboardingContainer";
import EventBus from "../../../eventBus.js";
import { OneTimePasswordResponse, OneTimePasswordStatus } from "@/services/OTPService";
import { omnicore } from "@/omnicore-lib";

@Component({
  //  component dependencies
  components: {
    Grouping
  }
})
export default class PrimaryApplicantMarketingAndTerms extends BaseStep {
  @Model() application?: OnboardingApplication;
  @Inject() container?: MbsOnboardingContainer;

  expandDetails = false;
  detailsInfo = "";
  isApplicationSubmitted = false;
  isApplicationAutoApproved = false;
  hasApplicationBeenRejected = false;
  hasErrors = false;
  isBusy = false;

  mustBeTrueRule = DefaultValidationRules.mustBeTrue(
    "Please confirm you have read and accepted that document"
  );

  mounted() {
    EventBus.$on('gonext', this.submitApplication);
  }

  async submitApplication(args) {
    if (args.name === 'PrimaryApplicantMarketingAndTerms') {
      console.log('Submitting application')
      this.isBusy = true;
      /* @ts-ignore */
      this.application!.partnerId = this.$route.query.CUREF!;

      console.log("Application:", this.application);

        try {
        
        delete this.application?.primaryApplicant?.contactDetails?.confirmEmailAddress;
        delete this.application?.primaryApplicant?.pinConfirm;

        const res = await this.container?.ApplicationService.saveApplication(
          this.application!
        );

        this.isBusy = false;

        switch (res!.application!.applicationStatus) {
          case ApplicationStatuses.KycChallengeOnGoing:
            this.application = res?.application;
           this.applicationIsInProgress();
            break;
          case ApplicationStatuses.Success:
           this.application = res?.application; 
            this.applicationIsComplete(true, false);
           break;
          case ApplicationStatuses.KycChallengeComplete:
            this.application = res?.application; 
            this.applicationIsComplete(true, false);
            break;
          case ApplicationStatuses.Failed:
            this.application = res?.application;
            this.applicationIsComplete(false, true);
            break;
          default:
            throw new Error(
                `Unknown application status '${
                  res!.application!.applicationStatus
                }'`
              );
        }
        this.emit("application::submitted", this.application!);
      } catch (error) {
        console.log("Failed to submit application:" + error);
        this.hasErrors = true;
        this.detailsInfo = error;
        this.isApplicationSubmitted = true;
        this.isApplicationAutoApproved = false;
        this.isBusy = false;
        this.detailsInfo = `Application Id: ${this.application?.id ||
          "(none)"}\nError: ${error}`;
      } 
    }
  }

  applicationIsComplete(approved: boolean, rejected: boolean) {
    console.log("Application is complete");
    this.hasErrors = false;
    this.isApplicationSubmitted = true;
    this.isApplicationAutoApproved = approved;
    this.hasApplicationBeenRejected = rejected;
    this.detailsInfo = `Application Id: ${this.application?.id}`;
    this.flowCompleted();
    window.location.replace(`#/application-complete`);
  }

  applicationIsInProgress() {
    if (this.application!.primaryApplicant!.kycChallenge!.status === ApplicantKycStatus.InReview) {
      console.log("Application is in review, need extra documents");
      // next phase is for document upload which is done as part of the next step
      const otp = new OneTimePasswordResponse();
      otp.status = OneTimePasswordStatus.Valid;
      otp.sessionId = this.application!.id;
      otp.requestId = this.application!.id;
      omnicore().localCache.put(`OnboardingApplication-Otp-${this.application!.id}`, otp, 3600);
      window.location.replace(`#/document-upload-portal?applicationId=${this.application!.id}&sessionId=${this.application!.id}`);
    } else {
      this.gotoLogin();
    }
  }
  
  gotoLogin() {
    window.location.replace("https://secure.voxmoney.co.uk/");
  }
}
</script>
<style scoped>
  .v-progress-circular {
    margin: 1rem;
  }
</style>