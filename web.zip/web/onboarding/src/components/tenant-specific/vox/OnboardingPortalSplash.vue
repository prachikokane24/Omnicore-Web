<template>
  <div class="login-wrapper">
    <div class="login">
      <div id="col-1">
        <div class="col1-content">
          <v-container>
            <p class="block white--text elevate mb-6 text-body-1">
              The Vox Money account and card are issued by Omnio EMI Limited (OEL), which is a principal member of Visa and authorised by the Financial Conduct Authority under the Electronic Money Regulations 2011 (Firm reference 900123) with its registered office at Clerks Court, 18-20 Farringdon Lane, London, England, EC1R 3AU.
            </p>
          </v-container>
        </div>
      </div>
      <div id="col-2">
        <div class="col2-content">
          <div class="logo" />
          <div class="content">
            <div class="intro">
              <h2>Apply for your Vox Account</h2>
            </div>
            <p>
              We need to gather information about you as part of this application and in most instances we will need you to provide some
              additional documents to  verify your identity. To give you a head start here is a list of documents we can accept:
            </p>
            <h3>Valid Identity Documents</h3>
            <p>
              <ul>
                <li>Passport</li>
                <li>European Identity card</li>
                <li>Northern Ireland Electoral Identity Card</li>
                <li>UK photocard Driving License (full or provisional)</li>

              </ul>
            </p>
            <h3>Proof of Address</h3>
            <p>
              <ul>
                <li>Bank, Credit Card, Building Society, Credit Union Statement (dated within the last 3 months)</li>
                <li>Annual Mortgage Statement (dated within the last 12 months)</li>
                <li>HMRC Letter or Tax Notification (dated within the last 6 months)</li>
                <li>UK Council Tax Bill or Statement (dated within the last 12 months)</li>
              </ul>
            </p>
            <p>
              <a href="https://www.voxmoney.co.uk/help/proof-of-identity/" target="_blank">Find out more about the documents we accept and how to upload them.</a>
            </p>
            <div class="steps">
              <v-btn
                block
                large
                icon
                color="white"
                class="btn primary"
                :disabled="loading"
                :loading="loading"
                @click="proceed">
                Start Application <v-icon color="white">mdi-arrow-right</v-icon>              
              </v-btn>
            </div>            
            <v-container v-if="error !== ''" class="errors">
              <v-alert type="error">{{ error }}</v-alert>
            </v-container>  
            <p class="block text-caption hidden-md-and-up footer-text">
              The Vox Money account and card are issued by Omnio EMI Limited (OEL), which is a principal member of Visa and authorised by the Financial Conduct Authority under the Electronic Money Regulations 2011 (Firm reference 900123) with its registered office at Clerks Court, 18-20 Farringdon Lane, London, England, EC1R 3AU.
            </p>      
          </div>
        </div>
      </div>
    </div>  
  </div>
</template>

<script lang="ts">
import Component from "vue-class-component";
import HttpOnboardingApplicationService from "@/services/impl/HttpOnboardingApplicationService";
import OnboardingApplicationService from "@/services/OnboardingApplicationService"; 
import Vue from "vue";

  @Component({
    components: {}
  })
  export default class OnboardingPortalSplash extends Vue {
    applicationId = "";
    error = "";
    loading = true;

    readonly ApplicationService: OnboardingApplicationService;
    sessionId?: string | null = null;

    constructor() {
      super();     
      this.ApplicationService = new HttpOnboardingApplicationService();   
    }

    mounted() {
      if (this.$route.query.applicationId) {
        this.applicationId = this.$route.query.applicationId.toString();
      }
      if (this.$route.query.sessionId) {
        this.sessionId = this.$route.query.sessionId.toString();
      }
      const helpUrl = 'https://www.voxmoney.co.uk/help/how-to-sign-up/';
      const partnerId = this.$route.query.CUREF
        ? this.$route.query.CUREF
        : "";
      console.log(partnerId);

      if(!partnerId) {
        window.location.replace(helpUrl);
      }  

      this.ApplicationService.validatePartnerId(partnerId.toString()).then(res => { 
          if(!res.isValid)
          {
            window.location.replace(helpUrl);
          }

          this.loading = false;
      }).catch(e =>{
        console.log(e);
        window.location.replace(helpUrl);
      });

    }

    async proceed() {
      try {
        this.$router.push({ name: 'apply', query: { CUREF: this.$route.query.CUREF } });
      } catch(error) {
        this.error = "We are having trouble finding your details - please try again.";
      }
    }
  }
</script>

<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";

  .v-stepper__wrapper {
    height: 100% !important;
  }
  
  form {
    height: 100%;
  }

  .icon-check {
    width:15px;
    height:20px;
    margin-right:10px;  
  }

  .login-wrapper {
    display: flex;
    align-items: stretch;
    height: 100%;
    width: 100%;
  }

  .login {
    display: flex;
    width: 100%;
  }

  #col-2 {
    display: flex;
    flex-direction: column;
    align-items: center;
    flex: 1;
    position: relative;
    background: --v-login-background;
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      flex-direction: row;
      align-items: center;
      padding-left: 3%;
    }
  }

  .col2-content {
    max-width: 480px;
    padding:0px 10px 0px 10px;
  }

  .v-alert {
    width: 100%;
  }
  
  h2 {
    text-align: center;
    color: var(--v-secondary-base);
  }

  .theme--light.v-btn.v-btn--icon {
    color: #fff !important;
  }
@media #{map-get($display-breakpoints, 'md-and-up')} {

  #col-1 {
    background: linear-gradient(0deg, rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url(../../../tenant/vox/assets/images/current-account-for-everyone.webp) no-repeat;
    background-position: right 165px center;
    background-repeat: no-repeat;
    background-size: cover;
    background-attachment: fixed;
    color: #fff;
    display: flex;
    flex-direction: column;
    flex: 1;
    justify-content: center;
    align-items: center;
    padding-right: 3%;
    height: 100%;
    position: relative;
  }
  
  .col1-content,
  .col2-content {
    z-index: 2;
    width: 100%;    
  }

  .col1-content {
    max-width: 560px;
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      display: flex;
      height: 100%;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      flex: 1;
    }
  }

  .col2-content{
    padding: 0px;
  }

  .col1-content > div.container {
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      display: flex;
      height: 100%;
      flex-direction: column;
      align-items: center;
      justify-content: flex-end;
      flex: 1;
      flex-grow: 1;
    }
    text-align: center;
  }

  .col1-content > div.container > div {
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      display: flex;
      height: 100%;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      flex: 1;
      flex-grow: 1;
    }
    text-align: center;
  }

  #col-2 > div > div.logo {
    flex-direction: row;
    align-items: flex-center;
    padding: 10px;
    position: static;
    width: 200px;
    height: 80px;
    left: 32px;
    top: 171.5px;
    background: url(../../../tenant/vox/assets/images/Logo.png);
    flex: none;
    order: 0;
    flex-grow: 0;
  }

  #col-2 > div > div.content {
    display: flex;
    flex-direction: column;
    height: 720px;
  }

  #col-2 > div > div.content > div.intro {
    margin: 30px 0 0 0;  
    text-align: center; 
  }

  .title {
    font-weight: 600;
  }

  #col-2 > div > div.content > div.steps {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    padding: 0px;  
    position: static;
    width: 467px;
    left: 0px;
    top: 104px;
    flex: none;
    order: 1;
    flex-grow: 0;
  }

  #col-2 > div > div.content > div.steps > div.step-item {  
    flex-direction: row;     
  }

  #col-2 > div > div.content > div.steps > div {
    display: flex;
    flex-direction: column;
    align-items: flex-start;   
  }

  #col-2 > div > div.content  {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    padding: 0px;  
    position: static;
    width: 467px;
    left: 0px;
    top: 104px;
    flex: none;
    order: 1;
    flex-grow: 0;
  }

  #col-2 > div > div.content > div.errors {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    padding: 8px;
    position: static;
    width: 467px;
    left: 0px;
    top: 75px;
    flex: none;
    order: 1;
    flex-grow: 0;
    margin-top: 5px;
    margin-left: 0;
  }

  #col-2 > div > div.content >  button {
    margin: 16px 0px;
  }
}

@media only screen and (max-width: 960px) {
  #col-1 {
    display: none;
  }

  #col-2 > div > div.logo {
    width: 200px;
    height: 80px;
    background: url(../../../tenant/vox/assets/images/Logo.png) no-repeat;
    margin: 30px auto;
  }

  #col-2 > div > div.content > div.intro {
    margin-bottom: 20px;
  }

  #col-2 > div > div.content > div.steps > button {
    margin: 16px 0px;
  }

  .title {
    font-size: 17px;
    margin-bottom: 15px;  
  }

  .footer-text { margin-top: 10px; color: #390F46; }
}
</style>