<template>
  <onboarding-base
    :steps="steps"
    :scenario="scenario"
    v-model="application"
    @progressupdated="progressUpdated"
  >
    <template slot="header">
      <v-container style="padding: 0px;">
        <v-row class="centerize">
          <img src="@tenantAssets/images/vox.svg" class="logo" />
          <h1 v-if="currentStep.idx !== 0">{{ currentStep.header }}</h1>
        </v-row>        
        <v-row class="bullet-main" v-if="currentStep.showProgressBar">
          <div
            v-for="[idx, section] in visibleSections.entries()"
            class="bullet-container"
            :key="idx"
          >
            <div class="bullet-step">
              <v-icon class="bullet-icon">{{
                sectionStateToIcon(section.status)
              }}</v-icon>
              <div v-if="$vuetify.breakpoint.smAndUp" class="bullet-label">
                {{ section.name }}
              </div>
            </div>
            <v-divider
              class="bullet-divider"
              v-if="idx !== visibleSections.length - 1"
            />
          </div>
        </v-row>
      </v-container>
    </template>
  </onboarding-base>
</template>

<script lang="ts">

import Component from "vue-class-component";
import Vue from "vue";
import OnboardingBase from "../../OnboardingBase.vue";
import OnboardingScenarioFactory, {
  OnboardingApplicationStepSetup,
  OnboardingApplicationStepStatus,
  Scenario,
  SectionStatus
} from "../../OnboardingScenarioModels";
import { OnboardingApplication } from "@/types/onboarding.types";
import { Provide } from "vue-property-decorator";
import MbsOnboardingContainer from "./../../OnboardingContainer";
import {
  AdultAccountApplicationScenario,
  ApplicantExtraDocumentUploadScenario,
  VOXOnboardingApplicationStepSetup
} from "./OnboardingModels";

@Component({
  components: { OnboardingBase }
})
export default class MBSOnboarding extends Vue {
  @Provide() container: MbsOnboardingContainer = new MbsOnboardingContainer();
  partnerId;
  application?: OnboardingApplication = undefined;
  useMock = false;
  debug = false;
  stepIdx = 1;
  scenario?: Scenario;

  get steps() {
    return this.scenario?.flow.flatMap(
      section => section.steps as VOXOnboardingApplicationStepSetup[]
    );
  }

  get visibleSections() {
    return this.scenario?.flow.filter(s => s.isVisible);
  }

  constructor() {
    super();

    this.partnerId = this.$route.query.CUREF
      ? this.$route.query.CUREF
      : "";
    const scenarios = [
      AdultAccountApplicationScenario,
      ApplicantExtraDocumentUploadScenario
    ];

    this.application = new OnboardingApplication();

    const scenarioFactory = new OnboardingScenarioFactory();
    scenarios.forEach(s => scenarioFactory.register(s));

    this.scenario = scenarioFactory.create(this.$route.query.s as string);
    this.currentStep = this.scenario.flow[0].steps![0];
    console.log(`Loading scenario ${this.scenario.name}`);
  }

  sectionStateToIcon(status: SectionStatus) {
    switch (status) {
      default:
      case SectionStatus.Todo:
        return "mdi-checkbox-blank-circle-outline";
      case SectionStatus.InProgress:
        return "mdi-radiobox-marked";
      case SectionStatus.Done:
        return "mdi-check-circle";
    }
  }

  updateSections() {
    // theoretically, this should belong to a different class but
    // not a biggie
    this.scenario?.flow.forEach(section => {
      if (this.debug) {
        console.log(`** Section ${section.name} **`);
        section.steps?.forEach(step =>
          console.log(
            ` - ${step.name}: valid=${step.isValid} complete=${step.status}`
          )
        );
      }

      const nbCompleted =
        section.steps?.filter(
          s => s.status === OnboardingApplicationStepStatus.Done
        ).length || 0;
      const nbInprogress =
        section.steps?.filter(
          s => s.status === OnboardingApplicationStepStatus.InProgress
        ).length || 0;

      if (nbCompleted === section.steps?.length) {
        section.status = SectionStatus.Done;
      } else if (nbInprogress >= 1) {
        section.status = SectionStatus.InProgress;
      } else {
        section.status = SectionStatus.Todo;
      }

      if (this.debug) {
        console.log(
          `Section ${section.name}: ${section.status} (${nbCompleted}/${section.steps?.length})`
        );
      }
    });
  }

  progressUpdated(progressUpdate) {
    const newCurrStep = progressUpdate.currentStep;
    this.currentStep = newCurrStep;

    if (this.debug) {
      console.log(`Progress update received: newStep=${newCurrStep.idx}`);
    }

    this.updateSections();
  }

  currentStep?: OnboardingApplicationStepSetup;
}
</script>

<style lang="scss" scoped>
h1 {
  font-size: 14px;
  color: var(--v-secondary-base);
}


h2 {
  font-size: 20px;
  color: var(--v-primary-base);
}

h3 {
  font-size: 18px;
  color: var(--v-primary-base);
}

p,
label,
input,
.v-select {
  color: grey;
  font-size: 14px !important;
}

.logo {
  margin: 5px;
  width:76px;  
}

.bullets {
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  flex-basis: 40px;
}

.centerize {
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
}

.bullet-main {
  padding: 5px;
  display: flex;
  margin-left: 10px;
  margin-right: 10px;
}

.bullet-container {
  display: contents;
}

.bullet-step {
  align-items: center;
  justify-content: flex-start;
  flex-direction: column;
  flex-basis: 40px;
  display: flex;
}

.bullet-icon {
  color: var(--v-primary-base) !important;
}

.bullet-label {
  align-items: center;
  justify-content: flex-start;
  flex-direction: column;
  font-size: 12px;
  width: 75px;
  text-align: center;
}

.bullet-divider {
  margin-left: 0px !important;
  margin-right: 0px !important;
  margin-top: 12px !important;
  align-self: initial !important;
}

.main-title {
  color: var(--v-primary-base);
  font-size: 24px;
}

/* removes grey hover effect */
.v-btn::before {
  background-color: transparent;
}

.v-btn:not(.v-btn--disabled) {
  background-color: white !important;
  border: solid 2px var(--v-primary-base) !important;
  color: var(--v-primary-base) !important;
  box-shadow: none;
}

.v-btn:hover {
  background-color: var(--v-primary-base) !important;
  border: solid 2px var(--v-primary-base) !important;
  color: white !important;
  box-shadow: none;
}

.v-date-picker-table .v-btn {
  background-color: transparent !important;
  border-color: transparent !important;
  color: black !important;
}

.v-date-picker-table__current.v-btn {
  border: solid 2px var(--v-primary-base) !important;
  border-color: var(--v-primary-base) !important;
  color: var(--v-primary-base) !important;
}

.v-chip {
  margin-left: 5px;
  margin-top: 5px;
  margin-bottom: 5px;
  background-color: #9a9c9c !important;
  color: white !important;
}

.v-alert.info {
  background-color: --v-info-base !important;
  color: white;
}

.v-alert.info .v-icon {
  color: white;
}

.v-alert.success {
  background-color: var(--v-success-base) !important;
  color: white;
}

.v-alert.success .v-icon {
  color: white;
}

.v-alert.error {
  background-color: var(--v-error-base) !important;
  color: white;
}

.v-alert.error .v-icon {
  color: white;
}

@media (min-width: 544px) {  
  h1  {
    font-size:24px;
  } 

  .logo{
    width:106px;
  }
}
</style>