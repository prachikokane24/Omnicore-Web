<template>
  <capture-base
    :steps="steps"
    :scenario="scenario"
    @progressupdated="progressUpdated">
    
    <template slot="header">
      <v-container style="padding: 0px;">
        <v-row class="centerize">
          <img src="@tenantAssets/images/vox.svg" class="logo" />
           <h1>{{ currentStep.header }}</h1>
        </v-row>        
        <v-row class="bullet-main" v-if="currentStep.showProgressBar">
          <div v-for="[idx, section] in visibleSections.entries()"
               class="bullet-container"
               :key="idx">
            <div class="bullet-step">
              <v-icon class="bullet-icon">{{
                sectionStateToIcon(section.status)
              }}</v-icon>
              <div class="bullet-label">
                {{ getSectionName($vuetify.breakpoint.smAndUp, section.name) }}
              </div>
            </div>
            <v-divider
              class="bullet-divider"
              v-if="idx !== visibleSections.length - 1"
            />
          </div>
        </v-row>
      </v-container>
    </template>
  </capture-base>
</template>

<script lang="ts">
  import Component from "vue-class-component";
  import Vue from "vue";
  import CaptureBase from "@/components/CaptureBase.vue";
  import OnboardingScenarioFactory, {
    OnboardingApplicationStepSetup,
    OnboardingApplicationStepStatus,
    Scenario,
    ScenarioFactoryEntry,
    Section,
    SectionStatus
  } from "../../OnboardingScenarioModels";
  import { Provide } from "vue-property-decorator";
  import MbsOnboardingContainer from "../../OnboardingContainer";
  import {
    InitialFlowCaptureScenario,
    VOXOnboardingApplicationStepSetup
  } from "./OnboardingModels";
  import { omnicore } from "@/omnicore-lib";
  import { DocumentCategoryType, KycChallengeDocumentCategory, KycReviewStatus, OnboardingApplication } from "@/types/onboarding.types";
  import SelfieCaptureStep from "./steps/13-SelfieCaptureStep.vue";
  import POICaptureStep from "./steps/14-POICaptureStep.vue";
  import POACaptureStep from "./steps/15-POACaptureStep.vue";

  @Component({
    components: { CaptureBase }
  })
  export default class Capture extends Vue {
    @Provide() container: MbsOnboardingContainer = new MbsOnboardingContainer();
    useMock = false;
    debug = false;
    stepIdx = 1;
    scenario?: Scenario;

    get steps() {
      return this.scenario!.flow.flatMap(
        section => section.steps as unknown as VOXOnboardingApplicationStepSetup[]
      );
    }
   
    get visibleSections() {
      const visiblesections = this.scenario?.flow.filter(s => s.isVisible);
      const step = visiblesections?.filter(s => s?.name == this.stepNameToSectionMapping(this.scenario!.flow[0] !.steps![0].name));
      step![0] !.status = SectionStatus.InProgress;
      return visiblesections;
    }

    currentStep?: OnboardingApplicationStepSetup;

    constructor() {
      super();
  
      const applicationId = this.$route.params.applicationId.toString();
      const application = omnicore().localCache.get<OnboardingApplication>(`OnboardingApplication-${applicationId}`);
      const scenarioFactory = new OnboardingScenarioFactory();

      if (application?.primaryApplicant?.kycChallenge?.reviewStatus === KycReviewStatus.Initial)
      {
        scenarioFactory.register(InitialFlowCaptureScenario);
        this.scenario = scenarioFactory.create('initial-capture');
      } else {
        const dynamicFlowCaptureScenario = this.createDynamicScenario(application);
        scenarioFactory.register(dynamicFlowCaptureScenario);
        this.scenario = scenarioFactory.create('dynamic-capture');
      }

      this.currentStep = this.scenario.flow[0].steps![0];
      this.currentStep!.status = OnboardingApplicationStepStatus.InProgress;
      
      console.log(`Loading scenario ${this.scenario.name}`);
    }

    stepNameToSectionMapping(name: string) {
    let section = "";
    switch (name) {
        case "AddressCapture": {
            section = "Address Document";
            break;
        }
        case "IdentityCapture": {
            section = "Identity Document";
            break;
        }
        case "SelfieCapture": {
            section = "Selfie";
            break;
        }
      }

      return section;
    }

    createDynamicScenario(application: OnboardingApplication): ScenarioFactoryEntry {
      const flow = new Array<Section>();
      let index = 0;

      // Reverse sort by name to ensure steps are done in the correct order
      const requiredDocuments = application?.primaryApplicant?.kycChallenge?.requiredDocuments?.sort((a,b) => a.type > b.type ? -1 : 1);

      const finalIndex = requiredDocuments?.reduce((previous, current)=> previous + (current?.numberRequired ?? 0), 0);

      requiredDocuments?.forEach((document: KycChallengeDocumentCategory) => {
        for (let idx = 0; idx < document!.numberRequired!; idx++) {
          switch (document.type) {
            case DocumentCategoryType.Photo: {
              const selfieSection = new Section("Selfie", []);
              this.createDynamicSections(flow, selfieSection, document.numberRequired, index, "SelfieCapture", SelfieCaptureStep, "Capturing your image", finalIndex ?? 0)
              break;
            }
            case DocumentCategoryType.Identity: {
              const poiSection = new Section("Identity Document", []);
              this.createDynamicSections(flow, poiSection, document.numberRequired, index, "IdentityCapture", POICaptureStep, "", finalIndex ?? 0)
              break;
            }
            case DocumentCategoryType.Address: {
              const poaSection = new Section("Address Document", []);
              this.createDynamicSections(flow, poaSection, document.numberRequired, index, "AddressCapture", POACaptureStep, "", finalIndex ?? 0)
              break;
            }
            default:
              break;  
          }

          index++;
        }
      });

      return new ScenarioFactoryEntry('dynamic-capture', () => new Scenario('Capture', flow), false);
    }

    createDynamicSections(flow: Section[], section: Section, numberRequired: number|undefined, index: number, name: string, step: any, content: string, finalIndex: number) {
      if (numberRequired && numberRequired > 0) {
        for (let idx = 0; idx < numberRequired; idx++) {
          section.steps?.push(new VOXOnboardingApplicationStepSetup(
            index + idx,
            name,
            step,
            content,
            true,
            index + idx === finalIndex,
            undefined
          ))
        }

        flow.push(section);
      }
    }

    sectionStateToIcon(status: SectionStatus) {
      switch (status) {
        default:
        case SectionStatus.Todo:
          return "mdi-checkbox-blank-circle-outline";
        case SectionStatus.InProgress:
          return "mdi-radiobox-marked";
        case SectionStatus.Done:
          return "mdi-check-circle";
      }
    }

    updateSections() {
      // theoretically, this should belong to a different class but
      // not a biggie
      this.scenario?.flow.forEach(section => {
        if (this.debug) {
          console.log(`** Section ${section.name} **`);
          section.steps?.forEach(step =>
            console.log(
              ` - ${step.name}: valid=${step.isValid} complete=${step.status}`
            )
          );
        }

        const nbCompleted =
          section.steps?.filter(
            s => s.status === OnboardingApplicationStepStatus.Done
          ).length || 0;
        const nbInprogress =
          section.steps?.filter(
            s => s.status === OnboardingApplicationStepStatus.InProgress
          ).length || 0;

        if (nbCompleted === section.steps?.length) {
          section.status = SectionStatus.Done;
        } else if (nbInprogress >= 1) {
          section.status = SectionStatus.InProgress;
        } else {
          section.status = SectionStatus.Todo;
        }

        if (this.debug) {
          console.log(
            `Section ${section.name}: ${section.status} (${nbCompleted}/${section.steps?.length})`
          );
        }
      });
    }

    progressUpdated(progressUpdate) {
      const newCurrStep = progressUpdate.currentStep;
      this.currentStep = newCurrStep;

      if (this.debug) {
        console.log(`Progress update received: newStep=${newCurrStep.idx}`);
      }

      this.updateSections();
    }

    getSectionName(smAndUp: boolean, name: string) {
      const nameMappings = {
        'Selfie': 'Selfie',
        'Identity Document': 'Identity',
        'Address Document': 'Address'
      };

      if (!smAndUp) {
        return nameMappings[name];
      } else {
        return name;
      }
    }
  }
</script>

<style lang="scss" scoped>

h1 {
  font-size: 14px;
  color: var(--v-secondary-base);
}

h2 {
  font-size: 20px;
  color: var(--v-primary-base);
}

h3 {
  font-size: 18px;
  color: var(--v-primary-base);
}

p,
label,
input,
.v-select {
  color: grey;
  font-size: 14px !important;
}

.logo {
  margin: 5px;
  width:76px;  
}

.bullets {
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  flex-basis: 40px;
}

.centerize {
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
}

.bullet-main {
  padding: 5px;
  display: flex;  
}

.bullet-container {
  display: contents;
}

.bullet-step {
  align-items: center;
  justify-content: center;
  flex-direction: column;
  flex-basis: 20px;
  display: flex;
}

.bullet-icon {
  color: var(--v-primary-base) !important;
}

.bullet-label {
  align-items: center;
  justify-content: flex-start;
  flex-direction: column;
  font-size: 12px;
  width: 75px;
  text-align: center;
}

.bullet-divider {
  margin-left: 0px !important;
  margin-right: 0px !important;
  margin-top: 12px !important;
  align-self: initial !important;
}

.main-title {
  color: var(--v-primary-base);
  font-size: 24px;
}

/* removes grey hover effect */
.v-btn::before {
  background-color: transparent;
}

.v-btn:not(.v-btn--disabled) {
  background-color: white !important;
  border: solid 2px var(--v-primary-base) !important;
  color: var(--v-primary-base) !important;
  box-shadow: none;
}

.v-btn:hover {
  background-color: var(--v-primary-base) !important;
  border: solid 2px var(--v-primary-base) !important;
  color: white !important;
  box-shadow: none;
}

.v-date-picker-table .v-btn {
  background-color: transparent !important;
  border-color: transparent !important;
  color: black !important;
}

.v-date-picker-table__current.v-btn {
  border: solid 2px var(--v-primary-base) !important;
  border-color: var(--v-primary-base) !important;
  color: var(--v-primary-base) !important;
}

.v-chip {
  margin-left: 5px;
  margin-top: 5px;
  margin-bottom: 5px;
  background-color: #9a9c9c !important;
  color: white !important;
}

.v-alert.info {
  background-color: --v-info-base !important;
  color: white;
}

.v-alert.info .v-icon {
  color: white;
}

.v-alert.success {
  background-color: var(--v-success-base) !important;
  color: white;
}

.v-alert.success .v-icon {
  color: white;
}

.v-alert.error {
  background-color: var(--v-error-base) !important;
  color: white;
}

.v-alert.error .v-icon {
  color: white;
}

@media (min-width: 544px) {  
  h1  {
    font-size:24px;
  } 

  .logo{
    width:106px;
  }
}

@media only screen and (min-width: 600px) {
  .bullet-main {
    margin-left: 10px;
    margin-right: 10px;
  }
}

@media only screen and (max-width: 600px) {
  h1 { display: none; }

  .bullet-step { flex-basis: 0; }
  .v-alert__content { font-size: 14px; }

  .bullet-main { flex-wrap: nowrap; }
}
</style>