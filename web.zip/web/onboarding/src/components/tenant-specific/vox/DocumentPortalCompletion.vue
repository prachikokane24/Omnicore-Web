<template>
  <div class="login-wrapper">
    <div class="login">
      <div id="col-1">
        <div class="col1-content">
          <v-container>
            <p class="block white--text elevate mb-6 text-body-1">
              The Vox Money account and card are issued by Omnio EMI Limited (OEL), which is a principal member of Visa and authorised by the Financial Conduct Authority under the Electronic Money Regulations 2011 (Firm reference 900123) with its registered office at Clerks Court, 18-20 Farringdon Lane, London, England, EC1R 3AU.
            </p>
          </v-container>
        </div>
      </div>
      <div id="col-2">
        <div class="col2-content">
          <div class="logo" />
          <div class="content">
            <div class="intro">
              <h2>Your application is complete</h2>
            </div>
            <p v-if="applicationId === null">
              Once your details have been verified we will notify you with an email. While your application is being processed you should check out the benefits that come with using a Vox Money account.<br />
            </p>
            <p v-else>We have all the information we need thank you. <br /> We’ll be in touch regarding your application soon.</p>
            <div class="steps">                       
              <button class="btn v-btn v-btn--block v-btn--has-bg theme--light v-size--large primary" @click="proceed">Vox Money Cashback &amp; Rewards</button>
            </div>
            <p class="block text-caption hidden-md-and-up footer-text">
              The Vox Money account and card are issued by Omnio EMI Limited (OEL), which is a principal member of Visa and authorised by the Financial Conduct Authority under the Electronic Money Regulations 2011 (Firm reference 900123) with its registered office at Clerks Court, 18-20 Farringdon Lane, London, England, EC1R 3AU.
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  import Component from "vue-class-component";
  import Vue from "vue";

  @Component
  export default class DocumentPortalSplash extends Vue {
    applicationId: string | null = null;

    mounted() {
      if (this.$route.params.applicationId) {
        this.applicationId = this.$route.params.applicationId.toString();
      }
    }
    
    proceed() {
      window.location.href = 'https://www.voxmoney.co.uk/rewards/';
    }
  }
</script>


<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";

  .v-stepper__wrapper {
    height: 100% !important;
  }
  
  form {
    height: 100%;
  }

  .icon-check {
    width:15px;
    height:20px;
    margin-right:10px;  
  }

  .login-wrapper {
    display: flex;
    align-items: stretch;
    height: 100%;
    width: 100%;
  }

  .login {
    display: flex;
    width: 100%;
  }

  #col-2 {
    display: flex;
    flex-direction: column;
    align-items: center;
    flex: 1;
    position: relative;
    background: --v-login-background;
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      flex-direction: row;
      align-items: center;
      padding-left: 3%;
    }
  }

  .col2-content {
    max-width: 480px;
    padding:0px 10px 0px 10px;
  }

  .v-alert {
    width: 100%;
  }

  .v-btn:not(.v-btn--round).v-size--large {
    height: 44px;
    min-width: 78px;
    padding: 0 19.5555555556px;
  }

  .v-btn:not(.v-btn--outlined).primary, .v-btn:not(.v-btn--outlined).secondary, .v-btn:not(.v-btn--outlined).accent, .v-btn:not(.v-btn--outlined).success, .v-btn:not(.v-btn--outlined).error, .v-btn:not(.v-btn--outlined).warning, .v-btn:not(.v-btn--outlined).info {
    color: #FFFFFF;
  }

  .v-btn.v-size--large {
      font-size: 0.875rem;
  }

  .v-btn--block {
      display: flex;
      flex: 1 0 auto;
      min-width: 100% !important;
      max-width: auto;
  }

  .v-btn {
    align-items: center;
    border-radius: 999px;
    display: inline-flex;
    flex: 0 0 auto;
    font-weight: 500;
    letter-spacing: 1px;
    justify-content: center;
    outline: 0;
    position: relative;
    text-decoration: none;
    text-indent: 1px;
    text-transform: normal;
    transition-duration: 0.28s;
    transition-property: box-shadow, transform, opacity;
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    vertical-align: middle;
    white-space: nowrap;
  }
  
  h2 {
    text-align: center;
    color: var(--v-secondary-base);
  }

@media #{map-get($display-breakpoints, 'md-and-up')} {

  #col-1 {
    background: linear-gradient(0deg, rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url(../../../tenant/vox/assets/images/current-account-for-everyone.webp) no-repeat;
    background-position: right 165px center;
    background-repeat: no-repeat;
    background-size: cover;
    background-attachment: fixed;
    color: #fff;
    display: flex;
    flex-direction: column;
    flex: 1;
    justify-content: center;
    align-items: center;
    padding-right: 3%;
    height: 100%;
    position: relative;
  }
  
  .col1-content,
  .col2-content {
    z-index: 2;
    width: 100%;
  }

  .col1-content {
    max-width: 560px;
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      display: flex;
      height: 100%;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      flex: 1;
    }
  }

  .col2-content{
    padding: 0px;
  }

  .col1-content > div.container {
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      display: flex;
      height: 100%;
      flex-direction: column;
      align-items: center;
      justify-content: flex-end;
      flex: 1;
      flex-grow: 1;
    }
    text-align: center;
  }

  .col1-content > div.container > div {
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      display: flex;
      height: 100%;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      flex: 1;
      flex-grow: 1;
    }
    text-align: center;
  }

  #col-2 > div > div.logo {
    flex-direction: row;
    align-items: flex-center;
    padding: 10px;
    position: static;
    width: 200px;
    height: 80px;
    left: 32px;
    top: 171.5px;
    background: url(../../../tenant/vox/assets/images/Logo.png);
    flex: none;
    order: 0;
    flex-grow: 0;
  }

  #col-2 > div > div.content {
    display: flex;
    flex-direction: column;
    height: 441px;
  }

  #col-2 > div > div.content > div.intro {
    margin: 30px 0 0 0;  
    text-align: center; 
  }

  .title {
    font-weight: 600;
  }

  #col-2 > div > div.content > div.steps {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    padding: 0px;  
    position: static;
    width: 467px;
    left: 0px;
    top: 104px;
    flex: none;
    order: 1;
    flex-grow: 0;
  }

  #col-2 > div > div.content > div.steps > div.step-item {  
    flex-direction: row;     
  }

  #col-2 > div > div.content > div.steps > div {
    display: flex;
    flex-direction: column;
    align-items: flex-start;   
  }

  #col-2 > div > div.content > div.errors {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    padding: 8px;
    position: static;
    width: 467px;
    left: 0px;
    top: 75px;
    flex: none;
    order: 1;
    flex-grow: 0;
    margin-top: 5px;
    margin-left: 0;
  }

  #col-2 > div > div.content > div.steps div.step-item {  
  display: flex;
    flex-direction: rows;
    align-items: flex-start;

    padding: 0px;
    position: static;
    width: 451px;  
    left: 8px;
    top: 8px;
    flex: none;
    order: 0;
    flex-grow: 0;
    margin-bottom: 10px;
    margin-left:20px;
  }

  #col-2 > div > div.content > div.steps div.step-item > span { 
    color: #404040;
    font-weight: 600;
    margin-bottom: 5px;
  }

  #col-2 > div > div.content > div.steps div.step-item > p { 
    color: #404040;
    font-weight: normal;
  }

  #col-2 > div > div.content > p {
    text-align: center;
  } 

  #col-2 > div > div.content > div.steps > button {
    margin: 16px 0px;
  }
}

@media only screen and (max-width: 960px) {
  #col-1 {
    display: none;
  }

  #col-2 > div > div.logo {
    width: 200px;
    height: 80px;
    background: url(../../../tenant/vox/assets/images/Logo.png) no-repeat;
    margin: 30px auto;
  }

  #col-2 > div > div.content > div.intro {
    margin-bottom: 20px;
  }

  #col-2 > div > div.content > div.steps > div.step-item > .v-icon {
    float: left;
  }

  #col-2 > div > div.content > div.steps > button {
    margin: 16px 0px;
  }

  .title {
    font-size: 17px;
    margin-bottom: 15px;  
  }

  .footer-text { color: #390F46; }
}
</style>