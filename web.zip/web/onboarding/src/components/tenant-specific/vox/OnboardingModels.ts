import {
  OnboardingApplicationStepSetup,
  ScenarioFactoryEntry,
  Scenario,
  Section,
  SectionStatus,
} from "../../OnboardingScenarioModels";
import StartOfApplicationStep from "./steps/1-StartOfApplicationStep.vue";
import PrimaryApplicantDetailsStep from "./steps/2-PrimaryApplicantDetailsStep.vue";
import PrimaryApplicantAddressDetailsStep from "./steps/3-PrimaryApplicantAddressStep.vue";
import PrimaryApplicantContactDetailsStep from "./steps/4-PrimaryApplicantContactDetailsStep.vue";
import SecureCustomerAuth from "./steps/4bis-SecureCustomerAuth.vue";
//import PrimaryApplicantCitizenshipAndResidencyStep from './steps/6-PrimaryApplicantCitizenshipAndResidencyStep.vue'
import PrimaryApplicantEmploymentStatusAndSecurityQuestionsStep from "./steps/7-PrimaryApplicantEmploymentStatusAndSecurityQuestionsStep.vue";
import PrimaryApplicantMarketingAndTerms from "./steps/8-PrimaryApplicantMarketingAndTerms.vue";
import ApplicationSubmissionStep from "./steps/9-ApplicationSubmissionStep.vue";
import DocumentUploadStep from "./steps/12-DocumentUploadStep.vue";
import SelfieCaptureStep from "./steps/13-SelfieCaptureStep.vue";
import POICaptureStep from "./steps/14-POICaptureStep.vue";
import POACaptureStep from "./steps/15-POACaptureStep.vue";

const applicationFormName = "Vox Account Application Form";

export class DocumentType {
  id = "";
  type = "";
  translatedType = "";
}

export class DocumentUpload {
  id = "";
  docUploadStatus = "pending";
  appStatus = "pending";
  file: any;
  fileId = "";
}

export class DocumentCategoryUpload {
  name = "";
  uploads?: Array<DocumentUpload> = new Array<DocumentUpload>();
  types: Array<DocumentType> = new Array<DocumentType>();
}

export class VOXOnboardingApplicationStepSetup extends OnboardingApplicationStepSetup {
  public header = "";
  public showProgressBar = true;
  public canReturn = true;

  constructor(
    idx: number,
    name: string,
    content: any,
    header = "",
    showProgressBar = true,
    isFinal = false,
    getNextStepId: any = undefined,
    canReturn = true
  ) {
    super(idx, name, content, isFinal, getNextStepId, canReturn);
    this.header = header;
    this.showProgressBar = showProgressBar;
    this.canReturn = canReturn
  }
}

export const BranchAdultAccountApplicationScenario: ScenarioFactoryEntry = new ScenarioFactoryEntry(
  "adapp",
  () =>
    new Scenario("AdultAccountApplicationForm", [
      new Section("Residency", [
        new VOXOnboardingApplicationStepSetup(
          0,
          "StartOfApplication",
          StartOfApplicationStep,
          applicationFormName
        ),
      ]),
      new Section("About You", [
        new VOXOnboardingApplicationStepSetup(
          1,
          "PrimaryApplicantContactDetails",
          PrimaryApplicantContactDetailsStep,
          applicationFormName
        ),
        new VOXOnboardingApplicationStepSetup(
          2,
          "PrimaryApplicantDetails",
          PrimaryApplicantDetailsStep,
          applicationFormName
        ),
        new VOXOnboardingApplicationStepSetup(
          3,
          "PrimaryApplicantAddressDetails",
          PrimaryApplicantAddressDetailsStep,
          applicationFormName
        ),
      ]),
      new Section("Employment", [
        new VOXOnboardingApplicationStepSetup(
          4,
          "PrimaryApplicantEmploymentStatusAndSecurityQuestions",
          PrimaryApplicantEmploymentStatusAndSecurityQuestionsStep,
          applicationFormName
        ),
      ]),
      new Section("Accept", [
        new VOXOnboardingApplicationStepSetup(
          5,
          "PrimaryApplicantMarketingAndTerms",
          PrimaryApplicantMarketingAndTerms,
          applicationFormName
        ),
      ]),
      new Section("Completion", [
        new VOXOnboardingApplicationStepSetup(
          6,
          "ApplicationSubmission",
          ApplicationSubmissionStep,
          applicationFormName,
          true,
          true,
          undefined
        ),
        new VOXOnboardingApplicationStepSetup(
          7,
          "DocumentUpload",
          DocumentUploadStep,
          applicationFormName,
          false,
          false,
          undefined
        ),
      ]),
    ]),
  true
);

export const AdultAccountApplicationScenario: ScenarioFactoryEntry = new ScenarioFactoryEntry(
  "adapp",
  () =>
    new Scenario("AdultAccountApplicationForm", [
      new Section("Getting Started", [
        new VOXOnboardingApplicationStepSetup(
          0,
          "StartOfApplication",
          StartOfApplicationStep,
          applicationFormName
        ),
      ]),
      new Section("About You", [
        new VOXOnboardingApplicationStepSetup(
          1,
          "PrimaryApplicantContactDetails",
          PrimaryApplicantContactDetailsStep,
          applicationFormName
        ),
        new VOXOnboardingApplicationStepSetup(
          2,
          "CustomerAuth",
          SecureCustomerAuth,
          applicationFormName
        ),
        new VOXOnboardingApplicationStepSetup(
          3,
          "PrimaryApplicantDetails",
          PrimaryApplicantDetailsStep,
          applicationFormName
        ),
        new VOXOnboardingApplicationStepSetup(
          4,
          "PrimaryApplicantAddressDetails",
          PrimaryApplicantAddressDetailsStep,
          applicationFormName
        ),
      ]),
      new Section("Account", [
        new VOXOnboardingApplicationStepSetup(
          5,
          "PrimaryApplicantEmploymentStatusAndSecurityQuestions",
          PrimaryApplicantEmploymentStatusAndSecurityQuestionsStep,
          applicationFormName
        ),
      ]),
      new Section("Consent", [
        new VOXOnboardingApplicationStepSetup(
          6,
          "PrimaryApplicantMarketingAndTerms",
          PrimaryApplicantMarketingAndTerms,
          applicationFormName,
          true,
          true
        ),
      ])
    ]),
  true
);

export const ApplicantExtraDocumentUploadScenario: ScenarioFactoryEntry = new ScenarioFactoryEntry(
  "du",
  () =>
    new Scenario("ApplicantExtraDocumentUpload", [
      new Section("ExtraDocumentsRequired", [
        new VOXOnboardingApplicationStepSetup(
          1,
          "DocumentUpload",
          DocumentUploadStep,
          applicationFormName,
          false,
          false,
          undefined
        ),
      ]),
    ])
);

export const SelfieSection = new Section("Selfie", [
  new VOXOnboardingApplicationStepSetup(
    0,
    "SelfieCapture",
    SelfieCaptureStep,
    "Supporting documents and Selfie",
    true,
    false,
    undefined,
    false
  )
]);

export const POISection = new Section("Identity Document", [
  new VOXOnboardingApplicationStepSetup(
    1,
    "IdentityCapture",
    POICaptureStep,
    "",
    true,
    false,
    undefined
  )
]);

export const POASection = new Section("Address Document", [
  new VOXOnboardingApplicationStepSetup(
    2,
    "AddressCapture",
    POACaptureStep,
    "",
    true,
    true,
    undefined
  )
]);

SelfieSection.status = SectionStatus.InProgress;

export const InitialFlowCaptureScenario: ScenarioFactoryEntry = new ScenarioFactoryEntry(
  "initial-capture", () =>
    new Scenario("Capture", [
      SelfieSection,
      POISection,
      POASection
    ]),
  true
);