<template>
  <div class="login-wrapper">
    <div class="login">
      <div id="col-1">
        <div class="col1-content">
          <v-container>
            <p class="block white--text elevate mb-6 text-body-1">
              The Vox Money account and card are issued by Omnio EMI Limited (OEL), which is a principal member of Visa and authorised by the Financial Conduct Authority under the Electronic Money Regulations 2011 (Firm reference 900123) with its registered office at Clerks Court, 18-20 Farringdon Lane, London, England, EC1R 3AU.
            </p>
          </v-container>
        </div>
      </div>
      <div id="col-2">
        <div class="col2-content">
          <div class="logo" />
            <div class="content">
              <div class="intro">
                <h2>Supporting documents and Selfie</h2>
              </div>
              <p>Please upload your documents to help us verify your identity. Here is a <a target="_blank" href="https://www.voxmoney.co.uk/help/proof-of-identity/">full list of acceptable documents</a>.</p>
              <p>If you would like to do this later we have sent you an email with a secure link that can bring you back to this step at a convenient time.</p>
              <p>Before progressing with the 'Upload Documents' button below please check the following:</p>    
              <div class="steps">
                <div class="step-item">   
                  <v-icon class="icon-check" small>mdi-check-circle</v-icon>
                  <div>You have your two acceptable documents ready</div>
                </div>
                <div class="step-item">                
                  <v-icon class="icon-check" small>mdi-check-circle</v-icon>Your device has a working camera and is uncovered
                </div>
                <div class="step-item">                
                  <v-icon class="icon-check" small>mdi-check-circle</v-icon>You're ready to take a selfie photo
                </div>           
                <button class="btn v-btn v-btn--block v-btn--has-bg theme--light v-size--large primary" @click="proceed">Upload Documents</button>
              </div>
              <v-container v-if="error !== ''" class="errors">
                <v-alert type="error">{{ error }}</v-alert>
              </v-container>
              <p class="block text-caption hidden-md-and-up footer-text">
                The Vox Money account and card are issued by Omnio EMI Limited (OEL), which is a principal member of Visa and authorised by the Financial Conduct Authority under the Electronic Money Regulations 2011 (Firm reference 900123) with its registered office at Clerks Court, 18-20 Farringdon Lane, London, England, EC1R 3AU.
              </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  import Component from "vue-class-component";
  import Vue from "vue";
  import { omnicore } from "@/omnicore-lib";
  import HttpOnboardingApplicationService from "@/services/impl/HttpOnboardingApplicationService";
  import HttpOTPService from "@/services/impl/HttpOTPService";
  import OnboardingApplicationService from "@/services/OnboardingApplicationService";
  import { OneTimePasswordStatus, OTPService } from "@/services/OTPService";
  import { OnboardingApplication } from "@/types/onboarding.types";
  import { ApplicantKycStatus } from "../../../types/onboarding.types";

  @Component({
    components: {}
  })
  export default class EmailLandingSplash extends Vue {
    personId = "";
    error = "";
    readonly OTPService: OTPService;    
    readonly ApplicationService: OnboardingApplicationService;

    constructor() {
      super();

      this.OTPService = new HttpOTPService();
      this.ApplicationService = new HttpOnboardingApplicationService();

    }

    mounted() {
      if (this.$route.query.personId) {
        this.personId = this.$route.query.personId.toString();
      }
    }

    async proceed() {
      try {
        const getApplicationPersonResponse = await this.ApplicationService.getApplicationPerson(this.personId);
        const getApplicationResponse = await this.ApplicationService.fetchApplication(getApplicationPersonResponse.applicationId as string);
        const application = getApplicationResponse.application;

        if (application!.primaryApplicant!.kycChallenge!.status === ApplicantKycStatus.Success) {
          this.error = "Your application has already been successfully reviewed";
        } else if (application!.primaryApplicant!.kycChallenge!.status === ApplicantKycStatus.Failed) {
          this.error = "Your application failed review";
        } else if (application!.primaryApplicant!.kycChallenge!.status === ApplicantKycStatus.InReview) {
          omnicore().localCache.put<OnboardingApplication>(`OnboardingApplication-${application.id}`, application, 3600);

          const otpResponse = await this.OTPService.sendOTP(application.primaryApplicant!.contactDetails.mobilePhoneNumber);

          if (otpResponse.status === OneTimePasswordStatus.Pending) {
             this.$router.push(`/document-upload-portal/verification/${application.id}/${otpResponse.sessionId}`);
          } else {
            throw new Error();
          }
        }
      } catch(error) {
        this.error = "We are having trouble finding your details - please try again.";
      }
    }
  }
</script>

<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";

  .v-stepper__wrapper {
    height: 100% !important;
  }
  
  form {
    height: 100%;
  }

  .icon-check {
    width:15px;
    height:20px;
    margin-right:10px;  
  }

  .login-wrapper {
    display: flex;
    align-items: stretch;
    height: 100%;
    width: 100%;
  }

  .login {
    display: flex;
    width: 100%;
  }

  #col-2 {
    display: flex;
    flex-direction: column;
    align-items: center;
    flex: 1;
    position: relative;
    background: --v-login-background;
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      flex-direction: row;
      align-items: center;
      padding-left: 3%;
    }
  }

  .col2-content {
    max-width: 480px;
    padding:0px 10px 0px 10px;
  }

  .v-alert {
    width: 100%;
  }
  
  h2 {
    text-align: center;
    color: var(--v-secondary-base);
  }

@media #{map-get($display-breakpoints, 'md-and-up')} {

  #col-1 {
    background: linear-gradient(0deg, rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url(../../../tenant/vox/assets/images/current-account-for-everyone.webp) no-repeat;
    background-position: right 165px center;
    background-repeat: no-repeat;
    background-size: cover;
    background-attachment: fixed;
    color: #fff;
    display: flex;
    flex-direction: column;
    flex: 1;
    justify-content: center;
    align-items: center;
    padding-right: 3%;
    height: 100%;
    position: relative;
  }
  
  .col1-content,
  .col2-content {
    z-index: 2;
    width: 100%;  
  }  

  .col1-content {
    max-width: 560px;
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      display: flex;
      height: 100%;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      flex: 1;
    }
  }

  .col2-content{
    padding: 0px;
  }

  .col1-content > div.container {
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      display: flex;
      height: 100%;
      flex-direction: column;
      align-items: center;
      justify-content: flex-end;
      flex: 1;
      flex-grow: 1;
    }
    text-align: center;
  }

  .col1-content > div.container > div {
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      display: flex;
      height: 100%;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      flex: 1;
      flex-grow: 1;
    }
    text-align: center;
  }

  #col-2 > div > div.logo {
    flex-direction: row;
    align-items: flex-center;
    padding: 10px;
    position: static;
    width: 200px;
    height: 80px;
    left: 32px;
    top: 171.5px;
    background: url(../../../tenant/vox/assets/images/Logo.png);
    flex: none;
    order: 0;
    flex-grow: 0;
  }

  #col-2 > div > div.content {
    display: flex;
    flex-direction: column;
    height: 441px;
  }

  #col-2 > div > div.content > div.intro {
    margin: 30px 0 0 0;  
    text-align: center; 
  }

  .title {
    font-weight: 600;
  }

  #col-2 > div > div.content > div.steps {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    padding: 0px;  
    position: static;
    width: 467px;
    left: 0px;
    top: 104px;
    flex: none;
    order: 1;
    flex-grow: 0;
  }

  #col-2 > div > div.content > div.steps > div.step-item {  
    flex-direction: row;     
  }

  #col-2 > div > div.content > div.steps > div {
    display: flex;
    flex-direction: column;
    align-items: flex-start;   
  }

  #col-2 > div > div.content > div.errors {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    padding: 8px;
    position: static;
    width: 467px;
    left: 0px;
    top: 75px;
    flex: none;
    order: 1;
    flex-grow: 0;
    margin-top: 5px;
    margin-left: 0;
  }

  #col-2 > div > div.content > div.steps div.step-item {  
  display: flex;
    flex-direction: rows;
    align-items: flex-start;

    padding: 0px;
    position: static;
    width: 451px;  
    left: 8px;
    top: 8px;
    flex: none;
    order: 0;
    flex-grow: 0;
    margin-bottom: 10px;
    margin-left:20px;
  }

  #col-2 > div > div.content > div.steps div.step-item > span { 
    color: #404040;
    font-weight: 600;
    margin-bottom: 5px;
  }

  #col-2 > div > div.content > div.steps div.step-item > p { 
    color: #404040;
    font-weight: normal;
  }

  #col-2 > div > div.content > div.steps > button {
    margin: 16px 0px;
  }
}

@media only screen and (max-width: 960px) {
  #col-1 {
    display: none;
  }

  #col-2 > div > div.logo {
    width: 200px;
    height: 80px;
    background: url(../../../tenant/vox/assets/images/Logo.png) no-repeat;
    margin: 30px auto;
  }

  #col-2 > div > div.content > div.intro {
    margin-bottom: 20px;
  }

  #col-2 > div > div.content > div.steps > div.step-item > .v-icon {
    float: left;
  }

  #col-2 > div > div.content > div.steps > button {
    margin: 16px 0px;
  }

  .title {
    font-size: 17px;
    margin-bottom: 15px;  
  }

  .footer-text { color: #390F46; }
}
</style>