import {
  OnboardingApplicationStepSetup,
  ScenarioFactoryEntry,
  Scenario,
  Section,
} from "../../OnboardingScenarioModels";
import WelcomeStep from "./steps/0-WelcomeStep.vue";
import StartOfApplicationStep from "./steps/1-StartOfApplicationStep.vue";
import PrimaryApplicantDetailsStep from "./steps/2-PrimaryApplicantDetailsStep.vue";
import PrimaryApplicantAddressDetailsStep from "./steps/3-PrimaryApplicantAddressStep.vue";
import PrimaryApplicantContactDetailsStep from "./steps/4-PrimaryApplicantContactDetailsStep.vue";
import SecureCustomerAuth from "./steps/4bis-SecureCustomerAuth.vue";
import PrimaryApplicantAdditionalDetailsStep from "./steps/5-PrimaryApplicantAdditionalDetailsStep.vue";
//import PrimaryApplicantCitizenshipAndResidencyStep from "./steps/6-PrimaryApplicantCitizenshipAndResidencyStep.vue";
import PrimaryApplicantEmploymentStatusAndSecurityQuestionsStep from "./steps/7-PrimaryApplicantEmploymentStatusAndSecurityQuestionsStep.vue";
import PrimaryApplicantMarketingAndTerms from "./steps/8-PrimaryApplicantMarketingAndTerms.vue";
import ApplicationSubmissionStep from "./steps/9-ApplicationSubmissionStep.vue";
import DocumentUploadStep from "./steps/12-DocumentUploadStep.vue";

export class MBSOnboardingApplicationStepSetup extends OnboardingApplicationStepSetup {
  public header = "";
  public showProgressBar = true;

  constructor(
    idx: number,
    name: string,
    content: any,
    header = "",
    showProgressBar = true,
    isFinal = false,
    getNextStepId: any = undefined
  ) {
    super(idx, name, content, isFinal, getNextStepId);
    this.header = header;
    this.showProgressBar = showProgressBar;
  }
}

export const AdultAccountApplicationScenario: ScenarioFactoryEntry = new ScenarioFactoryEntry(
  "adapp",
  () =>
    new Scenario("AdultAccountApplicationForm", [
      new Section("Residency", [
        new MBSOnboardingApplicationStepSetup(
          0,
          "Welcome",
          WelcomeStep,
          "Welcome to Monmouthshire Building Society",
          false
        ),
        new MBSOnboardingApplicationStepSetup(
          1,
          "StartOfApplication",
          StartOfApplicationStep,
          "Adult Account Application Form"
        ),
        new MBSOnboardingApplicationStepSetup(
          2,
          "PrimaryApplicantDetails",
          PrimaryApplicantDetailsStep,
          "Adult Account Application Form"
        ),
      ]),
      new Section("Address", [
        new MBSOnboardingApplicationStepSetup(
          3,
          "PrimaryApplicantAddressDetails",
          PrimaryApplicantAddressDetailsStep,
          "Adult Account Application Form"
        ),
        new MBSOnboardingApplicationStepSetup(
          4,
          "PrimaryApplicantContactDetails",
          PrimaryApplicantContactDetailsStep,
          "Adult Account Application Form"
        ),
        new MBSOnboardingApplicationStepSetup(
          5,
          "CustomerAuth",
          SecureCustomerAuth,
          "Adult Account Application Form"
        ),
      ]),
      new Section("Details", [
        new MBSOnboardingApplicationStepSetup(
          6,
          "PrimaryApplicantAdditionalDetails",
          PrimaryApplicantAdditionalDetailsStep,
          "Adult Account Application Form"
        ),
        // new MBSOnboardingApplicationStepSetup(7, "PrimaryApplicantCitizenshipAndResidence", PrimaryApplicantCitizenshipAndResidencyStep, "Adult Account Application Form"),
      ]),
      new Section("Employment", [
        new MBSOnboardingApplicationStepSetup(
          7,
          "PrimaryApplicantEmploymentStatusAndSecurityQuestions",
          PrimaryApplicantEmploymentStatusAndSecurityQuestionsStep,
          "Adult Account Application Form"
        ),
      ]),
      new Section("Marketing", [
        new MBSOnboardingApplicationStepSetup(
          8,
          "PrimaryApplicantMarketingAndTerms",
          PrimaryApplicantMarketingAndTerms,
          "Adult Account Application Form"
        ),
      ]),
      new Section("Completion", [
        new MBSOnboardingApplicationStepSetup(
          9,
          "ApplicationSubmission",
          ApplicationSubmissionStep,
          "Adult Account Application Form",
          true,
          true,
          undefined
        ),
        new MBSOnboardingApplicationStepSetup(
          10,
          "DocumentUpload",
          DocumentUploadStep,
          "Adult Account Application Form",
          false,
          false,
          undefined
        ),
      ]),
    ]),
  true
);

export const ApplicantExtraDocumentUploadScenario: ScenarioFactoryEntry = new ScenarioFactoryEntry(
  "du",
  () =>
    new Scenario("ApplicantExtraDocumentUpload", [
      new Section("ExtraDocumentsRequired", [
        new MBSOnboardingApplicationStepSetup(
          1,
          "DocumentUpload",
          DocumentUploadStep,
          "Adult Account Application Form",
          false,
          false,
          undefined
        ),
      ]),
    ])
);
