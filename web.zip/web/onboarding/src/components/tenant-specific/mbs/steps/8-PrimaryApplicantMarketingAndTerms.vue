<template>
  <v-form v-model="valid">
    <v-container style="padding: 0px">
      <grouping label="Marketing Preferences">
        <v-container>
          <v-row>
            The Monmouthshire Building Society would like to provide you with
            information on our products and services unless you opt of receiving
            this information. Please note the Society will continue to provide
            you with regulatory and service communications even if you have
            opted out. I do not wish to receive information on products and
            services by the following channels:
          </v-row>
          <v-row>
            <v-checkbox
              v-model="
                application.primaryApplicant.marketingPreferences.disableSMS
              "
              label="SMS"
              dense
              id="application-primary-marketing-disablesms"
            />
            <v-spacer />
            <v-checkbox
              v-model="
                application.primaryApplicant.marketingPreferences.disableEmail
              "
              label="Email"
              dense
              id="application-primary-marketing-disableemail"
            />
            <v-spacer />
            <v-checkbox
              v-model="
                application.primaryApplicant.marketingPreferences
                  .disableTelephone
              "
              label="Telephone"
              dense
              id="application-primary-marketing-disablephone"
            />
            <v-spacer />
            <v-checkbox
              v-model="
                application.primaryApplicant.marketingPreferences.disablePost
              "
              label="Post"
              dense
              id="application-primary-marketing-disablepost"
            />
          </v-row>
        </v-container>
      </grouping>
      <grouping label="Accept and Submit">
        <v-container>
          <v-row> I/We have read and agreed to the: </v-row>
          <v-row>
            <v-checkbox
              v-model="application.primaryApplicant.agreeMECurrentAccTAndCs"
              label="Account Terms and Conditions"
              dense
              id="application-primary-agreemecurrentacctandcs"
              :rules="[mustBeTrueRule]"
            />
          </v-row>
          <v-row>
            <v-checkbox
              v-model="application.primaryApplicant.agreePrivacyPolicy"
              label="Privacy Policy"
              dense
              id="application-primary-agreeprivacypolicy"
              :rules="[mustBeTrueRule]"
            />
          </v-row>
          <v-row>
            <v-checkbox
              v-model="application.primaryApplicant.agreeKeyFactsDocument"
              label="Key Facts Document"
              dense
              id="application-primary-agreekeyfactsdocument"
              :rules="[mustBeTrueRule]"
          /></v-row>
          <v-row>
            <v-checkbox
              v-model="application.primaryApplicant.agreeFeeInformationDocument"
              label="Fee Information Document"
              dense
              id="application-primary-agreekeyinfodoc"
              :rules="[mustBeTrueRule]"
            />
          </v-row>
          <v-row>
            <v-checkbox
              v-model="application.primaryApplicant.agreeFscsInfoSheet"
              label="FSCS Information Sheet"
              dense
              id="application-primary-agreefscsinfosheet"
              :rules="[mustBeTrueRule]"
            />
          </v-row>
        </v-container>
      </grouping>
    </v-container>
  </v-form>
</template>

<script lang="ts">
//  module imports
import Component from "vue-class-component";
import { Model } from "vue-property-decorator";
import Grouping from "@/components/Grouping.vue";
import BaseStep from "@/components/BaseStep.vue";
import { OnboardingApplication } from "@/types/onboarding.types";
import DefaultValidationRules from "@/components/CommonValidationRules";

@Component({
  //  component dependencies
  components: {
    Grouping
  }
})
export default class PrimaryApplicantMarketingAndTerms extends BaseStep {
  @Model() application?: OnboardingApplication;
  mustBeTrueRule = DefaultValidationRules.mustBeTrue(
    "Please confirm you have read and accepted that document"
  );
}
</script>