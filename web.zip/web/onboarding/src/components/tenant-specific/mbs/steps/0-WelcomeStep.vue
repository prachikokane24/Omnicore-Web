<template>
  <v-form v-model="valid">
    <div>
    <h2>Pre Application Page</h2>
    <p>
      You are about to apply for an MBS account. We will gather data relevant to your application, ensuring we
      can identify you successfully. In the event we can't identify you electronically you may need to provide some
      documents as part of your application. A list of the accepted documents can be found below:
    </p>
    <h3>Identity Documents</h3>
    <p>
      <ul>
        <li>UK or International Passport</li>
        <li>Valid EEA Identity card or Swiss National Identity card</li>
        <li>Valid Identity Card used by Electoral office in Northern Ireland</li>
        <li>UK Driving Licence</li>

      </ul>
    </p>
    <h3>Proof Of Address</h3>
    <p>
      <ul>
        <li>Bank Statement (dated within the last 3 months)</li>
        <li>Credit Card Statement (dated within the last 3 months)</li>
        <li>Annual Mortgage Statement (dated within the last 12 months)</li>
        <li>HMRC Letter or Tax Notification (dated within the last 12 months)</li>
        <li>UK Council Tax Bill or Statement (dated within the last 12 months)</li>
      </ul>
    </p>
    <p>
      Click <a href="#">here</a> to know all the documents required
    </p>
    <p>
      Please do not exit from the page until you complete the process
    </p>
    </div>
  </v-form>
</template>

<script lang="ts">
//  module imports
import Component from "vue-class-component";
import BaseStep from "@/components/BaseStep.vue";

@Component({
  //  component dependencies
  components: {}
})
export default class StartOfApplicationStep extends BaseStep {}
</script>
