<template>
  <v-form v-model="valid">
    <grouping label="Details">
      <v-container>
        <v-row>
          <v-select
            id="application-primary-title"
            :items="applicantTitles"
            :item-text="(item) => item.text"
            :item-value="(item) => item.id"
            :rules="namesValidationRules"
            v-model="application.primaryApplicant.name.title"
            label="Title"
            dense
            outlined
          ></v-select>
        </v-row>
        <v-row>
          <v-text-field
            id="application-primary-current-firstname"
            label="First name"
            v-model="application.primaryApplicant.name.firstName"
            :rules="namesValidationRules"
            :maxLength="maxNameLength"
            dense
            outlined
          />
        </v-row>
        <v-row>
          <v-text-field
            id="application-primary-current-middlenames"
            label="Middle names"
            v-model="application.primaryApplicant.name.middleName"
            :rules="namesValidationRulesNotRequired"
            :maxLength="maxNameLength"
            dense
            outlined
          />
        </v-row>
        <v-row>
          <v-text-field
            id="application-primary-current-lastname"
            label="Surname"
            v-model="application.primaryApplicant.name.lastName"
            :rules="namesValidationRules"
            :maxLength="maxNameLength"
            dense
            outlined
          />
        </v-row>
        <v-row dense>
          <v-radio-group 
            id="application-primary-gender"
            v-model="application.primaryApplicant.gender" 
            label="Gender" 
            :rules="[v => v !== undefined || 'Please specify a gender']"
            row 
            dense
            >
            <v-radio label="Male" id="application-primary-gender-male" value="Male"></v-radio>
            <v-radio label="Female" id="application-primary-gender-female" value="Female"></v-radio>
          </v-radio-group>
        </v-row>
        <v-row>
            <v-text-field 
              id = "application-primary-dob"
              label="Date of Birth (dd/mm/yyyy)" 
              v-model="dateOfBirth" 
              outlined
              v-mask="'##/##/####'"
              dense
              :rules="dateOfBirthRules"
            />
        </v-row>
        <p>Have you been known by any other names in the last three years?</p>
        <v-radio-group
            id="application-primary-hasbeenknownbyothernamelast3years"
            v-model="haveBeenKnownByAnotherNameInLastThreeYears"
            :rules="[v => v !== undefined || 'Please choose']"
            row
            dense
            
            @change="haveBeenKnownByAnotherNameInLastThreeYearsHandler"
            >
            <v-radio label="Yes" id="application-primary-hasbeenknownbyothernamelast3years-yes" :value="true"></v-radio>
            <v-radio label="No" id="application-primary-hasbeenknownbyothernamelast3years-no" :value="false"></v-radio>
          </v-radio-group>
      </v-container>
    </grouping>
    
    <div ref="otherNameGroup" />
    <grouping label="Other names" v-if="showPreviousNames">
      <v-container>
          <v-row>
            <v-text-field
              id="application-primary-previous-firstname"
              label="First name"
              v-model="application.primaryApplicant.previousName.firstName"
              :rules="namesValidationRules"
              :maxLength="maxNameLength"
              dense
              outlined
            />
          </v-row>
          <v-row>
            <v-text-field
              id="application-primary-previous-middlenames"
              dense
              label="Middle names"
              v-model="application.primaryApplicant.previousName.middleName"
              :rules="namesValidationRulesNotRequired"
              :maxLength="maxNameLength"              
              outlined
            />
          </v-row>
          <v-row>
            <v-text-field
              id="application-primary-previous-surname"
              label="Surname"
              v-model="application.primaryApplicant.previousName.lastName"
              :rules="namesValidationRules"
              :maxLength="maxNameLength"              
              dense
              outlined
            />
          </v-row>
      </v-container>
    </grouping>
  </v-form>
</template>

<script lang="ts">
//  module imports
import Component from "vue-class-component";
import { Model } from "vue-property-decorator";

import { Applicant, ApplicantCurrentTitle, Individual, OnboardingApplication } from "@/types/onboarding.types";
import DefaultValidationRules from "@/components/CommonValidationRules";
import Grouping from "@/components/Grouping.vue";
import BaseStep from "@/components/BaseStep.vue";
import DatePicker from "@/components/DatePicker.vue";
import moment from "moment";

@Component({
  components: {
    Grouping, DatePicker
  },
})
export default class PrimaryApplicantDetailsStep extends BaseStep {
  @Model() application?: OnboardingApplication;
  applicantTitles: { text: string; id: string }[] = [];

  readonly maxNameLength = 20;

  constructor() {
    super()

    if (this.application !== undefined && this.application?.primaryApplicant === undefined) {
      this.application.primaryApplicant = new Applicant();
      const date = moment.utc(this.application.primaryApplicant.dateOfBirth, "YYYY-MM-DD");
      if (date.isValid()) {
        this.dobBuffer = date.format("DD/MM/YYYY");
      }
    }

    this.applicantTitles = Object.keys(ApplicantCurrentTitle).map( x => ({ text: ApplicantCurrentTitle[x], id:x }));
  }

  //
  // Fields
  dobBuffer = "";
  haveBeenKnownByAnotherNameInLastThreeYears?: boolean = undefined;
  showPreviousNames = false; // this is used because Vue is not reactive to the model field for some reasons
  

  get dateOfBirth() { 
    return this.dobBuffer; 
  }
  set dateOfBirth(val) { 
    this.dobBuffer = val;
    if (this.application !== undefined && this.application.primaryApplicant !== undefined) {
      const date = moment.utc(val, "DD/MM/YYYY", true);
      if (date.isValid()) {
        this.application.primaryApplicant.dateOfBirth = date.toISOString();
      }
    }
  }

  //
  // Rules
  namesValidationRules = [
    DefaultValidationRules.isRequired,
    DefaultValidationRules.isValidName,
    DefaultValidationRules.textLenWithin(2, this.maxNameLength)
  ];
  namesValidationRulesNotRequired = [
    DefaultValidationRules.textLenWithin(0, this.maxNameLength),
    DefaultValidationRules.isValidName
  ]
  defaultIsrequiedRule = DefaultValidationRules.isRequired;
  dateOfBirthRules = [
    DefaultValidationRules.isValidDate("DD/MM/YYYY"),
    DefaultValidationRules.mustBeWithinAge(
      18,
      120,
      "DD/MM/YYYY",
      "You must be at least 18 years old to create an account."
    ),
    DefaultValidationRules.isRequired,
  ];


  haveBeenKnownByAnotherNameInLastThreeYearsHandler(value)
  {
    this.showPreviousNames = this.haveBeenKnownByAnotherNameInLastThreeYears || false;
    if (this.showPreviousNames) {
      this.$vuetify.goTo(
        this.$refs.otherNameGroup as HTMLElement,
        {
          container: '#componentContainer', // This references the container defined in the onboardingbase component. If missing, it doesnt scroll.
          duration: 600,
          offset: 0,
          easing: 'easeInOutCubic',
        }
      );
    }

    if (this.application !== null && this.application?.primaryApplicant && this.showPreviousNames)
      this.application.primaryApplicant.previousName = new Individual();
  }
}
</script>