<template>
  <v-form v-model="valid">
    <grouping label="Current Address">
      <v-container>
        <applicant-address
          v-model="application.primaryApplicant.currentAddress"
          id-prefix="application-primary-currentaddress"
        />
        <v-row>
          <v-text-field
            id="application-primary-movedToPrimaryAddressDate"
            label="When did you move to your address (dd/mm/yyyy)"
            outlined
            v-mask="'##/##/####'"
            dense
            hide-details="auto"
            v-model="movedToAddressOn"
            :rules="movedToAddressOnRules"
            @change="checkIfPreviousAddressRequired"
          />
        </v-row>
      </v-container>
    </grouping>
    <div ref="previousAddressGroup" />
    <grouping v-if="needsPreviousAddress" label="Previous Address">
      <v-container>
        <applicant-address
          v-model="application.primaryApplicant.previousAddress"
          id-prefix="application-primary-previousaddress"
        />
      </v-container>
    </grouping>
  </v-form>
</template>

<script lang="ts">
//  module imports
import Component from "vue-class-component";
import { Model } from "vue-property-decorator";
import ApplicantAddress from "@/components/ApplicantAddress.vue";
import Grouping from "@/components/Grouping.vue";
import BaseStep from "@/components/BaseStep.vue";
import DatePicker from "@/components/DatePicker.vue";
import {
  CommonTypesV1Address,
  OnboardingApplication
} from "@/types/onboarding.types";
import DefaultValidationRules from "@/components/CommonValidationRules";
import moment from "moment";

@Component({
  components: { ApplicantAddress, Grouping, DatePicker }
})
export default class PrimaryApplicantAddressDetailsStep extends BaseStep {
  @Model() application?: OnboardingApplication;

  constructor() {
    super();
    if (
      this.application !== undefined &&
      this.application.primaryApplicant !== undefined
    ) {
      this.application.primaryApplicant.currentAddress.country = "GBR";
      const date = moment.utc(
        this.application.primaryApplicant.currentAddress.movedToAddressOn,
        "YYYY-MM-DD"
      );
      if (date.isValid()) {
        this.movedToAddressOnBuffer = date.format("DD/MM/YYYY");
      }
    }
  }

  movedToAddressOnBuffer = "";

  isRequiredRule = DefaultValidationRules.isRequired;
  movedToAddressOnRules = [
    DefaultValidationRules.isRequired,
    DefaultValidationRules.isValidDate("DD/MM/YYYY"),
    DefaultValidationRules.dateMustBeWithin(
      () => moment(this.application?.primaryApplicant?.dateOfBirth),
      moment.now(),
      "DD/MM/YYYY",
      "The date cannot be in the future or before your date of birth"
    )
  ];

  get movedToAddressOn() {
    return this.movedToAddressOnBuffer;
  }
  set movedToAddressOn(val) {
    this.movedToAddressOnBuffer = val;
    if (
      this.application !== undefined &&
      this.application.primaryApplicant !== undefined
    ) {
      const date = moment.utc(val, "DD/MM/YYYY", true);
      if (date.isValid()) {
        this.application.primaryApplicant.currentAddress.movedToAddressOn = date.toISOString();
      }
    }
  }

  //
  // Fields
  needsPreviousAddress = false;

  checkIfPreviousAddressRequired(value) {
    const date = moment.utc(value, "DD/MM/YYYY", true);
    this.needsPreviousAddress = moment().diff(date, "years") < 3;
    if (this.needsPreviousAddress) {
      this.$vuetify.goTo(this.$refs.previousAddressGroup as HTMLElement, {
        container: "#componentContainer", // This references the container defined in the onboardingbase component. If missing, it doesnt scroll.
        duration: 600,
        offset: 0,
        easing: "easeInOutCubic"
      });

      if (this.application!.primaryApplicant!.previousAddress === undefined) {
        this.application!.primaryApplicant!.previousAddress = new CommonTypesV1Address();
        this.application!.primaryApplicant!.previousAddress.country = "GBR";
      }
    } else {
      this.application!.primaryApplicant!.previousAddress = undefined;
    }
  }
}
</script>