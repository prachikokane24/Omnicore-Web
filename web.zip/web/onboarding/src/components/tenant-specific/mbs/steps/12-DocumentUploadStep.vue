<template>
  <v-form v-model="valid" ref="form">
    <v-container v-if="isLoadingApplication">
      Please wait while we are loading your application...
    </v-container>

    <v-container v-if="hasError">
      <v-alert type="error">{{ errorMessage }}</v-alert>
    </v-container>

    <v-container v-if="isUploadSuccessful" class="centerize">
      <v-row>
        <img
          v-if="!$vuetify.breakpoint.smAndUp"
          src="@tenantAssets/images/thankyou-mobile.png"
        />
        <img
          v-if="$vuetify.breakpoint.smAndUp"
          src="@tenantAssets/images/thankyou-web.png"
        />
      </v-row>
      <v-row>
        <p>
          We are verifying your documents and you will hear back from us
          shortly.
        </p>
      </v-row>
    </v-container>

    <v-container v-show="isInUploadPhase && !isUploadSuccessful">
      To continue the processing of your application, could you please provide
      the following documents:
      <grouping :label="doc.name" v-for="doc in docUploads" :key="doc.name">
        <p>
          Please provide {{ doc.uploads.length }} proof{{
            doc.uploads.length > 1 ? "s" : ""
          }}
          of {{ doc.name }}
        </p>
        <v-container
          v-for="[idx, upload] in doc.uploads.entries()"
          :key="idx"
          style="padding: 0px; margin: 0px"
        >
          <div v-if="upload.appStatus === 'success'">
            <v-alert type="success" icon="mdi-check-circle-outline">
              Document successfully uploaded
            </v-alert>
          </div>
          <div v-if="upload.appStatus === 'error'">
            <v-alert type="error" icon="mdi-check-circle-outline">
              Document failed to upload, please retry
            </v-alert>
          </div>
          <div v-if="upload.appStatus !== 'success'">
            <v-select
              :items="doc.types"
              :item-value="item => item.id"
              :item-text="item => item.translatedType"
              label="Document Type"
              v-model="upload.id"
              dense
              outlined
              :rules="[isRequired, mustBeUniqueDocType(upload)]"
              :disabled="isPerformingUpload"
            >
            </v-select>
            <v-file-input
              :rules="[isRequired]"
              show-size
              v-model="upload.file"
              counter
              dense
              outlined
              truncate-length="15"
              required="true"
              label="Please select a file"
              :disabled="isPerformingUpload"
            />
          </div>
          <v-divider
            style="margin: 10px"
            v-if="doc.uploads.length > 1 && idx !== doc.uploads.length - 1"
          />
        </v-container>
      </grouping>
      <v-container class="centerize">
        <v-btn
          @click="handleUpload()"
          :loading="isPerformingUpload"
          class="action-btn"
          x-large
        >
          <v-icon>mdi-transfer-up</v-icon>Upload
        </v-btn>
      </v-container>
    </v-container>
  </v-form>
</template>

<script lang="ts">
//  module imports
import Component from "vue-class-component";
import BaseStep from "@/components/BaseStep.vue";
import { Inject } from "vue-property-decorator";
import {
  ApplicantKycStatus,
  OnboardingApplication
} from "@/types/onboarding.types";
import MbsOnboardingContainer from "../OnboardingContainer";
import Grouping from "@/components/Grouping.vue";
import DefaultValidationRules from "@/components/CommonValidationRules";
import { OnboardingDocumentUploadRequest } from "@/services/OnboardingDocumentService";
import {
  DocumentUploadOutcome,
  KycDocumentInfo
} from "@/services/OnboardingApplicationService";

class DocumentType {
  id = "";
  type = "";
  translatedType = "";
}

class DocumentCategoryUpload {
  name = "";
  uploads?: Array<DocumentUpload> = new Array<DocumentUpload>();
  types: Array<DocumentType> = new Array<DocumentType>();
}

class DocumentUpload {
  id = "";
  docUploadStatus = "pending";
  appStatus = "pending";
  file: any;
  fileId = "";
}

@Component({
  //  component dependencies
  components: {
    Grouping
  }
})
export default class DocumentUploadStep extends BaseStep {
  application?: OnboardingApplication;
  @Inject() container?: MbsOnboardingContainer;

  // note: mounted is called at the very beginning (when page is loaded), not when it becomes visible
  // Tried the @watch approach on application object to up

  isLoadingApplication = false;
  hasError = false;
  allowResume = false;
  errorMessage = "";
  isPerformingUpload = false;
  isInUploadPhase = false;
  isUploadSuccessful = false;
  docUploads: DocumentCategoryUpload[] | undefined = [];

  // rules
  isRequired = DefaultValidationRules.isRequired;
  mustBeUniqueDocType(docUpload: DocumentUpload) {
    return v => {
      if (!v) {
        return true;
      }

      const ids = this.docUploads?.flatMap(f => f.uploads).map(f => f?.id);
      const matches = ids?.filter(i => i == v).length;
      return (
        matches! <= 1 ||
        "Please select a different type of document for each upload"
      );
    };
  }

  mounted() {
    this.on("application::submitted", data => {
      // this way is used because vue very unhappy about mutation of the application model in step 9
      this.application = data;
      this.updateStatus();
    });

    if (this.allowResume) {
      if (!this.application) {
        console.log("no applications detected");
        const appId = String(this.$route.query.appId);
        if (!appId) {
          this.showError("No application loaded and no id provided in url");
        }
      } else {
        console.log("application already there");
        this.updateStatus();
      }
    }
  }

  updateStatus() {
    if (
      this.application!.primaryApplicant === undefined ||
      this.application!.primaryApplicant!.kycChallenge === undefined
    ) {
      return;
    }
    switch (this.application!.primaryApplicant!.kycChallenge!.status) {
      case ApplicantKycStatus.Success:
        this.showError(
          "Your application has already been approved, there is no need to provide extra documents"
        );
        break;

      case ApplicantKycStatus.Failed:
        this.showError(
          "Unfortunately your application has been rejected, there is no need to provide extra documents"
        );
        break;

      case ApplicantKycStatus.InReview:
        this.isInUploadPhase = true;
        this.docUploads = this.listDocumentToUpload(this.application);
        console.log(this.docUploads);
        break;

      default:
        this.showError(
          `Unhandled applicant KYC status '${
            this.application!.primaryApplicant!.kycChallenge!.status
          }'`
        );
    }
  }

  listDocumentToUpload(application: OnboardingApplication | undefined) {
    if (!application) {
      return [];
    }

    return application?.primaryApplicant?.kycChallenge?.requiredDocuments?.map(
      k => {
        const dcu = new DocumentCategoryUpload();
        dcu.name = k.type ?? "unknown";
        for (let i = 0; i < (k.numberRequired ?? 0); i++) {
          dcu.uploads?.push(new DocumentUpload());
        }

        dcu.types =
          k.documents?.map(t => {
            // the following is there because of the (told to be necessary) complicated
            // structure of documents
            let type = "";
            switch (k.type) {
              case "address":
                type = t.address ?? "";
                break;
              case "identity":
                type = t.identity ?? "";
                break;
              case "representation":
                type = t.representation ?? "";
                break;
              case "residence":
                type = t.residence ?? "";
                break;
              case "sourceOfIncome":
                type = t.sourceOfIncome ?? "";
                break;
              case "sourceOfWealth":
                type = t.sourceOfWealth ?? "";
                break;
              case "photo":
                type = t.photo ?? "";
                break;
              default:
                throw new Error(`Unhandled document type '${k.type}'`);
            }

            const dt = new DocumentType();
            dt.id = t.id ?? "unknown";
            dt.type = type;
            dt.translatedType = this.translateType(type);
            return dt;
          }) ?? [];

        return dcu;
      }
    );
  }

  translateType(type: string): string {
    if (type in this.translationMap) {
      return this.translationMap[type];
    } else {
      return type;
    }
  }

  showError(message) {
    this.hasError = true;
    this.errorMessage = message;
  }

  async handleUpload() {
    const isValid = (this.$refs.form as Vue & {
      validate: () => boolean;
    }).validate();
    if (!isValid) {
      return;
    }
    this.isPerformingUpload = true;

    console.log("Uploading::Uploading docs");

    await Promise.all(
      this.docUploads!.map(async du => {
        return this.uploadDocCategory(du);
      })
    );

    const allUploadOk = this.docUploads!.every(e =>
      e.uploads!.every(f => f.docUploadStatus === "success")
    );
    if (!allUploadOk) {
      this.isUploadSuccessful = false;
      this.isPerformingUpload = false;
      this.errorMessage =
        "One or more documents failed to upload, please retry";
      this.hasError = true;
      return;
    }

    const appDocs = this.docUploads!.flatMap(e =>
      e.uploads!.filter(f => f.appStatus !== "success")
    ).map(f => new KycDocumentInfo(f.id, f.fileId));

    try {
      const fssResponse = await this.container?.ApplicationService.submitDocument(
        this.application!.primaryApplicant!.kycChallenge!.id,
        appDocs
      );

      const res = fssResponse!.applicantsOutcomes?.filter(
        ao =>
          ao.kycChallengeId ===
          this.application!.primaryApplicant!.kycChallenge!.id
      );
      if (res === undefined || res.length < 1) {
        throw new Error(`Unable to retrieve information about doc submission`);
      }
      const failedDocs = res.flatMap(r => r.documentOutcomes);
      const uploadDocs = this.docUploads!.flatMap(ud => ud.uploads);
      let hasErrors = false;
      failedDocs.forEach(fd => {
        const upload = uploadDocs.find(
          ud => ud?.fileId === fd?.secureDocumentStorageId
        );
        upload!.appStatus =
          fd?.outcome === DocumentUploadOutcome.Success ? "success" : "error";
        upload!.docUploadStatus = upload!.appStatus;

        if (upload!.appStatus === "error") {
          hasErrors = true;
        }
      });
      if (hasErrors) {
        throw new Error(
          `Some documents could not be updated properly in the application`
        );
      }

      this.flowCompleted();
      this.isUploadSuccessful = true;
    } catch (Error) {
      this.errorMessage =
        "Failed to update the application with the uploaded documents";
      this.hasError = true;
      this.isUploadSuccessful = false;
    } finally {
      this.isPerformingUpload = false;
      if (this.isUploadSuccessful) {
        // making sure we dont have residual error message if it is all good after a retry
        this.errorMessage = "";
        this.hasError = false;
      }
    }
  }

  async uploadDocCategory(du): Promise<KycDocumentInfo[]> {
    const toUpload = du.uploads?.filter(up => up.docUploadStatus !== "success") || [];
    return Promise.all(
      toUpload.map(async up => {
        up.docUploadStatus = "uploading";
        try {
          return await this.uploadFile(up);
        } catch (error) {
          console.log(`Failed to upload file: ${error}`);
          up.docUploadStatus = "error";
        }
      })
    );
  }

  async uploadFile(
    upload: DocumentUpload
  ): Promise<KycDocumentInfo | undefined> {
    const data = new FormData();
    data.append("file", upload.file);
    const request = new OnboardingDocumentUploadRequest();
    request.file = data;

    try {
      const response = await this.container?.OnboardingDocumentService.upload(
        request
      );
      console.log(`Document uploaded successfully`);
      upload.docUploadStatus = "success";
      upload.fileId = response!.fileId;
      return new KycDocumentInfo(upload.id, response!.fileId);
    } catch (error) {
      upload.docUploadStatus = "error";
      console.log(`Failed to upload doc : ${error}`);
      this.hasError = true;
      this.errorMessage = `Failed to upload some files (${error})`;
    }

    return undefined;
  }

  translationMap = {
    // address
    annualMortgageStatement: "Annual mortgage statement",
    carorHomeInsturanceDocument: "Car or home insurance document",
    firearmsOrShotgunCertificate: "Firearms or shotgun certificate",
    creditOrDebitCardStatement: "Credit or debit card statement",
    currentTenanceAgreement: "Current tenancy agreement",
    hmrcLetter: "HMRC letter",
    leaseDeedOrRentalAgreementOrPropertyRegistrationDocument:
      "Lease, deed, rental agreement or property registration document",
    mooringFeesDocumentation: "Mooring fees documentation",
    personalBankStatement: "Personal bank statement",
    utilityBill: "Utility bill",
    solicitorsCompletionLetter: "Solicitors completion letter",
    taxStatement: "Tax statement",
    taxBill: "Tax bill",
    ukCreditUnionStatement: "UK credit union statement",
    vehicleRegistration: "Vehicle registration",

    // identity
    birthCertificate: "Birth certificate",
    drivingLicence: "Driving licence",
    eeaIdentityCard: "EEA identity card",
    homeOfficeTravelDocument: "Home Office travel document",
    identityCard: "Identity card",
    nhsLetter: "NHS letter",
    passport: "Passport",
    ukArmedForcesId: "UK Armed Forces Id",
    ukDisabilityBlueBadge: "UK Disability Blue Badge",
    ukResidencePermit: "UK Resident Permit",

    // photo
    selfie: "Selfie"
  };
}
</script>


<style scoped>
.centerize {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
}

.centerize .row {
  padding-top: 10px;
  padding-bottom: 10px;
  display: inherit !important;
}

.action-btn {
  border-radius: 30px !important;
}
</style>