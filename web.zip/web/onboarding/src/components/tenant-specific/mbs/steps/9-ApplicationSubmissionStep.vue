<template>
  <v-form v-model="valid">
    <!-- unhappy path: issue when submitting the application -->
    <v-container
      v-show="isApplicationSubmitted && hasErrors"
      class="centerize"
      id="application-submission-failed-container"
    >
      <v-row>
        <img
          v-if="!$vuetify.breakpoint.smAndUp"
          src="@tenantAssets/images/application-submission-error-mobile.png"
        />
        <img
          v-if="$vuetify.breakpoint.smAndUp"
          src="@tenantAssets/images/application-submission-error-normal.png"
        />
      </v-row>
      <v-row>
        <p>
          It looks like we're having a bit of a technical issue submitting your
          application.
        </p>
      </v-row>
      <v-row>
        <v-btn @click="expandDetails = !expandDetails" class="details-btn"
          >View Details</v-btn
        >
      </v-row>
      <v-row v-if="expandDetails" class="details-row">
        <p v-for="line in detailsInfo.split('\n')" :key="line">
          {{ line }}
        </p>
      </v-row>
      <v-row>
        <v-btn
          id="application-submission-resubmit-btn"
          :loading="isBusy"
          x-large
          class="action-btn"
          rounded
          @click="submitApplication"
          ><v-icon>mdi-transfer-up</v-icon>Re-submit!</v-btn
        >
      </v-row>
    </v-container>

    <!-- happy path / auto approved -->
    <v-container
      v-show="
        isApplicationSubmitted &&
          !isBusy &&
          isApplicationAutoApproved &&
          !hasErrors
      "
      class="centerize"
      id="application-submission-success-container"
    >
      <v-row>
        <img
          v-if="!$vuetify.breakpoint.smAndUp"
          src="@tenantAssets/images/application-submission-success-mobile.png"
        />
        <img
          v-if="$vuetify.breakpoint.smAndUp"
          src="@tenantAssets/images/application-submission-success-normal.png"
        />
      </v-row>
      <v-row>
        <v-btn @click="expandDetails = !expandDetails" class="details-btn"
          >View Details</v-btn
        >
      </v-row>
      <v-row v-if="expandDetails" class="details-row">
        <p v-for="line in detailsInfo.split('\n')" :key="line">
          {{ line }}
        </p>
      </v-row>
      <v-row>
        <p>
          Thank you for your application! We have received your application for
          a current account and be in contact via email shortly.
        </p>
      </v-row>
    </v-container>

    <!-- happy path / need more doc -->
    <v-container
      v-show="
        isApplicationSubmitted &&
          !isBusy &&
          !isApplicationAutoApproved &&
          !hasErrors &&
          !hasApplicationBeenRejected
      "
      class="centerize"
      id="application-submission-inprogress-container"
    >
      <v-row>
        <p>
          Your application has been processed and will require more
          documentation. (under development)
        </p>
      </v-row>
    </v-container>

    <!-- happy path / rejected -->
    <v-container
      v-show="isApplicationSubmitted && !isBusy && hasApplicationBeenRejected"
      class="centerize"
      id="application-submission-rejected-container"
    >
      <v-row>
        <p>
          The application has been rejected. (under development)
        </p>
      </v-row>
      <v-row>
        <v-btn @click="expandDetails = !expandDetails" class="details-btn"
          >View Details</v-btn
        >
      </v-row>
      <v-row v-if="expandDetails" class="details-row">
        <p v-for="line in detailsInfo.split('\n')" :key="line">
          {{ line }}
        </p>
      </v-row>
    </v-container>

    <!-- application submission -->
    <v-container v-show="!isApplicationSubmitted" class="centerize">
      <v-row class="bigSign">
        <v-icon block style="font-size:120px;" color="#FA6400"
          >mdi-upload</v-icon
        >
      </v-row>
      <v-row class="bigSign">
        <p>
          Thank you for providing the required information. Your application is
          ready now for submission!
        </p>
      </v-row>
      <v-row class="bigSign">
        <v-btn
          id="application-submission-btn"
          :loading="isBusy"
          x-large
          class="action-btn"
          rounded
          @click="submitApplication"
          ><v-icon>mdi-transfer-up</v-icon>Submit!</v-btn
        >
      </v-row>
    </v-container>
  </v-form>
</template>

<script lang="ts">
//  module imports
import Component from "vue-class-component";
import { Inject, Model } from "vue-property-decorator";
import Grouping from "@/components/Grouping.vue";
import BaseStep from "@/components/BaseStep.vue";
import {
  ApplicationStatuses,
  OnboardingApplication
} from "@/types/onboarding.types";
import MbsOnboardingContainer from "../../../OnboardingContainer";

@Component({
  //  component dependencies
  components: {
    Grouping
  }
})
export default class ApplicationSubmissionStep extends BaseStep {
  @Model() application?: OnboardingApplication;
  @Inject() container?: MbsOnboardingContainer;

  expandDetails = false;
  detailsInfo = "";
  isApplicationSubmitted = false;
  isApplicationAutoApproved = false;
  hasApplicationBeenRejected = false;
  hasErrors = false;
  isBusy = false;

  applicationIsInProgress() {
    console.log("Application is in review, need extra documents");
    // next phase is for document upload which is done as part of the next step
    this.goNext();
  }

  applicationIsSuccessful() {
    console.log("Application is successful");
    this.hasErrors = false;
    this.isApplicationSubmitted = true;
    this.isApplicationAutoApproved = true;
    this.hasApplicationBeenRejected = false;
    this.detailsInfo = `Application Id: ${this.application?.id}`;
    this.flowCompleted();
  }

  applicationIsRejected(error) {
    console.log("Application failed");
    this.hasErrors = false;
    this.isApplicationSubmitted = true;
    this.isApplicationAutoApproved = false;
    this.hasApplicationBeenRejected = true;
    this.detailsInfo = `Application Id: ${this.application?.id}\nError: ${error}`;
    this.flowCompleted();
  }

  async submitApplication() {
    this.isBusy = true;

    try {
      const res = await this.container?.ApplicationService.saveApplication(
        this.application!
      );

      this.isBusy = false;
      switch (res!.application!.applicationStatus) {
        case ApplicationStatuses.KycChallengeOnGoing:
          this.application = res?.application;
          this.applicationIsInProgress();
          break;
        case ApplicationStatuses.Success:
          this.application = res?.application;
          this.applicationIsSuccessful();
          break;
        case ApplicationStatuses.Failed:
          this.application = res?.application;
          this.applicationIsRejected("Application has been rejected");
          break;
        default:
          throw new Error(
            `Unknown application status '${
              res!.application!.applicationStatus
            }'`
          );
      }
      this.emit("application::submitted", this.application!);
    } catch (error) {
      console.log("Failed to submit application:" + error);
      this.hasErrors = true;
      this.detailsInfo = error;
      this.isApplicationSubmitted = true;
      this.isApplicationAutoApproved = false;
      this.isBusy = false;
      this.detailsInfo = `Application Id: ${this.application?.id ||
        "(none)"}\nError: ${error}`;
    }
  }
}
</script>

<style scoped>
.centerize {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
}

.centerize .row {
  padding-top: 10px;
  padding-bottom: 10px;
  display: inherit !important;
}

.action-btn {
  border-radius: 30px !important;
}

.details-row {
  display: flex;
  flex-direction: column;
}

.details-btn.v-btn:not(.v-btn--disabled) {
  border: none !important;
  color: grey !important;
  text-decoration: underline;
}

.details-btn.v-btn:hover {
  border: grey solid 1px !important;
  color: black !important;
  background-color: white !important;
  text-decoration: underline;
}
</style>