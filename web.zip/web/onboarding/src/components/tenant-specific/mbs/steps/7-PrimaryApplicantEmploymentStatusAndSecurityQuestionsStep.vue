<template>
  <v-form v-model="valid">
    <grouping label="Employment Status">
      <v-container>
        <v-row>
          <v-select
            id="application-primary-employmentstatus"
            :items="employmentStatuses"
            :item-text="item => item.text"
            :item-value="item => item.id"
            v-model="
              application.primaryApplicant.employmentDetails.employmentStatus
            "
            label="Employment Status"
            :rules="[v => v !== undefined]"
            outlined
            dense
            class="v-wrap"
          />
        </v-row>
        <v-row>
          <v-text-field
            id="application-primary-occupation"
            label="Occupation"
            v-model="application.primaryApplicant.employmentDetails.occupation"
            :value="application.primaryApplicant.employmentDetails.occupation"
            :rules="occupationRules"
            :maxLength="maxOccupationLen"
            dense
            outlined
          />
        </v-row>
        <!-- <v-row>
          <v-text-field
            id="application-primary-nameofemployerorcompany"
            label="Name of Employer/Company"
            v-model="
              application.primaryApplicant.employmentDetails.nameOfEmployer
            "
            :value="
              application.primaryApplicant.employmentDetails.nameOfEmployer
            "
            :rules="employerRules"
            :maxLength="maxEmployerLen"
            dense
            outlined
          />
        </v-row> -->
        <!-- <v-row>
          <p>
          Total Gross annual income including funds from all sources of income
          e.g. Pension, Dividends, Benefits etc.
          </p>
        </v-row>
        <v-row>
          <v-text-field
            id="application-primary-totalgrossincome"
            label="Total gross income"
            v-model="application.primaryApplicant.employmentDetails.totalGrossIncome"
            :value="application.primaryApplicant.employmentDetails.totalGrossIncome"
            :rules="[mustBePositiveNumberRule]"
            dense
            outlined
          />
        </v-row> -->
        <v-row>
          <v-select
            id="application-primary-accountusage"
            :items="accountUsages"
            :item-text="item => item.text"
            :item-value="item => item.id"
            v-model="
              application.primaryApplicant.employmentDetails.accountUsage
            "
            label="What will you use this account for?"
            dense
            outlined
            class="v-wrap"
          />
        </v-row>
        <v-row>
          <v-select
            id="application-primary-accountfundings"
            :items="accountFundings"
            :item-text="item => item.text"
            :item-value="item => item.id"
            v-model="
              application.primaryApplicant.employmentDetails.accountFunding
            "
            label="How will this account be funded?"
            dense
            outlined
            class="v-wrap"
          />
        </v-row>
        <v-row>
          <p>
            Approximately how much do you anticipate you will deposit into the
            account each month?
          </p>
        </v-row>
        <v-row>
          <v-text-field
            id="application-primary-estimatedMonthlydeposit"
            label="Estimated Monthly deposit"
            v-model="
              application.primaryApplicant.employmentDetails
                .estimatedMonthlydeposit
            "
            :value="
              application.primaryApplicant.employmentDetails
                .estimatedMonthlydeposit
            "
            :rules="monthlyDepositRules"
            dense
            outlined
          />
        </v-row>
      </v-container>
    </grouping>

    <grouping label="Security Questions">
      <v-container
        v-for="[
          idx,
          question
        ] in application.primaryApplicant.securityQuestions.entries()"
        :key="idx"
      >
        <v-row>
          <v-select
            :id="`application-primary-securityquestion-${idx}`"
            :items="securityQuestions"
            :item-text="item => item.text"
            :item-value="item => item.id"
            v-model="question.question"
            :label="`Security Question ${idx + 1}`"
            :rules="[questionShouldNotAlreadyUsed]"
            dense
            outlined
            class="v-wrap"
          />
        </v-row>
        <v-row>
          <v-text-field
            :id="`application-primary-securityquestion-${idx}-answer`"
            :label="`Answer to the Security Question ${idx + 1}`"
            v-model="question.answer"
            :rules="securityQuestionAnswerRule"
            :maxLength="maxSecurityQuestionAnswerLen"
            dense
            outlined
          />
        </v-row>
      </v-container>
    </grouping>
    <grouping label="Account PIN">
      <v-container>
        <v-row>
          <!-- <v-select
            :id="`application-primary-securityquestion-${idx}`"
            :items="securityQuestions"
            :item-text="item => item.text"
            :item-value="item => item.id"
            v-model="question.questionId"
            :label="`Security Question ${idx + 1}`"
            :rules="[questionShouldNotAlreadyUsed]"
            dense
            outlined
            class="v-wrap"
          /> -->
          <v-text-field
            id="application-primary-telephone-banking-pin"
            label="4 Digit E-Money account PIN"
            v-model="application.primaryApplicant.pin"
            :rules="[isRequiredRule]"
            maxLength="4"
            dense
            outlined
          />
        </v-row>
      </v-container>
    </grouping>
  </v-form>
</template>

<script lang="ts">
//  module imports
import Component from "vue-class-component";
import { Model } from "vue-property-decorator";

import Grouping from "@/components/Grouping.vue";
import BaseStep from "@/components/BaseStep.vue";
import {
  ApplicantAccountFunding,
  ApplicantAccountUsage,
  OnboardingApplication,
  SecurityQuestion,
  SecurityQuestions
} from "@/types/onboarding.types";
import DefaultValidationRules from "@/components/CommonValidationRules";

@Component({
  //  component dependencies
  components: {
    Grouping
  }
})
export default class PrimaryApplicantEmploymentStatusAndSecurityQuestionsStep extends BaseStep {
  @Model() application?: OnboardingApplication;

  readonly nbSecurityQuestions = 3;
  readonly maxOccupationLen = 50;
  readonly maxEmployerLen = 60;
  readonly maxSecurityQuestionAnswerLen = 20;

  isRequiredRule = DefaultValidationRules.isRequired;


  occupationRules = [
    DefaultValidationRules.isRequired,
    DefaultValidationRules.textLenWithin(3, this.maxOccupationLen)
  ];

  employerRules = [
    DefaultValidationRules.isRequired,
    DefaultValidationRules.textLenWithin(2, this.maxEmployerLen)
  ];

  securityQuestionAnswerRule = [
    DefaultValidationRules.isRequired,
    DefaultValidationRules.textLenWithin(2, this.maxSecurityQuestionAnswerLen)
  ];
  
  monthlyDepositRules = [
   DefaultValidationRules.mustBePositiveNumber,
   DefaultValidationRules.mustBeNotMoreThanTwoDecimalPoints,
   DefaultValidationRules.mustNotBeGreaterThan(7500),
  ];
  questionShouldNotAlreadyUsed = v => {
    const dups = this.application?.primaryApplicant?.securityQuestions.reduce(
      (a, sq) => (v === sq.question ? a + 1 : a),
      0
    );
    return dups == 1 || "You cannot use this question more than once";
  };

  constructor() {
    super();

    if (
      this.application !== undefined &&
      this.application.primaryApplicant !== undefined &&
      this.application.primaryApplicant.securityQuestions === undefined
    ) {
      this.application.primaryApplicant.securityQuestions = new Array<
        SecurityQuestion
      >(2);
      for (let i = 0; i < this.nbSecurityQuestions; i++) {
        this.application.primaryApplicant.securityQuestions[
          i
        ] = new SecurityQuestion();
      }
    }
  }

  accountFundings = [
    { id: ApplicantAccountFunding.SalaryWages, text: "Salary/Wages" },
    { id: ApplicantAccountFunding.Pension, text: "Pension" },
    { id: ApplicantAccountFunding.Benefits, text: "Benefits" },
    { id: ApplicantAccountFunding.StudentFunding, text: "Student funding" },
    { id: ApplicantAccountFunding.BusinessIncome, text: "Business income" },
    { id: ApplicantAccountFunding.Savings, text: "Savings" },
    { id: ApplicantAccountFunding.RentalIncome, text: "Rental income" },
    { id: ApplicantAccountFunding.Maintenance, text: "Maintenance" },
    { id: ApplicantAccountFunding.Other, text: "Other" }
  ];

  accountUsages = [
    { id: ApplicantAccountUsage.PayBills, text: "Paying bills" },
    { id: ApplicantAccountUsage.Saving, text: "Saving" },
    { id: ApplicantAccountUsage.Everything, text: "Everything" },
    { id: ApplicantAccountUsage.YouthAccount, text: "The youth account" }
  ];

  securityQuestions = [
    {
      id: SecurityQuestions.PrimarySchool,
      text: "What primary school did you attend?"
    },
    {
      id: SecurityQuestions.ChildhoodBestFriendName,
      text: "What was the name of your childhood best friend?"
    },
    {
      id: SecurityQuestions.WhenYoungerWhatDidYouWantToBe,
      text: "When you were younger, what did you want to be when grew up?"
    },
    {
      id: SecurityQuestions.MotherMaidenName,
      text: "What is your mother's maiden name?"
    },
    {
      id: SecurityQuestions.FirstCarMake,
      text: "What was the make of your first car?"
    },
    {
      id: SecurityQuestions.FirstHolidayAbroadDestination,
      text: "What was the destination of your first holiday abroad?"
    },
    {
      id: SecurityQuestions.ManagerNameAtFirstJob,
      text: "What is the name of your manager at your first job?"
    }
  ];
}
</script>
<style lang="scss" scoped>
.v-wrap {
  width: 0;
  white-space: nowrap;
  text-overflow: ellipsis;
}
</style>