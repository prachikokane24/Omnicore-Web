<template>
  <v-form v-model="valid">
    <grouping label="Contact Details">
      <v-container>
        <v-row>
          <v-text-field
            id="application-primary-emailaddress"
            label="Email Address"
            ref="emailAddress"
            v-model="application.primaryApplicant.contactDetails.emailAddress"
            :value="application.primaryApplicant.contactDetails.emailAddress"
            :rules="emailValidationRules"
            :maxLength="maxEmailLen"
            dense
            outlined
          />
        </v-row>
        <v-row>
          <v-text-field
            id="application-primary-emailaddresscheck"
            label="Confirm Email"
            ref="confirmEmailAddress"
            v-model="application.primaryApplicant.contactDetails.confirmEmailAddress"
            :value="application.primaryApplicant.contactDetails.confirmEmailAddress"
            :rules="confirmEmailValidationRules"
            :maxLength="maxEmailLen"
            dense
            outlined
          />
        </v-row>
        <v-row>
          <v-text-field
            id="application-primary-mobilephone"
            label="Mobile Telephone"
            v-model="mobilePhoneNumber"
            :value="mobilePhoneNumber"
            :rules="mobilePhoneNumberValidationRules"
            :maxLength="maxMobilePhoneLen"
            prefix="+44"
            v-mask="'###########'"
            dense
            outlined
          />
        </v-row>
      </v-container>
    </grouping>
  </v-form>
</template>
 
<script lang="ts">
//  module imports
import Component from "vue-class-component";
import { Model, Watch } from "vue-property-decorator";
import DefaultValidationRules from "@/components/CommonValidationRules";
import Grouping from "@/components/Grouping.vue";
import BaseStep from "@/components/BaseStep.vue";
import { OnboardingApplication } from "@/types/onboarding.types";
import { CommonUtil }  from "@/utils/common"

@Component({
  //  component dependencies
  components: {
    Grouping,
  },
})
export default class PrimaryApplicantContactDetailsStep extends BaseStep {
  @Model() application?: OnboardingApplication;

  readonly maxEmailLen = 50;
  readonly maxMobilePhoneLen = 11;

  mobilePhoneNumberBuffer?: string = undefined;

  check(v, field): boolean {
   if(!field) return true;
   return (v === field);
  }

  constructor() {
    super();
    if (this.application !== undefined && this.application.primaryApplicant !== undefined) {
      this.mobilePhoneNumberBuffer = this.application.primaryApplicant.contactDetails.mobilePhoneNumber;
    }
  }

  @Watch('application.primaryApplicant.contactDetails.emailAddress')
  async onEmailAddressChanged() {
    await this.$nextTick();
    if(this.application?.primaryApplicant?.contactDetails.confirmEmailAddress) {
      (this.$refs.confirmEmailAddress as Vue & { validate: () => boolean }).validate()
    }
  }

  @Watch('application.primaryApplicant.contactDetails.confirmEmailAddress')
  async onConfirmEmailAddress() {
    await this.$nextTick();
    if(this.application?.primaryApplicant?.contactDetails.emailAddress) {
     (this.$refs.emailAddress as Vue & { validate: () => boolean }).validate()
    }
  }

  confirmEmailIsEmpty(v,field): boolean {
    if(!field) return true;
    return v === field;
  }

  get mobilePhoneNumber(): string | undefined {
    return this.mobilePhoneNumberBuffer;
  }
  set mobilePhoneNumber(val: string | undefined) {
    const newVal = CommonUtil.trimLeadingZero(val!);
    this.mobilePhoneNumberBuffer = newVal;    
    this.application!.primaryApplicant!.contactDetails.mobilePhoneNumber = `+44${newVal}`;
  }

  emailValidationRules = [
    DefaultValidationRules.isEmailAddress,
    DefaultValidationRules.textLenWithin(5, this.maxEmailLen),
    v => this.confirmEmailIsEmpty(v,this.application?.primaryApplicant?.contactDetails.confirmEmailAddress) || 'Emails must match',  
  ];
  
  confirmEmailValidationRules = [
    DefaultValidationRules.isEmailAddress,
    DefaultValidationRules.textLenWithin(5, this.maxEmailLen),
    v => v === this.application?.primaryApplicant?.contactDetails.emailAddress || 'Emails must match',   
  ];

  mobilePhoneNumberValidationRules = [
    DefaultValidationRules.isRequired,    
    DefaultValidationRules.isPhoneNumber
  ];
}
</script>
