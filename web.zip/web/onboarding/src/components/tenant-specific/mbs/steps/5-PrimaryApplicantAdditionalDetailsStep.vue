<template>
  <v-form v-model="valid">
    <grouping label="Citizenship">
      <v-container>
        <v-row>
          <v-text-field
            id="application-primary-nationalinsurancenumber"
            label="National Insurance Number"
            v-model="
              application.primaryApplicant.additionalDetails
                .nationalInsuranceNumber
            "
            :value="
              application.primaryApplicant.additionalDetails
                .nationalInsuranceNumber
            "
            :rules="nationalInsuranceValidationRules"
            :maxLength="maxNationalInsuranceLen"
            dense
            outlined
          />
        </v-row>
        <v-form ref="form">
          <country-list
            :id="`application-primary-nationality-primary`"
            v-model="primaryNationality"
            ref="primaryNationality"
            topOfListCountry="GBR"
            label="Nationality"
            :rules="nationalityRules"
            :displayNationality=true
          />
        </v-form>
        <country-list
          id="application-primary-countryofbirth"
          v-model="
            application.primaryApplicant.additionalDetails.countryOfBirth
          "
          topOfListCountry="GBR"
          label="Country of birth"
          :rules="[countryRequiredRule]"
        />
        <v-row>
          <v-text-field
            id="application-primary-cityortownofbirth"
            label="City/Town of birth"
            v-model="
              application.primaryApplicant.additionalDetails.cityTownOfBirth
            "
            :value="
              application.primaryApplicant.additionalDetails.cityTownOfBirth
            "
            :rules="cityTownOfBirthValidationRules"
            :maxLength="maxCityTownOfBirthLen"
            dense
            outlined
          />
        </v-row>
      </v-container>
    </grouping>
  </v-form>
</template>

<script lang="ts">
//  module imports
import Component from "vue-class-component";
import { Model, Watch } from "vue-property-decorator";
import CountryList from "@/components/CountryList.vue";
import Grouping from "@/components/Grouping.vue";
import BaseStep from "@/components/BaseStep.vue";
import { OnboardingApplication } from "@/types/onboarding.types";
import DefaultValidationRules from "@/components/CommonValidationRules";

@Component({
  components: {
    CountryList,
    Grouping
  }
})
export default class PrimaryApplicantAdditionalDetailsStep extends BaseStep {
  @Model() application?: OnboardingApplication;

  readonly maxCityTownOfBirthLen = 60;
  readonly maxNationalInsuranceLen = 11;
  readonly noDualNationalityValue = "NONE";
  primaryNationalityBuffer = "";
  secondaryNationalityBuffer = "";

  constructor() {
    super();
    if (
      this.application !== undefined &&
      this.application?.primaryApplicant !== undefined &&
      (this.application?.primaryApplicant?.additionalDetails.nationalities ===
        undefined ||
        this.application?.primaryApplicant?.additionalDetails.nationalities
          .length != 2)
    ) {
      this.application.primaryApplicant.additionalDetails.nationalities = [];
    }
  }

  get primaryNationality(): string {
    return this.primaryNationalityBuffer;
  }
  set primaryNationality(countryIsoCode: string) {
    this.primaryNationalityBuffer = countryIsoCode;
    this.updateNationalities();
  }

  get secondNationality() {
    return this.secondaryNationalityBuffer;
  }
  set secondNationality(countryIsoCode: string) {
    this.secondaryNationalityBuffer = countryIsoCode;
    this.updateNationalities();
  }

  @Watch("primaryNationalityBuffer")
  async onPrimaryNationalityChanged() {
    await this.$nextTick();
    if (this.getSecondaryNationalityBuffer()) {
      (this.$refs.form as Vue & { validate: () => boolean }).validate();
    }
  }

  @Watch("secondaryNationalityBuffer")
  async onSecondayNationalityChanged() {
    await this.$nextTick();
    if (this.getPrimaryNationalityBuffer()) {
      (this.$refs.form as Vue & { validate: () => boolean }).validate();
    }
  }

  // required because the rule seems to be unable to retrieve the value
  // dynamically in any other way
  getPrimaryNationalityBuffer() {
    return this.primaryNationalityBuffer;
  }
  getSecondaryNationalityBuffer() {
    return this.secondaryNationalityBuffer;
  }

  updateNationalities() {
    this.application!.primaryApplicant!.additionalDetails.nationalities = [];
    if (
      this.primaryNationalityBuffer !== undefined &&
      this.primaryNationalityBuffer !== ""
    ) {
      this.application!.primaryApplicant!.additionalDetails.nationalities.push(
        this.primaryNationalityBuffer
      );
    }

    if (
      this.secondaryNationalityBuffer !== undefined &&
      this.secondaryNationalityBuffer !== "" &&
      this.secondaryNationalityBuffer !== this.noDualNationalityValue
    ) {
      this.application!.primaryApplicant!.additionalDetails.nationalities.push(
        this.secondaryNationalityBuffer
      );
    }
  }

  //
  // Validation rules
  nationalInsuranceValidationRules = [
    v => !v || DefaultValidationRules.isValidNationalInsuranceNumber(v)
  ];
  countryRequiredRule = DefaultValidationRules.isRequired;
  cityTownOfBirthValidationRules = [
    DefaultValidationRules.isRequired,
    DefaultValidationRules.textLenWithin(2, this.maxCityTownOfBirthLen)
  ];

  nationalityRules = [
    DefaultValidationRules.isRequired,
    DefaultValidationRules.isNotSame(
      () => this.getSecondaryNationalityBuffer(),
      "Primary nationality cannot be the same as secondary"
    )
  ];
  dualNationalityRules = [
    DefaultValidationRules.isRequired,
    DefaultValidationRules.isNotSame(
      () => this.getPrimaryNationalityBuffer(),
      "Secondary nationality cannot be the same as primary"
    )
  ];
}
</script>