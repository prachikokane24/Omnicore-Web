<template>
  <grouping label="Secure Customer Auth">
    <v-container>
      <v-alert
        v-show="hasErrors"
        dense
        type="error"
        id="application-otp-invalidotpalert">
        {{ errorMessage }} 
      </v-alert>
      <v-alert
        v-show="isOtpCheckSuccessful"
        type="success"
        dense
        id="application-otp-sucessalert">
        Your mobile number has been successfully verified.
      </v-alert>
      <v-alert
        v-show="isOtpSentSuccessfully && !hasErrors && actionStage==='Verify Code'"
        type="info"
        dense
        id="application-otp-otpsendalert"> 
        OTP code has been sent to your mobile.
      </v-alert>
      <v-container
        v-show="isOtpSentSuccessfully"
        style="padding: 0px"
      >
        <v-row class="otp-row">
          <v-text-field
            id="application-otp"
            class="otp-field"
            height="80px"
            label="One Time Passcode"
            v-if="actionStage !== 'Completed!'"
            v-model="otp"
            :value="otp"
            v-mask="'######'"
            dense
            outlined
          />
        </v-row>
      </v-container>
      <v-row v-show="showProcedure">
        <p>
          We need to send a one time passcode to confirm your phone number. When
          received, please enter the 6 digits code below to continue..
        </p>
      </v-row>
      <v-row v-show="showResendCode"> </v-row>
     
      <v-row class="action-div">
        <v-btn
          id="application-primary-performaction"
          :loading="isBusy"
          x-large
          @click="performAction"
          class="action-btn"
          v-show="!isOtpCheckSuccessful"
        >
          <v-icon>mdi-transfer-right</v-icon>{{ actionStage }}
        </v-btn>
      </v-row>

       <v-row class="action-div" style="padding-top: 10px" v-if="showResendCode">
        <v-btn
          id="application-primary-resendbtn"
          @click="sendCode"
          small
          class="resendcode-btn"
        >
          <v-icon>mdi-transfer-right</v-icon>Send new code
        </v-btn>
      </v-row>
    </v-container>
  </grouping>
</template>
 
<script lang="ts">
//  module imports
import Component from "vue-class-component";
import Grouping from "@/components/Grouping.vue";
import BaseStep from "@/components/BaseStep.vue";
import { OneTimePasswordStatus } from "@/services/OTPService"
import { Inject, Model } from "vue-property-decorator";
import { OnboardingApplication } from "@/types/onboarding.types";
import MbsOnboardingContainer from "../OnboardingContainer";

enum Stages {
  SendCode = "Send Code",
  VerifyCode = "Verify Code",
  VerifOk = "Completed!",
}

@Component({
  //  component dependencies
  components: {
    Grouping,
  },
})
export default class SecureCustomerAuth extends BaseStep {
  @Model() application?: OnboardingApplication;
  @Inject() container?: MbsOnboardingContainer;

  readonly TimeBeforeCanResend = 1000 * 20;

  otp?: string = "";
  useOtpServiceMock = true;

  otpSessionId = ""; 
  isBusy = false;
  hasErrors = false;
  isOtpCheckSuccessful = false;
  isOtpSentSuccessfully = false;
  showResendCode = false;
  canResend = false;
  showProcedure = true;
  actionStage = Stages.SendCode;
  errorMessage = ""; // 

  constructor() {
    super();
    this.valid = false;
  }

  sendCode() {
    this.isBusy = true;
    this.showResendCode = false;

    // call OTP Provider here
    this.container?.OTPService.sendOTP(this.application?.primaryApplicant?.contactDetails.mobilePhoneNumber || "")
      .then(response => {
        if (response.status === OneTimePasswordStatus.FailureOnOTPCreation) {
          this.isBusy = false;
          this.isOtpSentSuccessfully = false;
          this.hasErrors = true;
          this.showProcedure = true;
          this.showResendCode = false;
          this.canResend = false;
          this.errorMessage = `Failed to send the code to your mobile phone; please retry.`;
          return;
        }

        this.otpSessionId = response.sessionId!;
        this.isBusy = false;
        this.isOtpSentSuccessfully = true;
        this.showProcedure = false;
        this.canResend = true;
        this.hasErrors = false;
        this.actionStage = Stages.VerifyCode;

        // if the person is trying for more that x min, we offer
        // the possibility to
        setTimeout(
          () => { if (this.canResend && this.actionStage !== Stages.VerifOk) this.showResendCode = true; }, 
          this.TimeBeforeCanResend
        );
      })
      .catch(error => {
        this.isBusy = false;
        this.isOtpSentSuccessfully = false;
        this.hasErrors = true;
        this.showProcedure = true;
        this.showResendCode = false;
        this.canResend = false;
        this.errorMessage = `Failed to send the code to your mobile phone; please retry. Error: ${error}`
      });
  }

  verifyCode() {
    this.isBusy = false;
    this.container?.OTPService.verifyOTP(
      this.otpSessionId, 
      this.application?.primaryApplicant?.contactDetails.mobilePhoneNumber || "", 
      this.otp || "")
      .then(response => {

        if (response === OneTimePasswordStatus.Valid) {
          this.isOtpCheckSuccessful = true;
          this.actionStage = Stages.VerifOk;
          this.showProcedure = false;
          this.valid = true;
          this.hasErrors = false;
          this.canResend = false;
          this.showResendCode = false;
        }
        else {
          this.isOtpCheckSuccessful = false;
          this.hasErrors = true;
          this.showProcedure = false;
          this.errorMessage = `Invalid One Time Passcode. Please check and retry`;
        }
      })
      .catch(error => {
        this.isOtpCheckSuccessful = false;
        this.hasErrors = true;
        this.showProcedure = false;
        this.errorMessage = `Failed to confirmed the One Time Passcode. Please check and try again. Error: ${error}`;
      });
  }

  performAction() {
    this.isBusy = true;

    switch (this.actionStage) {
      case Stages.SendCode:
        this.sendCode();        
        break;

      case Stages.VerifyCode:
        this.verifyCode();
        break;
    }
  }
}
</script>
<style >

.otp-row {
  max-width: 200px;
  margin: 0 auto;
}

.otp-field {
  width: 140px;
  font-size: 30px !important;
}

.otp-field input {
  font-size: 30px !important;
  letter-spacing: 10px;
  text-align: center;
}

.action-div {
  justify-content: center;
}

.action-btn {
  border-radius: 30px !important;
}
</style>