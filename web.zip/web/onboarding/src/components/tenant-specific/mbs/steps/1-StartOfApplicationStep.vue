<template>
  <v-form v-model="valid">
    <grouping label="Account Type">
      <v-select
        dense
        outlined
        id="account-type"
        :items="accountTypes"
        :item-text="item => item.text"
        :item-value="item => item.id"
        v-model="application.accountType"
        label="Choose Account Type"
        :rules="accountTypeValidationRules"
      />
    </grouping>
    <v-spacer />
    <grouping label="Residency">
      <v-container>
        <v-row><p>Are all applicants permanent UK residents?</p></v-row>
        <v-radio-group
          id="application-residency"
          v-model="application.primaryApplicant.residencyStatus.UkPermResident"
          :rules="[
            mustBeTrue('Our current account is only available to UK residents')
          ]"
          row
        >
          <v-radio
            label="Yes"
            id="application-residency-yes"
            :value="true"
          ></v-radio>
          <v-radio
            label="No"
            id="application-residency-no"
            :value="false"
          ></v-radio>
        </v-radio-group>
        <v-row
          ><p>
            Are all applicants permanent UK or EEA nationals or have indefinite
            leave to remain in the UK?
          </p></v-row
        >
        <v-radio-group
          id="application-allApplicantsUkOrEEANationalsOrHaveIRL"
          v-model="application.primaryApplicant.residencyStatus.UkOrEEANational"
          :rules="[
            mustBeTrue(
              'Our current account is only available to UK, EEA nationals or those with indefinite leave to remain'
            )
          ]"
          row
        >
          <v-radio
            label="Yes"
            id="application-allApplicantsUkOrEEANationalsOrHaveIRL-yes"
            :value="true"
          ></v-radio>
          <v-radio
            label="No"
            id="application-allApplicantsUkOrEEANationalsOrHaveIRL-no"
            :value="false"
          ></v-radio>
        </v-radio-group>
      </v-container>
    </grouping>
    <grouping label="Your Privacy">
      <v-container>
        <v-row>
          <p>
            In order to proceed with your application, you must confirm that you
            have read and accept our privacy
          </p>
        </v-row>
        <v-row>
          <v-checkbox
            id="application-confirmreadpolicy"
            v-model="application.primaryApplicant.confirmReadPolicy"
            :rules="[mustBeTrue('You need to confirm to continue')]"
            label="I confirm"
          />
        </v-row>
      </v-container>
    </grouping>
  </v-form>
</template>

<script lang="ts">
//  module imports
import { Inject, Model } from "vue-property-decorator";
import Component from "vue-class-component";
import {
  Applicant,
  AccountType,
  ApplicationType,
  OnboardingApplication
} from "@/types/onboarding.types";
import DefaultValidationRules from "@/components/CommonValidationRules";
import BaseStep from "@/components/BaseStep.vue";
import Grouping from "@/components/Grouping.vue";

@Component({
  components: { Grouping }
})
export default class StartOfApplicationStep extends BaseStep {
  @Model() application: OnboardingApplication|undefined;

  constructor() {
    super();

    if (
      this.application !== undefined &&
      this.application?.primaryApplicant === undefined
    ) {
      this.application.primaryApplicant = new Applicant();

      this.application!.applicationType = ApplicationType.AdultSole;    
      this.application!.accountType = AccountType.eMoneyAccount;
    }   
  }

  accountTypeValidationRules = [DefaultValidationRules.isRequired];
  mustBeTrue = DefaultValidationRules.mustBeTrue; 

  isUKResident?: boolean;
  allApplicantsUkOrEEANationalsOrHaveIRL?: boolean;
  confirmInfoAccurate = false;

  accountTypes = [
    { text: "Adult Sole account", id: AccountType.eMoneyAccount }
  ];
}
</script>