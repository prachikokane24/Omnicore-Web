<template>
  <v-container style="padding: 0px;">
    <v-row class="pb-0" v-if="!hideSearch">
      <v-text-field
        :data-id="`${dataIDPrefix}-loquate`"
        prepend-icon="mdi-map-search"
        label="Start typing your address to search"
        v-model.lazy.trim="search"
        :loading="isLoading"
        dense
        outlined
        filled
      />
    </v-row>
    <v-row class="mb-4">
      <div v-if="showList" style="width: 100%">
        <p>
          <strong>
            <span v-if="search"
              >{{ items.length }} addresses found containing "{{
                search
              }}". </span
            >
            <span v-if="items.length > 0">Please choose your address from the options below.</span>
            <span v-else>Please manually enter your address.</span>
          </strong>
        </p>
        <p></p>
        <ul class="addresses" v-if="items.length > 0">
          <li v-for="(item, index) in items" :key="index">
            <a @click.prevent="handleFullAddress(item.Id, item.Type)">{{
              item.Description
            }}</a>
          </li>
        </ul>
      </div>
    </v-row>
    <div>
      <v-row>
        <v-text-field
          :data-id="`${dataIDPrefix}-housenameornumber`"
          label="House Name or Number"
          v-model="address.building"
          :value="address.building"
          :rules="houseNameOrNumberRules"
          :maxLength="maxHouseNameLen"
          dense
          outlined
        />
      </v-row>
      <v-row>
        <v-text-field
          :data-id="`${dataIDPrefix}-street`"
          label="Address Line 1"
          v-model="address.line2"
          :value="address.line2"
          :rules="streetRules"
          :maxLength="maxStreetLen"
          dense
          outlined
        />
      </v-row>
      <v-row>
        <v-text-field
          :data-id="`${dataIDPrefix}-addrline2`"
          label="Address Line 2 ( optional )"
          v-model="address.line3"
          :value="address.line3"
          dense
          outlined
        />
      </v-row>
      <v-row>
        <v-text-field
          :data-id="`${dataIDPrefix}-townorcity`"
          label="Town or City"
          v-model="address.city"
          :value="address.city"
          :rules="townOrCityRules"
          :maxLength="maxTownOrCityLen"
          dense
          outlined
        />
      </v-row>
      <v-row>
        <v-text-field
          :data-id="`${dataIDPrefix}-county`"
          label="County"
          v-model="address.state"
          :value="address.state"
          dense
          outlined
        />
      </v-row>
      <v-row>
        <v-text-field
          :data-id="`${dataIDPrefix}-postcode`"
          label="Postcode"
          v-model="address.postalCode"
          :value="address.postalCode"
          :rules="postalCodeRules"
          :maxLength="maxPostalCodeLen"
          dense
          outlined
        />
      </v-row>
    </div>
  </v-container>
</template>

<script lang="ts">
//  module imports
import LoqateApi from "../utils/loqateClient.js";
import Component from "vue-class-component";
import Vue from "vue";
import { Prop, Watch } from "vue-property-decorator";
import DefaultValidationRules from "./CommonValidationRules";

@Component
export default class ApplicantAddress extends Vue {

 mounted() {
    this.address["country"] = "GBR";
  }
  
  @Prop({ required: true }) readonly dataIDPrefix?: string;

readonly maxPostalCodeLen = 10;
  readonly maxStreetLen = 36;
  readonly maxTownOrCityLen = 58;
  readonly maxHouseNameLen = 24;

  timer = 0;
  address = {};
  showList = false;
  hideSearch = false;
  search = null;
  model = null;
  tab = null;
  isLoading = false;
  entries = { Items: [] };
  addressSelected = false;

  api = new LoqateApi({
    key: "GT66-UB28-KJ97-JZ93",
    countries: ["GB"]
  });

  postalCodeRules = [
    DefaultValidationRules.isRequired,
    DefaultValidationRules.textLenWithin(2, this.maxPostalCodeLen)
  ];

  streetRules = [
    DefaultValidationRules.isRequiredCustom('Please provide the first line of your address.'),
    DefaultValidationRules.textLenWithin(2, this.maxStreetLen)
  ];

  townOrCityRules = [
    DefaultValidationRules.isRequired,
    DefaultValidationRules.textLenWithin(2, this.maxTownOrCityLen)
  ];

  houseNameOrNumberRules = [
    DefaultValidationRules.isRequired,
    DefaultValidationRules.textLenWithin(1, this.maxHouseNameLen)
  ];

  postcode?: string;
  houseNameOrNumber?: string;
  street?: string;
  addressLine2?: string;
  townOrCity?: string;
  county?: string;

  @Watch("search")
  handleChange() {
    this.handleSearch();
  }

  @Watch("address", { deep: true })
  emit() {
    console.log(this.address);
    // N.B. Slight delay required for validation to complete, in PrimaryApplicantAddressStep, after UI is updated with model changes
    setTimeout(() => this.$emit("input", this.address), 200);
  }

  async handleSearch() {
    if (!this.search) return;
    this.showList = true;
    this.isLoading = true;

    try {
      this.entries = await this.api.getAddresses(this.search);
    } catch (e) {
      console.log(e);
    } finally {
      this.isLoading = false;
    }
  }

  async handleFullAddress(id, type) {
    this.showList = false;
    if (type == "Postcode" || type == "Street") {
      this.showList = true;
      this.isLoading = true;
      try {
        this.entries = await this.api.getAddressesByPostcode(id);
      } catch (e) {
        console.log(e);
      } finally {
        this.isLoading = false;
      }
      return;
    }

    try {
      const fullAddress = await this.api.getAddress(id);
      const {
        PostalCode,
        BuildingNumber,
        BuildingName,
        Street,
        Line2,
        City,
        Province
      } = fullAddress["Items"][0];
      this.addressSelected = true;
      this.address = {
        postalCode: PostalCode,
        building: BuildingNumber + " " + BuildingName,
        line2: Street,
        line3: Line2,
        city: City,
        state: Province,
        country: "GBR"
      };
    } catch (e) {
      console.log(e);
    }

    this.search = null;
  }

  get items() {
    return (
      this.entries.Items.map(({ Id, Text, Type, Description }) => {
        return {
          Id,
          Type,
          Description: Text + " " + Description
        };
      }) || []
    );
  }
}
</script>

<style lang="scss" scoped>
.addresses {
  list-style: none;
  width: 100%;
  margin: 0;
  padding: 0;
  max-height: 160px;
  overflow: scroll;
  border: 1px solid grey;
  li {
    width: 100%;
    padding: 3.5px 10px;
    a {
      display: block;
    }
    &:hover {
      background-color: #eee;
    }
  }
}
::-webkit-scrollbar {
  /* required, although an apparent no-op */
  color: inherit;
}
::-webkit-scrollbar-thumb {
  /* leave most bars alone */
  background-color: grey;
}
</style>