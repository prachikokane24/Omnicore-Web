<template>
  <v-container class="mb-6" v-if="status">
    <v-row align="center">
      <v-col key="1" id="col-1">
        <v-card class="pa-2" outlined tile> 
          <template v-if="isDoubleSided === true"> 
                <p class="bold"> FRONT SIDE </p>
          </template>
            
          <div  v-if="isPdf() === true"  :class="overlayClass">        
            <vue-pdf-embed  ref="pdfRef" :source="model.imageSrc" :page="1" height="450" />         
          </div>
          <div style="display: flex;justify-content: center;" v-else :class="overlayClass">
            <img :src="model.imageSrc" />
          </div>
        </v-card>
      </v-col>

      <v-col key="2" id="col-2">
        <v-card class="pa-2" outlined tile>
            <v-container v-if="selfie" fill-height>
              <v-card-text v-if="isInvalid()">
                <p>
                  There may be an issue with the image captured. Please ensure you have checked the following:
                </p>
                <ul> 
                  <li v-for="(item, index) in proTips" v-bind:key="index">{{item}}</li>
                </ul>
                <p>
                  If you have completed the above and you are still having issues then please select 
                  “Send for review” to progress while someone from our team helps.
                </p>
                <v-container class="centerize">
                  <v-row>
                    <v-btn
                      @click="retake()"
                      class="secondary"
                      large
                      rounded>
                      Retake
                    </v-btn>
                    <v-spacer />
                    <v-btn
                      @click="review()"
                      :loading="isPerformingUpload"
                      class="primary"
                      large
                      rounded>
                      Send for review
                    </v-btn>
                  </v-row>
                </v-container>
              </v-card-text>
              <v-card-text v-else class="valid">
                {{ validMessageText }}
                <v-container class="centerize">
                  <v-row>
                    <v-btn
                      @click="retake()"
                      class="secondary"
                      large
                      rounded>
                      Retake
                    </v-btn>
                  </v-row>
                </v-container>
              </v-card-text>
            </v-container>
            <v-container v-else fill-height>
              <v-card-text v-if="isInvalid()">
                <template>
                  <p v-html="getInvalidReasonText()" />
                  <ul> 
                    <li v-for="(item, index) in proTips" v-bind:key="index">{{item}}</li>
                  </ul>
                  <p>
                    If you have completed the above and you are still having issues then please select 
                    “Send for review” to progress while someone from our team helps.
                  </p>
                  <v-container class="centerize">
                    <v-row>
                      <v-btn
                        @click="retake()"
                        class="secondary"
                        large
                        rounded>
                        Retake
                      </v-btn>
                      <v-spacer />
                      <v-btn
                        @click="review()"
                        :loading="isPerformingUpload"
                        class="primary"
                        large
                        rounded>
                        Send for review
                      </v-btn>
                    </v-row>
                  </v-container>
                </template>
              </v-card-text>
              <v-card-text v-else class="valid">
                {{ validMessageText }}
              </v-card-text>
            </v-container>
        </v-card>
      </v-col>
    </v-row>
    
    <v-row align="center" v-if="isDoubleSided === true">
      <v-col key="1">
        <v-card class="pa-2" outlined tile>  <p class="bold"> REAR SIDE </p>  
          <div  v-if="isPdf() === true"  :class="overlayClass">        
           <vue-pdf-embed  ref="pdfRef" :source="model.dependantDocumentImageSrc" :page="1" />         
           </div>
          <div style="display: flex;justify-content: center;" v-else :class="overlayClass">
            <img  :src="model.dependantDocumentImageSrc" />
          </div>
        </v-card>
      </v-col>
      <v-col key="2">
      </v-col>
    </v-row>
  </v-container>
</template>

<script lang="ts">
import Vue from "vue";
import Component from "vue-class-component";
import { Model, Prop } from "vue-property-decorator";
import VuePdfEmbed from 'vue-pdf-embed/dist/vue2-pdf-embed';
import {
  DocumentValidationStatus,
  DrivingLicenceValidationResponse,
  IdentityCardValidationResponse,
  PassportValidationResponse,
  ProofOfAddressValidationResponse,
  SelfieValidationResponse,
} from "@/services/OnboardingApplicationService";
import {
  BaseDocumentValidationResponse,
  DocumentValidationReason,
} from "../services/OnboardingApplicationService";


@Component({
  components: {
    'vue-pdf-embed': VuePdfEmbed
  }
})

export default class QualityCheck extends Vue {
  @Model() model: any;
  @Prop({ required: true }) status?: DocumentValidationStatus | null;
  @Prop({ required: true }) isPerformingUpload?: boolean;
  @Prop({ required: true }) isDoubleSided?: boolean;
  @Prop() address?: ProofOfAddressValidationResponse;
  @Prop() drivingLicence?: DrivingLicenceValidationResponse;
  @Prop() identityCard?: IdentityCardValidationResponse;
  @Prop() passport?: PassportValidationResponse;
  @Prop() selfie?: SelfieValidationResponse | null;
  @Prop() overlayClass?: string;
  @Prop() readonly proTips?: [];
  @Prop() validMessageText?: string;

  isInvalid() {
    return this.status !== DocumentValidationStatus?.Valid;
  }

  isPdf(){
    return this.model.file?.type=== "application/pdf"
  }

  getInvalidReasonText() {
    const documentValidationResponse = (this.address ?? this.drivingLicence ?? this.identityCard ?? this.passport) as BaseDocumentValidationResponse;

    if (
      !documentValidationResponse ||
      documentValidationResponse.status == DocumentValidationStatus.Valid
    ) {
      return "";
    }

    const preReasonText =
      "We've checked the document image provided and have noticed that - <br /><br />";
    const postReasonText =
      "<br /><br />Please check the image against the hints provided and try the document capture &amp; upload again.";
    let messageText = "";

    if (
      documentValidationResponse &&
      documentValidationResponse!.reasons!.length !== 0 &&
      documentValidationResponse!.reasons!.includes(
        DocumentValidationReason.ExpiryDateInvalid
      )
    ) {
      messageText = `${preReasonText} The uploaded document has expired. Please upload a valid document. ${postReasonText}`;
    } else if (
      documentValidationResponse &&
      documentValidationResponse!.reasons!.length !== 0 &&
      documentValidationResponse!.reasons!.includes(DocumentValidationReason.NoDataExtracted)
    ) {
      messageText = `${preReasonText} We've had problems reading the document image. ${postReasonText}`;
    } else {
      messageText = "We've checked the document provided and have noticed that - <br /><br /> " 
        + "There maybe an issue with the document captured."
        + "<br /><br />Please check the document against the hints provided and try the document capture &amp; upload again.";
    }

    return messageText;
  }

  retake() {
    this.$emit("retake");
  }

  review() {
    this.$emit("review");
  }
}
</script>

<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";

.container > .row > .col:first-child > .v-card {
  background: #bfbfbf;
  border-radius: 8px !important;
}

.container > .row > .col > .v-card {
  background: #fff;
  border-radius: 8px !important;
}

.container > .row > .col > .v-card > div {
  background: #fff;
}

.centerize {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
}

.centerize .row {
  padding-top: 10px;
  padding-bottom: 10px;
  display: inherit !important;
}

.container > .row > .col > .v-card > div.selfie-overlay {
  background: #bfbfbf;
  clip-path: ellipse(170px 200px at 50% 50%);
}

.spacer {
  margin: 0 25px;
}

.valid { 
  display: flex;
  flex-direction: column;
  justify-content: center;
  // align-items: center;
  text-align: center;
  max-height: 420px;
}

.vue-pdf-embed > div {
  margin-bottom: 8px;
  box-shadow: 0 2px 8px 4px rgba(0, 0, 0, 0.1);
  max-height: 400px; 
}

p.bold{
  font-weight: bold;
  font-size: xx-large;
}
img {
     margin: auto;
     max-height: 400px;
 }

img { max-height: 400px; }

#col-1 .v-card, #col-2 .v-card { 
  height: 420px; 
  overflow: auto; 
}

ul { margin-bottom: 20px; }

@media only screen and (max-width: 1474px) {
    #col-2 p, #col-2 ul { 
      margin: 5px auto;
      width: 90%;
    }
}

@media only screen and (max-width: 600px) {
  .selfie-overlay {
    clip-path: ellipse(38% 46% at 50% 50%)  !important;
  }

  #col-1, #col-2 {
    flex-basis: 100%;
    flex-grow: 2;
  }

  #col-1 .v-card, #col-2 .v-card { 
    height: 50%; 
    overflow: auto;
  }
 
  #col-2 > .v-card > div > .container {
     margin-top: 0;
   }

  .spacer { margin: 0 5px; }

  img, .vue-pdf-embed > div { max-height: 300px; 
                              max-width: 100%;
                              width: 100%;
                            }
}
</style>