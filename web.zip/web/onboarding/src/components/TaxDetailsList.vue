<template>
  <v-container style="padding: 0px" >
    <p>{{ `Are you a ${mode} for tax purposes of anywhere other than the UK?` }}</p>
    <v-radio-group
      :id="`application-tax-${mode}-choice`"
      v-model="isAForTaxPurposes"
      style="margin-top:0px important!; padding-top:0px important!"
      row>
      <v-radio label="Yes" :id="`application-tax-${mode}-yes`" :value="true"></v-radio>
      <v-radio label="No" :id="`application-tax-${mode}-no`" :value="false"></v-radio>
    </v-radio-group>

    <v-container v-show="isAForTaxPurposes" style="padding: 0px">
      <v-container 
        style="padding-left: 5px; padding-right: 5px"
        v-for="[idx, ] in taxCountries.entries()" 
        :key="idx"
        >
        <p><b>Country #{{ idx + 1}}</b></p>
        <tax-details 
          @taxCountryChanged="onTaxCountryChagned(idx, $event)"
          :taxDetails="taxCountries[idx]"
          :rules="[mustBeUnique(idx)]"
          :idPrefix="`application-tax-${mode}-details-${idx}`"
        />
        <v-btn 
          small 
          rounded
          :id="`application-tax-${mode}-removecountrybtn-${idx}`"
          @click="removeTaxCountry(idx)" 
          v-if="taxCountries[idx].taxCountry !== '' && idx !== 0">
          Remove
        </v-btn>
        <v-divider 
          style="margin-top:10px; margin-bottom:10px" 
          v-if="taxCountries.length > 1 && idx !== taxCountries.length - 1"
        />
      </v-container>
      <v-btn 
        small 
        rounded 
        :id="`application-tax-${mode}-addcountrybtn`"
        v-if="taxCountries.length < maxTaxCountries"
        @click="addAnotherTaxCountry()">
        Add another</v-btn>
    </v-container>
  </v-container>
</template>

<script lang="ts">
//  module imports
import Component from "vue-class-component";
import Vue from "vue";
import CountryList from "./CountryList.vue";
import TaxDetails from "./TaxDetails.vue";
import { Model, Prop } from "vue-property-decorator";
import { TinDetails } from "@/types/onboarding.types";
import DefaultValidationRules from "./CommonValidationRules";

@Component({
  //  component dependencies
  components: {
    CountryList,
    TaxDetails
  },
})
export default class TaxDetailsList extends Vue {
  @Prop({ required: true }) readonly mode?: string;
  @Prop({ required: true }) readonly idPrefix?: string;
  @Prop() readonly rules?: Array<Function>;
  @Model() taxCountries: TinDetails[] = [];

  readonly maxTaxCountries = 3;
  
  // https://vuejs.org/v2/guide/reactivity.html#For-Arrays

  isAForTaxPurposesBuffer = false;
  get isAForTaxPurposes() {
    return this.isAForTaxPurposesBuffer;
  } 
  set isAForTaxPurposes(val) {
    this.isAForTaxPurposesBuffer = val;
    if (val && this.taxCountries.length === 0) {
      this.taxCountries.push(new TinDetails());
    }
    if (!val) {
      // dont use "= []" to clear as Vue looses reactivity on it somehow
      this.taxCountries.length = 0;
    }
  }

  addAnotherTaxCountry() {
    this.taxCountries.push(new TinDetails());
  }

  removeTaxCountry(idx) {
    this.taxCountries.splice(idx, 1);
    if (this.taxCountries.length === 0) {
      this.taxCountries.push(new TinDetails());
    }
  }

  mustBeUnique(idx) {
    return val => {
      return this.taxCountries.every((t,i,a) => i === idx || t.taxCountry !== this.taxCountries[idx].taxCountry) || "You cannot select a country multiple times";
    }
  }
}
</script>
