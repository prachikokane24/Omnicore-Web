<template>
  <v-container>
    <v-stepper
      v-model="stepIdx"
      class="elevation-0"
      ref="stepperContainer"
      id="stepperContent"
    >
      <v-stepper-header elevation="0" class="sticky white elevation-0">
        <slot name="header" />
      </v-stepper-header>
      <v-stepper-items
        class="step-card elevation-0"
        elevation="0"
        id="componentContainer">
        <v-stepper-content
          data-id="stepperContent"
          class="v-stepper-content"
          v-for="{ idx, step } in stepsSequence()"
          :step="idx"
          :key="idx">
          <v-card class="step-component-card" outlined>
            <component
              :stepIndex="idx"
              v-bind:is="step"
              @stepstatusupdated="stepCompleted"
              @flowCompleted="flowCompleted"
              @gonext="goNext" />
          </v-card>
        </v-stepper-content>
      </v-stepper-items>
      <v-container class="footer white">
        <v-btn
          data-id="onboarding_left_button"
          @click="goPrevious()"
          class="btn v-btn v-btn--has-bg theme--light v-size--large step-nav"
          v-if="stepIdx > 1 && !isApplicationCompleted"
          :disabled="disablePrevious"
        >
          Back
        </v-btn>
        <v-spacer />
        <v-btn
          data-id="onboarding_right_button"
          @click="goNext()"
          class="btn v-btn v-btn--has-bg theme--light v-size--large step-nav"
          :disabled="!steps[stepIdx - 1].isValid || stepIdx >= steps.length"
          v-if="stepIdx < steps.length &&
                  !isApplicationCompleted &&
                  !steps[stepIdx - 1].isFinal">
          Next <v-icon color="white">mdi-arrow-right</v-icon>
        </v-btn>
      </v-container>    
    </v-stepper>
    <v-footer bottom fixed class="disclaimer centerize white">
      The Vox Money account and card are issued by Omnio EMI Limited (OEL), which is a principal member of Visa and authorised by the Financial Conduct Authority under the Electronic Money Regulations 2011 (Firm reference 900123) with its registered office at Clerks Court, 18-20 Farringdon Lane, London, England, EC1R 3AU.
    </v-footer>
  </v-container>
</template>

<script lang="ts">
import Vue from "vue";
import Component from "vue-class-component";
import { Prop } from "vue-property-decorator";
import {
  OnboardingApplicationStepSetup,
  OnboardingApplicationStepStatus,
  Scenario
} from "./OnboardingScenarioModels";
import EventBus from "./eventBus.js";

@Component
export default class CaptureBase extends Vue {
  // CAREFUL: IT SEEMS THAT PROP INITIALIZATION CAUSES THE PARENT PROP INJECTION
  // DOES NOT WORK
  @Prop() readonly scenario?: Scenario;

  // Fields
  stepIdx = 1;
  debug = true;
  disableProgress = false;
  disablePrevious = false;
  isApplicationCompleted = false;
  steps: Array<OnboardingApplicationStepSetup> = new Array<OnboardingApplicationStepSetup>();
  stepsSequence = () => {
    const res = this.steps.map(s => ({
      idx: this.steps.indexOf(s) + 1,
      step: s.content
    }));
    return res;
  };

  constructor() {
    super();
    if (this.scenario) {
        this.steps = this.scenario.flow.flatMap(
        section => section.steps as OnboardingApplicationStepSetup[]
        );
        console.log(`Scenario: found ${this.steps?.length} steps`);
    }
  }

  // events
  updateOverallProgress() {
    this.$emit("progressupdated", {
      currentStep: this.steps[this.stepIdx - 1]
    });
    if (this.stepIdx > 1) {
      this.disablePrevious = !this.steps[this.stepIdx - 2].canReturn;
    } else {
      this.disablePrevious = false;
    }
  }

  stepCompleted = (newVal, sidx) => {
    if (this.steps === undefined) return;

    this.steps[sidx - 1].isValid = newVal;

    if (this.debug) {
      console.log(
        `Step [${sidx}]: isValid=${this.steps[sidx - 1].isValid}, isComplete=${
          this.steps[sidx - 1].status
        }`
      );
    }

    this.updateOverallProgress();
  };

  flowCompleted() {
    console.log(`Flow completed, disabling progress`);
    this.disableProgress = false;
    this.disablePrevious = false;
    this.isApplicationCompleted = true;
    this.$emit("flowCompleted"); // bubble this up to parent
  }

  //
  // actions
  goNext() {
    if (this.steps === undefined) return;

    const idx = this.stepIdx - 1;

    if (this.debug) {
      console.log(`Step ${idx} before: ${this.steps[idx].status}`);
    }

    if (this.steps[idx].isValid)
      this.steps[idx].status = OnboardingApplicationStepStatus.Done;

    if (this.debug) {
      console.log(`Step ${idx} after: ${this.steps[idx].status}`);
    }

    const newStepIdx = this.steps[idx].getNextStepId() + 1;
    this.stepIdx = Math.min(newStepIdx, this.steps.length);

    if (
      this.steps[this.stepIdx - 1].status ===
      OnboardingApplicationStepStatus.Todo
    )
      this.steps[this.stepIdx - 1].status =
        OnboardingApplicationStepStatus.InProgress;

    if (this.debug) {
      console.log(
        `GoNext: Moving to step [${this.steps[this.stepIdx - 1].name}]`
      );
    }

    EventBus.$emit('gonext', this.steps[idx]);
    this.updateOverallProgress();
    this.scrollToTop();
  }

  goPrevious() {
    if (this.steps === undefined) return;

    this.stepIdx = Math.max(this.stepIdx - 1, 1);
    console.log(
      `GoPrevious: Moving to step [${this.steps[this.stepIdx - 1].name}]`
    );
    this.updateOverallProgress();
    this.scrollToTop();
    // eventBus.$emit("goprevious");
  }

  scrollToTop() {
    this.$vuetify.goTo("#stepperContent", { container: "#componentContainer" });
  }
}
</script>

<style scoped>
#componentContainer { overflow: inherit; }
.v-stepper {
  height: 100%;
  border: 0px;
  box-shadow: 0;
  width: 80%;
  overflow: visible;
  display: flex;
  flex-direction: column;
  margin: 0 auto;
  min-width: 300px;
  padding-bottom:75px;
}

.step-card {
  width: 100%;  
  overflow-y: auto;
  overflow-x: hidden;
}

.v-sheet--outlined {
  border: 0px !important;
}

.step-component-card {
  border: 1px solid #BFBFBF !important;
  border-radius: 25px;
  padding: 10px;
}

.footer {  
  display: flex;
  padding: 0px;
  padding-bottom:20px;
  flex: none;
}

.sticky {
  position: sticky;
  top: 0;
  z-index: 1;
}

.v-stepper__step {
  padding: 5px;
}

.v-stepper__header {
  height: initial !important;
  flex: none;
}

.v-stepper-content {
  padding: 10px;
  width: 90%;
  margin: 0 auto;
}

.stepper-section {
  border: 2px black;
  padding: 12px;
  background-color: #9a9c9c;
  border-radius: 16px;
  color: white;
  align-items: center;
  display: inline-flex;
  font-size: 14px;
  height: 32px;
  margin-left: 5px;
  margin-top: 5px;
  margin-bottom: 5px;
}

button.step-nav {
  background-color: var(--v-secondary-base) !important;
  border: 2px solid var(--v-secondary-base);
  color: #fff;
}

button.step-nav:hover {
  background-color: var(--v-primary-base) !important;
  border: 2px solid var(--v-primary-base);
  color: #fff;
}

button.step-nav.v-btn--disabled {
  border: none !important;
}

.centerize {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
}

.centerize .row {
  display: inherit !important;
}


.disclaimer {
  width: 100%;
  padding-top:12px;
  justify-content: center;
  display: flex;
  flex-wrap: wrap;
  font-size: 12px;
  color: black !important;
}

@media only screen and (max-width: 600px) {
  /* For mobile phones: */
  .v-stepper {
    width: 90%;
    height: 95%;
  }

  .v-stepper-content {
      width: 100%;
    }

  .disclaimer {
    height: 100px;
  }
}
</style>