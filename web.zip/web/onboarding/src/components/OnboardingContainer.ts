import HttpOnboardingApplicationService from "@/services/impl/HttpOnboardingApplicationService";
import HttpOTPService from "@/services/impl/HttpOTPService";
import MockOnboardingApplication from "@/services/impl/MockOnboardingApplicationService";
import MockOTPService, { MockResponse } from "@/services/impl/MockOTPService";
import OnboardingApplicationService from "@/services/OnboardingApplicationService";
import { OneTimePasswordStatus, OTPService } from "@/services/OTPService";
import StaticDataService from "@/services/StaticDataService";
import OnBoardingDocumentService from "@/services/OnboardingDocumentService";
import HttpOnboardingDocumentService from "@/services/impl/HttpOnboardingDocumentService";
import MockOnboardingDocumentService from "@/services/impl/MockOnboardingDocumentService";

export default class MbsOnboardingContainer {
  constructor() {
    // if (process.env.NODE_ENV == "production") {
    this.OTPService = new HttpOTPService();
    this.ApplicationService = new HttpOnboardingApplicationService();
    this.OnboardingDocumentService = new HttpOnboardingDocumentService();
   // } else {
     // this.OTPService = new MockOTPService(
       //  [],
        // new MockResponse("*", "ABCDEF", "123456", OneTimePasswordStatus.Valid)
      // );
      // this.ApplicationService = new MockOnboardingApplication();
      // this.OnBoardingDocumentService = new MockOnBoardingDocumentService();
     //}

    this.StaticDataService = new StaticDataService();
  }

  readonly OTPService: OTPService;
  readonly ApplicationService: OnboardingApplicationService;
  readonly StaticDataService: StaticDataService;
  readonly OnboardingDocumentService: OnBoardingDocumentService;
}
