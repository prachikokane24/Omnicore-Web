<template>
    <v-container>
        <v-container class="centerize" v-if="selectedDocumentType && selectedDocumentType !== '' && file === null && !capturing">
            <v-container class="upload-container">
                <template v-if="isTwoSided"> 
                    <p class="bold"> {{ sideMessage }} </p>
                </template>
                <file-upload
                    ref="upload"
                    :accept="accept"
                    :drop="true"
                    :extensions="extensions"
                    :size="size || 0"
                    @input-filter="inputFilter"
                    @input-file="inputFile">
                        <v-icon>mdi-tray-arrow-up</v-icon>
                        <v-row>
                            <p>Drop files here or click icon to upload</p>
                        </v-row>
                </file-upload>
            </v-container>
        </v-container>

        <v-container style="width:95%" class="centerize" v-if="file !== null">
             <div v-if="isPdf()">
                <template v-if="isTwoSided"> 
                    <p class="bold"> {{ sideMessage }} </p>
                </template>
                <vue-pdf-embed  ref="pdfRef" :source="file.blob" :page="1" />
             </div>
            <div v-else>
            <template v-if="isTwoSided"> 
                <p class="bold"> {{ sideMessage }} </p>
            </template>
            <vue-cropper
                ref="cropper"
                @ready="onReady"
                :auto-crop-area="cropperOptions.autoCropArea"
                :src="file.blob" />

            <v-row class="edit-controls">
                <a @click.prevent="$refs.cropper.rotate(-90)"><v-icon title="Rotate left">mdi-arrow-u-left-top</v-icon></a>
                <a @click.prevent="$refs.cropper.rotate(90)"><v-icon title="Rotate right">mdi-arrow-u-right-top</v-icon></a>
                <a><v-icon @click.prevent="$refs.cropper.relativeZoom(0.1)" title="Zoom in">mdi-plus</v-icon></a>
                <a><v-icon @click.prevent="$refs.cropper.relativeZoom(-0.1)" title="Zoom out">mdi-minus</v-icon></a>
                <a><v-icon @click.prevent="$refs.cropper.getCroppedCanvas().toBlob(b => cropImage(b, $refs.cropper.replace))" title="Select crop area">mdi-select-all</v-icon></a>
            </v-row>
            <p><b> For Best results, please rotate and zoom the image before cropping.</b></p>
            </div>
        </v-container>

        <template v-if="isTwoSided && selectedDocumentType !== null && capturing"> 
            <p class="bold centerize"> {{ sideMessage }} </p>
        </template>
        <image-capture
            v-if="selectedDocumentType !== null && capturing"
            @error="showError"
            @clearError="clearError"
            @reset="reset"
            @submit="submit"
            @update="updateImageSelected"
            :application-id="applicationId"
            :is-captured="isCaptured"
            :is-performing-upload="isPerformingUpload"
            :max-size="size"
            :reset-button="resetButtonText"
            :isSelfie="false"
            :showSubmit="showSubmit()"
            :class="overlayClass" />

        <v-container class="centerize" v-if="!isCaptured && selectedDocumentType !== ''">
            <v-btn
                v-if="!capturing && file === null"
                @click="capturing = true"
                class="secondary"
                large
                rounded>
                Take Photo
            </v-btn>
            <v-row v-if="!capturing && file !== null">
                <v-btn
                    @click="reCapture()"
                    class="secondary"
                    large
                    rounded>
                    Retake
                </v-btn>
                <v-spacer v-if="showSubmit()" />
                <v-btn
                    v-if="showSubmit()"
                    @click="submit()"
                    :loading="isPerformingUpload"
                    class="primary"
                    large
                    rounded>
                    Submit
                </v-btn>
            </v-row>
        </v-container>
    </v-container>
</template>

<script lang="ts">

import Component from "vue-class-component";
import Vue from "vue";
import { Model, Prop, Watch } from "vue-property-decorator";
import VueUploadComponent from 'vue-upload-component';
import VueCropper from 'vue-cropperjs';
import 'cropperjs/dist/cropper.css';
import { DocumentCategoryUpload, DocumentType } from "@/components/OnboardingModelsBase";
import { KycChallengeDocumentCategory } from "@/types/onboarding.types";
import ImageCapture from "./ImageCapture.vue";
import VuePdfEmbed from 'vue-pdf-embed/dist/vue2-pdf-embed';

@Component({
  components: {
    VueCropper,
    'file-upload': VueUploadComponent,
    'image-capture': ImageCapture,
    'vue-pdf-embed': VuePdfEmbed
  }
})

export default class DocumentCapture extends Vue {
    @Model() model: any;
    @Prop({ required: true }) applicationId?: string;
    @Prop({ required: true }) docUpload?: DocumentCategoryUpload;
    @Prop({ required: true }) documentType?: string;
    @Prop({ required: true }) isCaptured?: boolean;
    @Prop({ required: true }) isPerformingUpload?: boolean;
    @Prop({ required: true }) isCountrySelected?: boolean;
    @Prop() isTwoSided?: boolean;
    @Prop() selectedDocumentType?: DocumentType;
    @Prop() requiredDocument?: KycChallengeDocumentCategory;
    @Prop() sideMessage?: string;
    @Prop() overlayClass?: string;
    
    file: any = null;
    image = {};
    hasError = false;
    accept = "image/jpeg,image/png,application/pdf";
    extensions = "jpg,jpeg,png,pdf";
    minSize = 1024;
    maxSize = 10;
    size = 1024 * 1024 * this.maxSize;
    capturing = false;
    video: any;
    canvas: any;
    cropperOptions = {
        autoCropArea: 1
    };
    resetButtonText = "Reset";
    isDocumentSelected = false;

    @Watch('isDocumentSelected')
    isDocumentSelectedChanged(val: boolean) {
        if (this.file?.file) {
            this.model.file = this.file.file;
        }
        this.$emit("update", val);
    }
    
    updateImageSelected(val: boolean, image: any) {
        this.model.file = image;
        this.isDocumentSelected = val;
    }

    visibilityChanged (isVisible: boolean, entry: any) {
        if (isVisible) {
            console.log('visible');
        }
    }
    
    reCapture() {
        this.file = null;
        this.isDocumentSelected = false;
    }
    
    isPdf(){
        return this.file?.type=== "application/pdf"
    }
    
    onReady() {
        (this.$refs.cropper as VueCropper).relativeZoom(-0.1);
    }

    inputFilter(newFile, oldFile, prevent) {
        let fileType = "";

        if (oldFile) {
            fileType = oldFile.type;
        } else if (newFile) {
            fileType = newFile.type; 
        }

        if (this.accept.split(',').indexOf(fileType) === -1) {
            prevent();
            this.showError(`Invalid file type. Accepted types are ${this.accept}`);
        } else {
            if (newFile && newFile.error === "" && newFile.file && (!oldFile || newFile.file !== oldFile.file)) {
                const url = (window.URL || window.webkitURL)
                newFile.blob = ''

                if (url) {
                    newFile.blob = url.createObjectURL(newFile.file);
                }
            }
        }
    }

    inputFile(newFile, oldFile) {
        if (!(newFile && oldFile))  {
            if (!newFile.active) {
                if (newFile.size > this.size) {
                    const uploadComponent = this.$refs.upload as VueUploadComponent;
                    uploadComponent.update(newFile, { error: 'size' });
                    this.showError(`The image selected is too large. The maximum image size for an upload is ${this.maxSize}Mb.`);
                } else {
                    this.clearError();
                    this.file = newFile;
                    this.isDocumentSelected = true;
                }
            }
        }
    }

    cropImage(blob: any, replace) {
        const url = (window.URL || window.webkitURL)
        this.file.blob = url.createObjectURL(blob);

        // N.B. Callback necessary as specifying this.$refs.cropper.replace wouldn't compile
        replace(this.file.blob); 

        this.urltoFile(this.file.blob, `image-${this.applicationId}-${new Date().getTime()}`)
            .then(image => {
                this.file = image;
                this.model.file = image;
            });
    }
    
    urltoFile(url: string, filename: string): Promise<File> {
        return (fetch(url)
            .then(function(res){return res.arrayBuffer();})
            .then(function(buf){return new File([buf], filename,{type:"image/png"});})
        );
    }

    reset() {
        this.capturing = false;
        this.isDocumentSelected = false;
    }

    showError(error: string) {
        this.$emit('showError', error);
    }

    clearError() {
        this.$emit('clearError');
    }

    showSubmit() {
        const result = this.isCountrySelected && (!this.isTwoSided
            || (this.model.isFlipSide && this.model.isDependantDocumentSelected));

        return result;    
    }

    async submit() {
        this.$emit('submit');
    }
}
</script>

<style lang="scss" scoped>

img {
  display: block;
  max-width: 100%;
}

.centerize {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
}

.centerize .row {
  padding-top: 10px;
  padding-bottom: 10px;
  display: inherit !important;
}

.video-container {
  background-color: #ddd;
}

.video-container button {
  background: #5B2298;
  border: 1px solid #5B2298;
  box-sizing: border-box;
  border-radius: 8px;
  margin: 0 10px;
}

.spacer { margin: 0 25px; }

.action-btn {
  border-radius: 30px !important;
  background: #5B2298 !important;
  color: #fff;
}

form > .container > .row {
  margin-bottom: 0;
  margin-top: 25px;
  margin-left: auto;
  margin-right: auto;
  width: 60%;
}

form > .container > .row.edit-controls {
  margin: 0;
  margin-right: auto;
}

.form-field, .upload-container {
  margin: 16px 0;
}

.upload-container {
  background: #BFBFBF;
  border-radius: 8px;
  cursor: pointer;
}

.upload-container .row > p {
  font-size: 16px;
  line-height: 19px;
  color: #404040;  
}

.upload-container .v-icon {
  color: #000;
  font-size: 80px;
  margin-top: 100px;
}

.file-uploads {
  height: 100%;
  width: 100%;
  display: block;
}

.vue-pdf-embed > div {
  margin-bottom: 8px;
  box-shadow: 0 2px 8px 4px rgba(0, 0, 0, 0.1);
}

.row.edit-controls > a > .v-icon {
  color: #000;
}

.cropper-modal {
    height: 800px;
    width: 700px;
}

@media only screen and (max-width: 600px) {
    .action-btn { 
        font-size: 11px;
        width: 200px;
        margin-bottom: 20px;
    }
    
    .spacer { margin: 0 5px; }

    .container {
        padding: 8px;
    }

    .upload-container .row > p {
        padding: 10px;
    }

    form > .container > .row {
      margin: auto;
      width: 90%;
    }

    form > .container > .row > div.v-input { 
        width: 90%;
    }
}
</style>