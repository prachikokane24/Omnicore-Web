<template>
  <v-container style="padding: 0px">
    <country-list 
      :id="`${idPrefix}-ifForTaxPurposeOfAnywhereOtherThanUKThenWhere`"
      v-model="ifForTaxPurposeOfAnywhereOtherThanUKThenWhere"
      label="Please select"
      topOfListCountry="GBR"
      :rules="rules"
    />
    <v-radio-group
      :id="`${idPrefix}-canprovidetin`"
      label="Are you able to provide a TIN?"
      v-model="tinAvailable"
      @change="onTinAvailableChange"
      :rules="[isRequiredRule]"
      row
      dense
      style="margin-top:0px important!; padding-top:0px important!"
    >
      <v-radio label="Yes" :id="`${idPrefix}-canprovidetin-yes`" :value="true"></v-radio>
      <v-radio label="No" :id="`${idPrefix}-canprovidetin-no`" :value="false"></v-radio>
    </v-radio-group>
    <v-row v-if="tinAvailable">
      <v-text-field
        :id="`${idPrefix}-taxidnumber`"
        label="Tax Identification Number"
        v-model="taxDetails.taxIdentificationNumber"
        :value="taxDetails.taxIdentificationNumber"
        :rules="tinRules"
        :maxLength="maxTinLen"
        dense
        outlined
      />
    </v-row>
    <v-row v-if="tinAvailable === false">
      <v-select
        :id="`${idPrefix}-cantprovidereasons`"
        :items="cantProvideReasons"
        :item-text="(item) => item.text"
        :item-value="(item) => item.id"
        v-model="taxDetails.cantProvideReason"
        label="I can't provide this because:"
        class="v-wrap"
        @change="onCantProvideReasonChange"
        :rules="[isRequiredRule]"
        dense
        outlined
      >
        <template v-slot:item="data">
          <span style="padding: 5px"> {{ data.item.text }} </span>
        </template>
      </v-select>
    </v-row>
    <v-row v-if="!tinAvailable && needsReason">
      <v-textarea
        :id="`${idPrefix}-reasonunableobtaintin`"
        label="Reason you are unable to obtain a TIN"
        v-model="taxDetails.reasonUnableToProvide"
        :value="taxDetails.reasonUnableToProvide"
        :rules="reasonUnableProvideRules"
        :maxLength="maxReasonLen"
        dense
        outlined
      />
    </v-row>
  </v-container>
</template>

<script lang="ts">
//  module imports
import Component from "vue-class-component";
import Vue from "vue";
import CountryList from "./CountryList.vue";
import { Model, Prop, Emit } from "vue-property-decorator";
import { TinDetails, TinDetailsCantProvideReason } from "@/types/onboarding.types";
import DefaultValidationRules from "./CommonValidationRules";

@Component({
  //  component dependencies
  components: {
    CountryList,
  },
})
export default class TaxDetails extends Vue {
  @Prop({ required: true }) readonly mode?: string;
  @Prop({ required: true }) readonly idPrefix?: string;
  @Prop() readonly rules?: Array<Function>;
  @Model() taxDetails?: TinDetails;

  readonly maxReasonLen = 1000;
  readonly maxTinLen = 12;
 
  requiresQuestions = false;
  needsReason = false;
  tinAvailable?: string = ""; // this is a trick to solve Vue painful reactive model
  countryBuffer = "";

  isRequiredRule = DefaultValidationRules.isRequired;

  reasonUnableProvideRules = [
    DefaultValidationRules.isRequired,
    DefaultValidationRules.textLenWithin(10, this.maxReasonLen)
  ];

  tinRules = [
    DefaultValidationRules.isRequired,
    DefaultValidationRules.textLenWithin(0, this.maxTinLen)
  ]

  onTinAvailableChange(value: boolean) {
    if (this.taxDetails !== undefined)
      this.taxDetails.tinAvailable = value;
  }

  onCantProvideReasonChange(value) {
    console.log(value);
    const reason = this.cantProvideReasons.filter(v => v.id === value);
    if (reason.length !== 1)
      // should not happen
      return;

    this.needsReason = reason[0].needsReason;
  }

  get ifForTaxPurposeOfAnywhereOtherThanUKThenWhere() {
    return this.countryBuffer;
  }
  set ifForTaxPurposeOfAnywhereOtherThanUKThenWhere(val) {
    this.countryBuffer = val;
    this.requiresQuestions = val !== "No";
    this.taxDetails!.taxCountry = val === "No" ? "" : val;
    this.$emit("taxCountryChanged", val);
  }

  cantProvideReasons = [
    {
      id: TinDetailsCantProvideReason.NotIssued,
      text: "The country/jurisdiction where the account holder is resident does not issue TINs to its residents",
      needsReason: false
    },
    {
      id: TinDetailsCantProvideReason.Unobtainable,
      text: "The account holder is otherwise unable to obtain a TIN or equivalent number (Please explain why you are unable to obtain a TIN in the below text box if you have selected this reason)",
      needsReason: true
    },
    {
      id: TinDetailsCantProvideReason.NotRequired,
      text: "No TIN is required. (Note: Only select this reason if the domestic law of the relevant jurisdiction does not require the collection of the TIN issued by such jurisdiction",
      needsReason: false
    },
  ];
}
</script>
<style lang="scss" scoped>
.v-wrap {
    width: 0;
    white-space: nowrap;
    text-overflow: ellipsis;
}
</style>