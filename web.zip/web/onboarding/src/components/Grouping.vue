<template>
  <fieldset class="elevation-3">
    <legend>
      <div class="group">{{ label }}</div>
    </legend>
    <slot />
  </fieldset>
</template>

<script lang="ts">

//  module imports
import { Prop } from 'vue-property-decorator';
import Vue from 'vue'
import Component from "vue-class-component";

@Component
export default class Grouping extends Vue {
  @Prop() readonly label?: string;
  
}

</script>

<style scoped>
fieldset {
  padding: 10px;
  border: 1px solid gainsboro;
  border-radius: 15px !important;
  margin: 8px;
}

.group {
  padding: 12px;
  background-color: var(--v-secondary-base);
  border-radius: 16px;
  color: white;
  align-items: center;
  display: inline-flex;
  font-size: 18px;
  justify-content: center;
  height: 32px;
  margin-top: 5px;
  margin-bottom: 5px;
  width: 238px;
}
</style>