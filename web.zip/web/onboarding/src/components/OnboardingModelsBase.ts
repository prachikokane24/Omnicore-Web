export class DocumentType {
  id = "";
  type = "";
  translatedType = "";
}

export class DocumentUpload {
  id = "";
  docUploadStatus = "pending";
  appStatus = "pending";
  file: any;
  fileId = "";
}

export class DocumentCategoryUpload {
  name = "";
  uploads?: Array<DocumentUpload> = new Array<DocumentUpload>();
  types: Array<DocumentType> = new Array<DocumentType>();
}