<template>
  <v-select v-if = "displayNationality"
    :id="`${id}-select`"
    :label="label"
    :items="nationalities"
    :item-text="item => item.nationality" 
    :item-value="item => item.alpha3Code"
    :rules="rules"
    v-model="selectedCountry"
    @change="onValueChanged"
    dense
    outlined 
    class="v-wrap colourise" />
  <v-select v-else 
    :id="`${id}-select`"
    :label="label"
    :items="countries"
    :item-text="item => item.name" 
    :item-value="item => item.alpha3Code"
    :rules="rules"
    v-model="selectedCountry"
    @change="onValueChanged"
    dense
    outlined 
    class="v-wrap colourise" />
</template>

<script lang="ts">

//  module imports
import { Emit, Inject, Model, Prop, Watch } from 'vue-property-decorator';
import Vue from 'vue'
import Component from "vue-class-component";
import MbsOnboardingContainer from "./OnboardingContainer";
import { CountryDefinition } from '@/services/StaticDataService';

@Component
export default class CountryList extends Vue {
  @Prop() readonly label?: string;
  @Prop() readonly id?: string;
  @Prop() readonly rules?: [];
  @Prop() readonly topOfListCountry?: string; // alpha 3 code
  @Prop() readonly allowEmptySelection?: boolean;
  @Prop() readonly displayNationality?: boolean;
  @Prop() readonly displayGbOnly?: boolean;
  @Prop() readonly allowEmptyText?: string;
  @Prop() readonly allowEmptyValue?: string;
  @Inject() container?: MbsOnboardingContainer;
  @Model('change') selectedCountry: any;

  countries: Array<CountryDefinition> | undefined = [];
  nationalities: Array<CountryDefinition> | undefined = [];
  gbCode ="GB";

constructor() {
    super()
    
    const countryList = this.container?.StaticDataService.getCountries();    
    let sortedCountryList = countryList?.slice(0).sort((x, y) =>  x?.name!.localeCompare(y?.name!));
    const sortedNationalityList = countryList?.slice(0).sort((x, y) =>  x?.nationality!.localeCompare(y?.nationality!));    
   
    if (this.allowEmptySelection) {
        countryList?.unshift(new CountryDefinition(this.allowEmptyText, this.allowEmptyValue, this.allowEmptyValue));
    }

    if (this.topOfListCountry !== undefined) {

        const topCountry = countryList?.find(obj => {
            return obj.alpha3Code === this.topOfListCountry;
        });        

        sortedCountryList?.sort((x, y) => x.name === topCountry?.name ? -1 : y.name === topCountry?.name ? 1 : x?.name!.localeCompare(y?.name!));
        sortedNationalityList?.sort((x, y) => x.nationality === topCountry?.nationality ? -1 : y.nationality === topCountry?.nationality ? 1 : x?.nationality!.localeCompare(y?.nationality!));

    }    

     if (this.displayGbOnly){
           sortedCountryList = sortedCountryList?.filter((el) => {
         return el.alpha2Code == this.gbCode;
     });

     }
    
    this.countries = sortedCountryList;
    this.nationalities = sortedNationalityList;
    
}
 loadCountryData(showUkOnly: boolean){
    const countryList = this.container?.StaticDataService.getCountries();    
    let sortedCountryList = countryList?.slice(0).sort((x, y) =>  x?.name!.localeCompare(y?.name!));
    const sortedNationalityList = countryList?.slice(0).sort((x, y) =>  x?.nationality!.localeCompare(y?.nationality!));    
   
    if (this.allowEmptySelection) {
        countryList?.unshift(new CountryDefinition(this.allowEmptyText, this.allowEmptyValue, this.allowEmptyValue));
    }

    if (this.topOfListCountry !== undefined) {

        const topCountry = countryList?.find(obj => {
            return obj.alpha3Code === this.topOfListCountry;
        });

        sortedCountryList?.sort((x, y) => x.nationality === topCountry?.name ? -1 : y.name === topCountry?.name ? 1 : x?.name!.localeCompare(y?.name!));
        sortedNationalityList?.sort((x, y) => x.nationality === topCountry?.nationality ? -1 : y.nationality === topCountry?.nationality ? 1 : x?.nationality!.localeCompare(y?.nationality!));

    }    

     if (showUkOnly){
           sortedCountryList = sortedCountryList?.filter((el) => {
         return el.alpha2Code == this.gbCode;
     });

     }
    
    this.countries = sortedCountryList;
    this.nationalities = sortedNationalityList;

}
  @Watch('displayGbOnly')
    isDisplayGbOnlyChanged(val: boolean) {
     this.loadCountryData(val);
}
  @Emit("change")
  public onValueChanged(value: string) {
    this.selectedCountry = value;
  }
}

</script>
<style lang="scss" scoped>
.v-wrap {
    width: 0;
    // white-space: nowrap;
    text-overflow: ellipsis;
}
</style>