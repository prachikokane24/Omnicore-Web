<template>
    <v-menu
        :id="`${id}-menu`"
        v-model="menu"
        transition="scale-transition"
        :close-on-content-click="false"
        offset-y
        min-width="290px">
        <template v-slot:activator="{ on, attrs }">
            <v-text-field
              :id="`${id}-datepicker`"
              :label="label"
              v-model="selectedDate"
              v-bind="attrs"
              v-on="on"         
              :rules="rules"       
              dense
              outlined
              @change="onValueChanged"
            ></v-text-field>
        </template>
        <v-date-picker
            v-model="selectedDate"
            scrollable
            @change="onValueChanged"></v-date-picker>
        <!-- min, max -->
    </v-menu>
</template>

<script lang="ts">

//  module imports
import { Emit, Model, Prop } from 'vue-property-decorator';
import Vue from 'vue'
import Component from "vue-class-component";

@Component
export default class DatePicker extends Vue {
  @Prop() readonly rules?: Array<Function>;
  @Prop() readonly label?: string;
  @Prop() readonly id?: string;
  @Model('change') public selectedDate!: string;
  
  @Emit("change")
  public onValueChanged(value: string) {
    this.selectedDate = value;
    this.menu = false;
  }

  menu = false;
}

</script>