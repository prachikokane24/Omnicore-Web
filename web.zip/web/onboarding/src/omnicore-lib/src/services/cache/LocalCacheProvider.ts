import {LocalCache} from "./LocalCache";
import {LocalCacheConfig} from "./LocalCacheConfig";


/**
 * CacheEntry class holds the cachedData and metadata needed to manage it
 */
class CacheEntry {
    expires = 0;
    data?: any;

    public hasExpired(): boolean {
        return this.expires < new Date().getUTCSeconds();
    }
}

export class LocalCacheProvider implements LocalCache
{
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    constructor(private localCacheConfig: LocalCacheConfig) {

    }

    private cache = new Map<string, CacheEntry>();

    flush(key: string): void {
        this.cache.delete(key);
    }

    flushAll(): void {
        this.cache.clear();
    }

    get<T>(key: string): T {
        if (!this.hasKey(key)) {
            throw new Error('LocalCacheProvider: get<T>, key not found');
        }
        const entry = this.cache.get(key);
        // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
        // @ts-ignore
        return entry.data as T;
    }

    hasKey(key: string): boolean {
        let result = false;
        const cacheEntry = this.cache.get(key);
        if (cacheEntry) {
            result = !cacheEntry.hasExpired();
            if (!result) {
                // cache entry has expired so flush it out
                this.flush(key);
            }
        }
        return result;
    }

    put<T>(key: string, data: T, ttlSeconds: number): void {
        const cacheEntry = new CacheEntry();
        const expiry = new Date().getUTCSeconds() + ttlSeconds;
        cacheEntry.data = data;
        cacheEntry.expires = expiry;
        this.cache.set(key, cacheEntry);
    }

}
