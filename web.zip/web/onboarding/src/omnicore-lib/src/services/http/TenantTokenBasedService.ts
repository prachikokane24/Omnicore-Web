import { OmnioIdRequestTransformer, ResponseCodeMapper } from "./HttpClientFactory";
import { omnicore } from "@/omnicore-lib";
import * as moment from 'moment';

class TenantCredentials {
    username: string;
    password: string;

    constructor(username: string, password: string) {
        this.username = username;
        this.password = password;
    }
}

class Token {
    token?: string;
    expires?: string;
}

class TokenPair {
    accessToken?: Token;
    refreshToken?: Token;
}

class CreateTenantTokenRequest {
    readonly credentials: TenantCredentials;

    constructor(username: string, password: string) {
        this.credentials = new TenantCredentials(username, password);
    }
}

class CreateTenantTokenResponse {
    tokens?: TokenPair;
}

class CreateTokenResponse {
    tokens?: TokenPair;
}

class RefreshTokenRequest {
}

class TokensContext {
    static currentAccessToken?: Token = undefined;
    static currentRefreshToken?: Token = undefined;

    constructor() {
        if ((process.env.VUE_APP_TENANT_ID === undefined || process.env.VUE_APP_TENANT_ID === "") ||
            (process.env.VUE_APP_TENANT_PWD === undefined || process.env.VUE_APP_TENANT_PWD === "")) {
            throw new Error("No tenant id or password specified")
        }
    }

    //
    // Creates a tenant token based on a usr/pwd combination
    static async getTenantToken() {
        const httpClient = omnicore().httpFactory.create(undefined, [
            OmnioIdRequestTransformer, 
        ]);

        await httpClient.post<CreateTenantTokenRequest>(
            "auth/authentication/v1/token/tenant", 
            new CreateTenantTokenRequest(process.env.VUE_APP_TENANT_ID!, process.env.VUE_APP_TENANT_PWD!),
            [
                ResponseCodeMapper(
                    {
                        "200": response => {
                            const tokenData = response.data as CreateTokenResponse;
                            TokensContext.currentAccessToken = tokenData.tokens?.accessToken;
                            TokensContext.currentRefreshToken = tokenData.tokens?.refreshToken;
                            return response;
                        },
                    },
                    data => {
                        throw Error("Unexpected response while trying to refresh access token");
                    }
                )
            ]
        );
    }

    //
    // Calls the auth api to refresh the access token
    static async refreshToken() {
        console.log("Refresh token requested")
        const httpClient = omnicore().httpFactory.create(undefined, [
            OmnioIdRequestTransformer,
            request => {
                request.headers = request.headers === undefined ? {} : request.headers;
                request.headers["Authorization"] = `bearer ${TokensContext.currentRefreshToken?.token}`;
                return request;
            }
        ]);

        return await httpClient.get<RefreshTokenRequest>(
            "auth/authentication/v1/token/refresh", 
            new RefreshTokenRequest(),
            [
                ResponseCodeMapper(
                    {
                        "200": data => {
                            console.log("Refresh token obtained successfully")
                            const tokenData = data as CreateTokenResponse;
                            TokensContext.currentAccessToken = tokenData.tokens?.accessToken;
                            TokensContext.currentRefreshToken = tokenData.tokens?.refreshToken;
                        }
                    },
                    data => {
                        throw Error("Unexpected response while trying to refresh access token");
                    }
                )
            ]
        );
    }
}


export async function TenantTokenRequestTransformer(request) {

    if (TokensContext.currentAccessToken === undefined) {
        console.log("Tenant token not requested before, getting a new one")
        await TokensContext.getTenantToken();
        console.log(`Tenant token obtained: ${TokensContext.currentAccessToken}`)
    } else {
        if (TokensContext.currentAccessToken.expires !== undefined && 
            moment(TokensContext.currentAccessToken.expires).diff(moment.now(), 'seconds') < 0 ) {
            console.log("Tenant access token has expired, refreshing");
            await TokensContext.refreshToken();
            console.log("Tenant access token refreshed");
        }
    }

    request.headers = request.headers === undefined ? {} : request.headers;
    request.headers["Authorization"] = `bearer ${TokensContext.currentAccessToken?.token}`;

    return request;
}
