import {AxiosInstance, AxiosResponse} from 'axios'
import {HttpMethod, HttpRequest, HttpRequestSpec} from "./HttpRequest";
import {HttpClient} from "./HttpClientFactory";
import {LocalCache} from "../cache/LocalCache";
import {HttpClientConfig} from "./HttpClientConfig";

export class HttpClientImpl implements HttpClient
{
    public constructor(
        private axiosClient: AxiosInstance, 
        private localCache: LocalCache, 
        private httpConfig: HttpClientConfig,
        private requestTransformers: Array<(request) => any> = []
        // private responseHandlers: Array<(data) => any> | undefined = undefined
        ) {
    }

    public async makeRequest<T = any>(request: HttpRequestSpec<T>, responseHandlers: Array<(data) => any> = []): Promise<any> {

        await Promise.all(this.requestTransformers.map(async t => {
            request = await t(request)
        }));

        let response = await this.axiosClient.request<T, AxiosResponse>(request);
 
        await Promise.all(responseHandlers.map(async t => {
            response = await t(response)
        }));
        
        return response;
    }

    public createRequest<T>(): HttpRequestSpec<T>
    {
        const request = new class implements HttpRequestSpec<T> {
            method: HttpMethod = "get";
        } as HttpRequestSpec;

        return request;
    }

    public get<T>(path: string, params: T, responseHandlers: Array<(response) => any>): Promise<any>
    {
        const req = this.createRequest();
        req.method = "get";
        req.url = path;
        req.params = params;
        return this.makeRequest(req, responseHandlers);
    }

    public async post<T>(path: string, data: T, responseHandlers: Array<(response) => any>): Promise<any>
    {
        const req = this.createRequest();
        req.method = "post";
        req.data = data;
        req.url = path;
        return await this.makeRequest(req, responseHandlers);
    }

    public put<T>(path: string, data: T, responseHandlers: Array<(response) => any>): Promise<any>
    {
        const req = this.createRequest();
        req.method = "put";
        req.data = data;
        req.url = path;
        return this.makeRequest(req, responseHandlers);
    }
}
