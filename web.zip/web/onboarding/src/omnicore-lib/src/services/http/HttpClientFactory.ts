
import axios, {AxiosRequestConfig} from 'axios'
import {HttpClientConfig} from "./HttpClientConfig";
import {HttpClientImpl} from "./HttpClientImpl";
import {HttpRequestSpec} from "./HttpRequest";
import {HttpResponse} from "./HttpResponse";
import {LocalCache} from "../cache/LocalCache";
import {Deferred} from "../deferred/deferred";
import { v4 as uuidv4 } from 'uuid';
import * as AxiosLogger from 'axios-logger';
export interface HttpClient
{
    makeRequest<T = any, R = any>(request: HttpRequestSpec<T>, responseHandlers?): Promise<R>;
    createRequest<T>(): HttpRequestSpec<T>;

    get<T, R = any>(path: string, params: T, responseTransformers: Array<(response) => any>): Promise<R>;
    post<T, R = any>(path: string, data: T, responseTransformers: Array<(response) => any>): Promise<R>;
    put<T, R = any>(path: string, data: T, responseTransformers: Array<(response) => any>): Promise<R>;
}


export function ResponseCodeMapper(mapping, defaultMapping: (data) => any = a => a) {
    return function(response) {
        if (response.status in mapping) {
            return mapping[response.status](response);
        } else {
            return defaultMapping !== undefined ?
                defaultMapping(response):
                response;
        }
    }
}

//
// Adds a request ID to the request if there is none
export function OmnioIdRequestTransformer(request) {

    const OmniRequestIdFieldName = "omn-request-id";

    request.headers = request.headers === undefined ? {} : request.headers;

    if (!(OmniRequestIdFieldName in request.headers)) {
        request.headers[OmniRequestIdFieldName] = uuidv4()
        console.log("OmnioID added to header")
    }

    return request;
}

//  The HttpClientFactory is the single place where axios http clients should be created.  Named configurations can be stored and used in the create process
export class HttpClientFactory {
    private readonly defaultConfigName = "_default";
    private configs: any = {};

    constructor(httpClientConfig: HttpClientConfig, private localCache: LocalCache) {
        this.setDefaultConfig(httpClientConfig);
    }

    public getDefaultConfig(): HttpClientConfig {
        let _default = this.configs[this.defaultConfigName] as HttpClientConfig;
        if (typeof _default === undefined) {
            _default = new HttpClientConfig();
            _default.baseURL = axios.defaults.baseURL || _default.baseURL;
            _default.timeout = axios.defaults.timeout || _default.timeout;
            this.configs[this.defaultConfigName] = _default;
        }
        return this.configs[this.defaultConfigName] as HttpClientConfig;
    }

    public setNamedConfig(configName: string, config: HttpClientConfig) {
        this.configs[configName] = config;
    }

    public setDefaultConfig(config: HttpClientConfig) {
        this.setNamedConfig(this.defaultConfigName, config);
        this.buildAxiosConfig(config);
    }

    //
    // Create a new http client
    public create(configName: string = this.defaultConfigName, requestTransformers: Array<(request) => any> = []): HttpClient  {
        const clientConfig = this.configs[configName] as HttpClientConfig;
        if (clientConfig) {
            const axiosConfig = this.buildAxiosConfig(clientConfig);
            const axiosInstance = axios.create(axiosConfig);

            axiosInstance.interceptors.request.use(AxiosLogger.requestLogger);
            axiosInstance.interceptors.response.use(AxiosLogger.responseLogger);
            
            return new HttpClientImpl(axiosInstance, this.localCache, clientConfig, requestTransformers);
        }
        
        const axiosInstance = axios.create();
        
        axiosInstance.interceptors.request.use(AxiosLogger.requestLogger);
        axiosInstance.interceptors.response.use(AxiosLogger.responseLogger);
        
        return new HttpClientImpl(axiosInstance, this.localCache, clientConfig);
    }

    /// map from HttpClientConfig into the AxiosRequestConfig
    private buildAxiosConfig(clientConfig: HttpClientConfig): AxiosRequestConfig {
        const axiosConfig: AxiosRequestConfig = {};
        
        axiosConfig.timeout = clientConfig.timeout || axiosConfig.timeout;
        axiosConfig.baseURL = clientConfig.baseURL || axiosConfig.baseURL;

        if (clientConfig.authToken && clientConfig.authTokenName) {
            axiosConfig.headers = {};
            axiosConfig.headers[clientConfig.authTokenName] = clientConfig.authToken;
        }
        return axiosConfig;
    }
}
