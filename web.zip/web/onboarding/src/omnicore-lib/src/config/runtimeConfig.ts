import {HttpClientConfig} from "../services/http/HttpClientConfig";
import {LocalCacheConfig} from "../services/cache/LocalCacheConfig";

export interface RuntimeConfig {
    http: HttpClientConfig;
    localCache: LocalCacheConfig;
    contactCentreTelephone: string;
    googleId: string;
    cookieBotId: string;
}
