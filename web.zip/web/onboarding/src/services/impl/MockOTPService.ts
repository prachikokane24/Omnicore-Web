import { OTPService, OneTimePasswordStatus, OneTimePasswordResponse } from "../OTPService";

export class MockResponse {
    Code?: string;
    UniqueId?: string;
    PhoneNumber?: string;
    ReturnedStatus?: OneTimePasswordStatus

    constructor(phoneNumber: string, uniqueId: string, code: string, returnedStatus: OneTimePasswordStatus) {
        this.Code = code;
        this.UniqueId = uniqueId;
        this.PhoneNumber = phoneNumber;
        this.ReturnedStatus = returnedStatus;
    }

    buildResponse() {
        const res = new OneTimePasswordResponse()
        res.status = this.ReturnedStatus;
        res.requestId = "";
        res.sessionId = this.UniqueId;
        return res;
    }
}

export default class MockOTPService implements OTPService{
    mockedResponses: Array<MockResponse>;
    defaultResponse: MockResponse;

    constructor(mockedResponses: Array<MockResponse>, defaultResponse: MockResponse) {
        this.mockedResponses = mockedResponses;
        this.defaultResponse = defaultResponse;
    }

    async sendOTP(phoneNumber: string): Promise<OneTimePasswordResponse> {
        const mockResponses = this.mockedResponses.filter(mr => mr.PhoneNumber === phoneNumber);
        if (mockResponses.length !== 1) {
            if (this.defaultResponse === undefined) {
                throw Error("No mocked response setup for this phone number, and no wildcard response setup either");
            }
            return this.defaultResponse.buildResponse();
        }
        return mockResponses[0].buildResponse();
    }

    async verifyOTP(sessionId: string, phoneNumber: string, otpCode: string): Promise<OneTimePasswordStatus | undefined> {
        const mockResponses = this.mockedResponses.filter(mr => mr.PhoneNumber === phoneNumber);
        let mockResponse: MockResponse;
        if (mockResponses.length !== 1) {
            if (this.defaultResponse === undefined) {
                throw Error("No mocked response setup for this phone number, and no wildcard response setup either");
            } else {
                mockResponse = this.defaultResponse;
            }
        } else {
            mockResponse = mockResponses[0];
        }

        return mockResponse.Code === otpCode ? OneTimePasswordStatus.Valid : OneTimePasswordStatus.Invalid;
    }
}