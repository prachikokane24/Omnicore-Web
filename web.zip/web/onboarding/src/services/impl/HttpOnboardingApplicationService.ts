import { omnicore } from "@/omnicore-lib";
import {
  HttpClient,
  OmnioIdRequestTransformer,
  ResponseCodeMapper,
} from "@/omnicore-lib/src/services/http/HttpClientFactory";

import { OnboardingApplication } from "@/types/onboarding.types";
import OnboardingApplicationService, {
  DrivingLicenceValidationResponse,
  PartnerIdCheckRequest,
  PartnerIdCheckResponse,
  EmailCheckRequest,
  EmailCheckResponse,
  GetApplicationPersonResponse,
  GetApplicationResponse,
  IdentityCardValidationResponse,
  KycDocumentInfo,
  PassportValidationResponse,
  ProofOfAddressValidationResponse,
  SaveApplicationRequest,
  SaveApplicationResponse,
  SelfieValidationResponse,
  SubmitDocumentRequest,
  SubmitDocumentResponse,
  ValidateDrivingLicenceRequest,
  ValidateIdentityCardRequest,
  ValidatePassportRequest,
  ValidateProofOfAddressRequest,
  ValidateSelfieRequest,
} from "../OnboardingApplicationService";

export default class HttpOnboardingApplicationService
  implements OnboardingApplicationService {

  createClient(): HttpClient {
    return omnicore().httpFactory.create(undefined, [
      OmnioIdRequestTransformer     
    ]);
  }  

  async saveApplication(
    application: OnboardingApplication
  ): Promise<SaveApplicationResponse> {
    const payload = new SaveApplicationRequest();    
    payload.application = application;

    console.log(JSON.stringify(payload));

    const httpClient = this.createClient();
    const path = "fss/fss/v1/onboarding/account/application";

    return httpClient.post<SaveApplicationRequest>(path, payload, [
      ResponseCodeMapper({
        "200": (response) => response.data as SaveApplicationResponse,
      }),
    ]);
  }

  async fetchApplication(
    applicationId: string
  ): Promise<GetApplicationResponse> {
    const httpClient = this.createClient();
    const path = `fss/fss/v1/onboarding/account/application/${applicationId}`;
    const response = await httpClient.get(path, undefined, []);
    return response.data as GetApplicationResponse;
  }
  
  async getApplicationPerson(
    personId: string
  ): Promise<GetApplicationPersonResponse> {
    const httpClient = this.createClient();
    const path = `fss/fss/v1/onboarding/application-person/${personId}`;
    const response = await httpClient.get(path, undefined, []);
    return response.data as GetApplicationPersonResponse;
  }

  async submitDocument(
    kycChallengeId: string,
    documents: KycDocumentInfo[]
  ): Promise<SubmitDocumentResponse> {
    const httpClient = this.createClient();
    const path = `fss/fss/v1/onboarding/account/application/documents`;
    const response = await httpClient.post<SubmitDocumentRequest>(
      path,
      new SubmitDocumentRequest(kycChallengeId, documents),
      []
    );

    return response.data as SubmitDocumentResponse;
  }

  async validateSelfie(image: string): Promise<SelfieValidationResponse>{
    const httpClient = this.createClient();
    const path = `fss/fss/v1/onboarding/validate-document/selfie`;
    const response = await httpClient.post<ValidateSelfieRequest>(
      path,
      new ValidateSelfieRequest(image),
      []
    );

    return response.data as SelfieValidationResponse;
  }
  
  async validateProofOfAddress(image: string, countryOfIssue: string, applicationId: string): Promise<ProofOfAddressValidationResponse>{
    const httpClient = this.createClient();
    const path = `fss/fss/v1/onboarding/validate-document/address`;
    const response = await httpClient.post<ValidateProofOfAddressRequest>(
      path,
      new ValidateProofOfAddressRequest(image, countryOfIssue, applicationId),
      []
    );

    return response.data as ProofOfAddressValidationResponse;
  }
    
  async validatePassport(image: string, countryOfIssue: string): Promise<PassportValidationResponse>{
    const httpClient = this.createClient();
    const path = `fss/fss/v1/onboarding/validate-document/passport`;
    const response = await httpClient.post<ValidatePassportRequest>(
      path,
      new ValidatePassportRequest(image, countryOfIssue),
      []
    );

    return response.data as PassportValidationResponse;
  }

  async validateDrivingLicence(frontImage: string, backImage: string, countryOfIssue: string): Promise<DrivingLicenceValidationResponse>{
    const httpClient = this.createClient();
    const path = `fss/fss/v1/onboarding/validate-document/driving-licence`;
    const response = await httpClient.post<ValidateDrivingLicenceRequest>(
      path,
      new ValidateDrivingLicenceRequest(frontImage, backImage, countryOfIssue),
      []
    );

    return response.data as DrivingLicenceValidationResponse;
  }
  
  async validateIdentityCard(frontImage: string, backImage: string, countryOfIssue: string): Promise<IdentityCardValidationResponse>{
    const httpClient = this.createClient();
    const path = `fss/fss/v1/onboarding/validate-document/identity`;
    const response = await httpClient.post<ValidateIdentityCardRequest>(
      path,
      new ValidateIdentityCardRequest(frontImage, backImage, countryOfIssue),
      []
    );

    return response.data as IdentityCardValidationResponse;
  }

  async emailCheck(email: string): Promise<EmailCheckResponse>{
    const httpClient = this.createClient();
    const path = `fss/fss/v1/onboarding/emailcheck`;
    const response = await httpClient.post<EmailCheckRequest>(
      path,
      new EmailCheckRequest(email),
      []
    );

    return response.data as EmailCheckResponse;
  }

  async validatePartnerId(partnerId: string): Promise<PartnerIdCheckResponse>{
     const httpClient = this.createClient();
     const path = `fss/fss/v1/onboarding/partner/validatecode`;
     const response = await httpClient.post<PartnerIdCheckRequest>(
       path,
       new PartnerIdCheckRequest(partnerId),
       []
     );
     
     return response.data as PartnerIdCheckResponse;

  }
}
