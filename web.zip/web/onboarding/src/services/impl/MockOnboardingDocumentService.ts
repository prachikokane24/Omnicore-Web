import OnboardingDocumentService, { OnboardingDocumentUploadRequest, OnboardingDocumentUploadResponse } from '../OnboardingDocumentService';

export default class MockOnboardingDocumentService implements OnboardingDocumentService {

    async upload(request: OnboardingDocumentUploadRequest): Promise<OnboardingDocumentUploadResponse> {
        return new Promise<OnboardingDocumentUploadResponse>((resolve, reject) => {
            resolve();
        });
    }
}