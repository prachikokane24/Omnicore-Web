import { ApplicantKycStatus, ApplicationStatuses, KycChallenge, KycChallengeDocument, KycChallengeDocumentCategory, OnboardingApplication } from "@/types/onboarding.types";
import OnboardingApplicationService, { DocumentValidationReason, DocumentValidationStatus, DrivingLicenceValidationResponse, EmailCheckRequest, EmailCheckResponse, Gender, GetApplicationPersonResponse, GetApplicationResponse, IdentityCardValidationResponse, KycDocumentInfo, PassportValidationResponse, ProofOfAddressValidationResponse, SaveApplicationResponse, SelfieValidationResponse, SubmitDocumentResponse,PartnerIdCheckResponse } from "../OnboardingApplicationService";

export default class MockOnboardingApplication implements OnboardingApplicationService {
    getApplicationPerson(personId: string): Promise<GetApplicationPersonResponse> {
        throw new Error("Method not implemented.");
    }
    async saveApplication(application: OnboardingApplication): Promise<SaveApplicationResponse> {
        return new Promise((resolve, reject) => {
            console.log(`SVC::saving application:`);
            console.log(JSON.stringify(application));

            const data = new SaveApplicationResponse();
            data.application = application;
            data.application.id = "123456-123-4654-987987";

            switch(application.primaryApplicant?.currentAddress.postalCode) {
                case "AB12CD":
                    application.applicationStatus = ApplicationStatuses.Success;
                    resolve(data);
                    break;
                case "EF12GH":
                    application.applicationStatus = ApplicationStatuses.Failed;
                    resolve(data);
                    break;
                case "IJ12KL":
                    application.applicationStatus = ApplicationStatuses.KycChallengeOnGoing;
                    resolve(data);
                    break;
                default:
                    application.applicationStatus = ApplicationStatuses.Failed;
                    reject(Error("Boommmmm!!"));
            }
        });
    }
    async submitDocument(kycChallengeId: string, documents: KycDocumentInfo[]): Promise<SubmitDocumentResponse> {
        return new Promise((resolve, reject) => resolve(new SubmitDocumentResponse()));
    }
    
    async getApplication(personId: string): Promise<GetApplicationResponse> {
        return new Promise((resolve, reject) => {
            const data = new GetApplicationResponse();
            data.application = new OnboardingApplication();
            data.application.id = "12345";
            data.application.applicationStatus = ApplicationStatuses.KycChallengeOnGoing;
            data.application.primaryApplicant!.id = personId;
            data.application.primaryApplicant!.contactDetails.mobilePhoneNumber = "0123456789";
            data.application.primaryApplicant!.kycChallenge = new KycChallenge();
            data.application.primaryApplicant!.kycChallenge.id = "1";
            data.application.primaryApplicant!.kycChallenge.status = ApplicantKycStatus.InReview;

            const poiCategory = new KycChallengeDocumentCategory();
            const passport: KycChallengeDocument = { id: "", identity: "Passport" };
            const identityCard: KycChallengeDocument = { id: "", identity: "IdentityCard" };
            const drivingLicence: KycChallengeDocument = { id: "", identity: "DrivingLicence" };
            const birthCertificate: KycChallengeDocument = { id: "", identity: "BirthCertificate" };
            const eeaIdentityCard: KycChallengeDocument = { id: "", identity: "EeaIdentityCard" };
            const ukResidencePermit: KycChallengeDocument = { id: "", identity: "UkResidencePermit" };
            const ukDisabilityBlueBadge: KycChallengeDocument = { id: "", identity: "UkDisabilityBlueBadge" };
            const homeOfficeTravelDocument: KycChallengeDocument = { id: "", identity: "HomeOfficeTravelDocument" };
            const ukArmedForcesId: KycChallengeDocument = { id: "", identity: "UkArmedForcesId" };
            const nhsLetter: KycChallengeDocument = { id: "", identity: "NhsLetter" };

            poiCategory.documents = new Array<KycChallengeDocument>();
            poiCategory.type = "identity"
            poiCategory.numberRequired = 1;
            poiCategory.documents.push(passport);
            poiCategory.documents.push(identityCard);
            poiCategory.documents.push(drivingLicence);
            poiCategory.documents.push(birthCertificate);
            poiCategory.documents.push(eeaIdentityCard);
            poiCategory.documents.push(ukResidencePermit);
            poiCategory.documents.push(ukDisabilityBlueBadge);
            poiCategory.documents.push(homeOfficeTravelDocument);
            poiCategory.documents.push(ukArmedForcesId);
            poiCategory.documents.push(nhsLetter);

            const poaCategory = new KycChallengeDocumentCategory();
            const utilityBill: KycChallengeDocument = { id: "", address: "UtilityBill" };
            const taxBill: KycChallengeDocument = { id: "", address: "TaxBill" };
            const personalBankStatement: KycChallengeDocument = { id: "", address: "PersonalBankStatement" };
            const annualMortgageStatement: KycChallengeDocument = { id: "", address: "AnnualMortgageStatement" };
            const hmrcLetter: KycChallengeDocument = { id: "", address: "HmrcLetter" };
            const taxStatement: KycChallengeDocument = { id: "", address: "TaxStatement" };
            const creditOrDebitCardStatement: KycChallengeDocument = { id: "", address: "CreditOrDebitCardStatement" };
            const ukCreditUnionStatement: KycChallengeDocument = { id: "", address: "UkCreditUnionStatement" };
            const currentTenanceAgreement: KycChallengeDocument = { id: "", address: "CurrentTenanceAgreement" };
            const vehicleRegistration: KycChallengeDocument = { id: "", address: "VehicleRegistration" };
            const carorHomeInsturanceDocument: KycChallengeDocument = { id: "", address: "CarorHomeInsturanceDocument" };
            const solicitorsCompletionLetter: KycChallengeDocument = { id: "", address: "SolicitorsCompletionLetter" };
            const firearmsOrShotgunCertificate: KycChallengeDocument = { id: "", address: "FirearmsOrShotgunCertificate" };
            const mooringFeesDocumentation: KycChallengeDocument = { id: "", address: "MooringFeesDocumentation" };
            const leaseDeedOrRentalAgreementOrPropertyRegistrationDocument: KycChallengeDocument = { id: "", address: "LeaseDeedOrRentalAgreementOrPropertyRegistrationDocument" };
            const ukDrivingLicense: KycChallengeDocument = { id: "", address: "UKDrivingLicense" };
            const letterFromNHS: KycChallengeDocument = { id: "", address: "LetterFromNHS" };

            poaCategory.documents = new Array<KycChallengeDocument>();
            poaCategory.type = "address"
            poaCategory.numberRequired = 1;
            poaCategory.documents.push(utilityBill);
            poaCategory.documents.push(taxBill);
            poaCategory.documents.push(personalBankStatement);
            poaCategory.documents.push(annualMortgageStatement);
            poaCategory.documents.push(hmrcLetter);
            poaCategory.documents.push(taxStatement);
            poaCategory.documents.push(creditOrDebitCardStatement);
            poaCategory.documents.push(ukCreditUnionStatement);
            poaCategory.documents.push(currentTenanceAgreement);
            poaCategory.documents.push(vehicleRegistration);
            poaCategory.documents.push(carorHomeInsturanceDocument);
            poaCategory.documents.push(solicitorsCompletionLetter);
            poaCategory.documents.push(firearmsOrShotgunCertificate);
            poaCategory.documents.push(mooringFeesDocumentation);
            poaCategory.documents.push(leaseDeedOrRentalAgreementOrPropertyRegistrationDocument);
            poaCategory.documents.push(ukDrivingLicense);
            poaCategory.documents.push(letterFromNHS);

            const photoCategory = new KycChallengeDocumentCategory();
            const selfie: KycChallengeDocument = { id: "", photo: "Selfie" };

            photoCategory.documents = new Array<KycChallengeDocument>();
            photoCategory.type = "photo"
            photoCategory.numberRequired = 1;
            photoCategory.documents.push(selfie);
            
            data.application.primaryApplicant!.kycChallenge.requiredDocuments = new Array<KycChallengeDocumentCategory>();
            data.application.primaryApplicant!.kycChallenge.requiredDocuments.push(poiCategory);
            data.application.primaryApplicant!.kycChallenge.requiredDocuments.push(poaCategory);
            data.application.primaryApplicant!.kycChallenge.requiredDocuments.push(photoCategory);

            resolve(data);
        });
    }
    async fetchApplication(applicationId: string): Promise<GetApplicationResponse> {
        return new Promise((resolve, reject) => {
            const data = new GetApplicationResponse();
            data.application = new OnboardingApplication();
            data.application.id = applicationId;
            data.application.applicationStatus = ApplicationStatuses.KycChallengeOnGoing;
            data.application.primaryApplicant!.contactDetails.mobilePhoneNumber = "0123456789";
            data.application.primaryApplicant!.kycChallenge = new KycChallenge();
            data.application.primaryApplicant!.kycChallenge.id = "1";
            data.application.primaryApplicant!.kycChallenge.status = ApplicantKycStatus.InReview;

            const poiCategory = new KycChallengeDocumentCategory();
            const passport: KycChallengeDocument = { id: "", identity: "Passport" };
            const identityCard: KycChallengeDocument = { id: "", identity: "IdentityCard" };
            const drivingLicence: KycChallengeDocument = { id: "", identity: "DrivingLicence" };
            const birthCertificate: KycChallengeDocument = { id: "", identity: "BirthCertificate" };
            const eeaIdentityCard: KycChallengeDocument = { id: "", identity: "EeaIdentityCard" };
            const ukResidencePermit: KycChallengeDocument = { id: "", identity: "UkResidencePermit" };
            const ukDisabilityBlueBadge: KycChallengeDocument = { id: "", identity: "UkDisabilityBlueBadge" };
            const homeOfficeTravelDocument: KycChallengeDocument = { id: "", identity: "HomeOfficeTravelDocument" };
            const ukArmedForcesId: KycChallengeDocument = { id: "", identity: "UkArmedForcesId" };
            const nhsLetter: KycChallengeDocument = { id: "", identity: "NhsLetter" };

            poiCategory.documents = new Array<KycChallengeDocument>();
            poiCategory.type = "identity"
            poiCategory.numberRequired = 1;
            poiCategory.documents.push(passport);
            poiCategory.documents.push(identityCard);
            poiCategory.documents.push(drivingLicence);
            poiCategory.documents.push(birthCertificate);
            poiCategory.documents.push(eeaIdentityCard);
            poiCategory.documents.push(ukResidencePermit);
            poiCategory.documents.push(ukDisabilityBlueBadge);
            poiCategory.documents.push(homeOfficeTravelDocument);
            poiCategory.documents.push(ukArmedForcesId);
            poiCategory.documents.push(nhsLetter);

            const poaCategory = new KycChallengeDocumentCategory();
            const utilityBill: KycChallengeDocument = { id: "", address: "UtilityBill" };
            const taxBill: KycChallengeDocument = { id: "", address: "TaxBill" };
            const personalBankStatement: KycChallengeDocument = { id: "", address: "PersonalBankStatement" };
            const annualMortgageStatement: KycChallengeDocument = { id: "", address: "AnnualMortgageStatement" };
            const hmrcLetter: KycChallengeDocument = { id: "", address: "HmrcLetter" };
            const taxStatement: KycChallengeDocument = { id: "", address: "TaxStatement" };
            const creditOrDebitCardStatement: KycChallengeDocument = { id: "", address: "CreditOrDebitCardStatement" };
            const ukCreditUnionStatement: KycChallengeDocument = { id: "", address: "UkCreditUnionStatement" };
            const currentTenanceAgreement: KycChallengeDocument = { id: "", address: "CurrentTenanceAgreement" };
            const vehicleRegistration: KycChallengeDocument = { id: "", address: "VehicleRegistration" };
            const carorHomeInsturanceDocument: KycChallengeDocument = { id: "", address: "CarorHomeInsturanceDocument" };
            const solicitorsCompletionLetter: KycChallengeDocument = { id: "", address: "SolicitorsCompletionLetter" };
            const firearmsOrShotgunCertificate: KycChallengeDocument = { id: "", address: "FirearmsOrShotgunCertificate" };
            const mooringFeesDocumentation: KycChallengeDocument = { id: "", address: "MooringFeesDocumentation" };
            const leaseDeedOrRentalAgreementOrPropertyRegistrationDocument: KycChallengeDocument = { id: "", address: "LeaseDeedOrRentalAgreementOrPropertyRegistrationDocument" };
            const ukDrivingLicense: KycChallengeDocument = { id: "", address: "UKDrivingLicense" };
            const letterFromNHS: KycChallengeDocument = { id: "", address: "LetterFromNHS" };

            poaCategory.documents = new Array<KycChallengeDocument>();
            poaCategory.type = "address"
            poaCategory.numberRequired = 1;
            poaCategory.documents.push(utilityBill);
            poaCategory.documents.push(taxBill);
            poaCategory.documents.push(personalBankStatement);
            poaCategory.documents.push(annualMortgageStatement);
            poaCategory.documents.push(hmrcLetter);
            poaCategory.documents.push(taxStatement);
            poaCategory.documents.push(creditOrDebitCardStatement);
            poaCategory.documents.push(ukCreditUnionStatement);
            poaCategory.documents.push(currentTenanceAgreement);
            poaCategory.documents.push(vehicleRegistration);
            poaCategory.documents.push(carorHomeInsturanceDocument);
            poaCategory.documents.push(solicitorsCompletionLetter);
            poaCategory.documents.push(firearmsOrShotgunCertificate);
            poaCategory.documents.push(mooringFeesDocumentation);
            poaCategory.documents.push(leaseDeedOrRentalAgreementOrPropertyRegistrationDocument);
            poaCategory.documents.push(ukDrivingLicense);
            poaCategory.documents.push(letterFromNHS);

            const photoCategory = new KycChallengeDocumentCategory();
            const selfie: KycChallengeDocument = { id: "", photo: "Selfie" };

            photoCategory.documents = new Array<KycChallengeDocument>();
            photoCategory.type = "photo"
            photoCategory.numberRequired = 1;
            photoCategory.documents.push(selfie);
            
            data.application.primaryApplicant!.kycChallenge.requiredDocuments = new Array<KycChallengeDocumentCategory>();
            data.application.primaryApplicant!.kycChallenge.requiredDocuments.push(poiCategory);
            data.application.primaryApplicant!.kycChallenge.requiredDocuments.push(poaCategory);
            data.application.primaryApplicant!.kycChallenge.requiredDocuments.push(photoCategory);

            resolve(data);
        });
    }

    async validateSelfie(image: string): Promise<SelfieValidationResponse>{
        return new Promise((resolve, reject) => {
            resolve(new SelfieValidationResponse());
        });
    }
      
    async validateProofOfAddress(image: string, countryOfIssue: string, applicationId: string): Promise<ProofOfAddressValidationResponse>{
        return new Promise((resolve, reject) => {
            resolve(new ProofOfAddressValidationResponse());
        });
    }
    
    async validatePassport(image: string, countryOfIssue: string): Promise<PassportValidationResponse>{
        return new Promise((resolve, reject) => {
            const response = new PassportValidationResponse();
            response.confidence = 1;
            response.countryOfIssue = 'GBP';
            response.expiryDate = "01/01/2025";
            response.firstName = "Hugh";
            response.id = "1";
            response.passportNumber = "ABC123";
            response.processedUtc = new Date().getDate().toString();
            response.reasons = new Array<DocumentValidationReason>();
            response.requestId = "1";
            response.status = DocumentValidationStatus.Valid;
            response.surname = "Janus";
            resolve(response);
        });
    }

    async validateDrivingLicence(frontImage: string, backImage: string, countryOfIssue: string): Promise<DrivingLicenceValidationResponse>{
        return new Promise((resolve, reject) => {
            const response = new DrivingLicenceValidationResponse();    
            response.confidence = 1;
            response.countryOfIssue = 'GBP';
            response.dateOfBirth = "01/01/1980";
            response.expirationDate = "01/01/2025";
            response.firstName = "Hugh";
            response.formattedAddress = "1 New Road, New Town, NT1 1NT";
            response.gender = Gender.Other;
            response.id = "1";
            response.issueDate = "01/01/2021";
            response.issuer = "Gov";
            response.licenceNumber = "ABC123";
            response.nationality = "British";
            response.placeOfBirth = "London";
            response.processedUtc = new Date().getDate().toString();
            response.reasons = new Array<DocumentValidationReason>();
            response.requestId = "1";
            response.status = DocumentValidationStatus.Valid;
            response.surname = "Janus";
            resolve(response);
        });
    }
    
    async validateIdentityCard(frontImage: string, backImage: string, countryOfIssue: string): Promise<IdentityCardValidationResponse>{
        return new Promise((resolve, reject) => {
            const response = new IdentityCardValidationResponse();
            response.confidence = 1;
            response.countryOfIssue = 'GBP';
            response.dateOfBirth = "01/01/1980";
            response.expirationDate = "01/01/2025";
            response.firstName = "Hugh";
            response.gender = Gender.Other;
            response.id = "1";
            response.identityNumber = "ABC123";
            response.issueDate = "01/01/2021";
            response.issuer = "Gov";
            response.nationality = "British";
            response.processedUtc = new Date().getDate().toString();
            response.reasons = new Array<DocumentValidationReason>();
            response.requestId = "1";
            response.status = DocumentValidationStatus.Valid;
            response.surname = "Janus";
            resolve(response);
        });
    }

    async emailCheck(email: string): Promise<EmailCheckResponse>{

        return new Promise((resolve) => {
            const response = new EmailCheckResponse();
            response.exists = false;            
            resolve(response);
        });       
      }

      async validatePartnerId(partnerId: string): Promise<PartnerIdCheckResponse>{

        return new Promise((resolve) => {
            const response = new PartnerIdCheckResponse();
            response.isValid = false;    
            resolve(response);
        });       
      }
}