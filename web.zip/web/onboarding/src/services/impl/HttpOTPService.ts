import { omnicore } from "@/omnicore-lib";
import { OmnioIdRequestTransformer, ResponseCodeMapper } from "@/omnicore-lib/src/services/http/HttpClientFactory";

import { OTPService, OneTimePasswordResponse, OneTimePasswordStatus, SendOneTimePasswordRequest, VerifyOneTimePasswordRequest } from "../OTPService";

export default class HttpOTPService implements OTPService{
    async sendOTP(phoneNumber: string): Promise<OneTimePasswordResponse> {
        const payload = new SendOneTimePasswordRequest()
        payload.mobileNumber = phoneNumber;

        const httpClient = this.createClient();
        const path = "fss/fss/proxy/authentication/v1/otp";
        try {
            const otpReponse = await httpClient.post<SendOneTimePasswordRequest>(path, payload, [
                ResponseCodeMapper(
                {
                    "200": response => response.data as OneTimePasswordResponse,
                })
            ]);
            return otpReponse;
        } catch(error) {
            const response = new OneTimePasswordResponse();
            response.status = OneTimePasswordStatus.FailureOnOTPCreation;
            return response;
        }
    }
    async verifyOTP(sessionId: string, phoneNumber: string, otpCode: string): Promise<OneTimePasswordStatus | undefined> {
        const request = new VerifyOneTimePasswordRequest();
        request.code = otpCode;
        request.mobileNumber = phoneNumber;

        const httpClient = this.createClient();
        const path = `fss/fss/proxy/authentication/v1/otp/${sessionId}`;
        try {
            const response = await httpClient.post<VerifyOneTimePasswordRequest>(path, request,
                [
                    ResponseCodeMapper(
                    {
                        "200": response => { 
                            const otpResponse = response.data as OneTimePasswordResponse;
                            return otpResponse.status;
                        },
                    })
                ]);
            return response;
        } catch(error) {
            return error.response.status === 400 ? OneTimePasswordStatus.Invalid : OneTimePasswordStatus.FailureOnVerif;
        }
    }

    private createClient() {
        return omnicore().httpFactory.create(undefined, [
            OmnioIdRequestTransformer           
        ]);
    }
}