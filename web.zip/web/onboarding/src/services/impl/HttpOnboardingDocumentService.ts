import { omnicore } from "@/omnicore-lib";
import  { AxiosError } from "axios";
import {
  OmnioIdRequestTransformer,  
} from "@/omnicore-lib/src/services/http/HttpClientFactory";

import OnboardingDocumentService, {
  OnboardingDocumentUploadRequest,
  OnboardingDocumentUploadResponse,
} from "../OnboardingDocumentService";

export default class HttpOnboardingDocumentService
  implements OnboardingDocumentService {
  async upload(
    request: OnboardingDocumentUploadRequest
  ): Promise<OnboardingDocumentUploadResponse> {
    const httpClient = omnicore().httpFactory.create(undefined, [
      OmnioIdRequestTransformer  
    ]);

    const req = httpClient.createRequest();
    req.data = request.file;
    req.url = "/fss/fss/v1/onboarding/document";
    req.method = "post";
    req.headers = {};
    req.headers["Content-type"] = "multipart/form-data";
    let response;
   
    try {
      response = await httpClient.makeRequest(req);
      console.log(response);
    } catch (error) {
      const err = error as AxiosError;

      if (err.response) {
        console.log(err.response.status);
        console.log(err.response.data);
        const documentUploadResponse = new OnboardingDocumentUploadResponse();
        documentUploadResponse.statusCode = err.response.data.statusCode;
        documentUploadResponse.errorCode = err.response.data.errorCode;
        return documentUploadResponse;
      }
    }
    console.log(response);
   
    const documentUploadResponse = response.data as OnboardingDocumentUploadResponse;
    documentUploadResponse.statusCode = response.status;
    return documentUploadResponse;
  }
}
