export class ProgressEvent {
    public loaded = 0
    public total = 0
}

export class OnboardingDocumentUploadRequest {
    public file: any;
    public progressEventCallback!: () => ProgressEvent;

    public OnboardingDocumentUploadRequest(file: any, progressEventCallback: () => ProgressEvent) {
        this.file = file;
        this.progressEventCallback = progressEventCallback;
    }
}

export class OnboardingDocumentUploadResponse {
    fileId = ""
    requestId = ""
    processedUtc = ""
    errorCode = ""
    statusCode = 0

}

export default interface OnboardingDocumentService {
    upload(data: OnboardingDocumentUploadRequest): Promise<OnboardingDocumentUploadResponse>;
}