import { OnboardingApplication } from "@/types/onboarding.types";

class StandardResponse {
    public requestId?: string;
    public processedUtc?: string;
}

export enum Gender {
    Male,
    Female,
    Other
}

export class GetApplicationResponse {
    public application: OnboardingApplication = new OnboardingApplication();
}

export class SaveApplicationRequest {
    public application: OnboardingApplication = new OnboardingApplication();
}

export class SaveApplicationResponse {
    public application: OnboardingApplication = new OnboardingApplication();
    // public TenantId?: string;
}

export class KycDocumentInfo {
    public kycDocumentId = "";
    public secureDocumentStorageId = "";
    public forceUpload = true;

    constructor(kycDocumentId: string, secureDocumentStorageId: string) {
        this.kycDocumentId = kycDocumentId;
        this.secureDocumentStorageId = secureDocumentStorageId;
    }
}

class KycChallengeDocument {
    public kycChallengeId = "";
    public documents: KycDocumentInfo[] = [];
}
export class SubmitDocumentRequest {
    public applicants: KycChallengeDocument[] = []; 

    constructor(kycChallengeId: string, documents: KycDocumentInfo[]) {
        const kcd = new KycChallengeDocument();
        kcd.kycChallengeId = kycChallengeId;
        kcd.documents = documents;
        this.applicants = [kcd];
    }
}

export enum DocumentUploadOutcome {
    Success = "success",
    FailedSystemError = "failedSystemError"
}

export class SubmitDocumentResponseDocumentOutcome {
    outcome?: DocumentUploadOutcome;
    kycDocumentId = "";
    secureDocumentStorageId = "";
}

export class SubmitDocumentResponseApplicantOutcome {
    kycChallengeId = "";
    documentOutcomes?: SubmitDocumentResponseDocumentOutcome[];
}

export class SubmitDocumentResponse {
    applicantsOutcomes?: SubmitDocumentResponseApplicantOutcome[];
}

export class ValidateSelfieRequest {
    public image: string; 

    constructor(image: string) {
        this.image = image;
    }
}

export class ValidateProofOfAddressRequest {
    public image: string; 
    public countryOfIssue: string;
    public applicationId: string;

    constructor(image: string, countryOfIssue: string, applicationId: string) {
        this.image = image;
        this.countryOfIssue = countryOfIssue;
        this.applicationId = applicationId;
    }
}

export class ValidatePassportRequest {
    public image: string; 
    public countryOfIssue: string;

    constructor(image: string, countryOfIssue: string) {
        this.image = image;
        this.countryOfIssue = countryOfIssue;
    }
}

export class ValidateDrivingLicenceRequest {
    public frontImage: string; 
    public backImage: string; 
    public countryOfIssue: string;

    constructor(frontImage: string, backImage: string, countryOfIssue: string) {
        this.frontImage = frontImage;
        this.backImage = backImage;
        this.countryOfIssue = countryOfIssue;
    }
}

export class ValidateIdentityCardRequest {
    public frontImage: string; 
    public backImage: string; 
    public countryOfIssue: string;

    constructor(frontImage: string, backImage: string, countryOfIssue: string) {
        this.frontImage = frontImage;
        this.backImage = backImage;
        this.countryOfIssue = countryOfIssue;
    }
}

export enum DocumentValidationStatus {
    Valid = 'valid',
    Invalid = 'invalid',
    NotValidated = 'not validated',
    Unknown = 'unknown'
}

export enum DocumentValidationReason{
    NoDataExtracted = 'noDataExtracted',
    ExpiryDateInvalid = 'expiryDateInvalid',
    ForensicCheckInvalid = 'forensicCheckInvalid',
    NoDateOfIssue = 'noDateOfIssue',
    DateOfIssueInvalid = 'dateOfIssueInvalid',
    GoogleCheckInvalid = 'googleCheckInvalid',
    IssuerInvalid = 'issuerInvalid',
    DataExtracted = 'dataExtracted',
    DataValid = 'dataValid',
    DataInvalid = 'dataInvalid',
    NotValidated = 'notValidated',
    Unknown = 'unknown'
}

export class BaseDocumentValidationResponse extends StandardResponse {
    public id?: string;
    public confidence?: number;
    public status?: DocumentValidationStatus;
    public reasons?: Array<DocumentValidationReason>
}

export class DrivingLicenceValidationResponse extends BaseDocumentValidationResponse {
    public licenceNumber?: string;
    public firstName?: string;
    public surname?: string;
    public gender?: Gender;
    public formattedAddress?: string;
    public dateOfBirth?: string;
    public placeOfBirth?: string;
    public issuer?: string;
    public nationality?: string;
    public countryOfIssue?: string;
    public issueDate?: string;
    public expirationDate?: string;
}

export class IdentityCardValidationResponse extends BaseDocumentValidationResponse {
    public identityNumber?: string;
    public firstName?: string;
    public surname?: string;
    public gender?: Gender;
    public dateOfBirth?: string;
    public issuer?: string;
    public nationality?: string;
    public countryOfIssue?: string;
    public issueDate?: string;
    public expirationDate?: string;
}

export class PassportValidationResponse extends BaseDocumentValidationResponse {
    public passportNumber?: string;
    public firstName?: string;
    public surname?: string;
    public countryOfIssue?: string;
    public expiryDate?: string;
}

export class ProofOfAddressValidationResponse extends BaseDocumentValidationResponse {
    public name?: string;
    public surname?: string;
    public countryOfIssue?: string;
    public formattedAddress?: string;
    public dateOfIssue?: string;
}

export class SelfieValidationResponse extends BaseDocumentValidationResponse {
    public containsFace?: boolean;
}

export class EmailCheckRequest {

    constructor(email: string) {
        this.email = email;       
    }

    public email: string;
}

export class EmailCheckResponse extends StandardResponse {
    public exists?: boolean;    
}

export class PartnerIdCheckRequest{
    constructor(partnerCode: string)
    {
        this.partnerCode = partnerCode;
    }
    public partnerCode: string;
}

export class PartnerIdCheckResponse extends StandardResponse
{
    public isValid?: boolean;
}

export class GetApplicationPersonResponse extends StandardResponse {
    public personId?: string;
    public applicationId?: string;
}

export default interface OnboardingApplicationService {
    fetchApplication(applicationId: string): Promise<GetApplicationResponse>;
    getApplicationPerson(personId: string): Promise<GetApplicationPersonResponse>;
    saveApplication(application: OnboardingApplication): Promise<SaveApplicationResponse>;
    submitDocument(kycChallengeId: string, documents: KycDocumentInfo[]): Promise<SubmitDocumentResponse>;
    validateSelfie(image: string): Promise<SelfieValidationResponse>;
    validateProofOfAddress(image: string, countryOfIssue: string, applicationId: string): Promise<ProofOfAddressValidationResponse>;
    validatePassport(image: string, countryOfIssue: string): Promise<PassportValidationResponse>;
    validateDrivingLicence(frontImage: string, backImage: string, countryOfIssue: string): Promise<DrivingLicenceValidationResponse>;
    validateIdentityCard(frontImage: string, backImage: string, countryOfIssue: string): Promise<IdentityCardValidationResponse>;
    emailCheck(email: string): Promise<EmailCheckResponse>;
    validatePartnerId(partnerId: string): Promise<PartnerIdCheckResponse>;
}

