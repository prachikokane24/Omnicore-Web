export class SendOneTimePasswordRequest {
    mobileNumber?: string;
}

export class VerifyOneTimePasswordRequest {
    code?: string;
    mobileNumber?: string;
}

export enum OneTimePasswordStatus {
    Invalid = "invalid",
    Valid = "valid",
    Cancelled = "cancelled",
    Pending = "pending",

    FailureOnVerif = "failureOnVerification",
    FailureOnOTPCreation = "failureOnOTPCreation"
}

export class OneTimePasswordResponse {
    status?: OneTimePasswordStatus;
    requestId?: string;
    sessionId?: string;
}

export interface OTPService {
    sendOTP(phoneNumber: string): Promise<OneTimePasswordResponse>;
    verifyOTP(sessionId: string, phoneNumber: string, otpCode: string): Promise<OneTimePasswordStatus | undefined>;
}