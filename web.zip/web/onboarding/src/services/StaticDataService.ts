import { countries } from "@/services/staticData/countries"

export class CountryDefinition {
    constructor(public name?: string, public alpha2Code?: string, public alpha3Code?: string, public nationality?: string) {
    }
}

export default class StaticDataService {
    static _countries: Array<CountryDefinition> = countries.map(c => new CountryDefinition(c["name"], c["alpha2Code"], c["alpha3Code"], c["nationality"]));

    getCountries(): Array<CountryDefinition> {
        return [...StaticDataService._countries]; // using the [...list] format allows to return a new copy of the list (shallowCopy)
    }
}