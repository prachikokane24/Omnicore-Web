import Vue from "vue";
import App from "./App.vue";
import i18n from "./plugins/i18n";
import { RuntimeConfig } from "@/omnicore-lib/src/config/runtimeConfig";
import router from "@/router";
import { buildOmnicore, loadCookieBot, loadGoogleAnalytics } from "@/omnicore-lib";
import AppSupport from "@/AppSupport";
import store from "@/store";
import { I18nbridgeImpl } from "@/plugins/i18nbridgeImpl";
import Carousel3d from "vue-carousel-3d";
import { buildVuetify } from "@/plugins/vuetify";
import Observer from 'intersection-observer';
import { Framework } from "vuetify";
import { ObserveVisibility } from 'vue-observe-visibility'

Vue.directive('observe-visibility', ObserveVisibility);

declare module "vue/types/vue" {
  // this.$vuetify inside Vue components
  interface Vue {
    $vuetify: Framework;
  }
}

Vue.use(Observer);
Vue.config.productionTip = false;

const getRuntimeConfig = async () => {
  console.log(`Loaded config file: ${process.env.VUE_APP_DEPLOY_ENV}`);
  let deployEnv = process.env.VUE_APP_DEPLOY_ENV || "default";
  deployEnv = deployEnv.toLowerCase();

  const filePath = process.env.BASE_URL + `runtimeConfig.${deployEnv}.json`;
  const runtimeConfig = await fetch(filePath);
  console.log(`Loaded config file: ${filePath}`);
  return (await runtimeConfig.json()) as RuntimeConfig;
};

getRuntimeConfig().then(function(runtimeConfig) {

  loadGoogleAnalytics(runtimeConfig);
  loadCookieBot(runtimeConfig);

  const i18nBridge = new I18nbridgeImpl(i18n);

  const omnicore = buildOmnicore(runtimeConfig, i18nBridge);

  const appSupport = new AppSupport();

  const vuetify = buildVuetify();

  Vue.use(Carousel3d);

  new Vue({
    router,
    store,
    vuetify,
    i18n,
    render: (h) => h(App),
    provide: () => {
      return {
        omnicore: omnicore,
        appSupport: appSupport,
      };
    },
  }).$mount("#app");
});
