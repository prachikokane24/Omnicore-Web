import Vue from "vue";
import Vuetify from "vuetify/lib/framework";
import VueMask from "v-mask";
import colors from "@tenantStyles/colors.js";

export function buildVuetify() {
  Vue.use(Vuetify);
  Vue.use(VueMask, {});

  const v = new Vuetify({
    theme: {
      options: {
        customProperties: true,
      },
      themes: {
        light: {
          primary: colors.light.primary,
          secondary: colors.light.secondary,
          accent: colors.light.accent,
          error: colors.light.error,
          info: colors.light.info,
          success: colors.light.success,
          warning: colors.light.warning,
        },
      },
    },
  });
  return v;
}
