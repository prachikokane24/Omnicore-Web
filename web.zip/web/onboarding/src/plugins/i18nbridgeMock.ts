import {I18NBridge} from "@/omnicore-lib/src/services/i8n/i18n";


export class I18NbridgeMock implements I18NBridge
{
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    setLocale(local: string): void {
    }
}
