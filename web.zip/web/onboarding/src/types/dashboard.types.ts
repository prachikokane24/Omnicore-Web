

export interface AccountHolder
{
    name: string;
    isPrimary: boolean;
}

export enum AccountType {
    current = 1,
    joint,
    youth,
    wallet = 99
}

export enum WalletType {
    Card = 1,
    Savings,
    Loan,
    Emergency
}

export interface Transaction
{
    transactionId: string;
    date: Date;
    description: string;
    value: number;
    balance: number;
}

export interface Transactions
{
    items: Transaction[];
    cutoff: Date;
}

export class TransactionsBase implements Transactions {
    cutoff = new Date();
    items = new Array<Transaction>();
}

export interface Account
{
    accountId: string;
    accountType: AccountType;
    accountHolders: AccountHolder[];
    sortCode: string;
    accountNumber: string;
    transactions: Transactions;
}

export interface WalletData
{
    walletId: string;
    availableBalance: number;
    pendingCredits: number;
    pendingDebits: number;
    currency: string;
    nickName: string;
    walletType: WalletType;
    linkedToAccount: string;
    walletImageUrl: string;
    color: string;
    textColor: string;
    icon: string;
    transactions: Transactions;
}


export interface SummaryData
{
    accounts: Account[];
    wallets: WalletData[];
}

export class Wallet
{
    constructor(public walletData: WalletData, public  account: Account) {
        if (!walletData.transactions) {
            walletData.transactions = new TransactionsBase();
        }
    }

    public walletId(): string {
        return this.walletData.walletId;
    }

    public isCardAccount(): boolean {
        return typeof this.walletData.walletImageUrl == "string";
    }

    public nickName(): string {
        return this.walletData.nickName;
    }

    public textColor(): string {
        return this.walletData.textColor;
    }

    public color(): string {
        return this.walletData.color;
    }

    public icon(): string {
        return this.walletData.icon
    }

    public accountHoldersText() {
        let result = "";
        if (this.account.accountHolders.length > 0) {
            const accountHolders = this.account.accountHolders;
            if (accountHolders) {
                if (accountHolders.length == 2) {
                    result =  accountHolders.find(h => h.isPrimary)!.name +', ' + accountHolders.find(h => !h.isPrimary)!.name
                }
                else {
                    result =  accountHolders[0].name;
                }
            }
        }
        return result;
    }

    public getTransactions(): Transactions {
        return this.walletData.transactions ? this.walletData.transactions : new TransactionsBase();
    }

    public getBalance(): number {
        return this.walletData.availableBalance;
    }

    public getWalletType(): WalletType {
        return this.walletData.walletType;
    }
}

export class AuthRequest {
    customerId = "123456789";
    email = "richard.gillingham@omnio.global";
    password  = "1234";
}

export interface LoggedInUser {
    Firstname: string;
    Lastname: string;
    Fullname: string;
    token: string;
    tokenExpiry: bigint;
}

export interface AuthResponse {
    success: boolean;
    user: LoggedInUser;
    summaryData: SummaryData;
}
