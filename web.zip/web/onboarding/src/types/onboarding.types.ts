export enum ApplicationStatuses {
  InProgress = "inProgress",
  KycChallengeOnGoing = "kycChallengeOnGoing",
  KycChallengeComplete = "kycChallengeComplete",
  Success = "success",
  Failed = "failed",
}

export class Individual {
  title?: string = "";
  firstName?: string = "";
  middleName?: string = "";
  lastName?: string = "";
}

export class ApplicantResidencyStatus {
  UkPermResident?: boolean;
  UkOrEEANational?: boolean;
}

export enum ApplicationType {
  AdultSole = "AdultSole",
  AdultJoint = "AdultJoint", 
}

export enum AccountType {  
  eMoneyAccount ="eMoneyAccount"
}

export enum ApplicantKycStatus {
  InReview = "inReview",
  Success = "success",
  Failed = "failed",
}

export enum KycReviewStatus {
  Initial = "initial",
  Additional = "additional",
  Complete ="complete"
}

export class AdditionalDetails {
  "nationalities"?: Array<string> = [];
}

export enum ApplicantCurrentTitle {
  Mr = "Mr",
  Mrs = "Mrs",
  Master = "Master",
  Miss = "Miss",
  Ms = "Ms",
  Capt = "Capt",
  Col = "Col",
  Corp = "Corp",
  Dr = "Dr",
  Hon = "Hon",
  Lady = "Lady",
  Major = "Major",
  Prof = "Prof",
  Sir = "Sir",
}

/**
 * Represents an address - iCal standard
 */
export class CommonTypesV1Address {
  "companyName"?: string;
  "building"?: string;
  "line1"?: string;
  "line2"?: string;
  "line3"?: string;
  "line4"?: string;
  "county"?: string;
  "city"?: string;
  "state"?: string;
  "postalCode"?: string;
  "country"?: string;
  "movedToAddressOn"?: string;
}

/**
 * Gender of an individual
 */
export enum CommonTypesV1Gender {
  Male = "Male",
  Female = "Female",
  Other = "Other",
}

export class ContactDetails {
  "emailAddress": string;
  "confirmEmailAddress"?: string;
  /**
   * A UK format mobile phone number starting 07
   */
  "mobilePhoneNumber": string;
}

/**
 * Tax identification details.  Is a TIN available, if so supply it.  If unable to supply what is the reason.
 */
export class TinDetails {
  "tinAvailable"?: boolean;
  /**
   * Tax Identification Number the format of which varies by juristriction.  See  https://www.oecd.org/tax/automatic-exchange/crs-implementation-and-assistance/tax-identification-numbers/
   */
  "taxIdentificationNumber"?: string;
  "cantProvideReason"?: TinDetailsCantProvideReason;
  "reasonUnableToProvide"?: string;
  "taxCountry"?: string;
}

export enum TinDetailsCantProvideReason {
  NotIssued = "NotIssued",
  Unobtainable = "Unobtainable",
  NotRequired = "NotRequired",
}

export enum ApplicantAccountFunding {
  SalaryWages = "SalaryWages",
  Pension = "Pension",
  Benefits = "Benefits",
  StudentFunding = "StudentFunding",
  BusinessIncome = "BusinessIncome",
  Savings = "Savings",
  RentalIncome = "RentalIncome",
  Maintenance = "Maintenance",
  Other = "Other",
}

export enum ApplicantAccountUsage {
  PayBills = "PayBills",
  Saving = "Saving",
  Everything = "Everything",
  YouthAccount = "YouthAccount",
  MainAccount = "Everything",
  Benefits = "Benefits",
  HouseholdExpenditures = "HouseholdExpenditures",
  Other = "Other"
}



export class ApplicantEmploymentDetails {
  accountUsage?: ApplicantAccountUsage;
  accountFunding?: ApplicantAccountFunding;
  //nameOfEmployer?: string = "";
  //totalGrossIncome?: string = "";
  estimatedMonthlyDeposit?: number;
}

export class MarketingPreferences {
  disableSMS?: boolean = true;
  disableEmail?: boolean = true;
  disableTelephone?: boolean = true;
  disablePost?: boolean = true;
}

export enum SecurityQuestions {
  PrimarySchool = "PrimarySchool",
  ChildhoodBestFriendName = "ChildhoodBestFriendName",
  WhenYoungerWhatDidYouWantToBe = "WhenYoungerWhatDidYouWantToBe",
  MotherMaidenName = "MotherMaidenName",
  FirstCarMake = "FirstCarMake",
  FirstHolidayAbroadDestination = "FirstHolidayAbroadDestination",
  ManagerNameAtFirstJob = "ManagerNameAtFirstJob",
}

export class SecurityQuestion {
  question?: SecurityQuestions = undefined;
  answer? = "";

  constructor(
    question: SecurityQuestions | undefined = undefined,
    answer: string | undefined = undefined
  ) {
    this.question = question;
    this.answer = answer;
  }
}

export class KycChallengeDocument {
  id = "";
  address?: string;
  identity?: string;
  representation?: string;
  residence?: string;
  sourceOfIncome?: string;
  sourceOfWealth?: string;
  photo?: string;
}

export enum DocumentCategoryType {
    Identity = 'identity',
    Address = 'address',
    Representation = 'representation',
    Residence = 'residence',
    SourceOfIncome = 'sourceOfIncome',
    SourceOfWealth = 'sourceOfWealth',
    Photo = 'photo',
    Unknown = 'unknown'
}

export class KycChallengeDocumentCategory {
  type = "";
  numberRequired?: number;
  documents?: KycChallengeDocument[];
}

export class KycChallenge {
  id = "";
  status?: ApplicantKycStatus;
  reviewStatus? : KycReviewStatus;
  requiredDocuments?: KycChallengeDocumentCategory[];
  
}

export class Applicant {
  "id"?: string;
  "partnerId"?: string | "";
  "currentTitle": ApplicantCurrentTitle;
  "name"?: Individual = new Individual();
  "previousName"?: Individual;
  "gender"?: CommonTypesV1Gender;
  "dateOfBirth"?: string;
  "currentAddress" = new CommonTypesV1Address();
  "previousAddress"?: CommonTypesV1Address;
  "contactDetails" = new ContactDetails();
  "marketingPreferences": MarketingPreferences = new MarketingPreferences();
  "employmentDetails": ApplicantEmploymentDetails = new ApplicantEmploymentDetails();
  "pin": string;
  "pinConfirm"?: string;
  "residencyStatus"?: ApplicantResidencyStatus = new ApplicantResidencyStatus();
  "additionalDetails": AdditionalDetails = new AdditionalDetails();
  "residencyTaxDetails": Array<TinDetails> = [];
  "citizenshipTaxDetails": Array<TinDetails> = [];
  "securityQuestions": Array<SecurityQuestion>;
  "kycChallenge"?: KycChallenge;
  "agreeMECurrentAccTAndCs"?: boolean;
  "agreePrivacyPolicy"?: boolean;
  "agreeKeyFactsDocument"?: boolean;
  "agreeFeeInformationDocument"?: boolean;
  "agreeFscsInfoSheet"?: boolean;
  "confirmCitizenAndResidencyDeclaration"?: boolean;
  "confirmReadPolicy"?: boolean;
}

export class OnboardingApplication {
  "id": string;
  "partnerId"?: string;
  "accountType": AccountType;
  "applicationType": string;
  "privacyTermsAccepted": boolean;
  "primaryApplicant"?: Applicant = new Applicant();
  "secondaryApplicant"?: Applicant;
  "applicationStatus"?: ApplicationStatuses;
}
