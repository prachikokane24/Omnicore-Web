/* eslint @typescript-eslint/no-var-requires: "off" */
const httpism = require("httpism");

export default class LoqateApi {
  constructor({ key, countries }) {
    this._key = key;
    this._client = httpism.client(
      "https://api.addressy.com/Capture/Interactive/"
    );
    this._countries = countries || [];
  }

  async getAddresses(query) {
    const response = await this.fetch("Find", {
      params: { Text: query, Countries: this._countries },
    });

    // Text=13%20&Container=&Origin=GBR&Countries=&Datasets=&Limit=7&Filter=&Language=en&$block=true&$cache=true&SOURCE=PCA-SCRIPT&SESSION=05f2feba-c2ab-c9aa-bd91-ad05f7e0d0bb

    return response;
  }

  async getAddressesByPostcode(id) {
    const response = await this.fetch("Find", {
      params: { Container: id, Countries: this._countries },
    });
    return response;
  }

  async getAddress(addressId, query) {
    const response = await this.fetch("Retrieve", {
      params: { Text: query, Countries: this._countries, Id: addressId },
    });
    return response;
  }

  async fetch(endPoint, options) {
    options.params.Key = this._key;
    return this._client.get(`${endPoint}/v1.1/json3.ws`, options);
  }
}
