export class CommonUtil {
    static trimLeadingZero(val: string): string {
        return val.replace(/^0+/, ''); 
    }
 }