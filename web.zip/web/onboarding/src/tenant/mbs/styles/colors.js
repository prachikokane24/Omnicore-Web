export default {
  light: {
    primary: "#fa6400",
    info: "#4682B4",
    success: "#008000",
    accent: "#00E4FF",
    default: "#563dea",
    error: "#d4351c",
  },
};
