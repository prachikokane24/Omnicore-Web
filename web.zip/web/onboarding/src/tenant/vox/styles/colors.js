export default {
  light: {
    primary: "#E75A7C",
    secondary: "#4E0B7A",
    info: "#4E7BEB",
    success: "#90cc6a",
    accent: "#ff5722",
    default: "#64189E",
    error: "#E73D3E",
    text: "#390F46",
  },
};
