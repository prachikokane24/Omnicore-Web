
import Vue from "vue";
import VueRouter, { RouteConfig } from 'vue-router'


export default class AppSupport
{
    public homePath = "/";
    public loginPath = "/authentication/login";
}

//  top level Vue application component
export class OmnioVue extends Vue
{
    public $router!: VueRouter;
}

//  Veutify form
export interface VForm extends HTMLFormElement {
    validate(mode?: boolean): boolean;
}



