const Page = require("./page");

class OnboardingPACitzenshipPage extends Page {

    //Marketing prefernces
    get chkSMS () { return $("[data-id=application-primary-marketing-disablesms]").parentElement() }
    get chkEmail () { return $("[data-id=application-primary-marketing-disableemail]").parentElement() }
    get chkPhone () { return $("[data-id=application-primary-marketing-disablephone]").parentElement() }
    get chkPost () { return $("[data-id=application-primary-marketing-disablepost]").parentElement() }

    //Terms
    get chkTCs () { return $("[data-id=application-primary-agreemecurrentacctandcs]").parentElement() }
    get chkPrivacy () { return $("[data-id=application-primary-agreeprivacypolicy]").parentElement() }
    get chkFeeInfo () { return $("[data-id=application-primary-agreekeyinfodoc]").parentElement() }
    
    selectMarketingPreferences(smsFlag, emailFlag, phoneFlag, postFlag) {

     //   console.log("The sms flag is " + smsFlag)

        this.chkSMS.scrollIntoView();
        this.chkSMS.waitForClickable({ timeout: 5000 });

        if (smsFlag == "Yes") {
            this.chkSMS.click()
        }

        if (emailFlag == "Yes") {
            this.chkEmail.click()
        }

        if (phoneFlag == "Yes") {
            this.chkPhone.click()
        }

        if (postFlag == "Yes") {
            this.chkPost.click()
        }
    } 

    agreeToTermsAndConditions(tcsFlag, privacyFlag, factsFlag, feeFlag, fscsFlag ) {

        this.chkTCs.waitForClickable({ timeout: 5000 });
        if (tcsFlag == "Yes") {
            this.chkTCs.click()
        }

        if (privacyFlag == "Yes") {
            this.chkPrivacy.click()
        }

        if (feeFlag == "Yes") {
            this.chkFeeInfo.click()
        }
    }
}

module.exports = new OnboardingPACitzenshipPage();
