const Page = require('./page');

/**
 * Onboarding - Primary Applicant Details   
 */
class OnboardingPAOTPPage extends Page {

    get btnSendCode () { return $('#application-primary-performaction')}
    get btnResendCode () { return $('#application-primary-performaction')}
     
    get txtOTP () { return $('#application-otp')}

    provideOTP() {

        browser.pause(2000)

        this.btnSendCode.waitForClickable({ timeout: 5000 })
        this.btnSendCode.click()

        this.txtOTP.waitForClickable({ timeout: 5000 })
        this.txtOTP.setValue("123456")
        this.btnSendCode.click()
    }

}

module.exports = new OnboardingPAOTPPage();
