const Page = require('./page');

class OnboardingPAAdditionalDetailsPage extends Page {

    get txtNI () { return $('[data-id=application-primary-nationalinsurancenumber]')}
    get lblNI () { return $('[for="application-primary-nationalinsurancenumber"]')}

    get ddlNationality () { return $('[data-id=application-primary-nationality-primary] > div > div.v-input__control > div.v-input__slot > div.v-select__slot > div.v-select__selections') }
    get lblNationality () { return $('[for="application-primary-nationality-primary-select"]')}

    get ddlCountryOfBirth () { return $('[data-id=application-primary-countryofbirth] > div > div.v-input__control > div.v-input__slot > div.v-select__slot > div.v-select__selections') }
    get lblCountryOfBirth () { return $('[for="application-primary-countryofbirth-select"]')}
    
    get txtCityTownOfBirth () { return $('[data-id=application-primary-cityortownofbirth]')}   
    get lblCityTownOfBirth () { return $('[for="application-primary-cityortownofbirth"]')}

    provideAdditionalDetails(NI, nationality, countryOfBirth, cityTownBirth) {

        //National Insurance Number - Optional
        // expect(this.lblNI.getText()).toEqual("National Insurance Number")
        this.txtNI.waitForClickable({ timeout: 5000 })
       
        if (NI.length > 0) {
            this.txtNI.setValue(NI)
        }
        
        //Nationality - Mandatory
        // expect(this.lblNationality.getText()).toEqual("Nationality")
        this.ddlNationality.waitForClickable({ timeout: 5000 });
        this.ddlNationality.click()
        this.clickOnItem(nationality)

        //Dual Nationality - Mandatory
        // expect(this.lblDualNationality.getText()).toEqual("Dual Nationality (If held)")
        // if (dualNationality.length > 0) {
        //     this.ddlDualNationality.parentElement().click()
        //     this.clickOnItem(dualNationality)
        // }

        //Country of birth - Mandatory
        // expect(this.lblCountryOfBirth.getText()).toEqual("Country of birth")
        this.ddlCountryOfBirth.waitForClickable({ timeout: 5000 });
        this.ddlCountryOfBirth.click()
        this.clickOnItem(countryOfBirth)
        
        //City town of birth - Mandatory
        // expect(this.lblCityTownOfBirth.getText()).toEqual("City/Town of birth")
        this.txtCityTownOfBirth.setValue(cityTownBirth)
    } 

    selectButDoNotProvideMandatoryAdditionalData() {

        //Click on national insurance
        this.txtNI.waitForClickable({ timeout: 5000 })
        this.txtNI.click()

        //Click on nationality
        this.ddlNationality.click()
        browser.keys('Escape')

        //Click on dual nationality
        // this.ddlDualNationality.parentElement().click()
        // browser.keys('Escape')

        //Click on country of birth
        this.ddlCountryOfBirth.click()
        browser.keys('Escape')

        this.txtCityTownOfBirth.click()
        browser.keys('Tab')

    }

    checkErrors(errors) {

        for (const error in errors) {

            if (errors[error]=="No Error") {
                switch(error) {
                    case "NationalInsurance":
                        expect(this.getErrorMessageElement(this.txtNI).isDisplayed()).toBeFalsy()            
                }
            } else {
                switch(error) {
                    case "Nationality":
                        expect(this.getErrorMessageElement(this.lblNationality).getText()).toEqual(errors.Nationality);
                        break
                    case "DualNationality":
                        expect(this.getErrorMessageElement(this.lblDualNationality).getText()).toEqual(errors.DualNationality);       
                        break
                    case "CountryOfBirth":
                        expect(this.getErrorMessageElement(this.lblCountryOfBirth).getText()).toEqual(errors.CountryOfBirth);
                        break
                    case "CityTownBirth":
                         expect(this.getErrorMessageElement(this.txtCityTownOfBirth).getText()).toEqual(errors.CityTownBirth);        
                         break
                 }
            }    
        }
    }

}

module.exports = new OnboardingPAAdditionalDetailsPage();
