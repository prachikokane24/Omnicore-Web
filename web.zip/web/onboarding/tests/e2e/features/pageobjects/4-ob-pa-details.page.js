const Page = require('./page');
const moment = require('moment');
const dateCreator = require('../../utilities/dateCreator');

/**
 * sub page containing specific selectors and methods for a specific page
 */
class OnboardingPADetailsPage extends Page {
    
    get ddlTitle () { return $('[data-id=application-primary-title]').parentElement() }
    get lblTitle () { return $('[for="application-primary-title"]') }
      
    get txtFirstName () { return $('[data-id=application-primary-current-firstname]') }
    get lblFirstName () { return $('[for="application-primary-current-firstname"]') }

    get txtMiddleNames () { return $('[data-id=application-primary-current-middlenames]') }
    get lblMiddleNames () { return $('[for="application-primary-current-middlenames"]')}

    get txtSurname () { return $('[data-id=application-primary-current-lastname]') }
    get lblSurname () {return $('[for="application-primary-current-lastname"]')}
   
    get rdoMale () { return $('[data-id=application-primary-gender-male]') }
    get rdoFemale () { return $('[data-id=application-primary-gender-female]')}

    get txtDOB () { return $('[data-id=application-primary-dob]')}
    get lblDOB () { return $('[for="application-primary-dob"]')}
    //get txtDOB () {return $('#application-primary-dob-datepicker')}
    
    get rdoOtherNamesYes () { return $('[data-id=application-primary-hasbeenknownbyothernamelast3years-yes]')}
    get rdoOtherNamesNo () { return $('[data-id=application-primary-hasbeenknownbyothernamelast3years-no]')}

    get txtOtherFirstName () { return $('[data-id=application-primary-previous-firstname]')}
    get lblOtherFirstName () { return $('[For="application-primary-previous-firstname"]')}

    get txtOtherMiddleNames () { return $('[data-id=application-primary-previous-middlenames]')}
    get lblOtherMiddleNames () { return $('[For="application-primary-previous-middlenames"]')}

    get txtOtherSurname () { return $('[data-id=application-primary-previous-surname]') }
    get lblOtherSurname () { return $('[For="application-primary-previous-surname"]') }


    provideTitle(title) {

        //Title - Mandatory
        this.ddlTitle.waitForClickable({ timeout: 5000 });
        //expect(this.lblTitle.getText()).toEqual("Title");
        browser.pause(2000)
        this.ddlTitle.click()

        this.clickOnItem(title)

    }
  
    provideName(firstName, middleNames, surname) {

        console.log("Firstname: " + firstName)

        //First name 
        //expect(this.lblFirstName.getText()).toEqual("First name");
        this.txtFirstName.setValue("") 
        this.txtFirstName.setValue(firstName) // Mandatory, 2 min and 20 max
        
        //Middle names - Mandatory
        //expect(this.lblMiddleNames.getText()).toEqual("Middle names");
        if (middleNames.length > 0) {
            this.txtMiddleNames.setValue("") 
            this.txtMiddleNames.setValue(middleNames) // Optional, 2 min and 20 max
        }

        //Surname - Mandatory
        //expect(this.lblSurname.getText()).toEqual("Surname");
        this.txtSurname.setValue("") 
        this.txtSurname.setValue(surname) // Mandatory, 2 min and 20 max
        this.txtSurname.keys('Tab')

    }

    provideGender(gender) {

        //Gender - Mandatory
        if (gender=="Male") {
            this.rdoMale.parentElement().click() 
        } else if (gender=="Female") {
            this.rdoFemale.parentElement().click()
        }
    }

    provideDOB(DOB) {

        //Date of Birth - Mandatory
        //this.datePicker(this.txtDOB, DOB)
        //expect(this.lblDOB.getText()).toEqual("Date of Birth (dd/mm/yyyy)");
        this.txtDOB.waitForClickable({ timeout: 5000 })
        this.txtDOB.scrollIntoView()

        if (DOB.includes("-") || DOB.includes("+")) {

            DOB = dateCreator.getDate(DOB)

/*
            const date = moment();
            console.log("The date is: " + date.format())

            //Get Year
            let years = DOB.substring(1,4) 
            console.log("the year is " + years)
            if (DOB.substring(0,1) == "-") {
                date.subtract(years, 'years')
            } else if (DOB.substring(0,1) == "+") {
                date.add(years, 'years')
            }

            //Get Month
            let months = DOB.substring(6,8) 
            console.log("the month is " + months)
            if (DOB.substring(5,6) == "-") {
                date.subtract(months, 'months')
            } else if (DOB.substring(5,6) == "+"){
                date.add(months, 'months')
            }

            //Get Day
            let days = DOB.substring(10,13) 
            console.log("the day is " + days)
            if (DOB.substring(9,10) == "-") {
                date.subtract(days, 'days')
            } else if (DOB.substring(9,10) == "+"){
                date.add(days, 'days')
            }

            console.log("date is: " + date)
            DOB = date.format("DD/MM/YYYY")
            console.log("the date is now " + DOB)
        */  }

        this.txtDOB.setValue("")
        this.txtDOB.setValue(DOB)
    }

    anyOtherNames(nameFlag){

        //Other Names Flag - Mandatory
        this.rdoOtherNamesYes.scrollIntoView()
        if (nameFlag=="Yes") {
            this.rdoOtherNamesYes.parentElement().click() 
        } else if (nameFlag=="No") {
            this.rdoOtherNamesNo.parentElement().click()
        }
    }

    provideOtherNames(firstName, middleNames, lastName) {

        //Other Names - Mandatory is selected yes
        this.txtOtherFirstName.scrollIntoView()
        //expect(this.lblOtherFirstName.getText()).toEqual("First name");
        this.txtOtherFirstName.setValue(firstName) // Mandatory, 2 min and 20 max
        
        //expect(this.lblOtherMiddleNames.getText()).toEqual("Middle names");
        this.txtOtherMiddleNames.setValue(middleNames) // Optional, 2 min and 20 max

        //expect(this.lblOtherSurname.getText()).toEqual("Surname"); // Mandatory, 2 min and 20 max
        this.txtOtherSurname.setValue(lastName)

    }

    selectButDoNotProvideMandatoryPersonalData() {

        //Title
        this.ddlTitle.waitForClickable({ timeout: 5000 });
        browser.pause(2000)
        this.ddlTitle.click()
        browser.keys('Escape')
        
        //First Name
        this.txtFirstName.click()

        //Surname
        this.txtSurname.click()

        //Date of Birth
        this.txtDOB.scrollIntoView()
        this.txtDOB.click()
        browser.keys('Escape')
        browser.keys('Tab')

    }
  
    checkErrors(errors) {

        for (const error in errors) {

            console.log("The error is: " + error)

            switch(error) {
                case "Title":
                    expect(this.getErrorMessageElement(this.lblTitle).getText()).toEqual(errors.Title);
                    break
                case "FirstName":
                    expect(this.getErrorMessageElement(this.txtFirstName).getText()).toEqual(errors.FirstName);
                    break
                case "Surname":
                    expect(this.getErrorMessageElement(this.txtSurname).getText()).toEqual(errors.Surname);
                    break
                case "DOB":
                    expect(this.getErrorMessageElement(this.txtDOB).getText()).toEqual(errors.DOB);
                    break
            } 
        }

        //browser.pause(10000)
    }

}


module.exports = new OnboardingPADetailsPage();
