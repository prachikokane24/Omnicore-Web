const moment = require('moment');
const config = require("../../wdio.conf").config;

/**
* main page object containing all methods, selectors and functionality
* that is shared across all page objects
*/
module.exports = class Page {

    constructor() {
        this.errorMessage = ".v-messages.error--text > .v-messages__wrapper> .v-messages__message"
    }
  
    get btnPrevious () { return $('[data-id=onboarding_left_button]') }
    get btnNext () { return $('[data-id=onboarding_right_button]') } 
    get activeList () { return $('.menuable__content__active')}
    get datePickerHeader () { return $('.menuable__content__active .v-date-picker-header__value')}
    //get activeListXPath () { return $('//div[contains(@class, "menuable__content__active")]')} 
    get txtMoveDate() { return $('#application-primary-movedToPrimaryAddressDate-datepicker') }
   
    /**
    * Opens a sub page of the page
    * @param path path of the sub page (e.g. /path/to/page.html)
    */
    open (path) {
        return browser.url(config.baseUrl)
    }

    clickOnItem(item) {
      //  this.activeList.$(".v-list-item__title=" + item).waitForClickable({ timeout: 5000 })
      //  this.activeList.$(".v-list-item__title=" + item).scrollIntoView()
        //browser.pause(5000)
      
        console.log("The item we are looking for is - " + item)
             
        /*   browser.waitUntil( 
            () => this.activeList.getHTML().includes(item),
            this.activeList().scr
            {
                timeout: 10000,
                timeoutMsg: "The item " + item + " was not found."
            }
        ) */
        //this.activeList.$(".v-list-item__title=" + item).waitForDisplayed()

        this.activeList.keys(item)
        this.activeList.$(".v-list-item__title=" + item).click()

    }

    findAndClickOnItem(item) {

        console.log("The item we are looking for is - " + item)
        console.log("The html is " + this.activeList.getHTML())

        const cntryList = $$('.menuable__content__active .v-list')

        const countryFound = this.searchForCountry(item, cntryList)

        browser.pause(20000)


    }

    searchForCountry(item, listOfElements) {

        console.log("The size is: " + browser.elements(listOfElements).value.length)

        for (const element of listOfElements) {
            console.log("The text is " + element.getText())
            if (element.getText() === item) {
                return true
            } else {
                //for (let i=0; i < 20; i++)
                  //  elements.keys('ARROW_DOWN')
                 // browser.pause(2000)
                 element.click()   
                 //$('.menuable__content__active .v-list').keys('ARROW_DOWN')
                    return false
            }
        }

    }


    clickOnNext() {
        this.btnNext.waitForDisplayed()
        expect(this.btnNext).toBeEnabled()
        this.btnNext.click();
    }

    clickOnPrevious() {
        this.btnPrevious.waitForDisplayed()
        expect(this.btnPrevious).toBeEnabled()
        this.btnPrevious.click();
    }

    datePicker(dateElement, stringDate) {

        const date = new Date(stringDate)

        console.log("Day: " + date.getDate())
        console.log("Month: " + moment(date).format("MMM"))
        console.log("Year: " + date.getFullYear())
        
        //Scroll date into view and click on date element
        dateElement.scrollIntoView()
        dateElement.click()

        //browser.pause(10000)

        //Click on the date picker header to get to months
        this.datePickerHeader.waitForClickable()
        this.datePickerHeader.click() 

        //Click on the date picker header to get to years
        this.datePickerHeader.waitForClickable()
        this.datePickerHeader.click() 

        //Select the year
        $('//div[contains(@class, "menuable__content__active")]//li[text()="' + date.getFullYear() + '"]').click()

        //Select the month
        $('//div[contains(@class, "menuable__content__active")]//div[text()="' + moment(date).format("MMM") + '"]').click()

        //Select the day
        $('//div[contains(@class, "menuable__content__active")]//div[text()="' + date.getDate() + '"]').click()

    }

    getErrorMessageElement(baseElement) {
        return baseElement.parentElement().parentElement().nextElement().$(this.errorMessage)
    }
    

}
