const Page = require('./page');

class OnboardingPACitzenshipPage extends Page {

    get ddlCitizen () { return $('#application-primary-citizenshipTaxDetails-ifForTaxPurposeOfAnywhereOtherThanUKThenWhere-select')}
    get lblCitizen () { return $('[for="application-primary-citizenshipTaxDetails-ifForTaxPurposeOfAnywhereOtherThanUKThenWhere-select"]')}

    //get ddlCitizenOther () { return $('#application-primary-citizenshipTaxDetails-ifForTaxPurposeOfAnywhereOtherThanUKorOtherThenWhere-select')}
    // get lblCitizenOther () { return $('[for="application-primary-citizenshipTaxDetails-ifForTaxPurposeOfAnywhereOtherThanUKorOtherThenWhere-select"]')}

    get ddlResident () { return $('#application-primary-residencyTaxDetails-ifForTaxPurposeOfAnywhereOtherThanUKThenWhere-select')}
    get lblResident () { return $('[for="application-primary-residencyTaxDetails-ifForTaxPurposeOfAnywhereOtherThanUKThenWhere-select"]')}

    // get ddlResidentOther () { return $('#application-primary-residencyTaxDetails-ifForTaxPurposeOfAnywhereOtherThanUKorOtherThenWhere-select')}
    // get lblResidentOther () { return $('[for="application-primary-residencyTaxDetails-ifForTaxPurposeOfAnywhereOtherThanUKorOtherThenWhere-select"]')}

    get rdoCitizenTINYes () { return $('#application-primary-citizenshipTaxDetails-canprovidetin-yes')}
    get rdoCitizenTINNo () { return $('#application-primary-citizenshipTaxDetails-canprovidetin-no')}

    get txtCitizenTaxIdentification () { return $('#application-primary-citizenshipTaxDetails-taxidnumber')}    
    get lblCitizenTaxIdentification ()  { return $('[for="application-primary-citizenshipTaxDetails-taxidnumber"]')}

    get rdoResidentTINYes () { return $('#application-primary-residencyTaxDetails-canprovidetin-yes')}
    get rdoResidentTINNo () { return $('#application-primary-residencyTaxDetails-canprovidetin-no')}

    get txtResidentTaxIdentification () { return $('#application-primary-residencyTaxDetails-taxidnumber')}  
    get lblResidentTaxIdentification ()  { return $('[for="application-primary-residencyTaxDetails-taxidnumber"]')}  

    get chkConfirm () { return $('#application-primary-confirmInfoAccurate')}   
    get lblConfirm () { return $('[for="application-primary-confirmInfoAccurate"]')}

    domesticCitizen() {

        this.ddlCitizen.parentElement().waitForClickable({ timeout: 5000 })
        this.ddlCitizen.parentElement().click()

        this.clickOnItem("No")

    }

    domesticResident() {

        this.ddlResident.parentElement().waitForClickable({ timeout: 5000 })
        this.ddlResident.parentElement().click()

        this.clickOnItem("No")

    }


    provideCitizenshipDetails(citizen, citizenTin, citizenTinTaxID, citizenOfAnotherCountry) {

        this.ddlCitizen.parentElement().waitForClickable({ timeout: 5000 })
        this.ddlCitizen.parentElement().click()

        this.clickOnItem(citizen)

        this.rdoCitizenTINYes.parentElement().waitForClickable({ timeout: 5000 })
        
        if (citizenTin=="Yes") {
            this.rdoCitizenTINYes.parentElement().click() 
            expect(this.lblCitizenTaxIdentification.getText()).toEqual("Tax Identification Number")
            this.txtCitizenTaxIdentification.setValue(citizenTinTaxID)

            // Text gets truncated - need to raise an issue on this
            // expect(this.lblCitizenOther.getText()).toEqual("????")
            // this.ddlCitizenOther.parentElement().click()
            // this.clickOnItem(citizenOfAnotherCountry)
        } else if (citizenTin=="No") {
            this.rdoCitizenTINNo.parentElement().click()

            //Give a reason
        }
    }

    provideResidencyDetails(residency, residencyTin, residencyTinTaxID, residencyOfAnotherCountry) {

        this.ddlResident.parentElement().waitForClickable({ timeout: 5000 })
        this.ddlResident.parentElement().click()

        this.clickOnItem(residency)

        this.rdoResidentTINYes.parentElement().waitForClickable({ timeout: 5000 })
        if (residencyTin=="Yes") {
            this.rdoResidentTINYes.parentElement().click() 
            expect(this.lblResidentTaxIdentification.getText()).toEqual("Tax Identification Number")
            this.txtResidentTaxIdentification.setValue(residencyTinTaxID)

            // Text gets truncated - need to raise an issue on this
            // expect(this.lblResidentOther.getText()).toEqual("????")
            // this.ddlResidentOther.parentElement().click()
            // this.clickOnItem(residencyOfAnotherCountry)
        } else if (residencyTin=="No") {
            this.rdoResidentTINNo.parentElement().click()
        }
    }

    confirmDetails(confirm) {

        this.chkConfirm.scrollIntoView();
        if (confirm=="Yes") {
            this.chkConfirm.parentElement().click()
        }

    } 

    selectButDoNotProvideMandatoryCitizenshipResidencyData() {
        
        this.ddlCitizen.parentElement().waitForClickable({ timeout: 5000 })
        this.ddlCitizen.parentElement().click()
        browser.keys('Escape')

        this.ddlResident.parentElement().waitForClickable({ timeout: 5000 })
        this.ddlResident.parentElement().click()
        browser.keys('Escape')

        this.chkConfirm.scrollIntoView();
        this.chkConfirm.parentElement().doubleClick()

        browser.pause(10000)

    }

    checkErrors(errors) {

        for (const error in errors) {

            switch(error) {
                case "CitizenForTax":
                    expect(this.getErrorMessageElement(this.lblCitizen).getText()).toEqual(errors.CitizenForTax);
                    break
                case "ResidencyForTax":
                    expect(this.getErrorMessageElement(this.lblResident).getText()).toEqual(errors.ResidencyForTax);       
                    break
                case "Declaration":
                    expect(this.getErrorMessageElement(this.chkConfirm).getText()).toEqual(errors.Declaration);      
                    break
            }
        }
    }
}


module.exports = new OnboardingPACitzenshipPage();
