const Page = require('./page');
const dateCreator = require('../../utilities/dateCreator');

/**
 * sub page containing specific selectors and methods for a specific page
 */
class OnboardingPAAddressPage extends Page {
    
    get txtPostcode () { return $('[data-id=application-primary-currentaddress-postcode]') }
    get lblPostcode () { return $('[for="application-primary-currentaddress-postcode"]')}

    get txtHouseNameNumber () { return $('[data-id=application-primary-currentaddress-housenameornumber]') }
    get lblHouseNameNumber () { return $('[for="application-primary-currentaddress-housenameornumber"]') }

    get txtStreet () { return $('[data-id=application-primary-currentaddress-street]') }
    get lblStreet () { return $('[for="application-primary-currentaddress-street"]') }

    get txtAddressTwo () { return $('[data-id=application-primary-currentaddress-addrline2]') }
    get lblAddressTwo () { return $('[for="application-primary-currentaddress-addrline2"]') }

    get txtTownCity () { return $('[data-id=application-primary-currentaddress-townorcity]') }
    get lblTownCity () { return $('[for="application-primary-currentaddress-townorcity"]') }

    get txtCounty () { return $('[data-id=application-primary-currentaddress-county]') }
    get lblCounty () { return $('[for="application-primary-currentaddress-county"]') }

    //get txtMoveDate() { return $('#application-primary-movedToPrimaryAddressDate-datepicker') }
    get txtMoveDate() { return $('[data-id=application-primary-movedToPrimaryAddressDate]') }
    get lblMoveDate() { return $('[for="application-primary-movedToPrimaryAddressDate"]') } 

    //Previous Address
    get txtPreviousPostcode () { return $('[data-id=application-primary-previousaddress-postcode]') }
    get lblPreviousPostcode () { return $('[for="application-primary-previousaddress-postcode"]')}

    get txtPreviousHouseNameNumber () { return $('[data-id=application-primary-previousaddress-housenameornumber]') }
    get lblPreviousHouseNameNumber () { return $('[for="application-primary-previousaddress-housenameornumber"]') }

    get txtPreviousStreet () { return $('[data-id=application-primary-previousaddress-street]') }
    get lblPreviousStreet () { return $('[for="application-primary-previousaddress-street"]') }

    get txtPreviousAddressTwo () { return $('[data-id=application-primary-previousaddress-addrline2]') }
    get lblPreviousAddressTwo () { return $('[for="application-primary-previousaddress-addrline2"]') }

    get txtPreviousTownCity () { return $('[data-id=application-primary-previousaddress-townorcity]') }
    get lblPreviousTownCity () { return $('[for="application-primary-previousaddress-townorcity"]') }

    get txtPreviousCounty () { return $('[data-id=application-primary-previousaddress-county]') }
    get lblPreviousCounty () { return $('[for="application-primary-previousaddress-county"]') }


    provideAddress(postcode, house, street, addressTwo, townCity, county, moveDate) {

        this.txtPostcode.waitForClickable({ timeout: 5000 });

        //Postcode
        // expect(this.lblPostcode.getText()).toEqual("Postcode");
        this.txtPostcode.setValue(postcode) //Mandatory, 5 min & 10 max

        //House
        // expect(this.lblHouseNameNumber.getText()).toEqual("House Name or Number");
        this.txtHouseNameNumber.setValue(house) //Mandatory, 1 min & 20 max

        //Street
        // expect(this.lblStreet.getText()).toEqual("Street");
        this.txtStreet.setValue(street) //Mandatory, 2 min & 36 max

        //Address Two
        // expect(this.lblAddressTwo.getText()).toEqual("Address Line 2");
        if (addressTwo.length > 0) {
            this.txtAddressTwo.setValue(addressTwo) 
        }

        //Town or City
        // expect(this.lblTownCity.getText()).toEqual("Town or City");
        this.txtTownCity.setValue(townCity) //Mandatory, 2 min and 58 max
        
        //County
        // expect(this.lblCounty.getText()).toEqual("County");
        this.txtCounty.scrollIntoView()
        this.txtCounty.setValue(county)

        //Find the moved date using the date picker
        //this.datePicker(this.txtMoveDate, moveDate)
        // expect(this.lblMoveDate.getText()).toEqual("When did you move to your address (dd/mm/yyyy)");
        console.log("The move date is:" + moveDate)
        if (moveDate.includes("-") || moveDate.includes("+")) {

            moveDate = dateCreator.getDate(moveDate)
            console.log("************The move date is: " + moveDate)

        }
      
        console.log("************The move date 2 is: " + moveDate)
       // this.txtMoveDate.setValue("")
        this.txtMoveDate.setValue(moveDate)
        browser.keys('Tab') // This looks like an issue 
    }

    providePreviousAddress(postcode, house, street, addressTwo, townCity, county) {

        this.txtPreviousPostcode.waitForClickable({ timeout: 5000 });

        //Postcode
        // expect(this.lblPreviousPostcode.getText()).toEqual("Postcode");
        this.txtPreviousPostcode.setValue(postcode) //Mandatory, 5 min & 10 max

        //House
        // expect(this.lblPreviousHouseNameNumber.getText()).toEqual("House Name or Number");
        this.txtPreviousHouseNameNumber.setValue(house) //Mandatory, 1 min & 20 max

        //Street
        // expect(this.lblPreviousStreet.getText()).toEqual("Street");
        this.txtPreviousStreet.setValue(street) //Mandatory, 2 min & 36 max

        //Address Two
        // expect(this.lblPreviousAddressTwo.getText()).toEqual("Address Line 2");
        if (addressTwo.length > 0) {
            this.txtPreviousAddressTwo.setValue(addressTwo) 
        }

        //Town or City
        // expect(this.lblPreviousTownCity.getText()).toEqual("Town or City");
        this.txtPreviousTownCity.setValue(townCity) //Mandatory, 2 min and 58 max
        
        //County
        // expect(this.lblPreviousCounty.getText()).toEqual("County");
        this.txtPreviousCounty.scrollIntoView()
        this.txtPreviousCounty.setValue(county)

    }

    selectButDoNotProvideMandatoryAddressData() {
        
        //Need to get rid of this pause!
        browser.pause(1000)
        this.txtPostcode.waitForClickable({ timeout: 5000 });
        this.txtPostcode.click()
       
        this.txtHouseNameNumber.click()
        this.txtStreet.click()
        this.txtTownCity.click()
        this.txtCounty.scrollIntoView();
        this.txtCounty.click()

        this.txtMoveDate.scrollIntoView();
        this.txtMoveDate.click();
        browser.keys('Escape')
        browser.keys('Tab')

    }

    checkErrors(errors) {

        for (const error in errors) {

            switch(error) {
                case "Postcode":
                    expect(this.getErrorMessageElement(this.txtPostcode).getText()).toEqual(errors.Postcode);
                    break
                case "HouseNameNumber":
                    expect(this.getErrorMessageElement(this.txtHouseNameNumber).getText()).toEqual(errors.HouseNameNumber);
                    break
                case "Street":
                    expect(this.getErrorMessageElement(this.txtStreet).getText()).toEqual(errors.Street);
                    break
                case "TownCity":
                    expect(this.getErrorMessageElement(this.txtTownCity).getText()).toEqual(errors.TownCity);
                    break
                case "County":
                    expect(this.getErrorMessageElement(this.txtCounty).getText()).toEqual(errors.County);
                    break
                case "DateMovedToAddress":
                    expect(this.getErrorMessageElement(this.txtMoveDate).getText()).toEqual(errors.DateMovedToAddress);
                    break
            }               
        }
    }
}

module.exports = new OnboardingPAAddressPage();
