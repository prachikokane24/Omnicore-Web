const Page = require('./page');
const errorMessage = ".v-messages.error--text > .v-messages__wrapper> .v-messages__message"
const label = ".v-label"

/**
 * Onboarding - Primary Applicant Details   
 */
class OnboardingPAAccountPage extends Page {

    //Account Type
    get ddlAccountType() { return $('[data-id=account-type]')}
    get lblAccountType() { return $('[for="application-type"]')}

    get rdoGroupResidency() { return $('#application-residency')}
    get lblGroupResidency() { return $('#application-residency > .v-label')}

    get rdoGroupRemain() { return $('[data-id=application-allApplicantsUkOrEEANationalsOrHaveIRL]')}
    get lblTest() { return $('.v-label')}

    //Residency radio buttons
    get rdoResidencyYes () { return $('[data-id=application-residency-yes]')}
    get rdoResidencyNo () { return $('[data-id=application-residency-no]')}

    //Right to remain radio buttons
    get rdoRemainYes () { return $('[data-id=application-allApplicantsUkOrEEANationalsOrHaveIRL-yes]')}
    get rdoRemainNo () { return $('[data-id=application-allApplicantsUkOrEEANationalsOrHaveIRL-no]')}

    //Confirm your privacy 
    get chkConfirm () {  return $('[data-id=application-confirmreadpolicy]') }
    
    startApplication() {
        this.btnNext.waitForDisplayed();
        this.btnNext.click();
    }

    provideStartApplicationDetails(ukResident, leaveToRemain, yourPrivacy) {
        browser.pause(2000);

        //Account Type
        this.ddlAccountType.parentElement().waitForClickable({ timeout: 5000 });
        //expect(this.lblAccountType.getText()).toEqual('Choose Account Type')

        // this.ddlAccountType.parentElement().click()
        // this.clickOnItem(accountType)

        //Permanent resident
        if (ukResident == "Yes") {
            this.rdoResidencyYes.parentElement().click()
        } else if (ukResident == "No") {
            this.rdoResidencyNo.parentElement().click()
        }
       
        //Leave to remain
        if (leaveToRemain == "Yes") {
            this.rdoRemainYes.parentElement().click()
        } else if (leaveToRemain == "No") {
            this.rdoRemainNo.parentElement().click()
        }

        //Confirm
        this.chkConfirm.scrollIntoView();
        this.chkConfirm.parentElement().waitForClickable({ timeout: 5000 });
 
        //Click on confirm checkbox
        if (yourPrivacy == "Yes") {
            this.chkConfirm.parentElement().click()
        }
        
    }

    selectButDoNotProvideMandatoryStartData() {

        this.ddlAccountType.parentElement().waitForClickable({ timeout: 5000 });
        this.ddlAccountType.parentElement().click()
        browser.keys('Escape')
        
        this.rdoResidencyNo.parentElement().click()
        this.rdoRemainNo.parentElement().click()
        this.chkConfirm.scrollIntoView();
        this.chkConfirm.parentElement().waitForClickable({ timeout: 5000 });
        this.chkConfirm.parentElement().doubleClick()

    }

    checkErrors(errors) {

      for (const error in errors) {

            switch(error) {
                case "AccountType":
                    expect(this.getErrorMessageElement(this.lblAccountType).getText()).toEqual(errors.AccountType);
                    break
                case "UKResident":
                    expect(this.rdoGroupResidency.parentElement().nextElement().$(errorMessage).getText()).toEqual(errors.UKResident);
                    break
                case "LeaveToRemain":
                    expect(this.rdoGroupRemain.parentElement().nextElement().$(errorMessage).getText()).toEqual(errors.LeaveToRemain);
                    break
                case "Confirm":
                    expect(this.getErrorMessageElement(this.chkConfirm).getText()).toEqual(errors.Confirm);
                    break
            } 
        }
    }
}

module.exports = new OnboardingPAAccountPage();
