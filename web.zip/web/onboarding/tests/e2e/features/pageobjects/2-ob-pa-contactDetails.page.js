const Page = require('./page');

class OnboardingPAContactDetailsPage extends Page {

    get txtEmail () { return $('[data-id=application-primary-emailaddress]')}
    get lblEmail () { return $('[for="application-primary-emailaddress"]')}

    get txtConfirmEmail () { return $('[data-id=application-primary-emailaddresscheck]')}
    get lblConfirmEmail () { return $('[for="application-primary-emailaddresscheck"]')}

    get txtMobileTel () { return $('[data-id=application-primary-mobilephone]')}
    get lblMobileTel () { return $('[for="application-primary-mobilephone"]')}

    get txtHomeTel () { return $('[data-id=application-primary-homephone]')}
    get lblHomeTel () { return $('[for="application-primary-homephone"]')}

    provideContactDetails(email, confirmEmail, mobileTel, homeTel) {

        this.txtEmail.waitForClickable({ timeout: 5000 });
        const randomNumber = Math.floor(Math.random() * 9999);;

        //Email
        // expect(this.lblEmail.getText()).toEqual("Email Address"); 
        this.txtEmail.setValue(`${email}+${randomNumber}@omnio.global`) //Mandatory, min 8 & max 50

        //Confirm Email
        // expect(this.lblConfirmEmail.getText()).toEqual("Confirm Email");
        this.txtConfirmEmail.setValue(`${confirmEmail}+${randomNumber}@omnio.global`) //Mandatory, min 8 & max 50

        //Mobile Phone Number
        // expect(this.lblMobileTel.getText()).toEqual("Mobile Telephone");
        this.txtMobileTel.setValue(mobileTel) //Mandatory, min 10 & max 15
    } 

    selectButDoNotProvideMandatoryContactData() {
        browser.pause(2000)
        this.txtEmail.waitForClickable({ timeout: 5000 });
        this.txtEmail.click()
        this.txtConfirmEmail.click()
        this.txtMobileTel.click()
        this.txtHomeTel.click()
        browser.keys('Tab')
    }

    checkErrors(errors) {

        for (const error in errors) {

            if (errors[error]=="No Error") {
                switch(error) {
                    case "HomeTelephone":
                        expect(this.getErrorMessageElement(this.txtHomeTel).isDisplayed()).toBeFalsy()
                }
            } else {
                switch(error) {
                    case "Email":
                        expect(this.getErrorMessageElement(this.txtEmail).getText()).toEqual(errors.Email);
                        break
                    case "ConfirmEmail":
                        expect(this.getErrorMessageElement(this.txtConfirmEmail).getText()).toEqual(errors.ConfirmEmail);
                        break
                    case "MobileTelephone":
                         expect(this.getErrorMessageElement(this.txtMobileTel).getText()).toEqual(errors.MobileTelephone);        
                         break
                 }
            }    
        }
    }

}


module.exports = new OnboardingPAContactDetailsPage();
