const Page = require("./page");

class OnboardingPACitzenshipPage extends Page {
  get ddlEmploymentStatus() {
    return $("[data-id=application-primary-employmentstatus]").parentElement();
  }
  get txtOccupation() {
    return $("[data-id=application-primary-occupation]");
  }
  //   get txtNameOfEmployerCompany() {
  //     return $("#application-primary-nameofemployerorcompany");
  //   }
  // get txtGrossIncome () { return $('#application-primary-totalgrossincome')}
  get ddlAccountFor() {
    return $("[data-id=application-primary-accountusage]").parentElement();
  }
  get ddlAccountFunded() {
    return $("[data-id=application-primary-accountfundings]").parentElement();
  }
  get txtEstimatedDeposit() {
    return $("[data-id=application-primary-estimatedMonthlydeposit]");
  }

  get ddlSecurityQuestionOne() {
    return $("[data-id=application-primary-securityquestion-0]").parentElement();
  }
  get txtSecurityAnswerOne() {
    return $("[data-id=application-primary-securityquestion-0-answer]");
  }
  get ddlSecurityQuestionTwo() {
    return $("[data-id=application-primary-securityquestion-1]").parentElement();
  }
  get txtSecurityAnswerTwo() {
    return $("[data-id=application-primary-securityquestion-1-answer]");
  }
  get ddlSecurityQuestionThree() {
    return $("[data-id=application-primary-securityquestion-2]").parentElement();
  }
  get txtSecurityAnswerThree() {
    return $("[data-id=application-primary-securityquestion-2-answer]");
  }
  get txtPin() {
    return $("[data-id=application-primary-telephone-banking-pin]");
  }
  get txtConfirmPin() {
    return $("[data-id=application-primary-telephone-banking-pin-confirm]");
  }

  provideEmploymentStatusDetails(employStatus, occupation) {
    browser.pause(2000);
    this.ddlEmploymentStatus.waitForClickable({ timeout: 5000 }); //Mandatory
    this.ddlEmploymentStatus.click();

    this.clickOnItem(employStatus);

    this.txtOccupation.setValue(occupation); //Mandatory, min 3 & max 50
    //Company.setValue(employerCompany); //Mandatory, min 2 & max 60
  }

  provideAccountInformation(
    whatIsAccountFor,
    accountFunded,
    deposit
  ) {
    // this.txtGrossIncome.setValue(grossIncome) //Mandatory, min 5 & max 12

    this.ddlAccountFor.click();
    this.clickOnItem(whatIsAccountFor);

    this.ddlAccountFunded.scrollIntoView();
    this.ddlAccountFunded.waitForClickable();
    this.ddlAccountFunded.click();
    this.clickOnItem(accountFunded);

    this.txtEstimatedDeposit.scrollIntoView();
    this.txtEstimatedDeposit.waitForClickable();
    this.txtEstimatedDeposit.setValue(deposit); //Mandatory, min 3 & max 12
  }

  provideSecurityDetails(q1, a1, q2, a2, q3, a3) {
    this.ddlSecurityQuestionOne.scrollIntoView();
    this.ddlSecurityQuestionOne.waitForClickable();
    this.ddlSecurityQuestionOne.click();
    this.clickOnItem(q1);

    this.txtSecurityAnswerOne.setValue(a1); //Mandatory, min 3 and max 12

    this.ddlSecurityQuestionTwo.click();
    this.clickOnItem(q2);

    this.txtSecurityAnswerTwo.setValue(a2); //Mandatory, min 3 and max 12

    this.ddlSecurityQuestionThree.scrollIntoView();
    this.ddlSecurityQuestionThree.waitForClickable();
    this.ddlSecurityQuestionThree.click();
    this.clickOnItem(q3);

    this.txtSecurityAnswerThree.setValue(a3); //Mandatory, min 3 and max 12
  }

  providePinDetails(pin, confirmPin) {
    this.txtPin.scrollIntoView();
    this.txtPin.waitForClickable();
    this.txtPin.setValue(pin);
    this.txtConfirmPin.setValue(confirmPin);
  }
}

module.exports = new OnboardingPACitzenshipPage();
