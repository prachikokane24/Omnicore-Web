const Page = require('./page');

class OnboardingPACitzenshipPage extends Page {

    get btnSubmit () { return $('[data-id=application-submission-btn]')}
    
    submitApplication() {
        this.btnSubmit.waitForDisplayed();
        this.btnSubmit.click();
    }
}

module.exports = new OnboardingPACitzenshipPage();
