const Page = require('./page');

/**
 * Onboarding - Primary Applicant Details   
 */
class OnboardingPAWelcomePage extends Page {

}

module.exports = new OnboardingPAWelcomePage();
