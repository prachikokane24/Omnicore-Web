const { Given, When, Then } = require('@cucumber/cucumber');

const OnboardingPAWelcomePage = require('../pageobjects/0-ob-pa-welcome.page');
const OnboardingPAStartPage = require('../pageobjects/1-ob-pa-start.page');
const OnboardingPAContactDetailsPage = require('../pageobjects/2-ob-pa-contactDetails.page');
const OnboardingPACustomerAuthPage = require('../pageobjects/3-ob-pa-customerAuth.page');
const OnboardingPADetailsPage = require('../pageobjects/4-ob-pa-details.page');
const OnboardingPAAddressPage = require('../pageobjects/5-ob-pa-address.page');
const OnBoardingPAAdditionalDetailsPage = require('../pageobjects/6-ob-pa-additionalDetails.page');
const OnBoardingPAEmploymentStatusPage = require('../pageobjects/7-ob-pa-employmenStatusAndSecurity.page');
const OnBoardingPAMarketingTermsPage = require('../pageobjects/8-ob-pa-marketingAndTerms.page');
const OnBoardingPASubmissionPage = require('../pageobjects/9-ob-pa-submission.page');
const OnBoardingPACitizenResidencyPage = require('../pageobjects/x-ob-pa-citizenshipResidency.page');

const pages = {
    onboarding: OnboardingPAWelcomePage
}

Given(/^I am on the (\w+) page$/, (page) => {
    pages[page].open()
  //  browser.maximizeWindow()
});

When(/^I click on the start button$/, () => {
    OnboardingPAWelcomePage.clickOnNext();  
})

When(/^I enter applicant details$/, (dataTable) => {
    const data = dataTable.hashes()    
    OnboardingPAStartPage.provideStartApplicationDetails(data[0].UKResident, data[0].LeaveToRemain, data[0].YourPrivacy)
    OnboardingPADetailsPage.clickOnNext()
})

When(/^I enter my personal details$/, (dataTable) => {

    const data = dataTable.rowsHash()  
    OnboardingPADetailsPage.provideTitle(data.Title)
    OnboardingPADetailsPage.provideName(data.FirstName, data.MiddleNames, data.Surname)
    OnboardingPADetailsPage.provideGender(data.Gender)
    OnboardingPADetailsPage.provideDOB(data.DOB)
    OnboardingPADetailsPage.anyOtherNames(data.OtherNames)
    if (data.OtherNames=="Yes") {
        OnboardingPADetailsPage.provideOtherNames(data.OthFirstName, data.OthMiddleNames, data.OthSurname)
    }
    OnboardingPADetailsPage.clickOnNext()

})

When(/^I enter an invalid date of birth$/, (dataTable) => {

    const data = dataTable.rowsHash()  
    OnboardingPADetailsPage.provideDOB(data.DOB)
    browser.pause(5000)

})

When(/^I enter my invalid personal name details$/, (dataTable) => {

    const data = dataTable.rowsHash()  
    OnboardingPADetailsPage.provideName(data.FirstName, data.MiddleNames, data.Surname)
 /*   OnboardingPADetailsPage.anyOtherNames(data.OtherNames)
    if (data.OtherNames=="Yes") {
        OnboardingPADetailsPage.provideOtherNames(data.OthFirstName, data.OthMiddleNames, data.OthSurname)
    } */
})

When(/^I enter address details$/, (dataTable) => {

    

    const data = dataTable.hashes()
    OnboardingPAAddressPage.provideAddress(data[0].Postcode, data[0].HouseNameNumber, data[0].Street, data[0].AddressTwo, data[0].TownCity, data[0].County, data[0].DateMovedToAddress)
    if (data[0].PreviousAddress === "No") {
        OnboardingPAAddressPage.clickOnNext()
    }
    
})

When(/^I enter previous address details$/, (dataTable) => {
    const data = dataTable.hashes()
    OnboardingPAAddressPage.providePreviousAddress(data[0].Postcode, data[0].HouseNameNumber, data[0].Street, data[0].AddressTwo, data[0].TownCity, data[0].County)
    OnboardingPAAddressPage.clickOnNext()
})


When (/^I enter contact details$/, (dataTable) => {
    const data = dataTable.hashes()
    OnboardingPAContactDetailsPage.provideContactDetails(data[0].Email,data[0].ConfirmEmail,data[0].MobileNumber,data[0].HomeNumber)
    OnboardingPAContactDetailsPage.clickOnNext()
})

When (/^I provide the OTP$/, ()=> {

    OnboardingPACustomerAuthPage.provideOTP()
    OnboardingPACustomerAuthPage.clickOnNext()  

})

When (/^I provide additional details$/, (dataTable)=> {

    const data = dataTable.hashes()
    console.log(data);
    OnBoardingPAAdditionalDetailsPage.provideAdditionalDetails(data[0].NationalInsurance, data[0].Nationality, data[0].CountryOfBirth, data[0].CityTownBirth)
    OnBoardingPAAdditionalDetailsPage.clickOnNext()

})

When (/^I provide additional citizenship and residency details$/, (dataTable) => {

    const data = dataTable.rowsHash()
    if (data.CitizenForTax === "No") {
        OnBoardingPACitizenResidencyPage.domesticCitizen()
    } else {
        OnBoardingPACitizenResidencyPage.provideCitizenshipDetails(data.CitizenForTax, data.CitizenTIN, data.CitizenTaxID, data.CitizenOfAnotherCountry) 
    }

    if (data.ResidencyForTax === "No") {
        OnBoardingPACitizenResidencyPage.domesticResident()
    } else {
        OnBoardingPACitizenResidencyPage.provideResidencyDetails(data.ResidencyForTax, data.ResidencyTIN, data.ResidencyTaxID, data.ResidencyOfAnotherCountry)
    }
    OnBoardingPACitizenResidencyPage.confirmDetails(data.Declaration)    
    OnBoardingPACitizenResidencyPage.clickOnNext()

})

When (/^I provide employment status and security questions$/, (dataTable) => {

    const data = dataTable.rowsHash()

    OnBoardingPAEmploymentStatusPage.provideEmploymentStatusDetails(data.EmployStatus, data.Occupation) 
    OnBoardingPAEmploymentStatusPage.provideAccountInformation(data.WhatIsAccountFor, data.AccountFunded, data.Deposit)
    OnBoardingPAEmploymentStatusPage.provideSecurityDetails(data.SecurityQ1, data.SecurityA1, data.SecurityQ2, data.SecurityA2, data.SecurityQ3, data.SecurityA3)
    OnBoardingPAEmploymentStatusPage.providePinDetails(data.Pin, data.ConfirmPin)

    OnBoardingPAEmploymentStatusPage.clickOnNext()
})

When (/^I provide marketing preferences and accept terms$/, (dataTable) => {

    const data = dataTable.rowsHash()
    OnBoardingPAMarketingTermsPage.selectMarketingPreferences(data.SMS, data.Email, data.Telephone, data.Post)
    OnBoardingPAMarketingTermsPage.agreeToTermsAndConditions(data.METC, data.PrivacyPolicy, data.KeyFacts, data.FeeInfo, data.FSCSInfo)

    OnBoardingPAMarketingTermsPage.clickOnNext()

})

When(/^I submit my application$/, () => {
    OnBoardingPASubmissionPage.submitApplication()
    browser.pause(20000)
})


When(/^I do not provide applicant details for the mandatory fields$/, () => {

    OnboardingPAStartPage.selectButDoNotProvideMandatoryStartData()

})

When (/^I do not provide my personal details for the mandatory fields$/, () => {

    OnboardingPADetailsPage.selectButDoNotProvideMandatoryPersonalData()

})

When(/^I do not provide my address details for the mandatory fields$/, () => {

    OnboardingPAAddressPage.selectButDoNotProvideMandatoryAddressData()

})


When(/^I do not provide my contact details for the mandatory fields$/, () => {
   
    OnboardingPAContactDetailsPage.selectButDoNotProvideMandatoryContactData()

})

When(/^I do not provide my additional details for the mandatory fields$/, () => {
   
    OnBoardingPAAdditionalDetailsPage.selectButDoNotProvideMandatoryAdditionalData()

})

When(/^I do not provide my citizenship and residency details for the mandatory fields$/, () => {
   
    OnBoardingPACitizenResidencyPage.selectButDoNotProvideMandatoryCitizenshipResidencyData()

})

Then(/^I expect field error messages on my applicant details page$/, (dataTable) => {

    const data = dataTable.rowsHash()
    OnboardingPAStartPage.checkErrors(data)

})

Then(/^I expect field error messages on my personal details page$/, (dataTable) => {

    const data = dataTable.rowsHash()
    OnboardingPADetailsPage.checkErrors(data)

})

Then(/^I expect field error messages on address details page$/, (dataTable) => {

    const data = dataTable.rowsHash()
    OnboardingPAAddressPage.checkErrors(data)

})

Then(/^I expect field error messages on contact details page$/, (dataTable) => {

    const data = dataTable.rowsHash()
    OnboardingPAContactDetailsPage.checkErrors(data)

})

Then(/^I expect field error messages on additional details page$/, (dataTable) => {

    const data = dataTable.rowsHash()
    OnBoardingPAAdditionalDetailsPage.checkErrors(data)

})

Then(/^I expect field error messages on citizen residency details page$/, (dataTable) => {

    const data = dataTable.rowsHash()
    OnBoardingPACitizenResidencyPage.checkErrors(data)

})
