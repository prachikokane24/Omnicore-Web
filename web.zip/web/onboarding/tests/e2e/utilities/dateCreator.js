const moment = require('moment');

class DateCreator {

    getDate(dateRequired) {
        const date = moment();
        console.log("The date is: " + date.format())

        //Get Year
        const years = dateRequired.substring(1,4) 
        if (dateRequired.substring(0,1) == "-") {
            date.subtract(years, 'years')
        } else {
            date.add(years, 'years')
        }

        //Get Month
        const months = dateRequired.substring(6,8) 
        if (dateRequired.substring(5,6) == "-") {
            date.subtract(months, 'months')
        } else {
            date.add(months, 'months')
        }

        //Get Day
        const days = dateRequired.substring(10,13) 
        if (dateRequired.substring(9,10) == "-") {
            date.subtract(days, 'days')
        } else {
            date.add(days, 'days')
        }

        return date.format("DD/MM/YYYY")
    }
}

module.exports = new DateCreator();


