import OnboardingScenarioFactory, { Scenario } from '@/components/OnboardingScenarioModels'
import { ScenarioFactoryEntry } from '@/components/OnboardingScenarioModels'

describe('OnboardingScenarioFactory', () => {
    it('should not register a scenario with the same code', () => {
        const factory = new OnboardingScenarioFactory();
        const scenarioFactoryEntry = new ScenarioFactoryEntry("test", () => new Scenario("testScenario", []));

        factory.register(scenarioFactoryEntry);

        expect(() => factory.register(scenarioFactoryEntry)).toThrowError(`Cannot register scenario with code '${scenarioFactoryEntry.code}' because one with the same name is already registered`);
    });

    it('should not register more than one default scenario', () => {
        const factory = new OnboardingScenarioFactory();
        const scenarioFactoryEntry1 = new ScenarioFactoryEntry("test1", () => new Scenario("testScenario", []), true);
        const scenarioFactoryEntry2 = new ScenarioFactoryEntry("test2", () => new Scenario("testScenario", []), true);

        factory.register(scenarioFactoryEntry1);

        expect(() => factory.register(scenarioFactoryEntry2)).toThrowError(`Cannot register more than one default scenario`);
    });

    it('should not create a scenario when no code is provided and there is no default', () => {
        const factory = new OnboardingScenarioFactory();
        const scenarioFactoryEntry = new ScenarioFactoryEntry("test", () => new Scenario("testScenario", []));

        factory.register(scenarioFactoryEntry);

        expect(() => factory.create("")).toThrowError(`No code provided and cannot find a default factory`);
    });
    
    it('should not create a scenario when no code is provided and use default is false', () => {
        const factory = new OnboardingScenarioFactory();
        const scenarioFactoryEntry = new ScenarioFactoryEntry("test", () => new Scenario("testScenario", []));

        factory.register(scenarioFactoryEntry);

        expect(() => factory.create("", false)).toThrowError(`No code provided`);
    });

    it('should not create a scenario when code is provided but is not found', () => {
        const factory = new OnboardingScenarioFactory();
        const scenarioFactoryEntry = new ScenarioFactoryEntry("test", () => new Scenario("testScenario", []));

        factory.register(scenarioFactoryEntry);

        expect(() => factory.create("test1")).toThrowError(`No scenario factory found for code 'test1'`);
    });

    it('should create the default scenario when no code is provided', () => {
        const factory = new OnboardingScenarioFactory();
        const scenarioFactoryEntry = new ScenarioFactoryEntry("test", () => new Scenario("testScenario", []), true);

        factory.register(scenarioFactoryEntry);

        expect(factory.create("").name).toBe(scenarioFactoryEntry.create().name);
    });

    it('should create the scenario when a code is provided', () => {
        const factory = new OnboardingScenarioFactory();
        const scenarioFactoryEntry = new ScenarioFactoryEntry("test", () => new Scenario("testScenario", []));

        factory.register(scenarioFactoryEntry);

        expect(factory.create("test").name).toBe(scenarioFactoryEntry.create().name);
    });
});