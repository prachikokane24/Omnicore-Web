import { CommonUtil } from '@/utils/common';

const withLeadingZero = "0123456789";
const withoutLeadingZero = "123456789";

describe('CommonUtil', () => {
    it('trimLeadingZero with leading zero', () => {
        var trimmed = CommonUtil.trimLeadingZero(withLeadingZero);
        expect(trimmed).toEqual(withoutLeadingZero);
    })

    it('trimLeadingZero without leading zero', () => {
        var trimmed = CommonUtil.trimLeadingZero(withoutLeadingZero);
        expect(trimmed).toEqual(withoutLeadingZero);
    })
});