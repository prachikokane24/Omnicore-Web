import { createLocalVue, shallowMount } from '@vue/test-utils'
import ApplicantAddress from '../../src/components/ApplicantAddress.vue'
import Vuetify from "vuetify";

const sectionId = "application-primary-currentaddress";
const addressSearchId = "-loquate";
const houseNameId = "-housenameornumber";
const addressLine1Id = "-street";
const addressLine2Id = "-addrline2";
const cityId = "-townorcity";
const countyId = "-county";
const postCodeId = "-postcode";

let wrapper;
let vuetify

beforeEach(()=>{
    const localVue = createLocalVue();
    vuetify = new Vuetify();

    wrapper = shallowMount(ApplicantAddress,
    {
        propsData: { dataIDPrefix: sectionId  },
        localVue
    });

});

afterEach(() => {
    wrapper.destroy();
});


describe('ApplicantAddress component', () => {

    it('renders a vue instance', () => {
        expect(wrapper.isVueInstance).toBeTruthy();
    });

    it('renders an address search input', () => {
        expect(wrapper.find('[data-id=' + sectionId + addressSearchId + ']').attributes('label')).toEqual("Start typing your address to search")
    })

    it('renders mandatory house name or number field input', () => {
        expect(wrapper.find('[data-id=' + sectionId + houseNameId + ']').attributes('label')).toEqual("House Name or Number");
    })

    it('renders mandatory address line 1 field input', () => {
        expect(wrapper.find('[data-id=' + sectionId + addressLine1Id + ']').attributes('label')).toEqual("Address Line 1");
    })

    it('renders mandatory town or city field input', () => {
        expect(wrapper.find('[data-id=' + sectionId + cityId + ']').attributes('label')).toEqual("Town or City");
    })

    it('renders mandatory county field input', () => {
        expect(wrapper.find('[data-id=' + sectionId + countyId + ']').attributes('label')).toEqual("County");
    })

    it('renders mandatory postcde field input', () => {
        expect(wrapper.find('[data-id=' + sectionId + postCodeId + ']').attributes('label')).toEqual("Postcode");
    })

    it('renders non-mandatory address line 2 field input', () => {
        expect(wrapper.find('[data-id=' + sectionId + addressLine2Id + ']').attributes('label')).toEqual("Address Line 2 ( optional )");
    })
})