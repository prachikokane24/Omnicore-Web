import { createLocalVue, mount, shallowMount } from '@vue/test-utils'
import Vuetify from "vuetify";
import BaseStep from '../../src/components/BaseStep.vue'

let wrapper;
let vuetify;

const startStepIndex = 1;
const finishStepIndex = 3;

const stepNoError = "";
const stepError = "error in step";

describe('Stepper base class', () => {

    beforeEach( async  ()=> {
        const localVue = createLocalVue();
        vuetify = new Vuetify();
    
        wrapper = shallowMount(BaseStep,
        {
            propsData: { stepIndex: startStepIndex, stepError: stepNoError },
            localVue
        });

        wrapper.vm.$emit('stepstatusupdated');
        wrapper.vm.$emit('stepstatusupdated',false,startStepIndex);
        wrapper.vm.$emit('stepstatusupdated',true,startStepIndex);

        await wrapper.vm.$nextTick();    
    });
    
    afterEach(() => {
        wrapper.destroy();
    });

    it('renders a vue instance', () => {
        expect(wrapper.isVueInstance).toBeTruthy();
    });

    it('StepStatusUpdated fired multiple times', () => {
        expect(wrapper.emitted().stepstatusupdated.length).toBe(3);
    })

    it('StepStatusUpdated fired states correct for each invocation', () => {
        expect(wrapper.emitted().stepstatusupdated[1]).toEqual([false,startStepIndex]);
        expect(wrapper.emitted().stepstatusupdated[2]).toEqual([true,startStepIndex]);
    })

    it('BaseStep - call goNext()', () => {
        wrapper.vm.goNext();
        expect(wrapper.emitted().gonext.length).toBe(1);
    })

    it('BaseStep - call goPrevious()', () => {
        wrapper.vm.goPrevious();
        expect(wrapper.emitted().goprevious.length).toBe(1);
    })

    it('BaseStep - call flowCompleted()', () => {
        wrapper.vm.flowCompleted();
        expect(wrapper.emitted().flowCompleted.length).toBe(1);
    })
})