import StaticDataService from '@/services/StaticDataService'

const firstElement = { "name":"Afghanistan", "alpha2Code": "AF", "alpha3Code": "AFG" , "nationality": "Afghan" };
const lastElement = { "name":"Zimbabwe", "alpha2Code": "ZW", "alpha3Code": "ZWE" , "nationality": "Zimbabwean" };
const elementCount = 249;

describe('StaticDataService', () => {
    it(`getCountries  - first item is ${lastElement}`, () => {
      
        const testService = new StaticDataService()

        var countryList = testService.getCountries();
        expect(countryList[0]).toEqual(firstElement);
    })

    it(`getCountries  - last item is ${lastElement}`, () => {
      
        const testService = new StaticDataService()

        var countryList = testService.getCountries();
        expect(countryList[elementCount-1]).toEqual(lastElement);
    })

    it(`getCountries  has a total of ${elementCount} items`, () => {
      
        const testService = new StaticDataService()

        var countryList = testService.getCountries();
        expect(countryList.length).toEqual(elementCount);
    })
});