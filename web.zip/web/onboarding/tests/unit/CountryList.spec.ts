import { createLocalVue, mount, shallowMount } from '@vue/test-utils'
import CountryList from '../../src/components/CountryList.vue'
import MbsOnboardingContainer from "../../src/components/OnboardingContainer";
import Vuetify from "vuetify";

const elementId = "application-primary-nationality-primary";
const findSelect = "[id=" + elementId + "-select]"  ; 

let wrapper;
let vuetify

describe('CountryList component used for selecting Nationality', () => {

    const labelForNationalityList = "Nationality *";

    beforeEach(()=>{
        const localVue = createLocalVue();
        vuetify = new Vuetify();
    
        wrapper = shallowMount(CountryList,
        {
            propsData: { id: elementId, label: labelForNationalityList, displayNationality: true },
            localVue
        });
    
    });
    
    afterEach(() => {
        wrapper.destroy();
    });

    it('renders a vue instance', () => {
        expect(wrapper.isVueInstance).toBeTruthy();
    });

    it('renders a select list', () => {
        expect(wrapper.find(findSelect).attributes('label')).toEqual(labelForNationalityList);
    })
})

describe('CountryList component used for selecting Country', () => {

    const labelForCountryList = "Countries *";    

    beforeEach(()=>{
        const localVue = createLocalVue();
        vuetify = new Vuetify();
    
        wrapper = shallowMount(CountryList,
        {
            propsData: { id: elementId, label:"Countries *", displayNationality: false  },
            localVue
        });
    
    });
    
    afterEach(() => {
        wrapper.destroy();
    });

    it('renders a vue instance', () => {
        expect(wrapper.isVueInstance).toBeTruthy();
    });

    it('renders a select list', () => {
        expect(wrapper.find(findSelect).attributes('label')).toEqual(labelForCountryList);
    })
})