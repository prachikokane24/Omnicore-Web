import { buildOmnicore, omnicore } from "@/omnicore-lib";
import { I18NbridgeMock } from "@/plugins/i18nbridgeMock";
import { RuntimeConfig } from "@/omnicore-lib/src/config/runtimeConfig";
import { I18NBridge } from "@/omnicore-lib/src/services/i8n/i18n";
import { HttpClientConfig } from "@/omnicore-lib/src/services/http/HttpClientConfig";
import { LocalCacheConfig } from "@/omnicore-lib/src/services/cache/LocalCacheConfig";

const runtimeConfig: RuntimeConfig = {
    contactCentreTelephone: '',
    http: new HttpClientConfig(),
    localCache: new LocalCacheConfig(),
    googleId: '',
    cookieBotId: '',
};

const i18nBridge: I18NBridge = new I18NbridgeMock();

describe('LocalCacheProvider', () => {
    it('should add a value to the cache', () => {
        const omnicore = buildOmnicore(runtimeConfig, i18nBridge);
        omnicore.localCache.put('foo', { foo: 'bar' }, 3600);

        expect(omnicore.localCache.hasKey('foo')).toBeTruthy();
    });

    it('should get a value from the cache', () => {
        const omnicore = buildOmnicore(runtimeConfig, i18nBridge);
        const value = { foo: 'bar' };

        omnicore.localCache.put('foo', value, 3600);

        expect(omnicore.localCache.get('foo')).toBe(value);
    });

    it('should flush an expired value from the cache', () => {
        const omnicore = buildOmnicore(runtimeConfig, i18nBridge);
        const value = { foo: 'bar' };

        omnicore.localCache.put('foo', value, 1);
        
        setTimeout(() => {
            expect(omnicore.localCache.hasKey('foo')).toBeFalsy();
        }, 2);
    });

    it('should remove a value from the cache', () => {
        const omnicore = buildOmnicore(runtimeConfig, i18nBridge);
        const value1 = { foo: 'bar' };
        const value2 = { bar: 'baz' };

        omnicore.localCache.put('foo', value1, 3600);
        omnicore.localCache.put('bar', value2, 3600);

        omnicore.localCache.flush('foo');
 
        expect(omnicore.localCache.hasKey('foo')).toBeFalsy();
        expect(omnicore.localCache.hasKey('bar')).toBeTruthy();
    });

    it('should remove all values from the cache', () => {
        const omnicore = buildOmnicore(runtimeConfig, i18nBridge);
        const value1 = { foo: 'bar' };
        const value2 = { bar: 'baz' };

        omnicore.localCache.put('foo', value1, 3600);
        omnicore.localCache.put('bar', value2, 3600);

        omnicore.localCache.flushAll();
 
        expect(omnicore.localCache.hasKey('foo')).toBeFalsy();
        expect(omnicore.localCache.hasKey('bar')).toBeFalsy();
    });
});
