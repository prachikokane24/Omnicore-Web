import DefaultValidationRules from '@/components/CommonValidationRules'
import moment from 'moment';

describe('ValidationRules', () => {
  it('isRequired', () => {
    const expectedMessage = DefaultValidationRules.FieldIsRequiredDefaultMessage;

    const testCases = [
      { input: undefined, output: expectedMessage },
      { input: "", output: expectedMessage },
      { input: "   ", output: expectedMessage },
      { input: "abc", output: true },
      { input: "  abc", output: true },
      { input: "abc  ", output: true },
      { input: "  abc  ", output: true },
    ]

    testCases.forEach( testCase => {
      expect(DefaultValidationRules.isRequired(testCase.input)).toBe(testCase.output)
    })
  }),

  it('isRequiredCustom', () => {
    const expectedMessage ="This field is required with a custom message.";

    const testCases = [
      { input: undefined, message: expectedMessage, output: expectedMessage },
      { input: "", message: expectedMessage, output: expectedMessage },
      { input: "   ", message: expectedMessage, output: expectedMessage },
      { input: "abc", message: expectedMessage, output: true },
      { input: "  abc", message: expectedMessage, output: true },
      { input: "abc  ", message: expectedMessage, output: true },
      { input: "  abc  ", message: expectedMessage, output: true },
    ]

    testCases.forEach( testCase => {
      expect(DefaultValidationRules.isRequiredCustom(testCase.message)(testCase.input)).toBe(testCase.output)
    })
  }),

  it('mustBeTrue', () => {
    const expectedMessage = "returned message";

    const testCases = [
      { input: undefined, output: expectedMessage },
      { input: "", output: expectedMessage },
      { input: true, output: true },
      { input: false, output: expectedMessage },
    ]

    testCases.forEach( testCase => {
      expect(DefaultValidationRules.mustBeTrue(expectedMessage)(testCase.input)).toBe(testCase.output)
    });
  })

  it('checkboxRequired', () => {
    const expectedMessage = "A choice is required.";

    const testCases = [
      { input: undefined, output: expectedMessage },
      { input: true, output: true },
      { input: false, output: true },
    ]

    testCases.forEach( testCase => {
      expect(DefaultValidationRules.checkboxRequired(testCase.input)).toBe(testCase.output)
    });
  })

  it('isEmailAddress', () => {
    const expectedMessage = "Please ensure you have provided a valid email address.";

    const testCases = [
      { input: "", output: expectedMessage },
      { input: "a.b@a.co.uk", output: true },
      { input: "a-z0-9!#$%&'*+/=?^_`{|}~-@something.com", output: true },
      { input: "@something.com", output: expectedMessage },
    ]

    testCases.forEach( testCase => {
      expect(DefaultValidationRules.isEmailAddress(testCase.input)).toBe(testCase.output)
    });
  })

  it('mustBeWithinAge', () => {
    const expectedMessage = "Wrong!";

    const testCases = [
      { minAge: 3, maxAge: 5, input: 2, output: 'Sorry, you must be at least 3 years old to create an account.' },
      { minAge: 3, maxAge: 5, input: 3, output: true },
      { minAge: 3, maxAge: 5, input: 4, output: true },
      { minAge: 3, maxAge: 5, input: 5, output: true },
      { minAge: 3, maxAge: 5, input: 6, output: 'Sorry, the maximum age for an applicant is 5 Years old.' },

      { minAge: undefined, maxAge: 5, input: 2, output: true },
      { minAge: undefined, maxAge: 5, input: 6, output: 'Sorry, the maximum age for an applicant is 5 Years old.' },
      { minAge: 3, maxAge: undefined, input: 3, output: true },
      { minAge: 3, maxAge: undefined, input: 2, output: 'Sorry, you must be at least 3 years old to create an account.' },
      { minAge: undefined, maxAge: undefined, input: 6, output: true },
    ]

    testCases.forEach( testCase => {
      const dob = moment().add(-testCase.input, 'year').add(-1, 'day');
      expect(DefaultValidationRules.mustBeWithinAge(
        testCase.minAge, testCase.maxAge, "YYYY-MM-DD", expectedMessage)(dob))
        .toBe(testCase.output)
    });
  })

  it('mustBeWithinAge with invalid values', () => {
    const testCases = [
      { minAge: -1, maxAge: 5, input: 2, output:"MinAge must be positive." },
      { minAge: 3, maxAge: -5, input: 3, output:"MaxAge must be positive." },
      { minAge: 3, maxAge: 5, dob: "2018-13-01", output: 'Please ensure the date provided is valid and follows the yyyy-mm-dd convention.' },
    ]

    testCases.forEach( testCase => {
      if(testCase.dob === undefined)
      {
        const dob = moment().add(-testCase.input, 'year');
        expect(() => { DefaultValidationRules.mustBeWithinAge(testCase.minAge, testCase.maxAge, "YYYY-MM-DD")(dob); }).toThrowError(new Error(testCase.output));
      }
      else
      {
        const invalidDob = moment(testCase.dob);
        expect(DefaultValidationRules.mustBeWithinAge(testCase.minAge, testCase.maxAge, "YYYY-MM-DD")(invalidDob)).toBe(testCase.output);   
      }         
    });
  })

  it('dateMustBeWithin', () => {
    const expectedMessage = "The date must be within A and B";

    const testCases = [
      { dateFrom: Date.parse("2001-01-01"), dateTo: Date.parse("2001-01-03"), input: "2001-01-01", output: true },
      { dateFrom: Date.parse("2001-01-01"), dateTo: Date.parse("2001-01-03"), input: "2001-01-02", output: true },
      { dateFrom: Date.parse("2001-01-01"), dateTo: Date.parse("2001-01-03"), input: "2001-01-03", output: true },
      { dateFrom: Date.parse("2001-01-01"), dateTo: Date.parse("2001-01-03"), input: "2001-01-04", output: expectedMessage },
      { dateFrom: undefined, dateTo: Date.parse("2001-01-03"), input: "2001-01-01", output: true },
      { dateFrom: undefined, dateTo: Date.parse("2001-01-03"), input: "2001-01-04", output: expectedMessage },
      { dateFrom: Date.parse("2001-01-01"), dateTo: undefined, input: "2001-01-02", output: true },
      { dateFrom: Date.parse("2001-01-01"), dateTo: undefined, input: "2000-01-01", output: expectedMessage },
      { dateFrom: undefined, dateTo: undefined, input: "2000-01-01", output: true },
    ]

    testCases.forEach( testCase => {
      expect(DefaultValidationRules.dateMustBeWithin(
        testCase.dateFrom, testCase.dateTo, "YYYY-MM-DD", expectedMessage)(testCase.input)).toBe(testCase.output)
    });
  })

  it('mustBePositiveNumber', () => {
    const expectedMessage = `Please ensure Foo is a positive number.`;

    const testCases = [
      // { input: undefined, output: expectedMessage },
      { input: "215", output: true },
      { input: "-215", output: expectedMessage },
      { input: "", output: expectedMessage },
      { input: 0, output: true },
      { input: -1.2, output: expectedMessage },
      { input: 1.2, output: true },
    ]

    testCases.forEach( testCase => {
      expect(DefaultValidationRules.mustBePositiveNumber('Foo')(testCase.input)).toBe(testCase.output)
    });
  })

  it('textLenWithin', () => {
    const minTest = 2
    const maxTest = 20
    const expectedMessage = `Please keep to a minimum of ${minTest} and maximum of ${maxTest} characters.`;

    const testCases = [
      { min: minTest, max: maxTest, input: " aa ", output: true },
      { min: minTest, max: maxTest, input: "aa ", output: true },
      { min: minTest, max: maxTest, input: " aa", output: true },
      { min: minTest, max: maxTest, input: " 123456789abcdfesdsed ", output: true },
      { min: minTest, max: maxTest, input: " 123456789abcdfesdsed", output: true },
      { min: minTest, max: maxTest, input: "123456789abcdfesdsed ", output: true },
      { min: minTest, max: maxTest, input: "d ", output: expectedMessage },
      { min: minTest, max: maxTest, input: " d ", output: expectedMessage },
      { min: minTest, max: maxTest, input: " d", output: expectedMessage },
      { min: minTest, max: maxTest, input: "123456789abcdfesdsed1", output: expectedMessage },
      { min: minTest, max: maxTest, isRequired: false, input: "", output: true },
      { min: 0, max: maxTest, input: "", output: true },
      { min: 0, max: maxTest, input: undefined, output: true },
    ]

    testCases.forEach( testCase => {
      if(typeof testCase.isRequired !== 'undefined')
      {
        expect(DefaultValidationRules.textLenWithin(testCase.min,testCase.max,testCase.isRequired)(testCase.input)).toBe(testCase.output)
      }
      else
      {
        expect(DefaultValidationRules.textLenWithin(testCase.min,testCase.max)(testCase.input)).toBe(testCase.output)
      }      
    });
  })

  // Accept alpha characters - Samit : accepted
  // Accept space - Samit Double
  // Accept full stop - Jr. : accepted
  // No digits or underscores - Samit99 or Sam_it : Not accepted
  // Allows apostrophes and hyphens -  Sami’t or Sam-it : Accepted
  // Allows reduced  unicode character set 00C0-00FF - ßáçøñ : Accepted 

  it('isValidName and is Required', () => {
    const expectedMessage = "Please review invalid characters and try again.";

    const testCases = [
      {input: "", output: expectedMessage },
      {input: "Samit99", output: expectedMessage },
      {input: "Sam_it", output: expectedMessage },
      {input: "Samit", output: true },
      {input: "Samit Double", output: true },
      {input: "Jr.", output: true },
      {input: "Sami’t", output: true },
      {input: "Sam-it", output: true },
      {input: "ßáçøñ", output: true },
    ]

    testCases.forEach( testCase => {
      expect(DefaultValidationRules.isValidName()(testCase.input)).toBe(testCase.output)
    });
  })

  it('isValidName and is not Required', () => {
    const expectedMessage = "Please review invalid characters and try again.";

    const testCases = [
      {isRequired: false, input: "", output: true },
      {isRequired: false,input: "Samit99", output: expectedMessage },
      {isRequired: false,input: "Sam_it", output: expectedMessage },
      {isRequired: false,input: "Samit", output: true },
      {isRequired: false,input: "Samit Double", output: true },
      {isRequired: false,input: "Jr.", output: true },
      {isRequired: false,input: "Sami’t", output: true },
      {isRequired: false,input: "Sam-it", output: true },
      {isRequired: false,input: "ßáçøñ", output: true },
    ]

    testCases.forEach( testCase => {
      expect(DefaultValidationRules.isValidName(testCase.isRequired)(testCase.input)).toBe(testCase.output)
    });
  })

  it('isUkPostCode', () => {
    const expectedMessage = "Please provide a valid UK postcode.";

    const testCases = [
      { input: "RG200PR", output: true},
      { input: "RG20 0PR", output: true},
      { input: "E1 6AN", output: true},
      { input: "EC1A 4EA", output: true},
      { input: "G1XX0ZZ", output: expectedMessage}
    ]

    testCases.forEach( testCase => {
      expect(DefaultValidationRules.isUkPostCode(testCase.input)).toBe(testCase.output)
    });
  })

  it('checkSpaces', () => {
    const expectedMessage = "Please remove any leading and trailing spaces.";

    const testCases = [
      { input: "  AA  ", output: expectedMessage},
      { input: "AA  ", output: expectedMessage},
      { input: "  AA", output: expectedMessage},
      { input: "AA", output: true}
    ]

    testCases.forEach( testCase => {
      expect(DefaultValidationRules.checkSpaces(testCase.input)).toBe(testCase.output)
    });
  })

  it('isValidDate', () => {
    const expectedMessage = "Please ensure the date provided is valid and follows the yyyy-mm-dd convention.";

    const testCases = [
      { date: "2022-01-01", format: "YYYY-MM-DD", output: true},
      { date: "2022-13-01", format: "YYYY-MM-DD", output: expectedMessage},
    ]

    testCases.forEach( testCase => {
      expect(DefaultValidationRules.isValidDate(testCase.format)(testCase.date)).toBe(testCase.output)
    });
  })

  it('isSame', () => {
    const expectedMessage = "Must be the same";
    const customMessage = "Values must be the same";

    const testCases = [
      { value: 1, compare:1, output: true},
      { value: 1, compare:2, output: expectedMessage},
      { value: 1, compare:2, useCustom: true, output: customMessage},
    ]

    testCases.forEach( testCase => {
      if(testCase.useCustom) {
        expect(DefaultValidationRules.isSame(() => { return testCase.compare; }, testCase.output)(testCase.value)).toBe(testCase.output);
      }
      else {
        expect(DefaultValidationRules.isSame(() => { return testCase.compare; })(testCase.value)).toBe(testCase.output);
      }      
    });
  })

  it('isNotSame', () => {
    const expectedMessage = "Must not be the same";
    const customMessage = "Values must not be the same";

    const testCases = [
      { value: 1, compare:1, output: expectedMessage},
      { value: 1, compare:2, output: true},
      { value: 1, compare:1, useCustom: true, output: customMessage},
    ]

    testCases.forEach( testCase => {
      if(testCase.useCustom) {
        expect(DefaultValidationRules.isNotSame(() => { return testCase.compare; }, testCase.output)(testCase.value)).toBe(testCase.output);
      }
      else {
        expect(DefaultValidationRules.isNotSame(() => { return testCase.compare; })(testCase.value)).toBe(testCase.output);
      }      
    });
  })

  it('mustNotBeGreaterThan', () => {
    const expectedMessage = "Please ensure the amount provided does not exceed £7500.";

    const testCases = [
      { amount: 1500, max: 7500, output: true},
      { amount: undefined,max: 0, output: true},
      { amount: "",max: 0, output: true},
      { amount: 7501,max: 7500, output: expectedMessage},
    ]

    testCases.forEach( testCase => {
      expect(DefaultValidationRules.mustNotBeGreaterThan(testCase.max)(testCase.amount)).toBe(testCase.output);
    });
  })

  it('mustBeNotMoreThanTwoDecimalPoints', () => {
    const expectedMessage = "Please ensure you do not provide more than two decimal places.";

    const testCases = [
      { amount: "1000.00",  output: true},
      { amount: undefined,  output: true},
      { amount: "1000",  output: true},
      { amount: "1000.000",  output: expectedMessage},
    ]

    testCases.forEach( testCase => {
      expect(DefaultValidationRules.mustBeNotMoreThanTwoDecimalPoints(testCase.amount)).toBe(testCase.output);
    });
  })

  it('isValidPin', () => {
    const expectedMessage = "Please avoid using sequential numbers e.g 1234 or 0987.";
    const concurrentMessage = "Please avoid using three concurrent numbers e.g 1110.";
    const lengthMessage="Please ensure you provide 4 numbers.";

    const testCases = [
      { pin: "2121",  output: true},
      { pin: "3421",  output: true},
      { pin: "1234",  output: expectedMessage},
      { pin: "4321",  output: expectedMessage},
      { pin: "1114",  output: concurrentMessage},
      { pin: "1444",  output: concurrentMessage},
      { pin: "444",  output: lengthMessage},
    ]

    testCases.forEach( testCase => {
      expect(DefaultValidationRules.validPin(testCase.pin)).toBe(testCase.output);
    });
  })

  it('isPhoneNumber', () => {
    const expectedMessage = "Please keep to a minimum of 10 and maximum of 11 numbers.";
    const testCases = [
      { phoneNumber: "0163547862",  output: true},
      { phoneNumber: "016354321",  output: expectedMessage},
      { phoneNumber: "020712345678",  output: expectedMessage},

    ]
    testCases.forEach( testCase => {
      expect(DefaultValidationRules.isPhoneNumber(testCase.phoneNumber)).toBe(testCase.output);
    });
  })

  it('isUkDomesticPhoneNumber', () => {
    const expectedMessage = "Please keep to a minimum of 9 and maximum of 11 numbers.";
    const testCases = [
      { phoneNumber: "016354786",  output: true},
      { phoneNumber: "01635478600",  output: true},
      { phoneNumber: undefined,  output: true},
      { phoneNumber: "01635432",  output: expectedMessage},
      { phoneNumber: "020712345678",  output: expectedMessage},

    ]
    testCases.forEach( testCase => {
      expect(DefaultValidationRules.isUkDomesticPhoneNumber(testCase.phoneNumber)).toBe(testCase.output);
    });
  })

  it('isValidNationalInsuranceNumber', () => {
    const expectedMessage = "Please ensure your national insurance number is in the correct format.";
    const testCases = [
      { niNumber: "AB123456C",  output: true},
      { niNumber: "ABC12345C",  output: expectedMessage},
   ]
    testCases.forEach( testCase => {
      expect(DefaultValidationRules.isValidNationalInsuranceNumber(testCase.niNumber)).toBe(testCase.output);
    });
  })

})
