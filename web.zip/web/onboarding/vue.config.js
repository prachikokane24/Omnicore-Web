/* eslint @typescript-eslint/no-var-requires: "off" */
const tenant = process.env.VUE_APP_TENANT || "default";
const locale = process.env.VUE_APP_I18N_LOCALE || "en";
const fallbackLocale = process.env.VUE_APP_I18N_FALLBACK_LOCALE || "en";
const path = require("path");

module.exports = {
  transpileDependencies: ["vuetify"],
  publicPath: "./",
  configureWebpack: {
    output: {
      chunkFilename: "[id].[contenthash].js",
      filename: "[hash].bundle.js",
    },
  },

  // Caveat: https://joshuatz.com/posts/2019/vue-mixing-sass-with-scss-with-vuetify-as-an-example
  css: {
    extract: false,
    loaderOptions: {
      // Required for Vuetify - remove semi-colon
      sass: {
        additionalData: `
          @import "@tenantStyles/variables.scss"
        `,
      },
      // Required for normal scss - semi-colon included
      scss: {
        additionalData: `
          @import "@tenantStyles/variables.scss";
        `,
      },
    },
  },

  chainWebpack: (config) => {
    config.resolve.alias.set(
      "@tenant",
      path.resolve(__dirname, `src/tenant/${tenant}`)
    );
    config.resolve.alias.set(
      "@tenantAssets",
      path.resolve(__dirname, `src/tenant/${tenant}/assets`)
    );
    config.resolve.alias.set(
      "@tenantFonts",
      path.resolve(__dirname, `src/tenant/${tenant}/fonts`)
    );
    config.resolve.alias.set(
      "@tenantStyles",
      path.resolve(__dirname, `src/tenant/${tenant}/styles`)
    );
    config.resolve.alias.set(
      "@tenantComponents",
      path.resolve(__dirname, `src/tenant/${tenant}/components`)
    );
    config.resolve.alias.set(
      "@tenantLocales",
      path.resolve(__dirname, `src/tenant/${tenant}/locales`)
    );
  },

  pluginOptions: {
    i18n: {
      locale,
      fallbackLocale,
      localeDir: "locales",
      enableInSFC: true,
    },
  },
};
