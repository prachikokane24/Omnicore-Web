module.exports = {
  collectCoverage: true,
  collectCoverageFrom: ["**/*.{js,ts,vue}", "!**/node_modules/**", "!**/coverage/**"],
  coverageReporters: ["json","lcov","text","cobertura"],
  modulePaths: ["<rootdir>/src","<rootDir>/node_modules"],
  preset: "@vue/cli-plugin-unit-jest/presets/typescript-and-babel",
  setupFiles: ["./tests/unit/index.js"]
};
