# omnicore-web

## IMPORTANT

If in "production" mode (e.g. npm run build), OTP and Application services are using HTTP implementation.
In "development" (npm run serve) or "test", both are using mocks

Runtimeconfig files specify which api endpoint to use; this is configured with VUE_APP_DEPLOY_ENV env var.
Default is local, possible choices are local, dev, sit, uat

Other important information:
- VUE_APP_TENANT (must correspond to the same tenant name used by banking app)
## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Run your unit tests
```
npm run test:unit
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
