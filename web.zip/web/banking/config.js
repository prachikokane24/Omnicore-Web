// Default config
const config = {
  development: {
    http: {
      baseURL: "https://public.dev.omnicore.global",
      mockURL: "https://run.mocky.io",
      cacheTTLSeconds: 300,
    },
  },
  sit: {
    http: {
      baseURL: "https://public.sit.omnicore.global",
      mockURL: "https://run.mocky.io",
      cacheTTLSeconds: 300,
    },
  },
  uat: {
    http: {
      baseURL: "https://public.uat.omnicore.global",
      mockURL: "https://run.mocky.io",
      cacheTTLSeconds: 300,
    },
  },
  production: {
    http: {
      baseURL: "https://omnicoreapi.omnio-global.com",
      mockURL: () => {
        return this.production.http.baseURL;
      },
      cacheTTLSeconds: 300,
    },
  },
};
module.exports = config;
