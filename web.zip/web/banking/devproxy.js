// This is a node app to allow debugging of the web app in a dev VM environment. Run with: node devproxy.js
// Run the Authentication service locally, http only on port 5021
// Run the MbsT2Fss service locally, http only on port 5000
// Change config.js to set dev base address to the listen port below, eg http://localhost:5001 and run: npm run serve
// 

const fs = require('fs');
const http = require('http');
const httpProxy = require('http-proxy');

// listen port
const port = 5001;

// create proxy server
const proxy = httpProxy.createProxyServer({});

// Additional redirects could be added here.
const redirects = [
    { path: '/auth', target: 'http://localhost:5021' },
    { path: '/webfss', target: 'http://localhost:5000' }
];

// create the server
const server = http.createServer((req, res) => {
    res.setHeader('Access-Control-Allow-Origin','*');
    res.setHeader('Access-Control-Allow-Methods','DELETE, POST, PUT, GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers','*');
    if(req.method == "OPTIONS") {
        res.writeHead(200);
        res.end();
        return;
    } 

    var matched = false;
    redirects.forEach(r => {
        if(!matched && req.url.startsWith(r.path)) {
            matched = true;
            console.log(`${req.method}: ${req.url} -> ${r.target}`);
            req.url = req.url.substring(r.path.length);
            proxy.web(req, res, {
                target: r.target
            });
        }
    });

    if(!matched) {
        res.writeHead(404);
        res.end();        
        console.log('unknown: ' + req.url);
    }
});

server.listen(port);
console.log(`DEBUG: listening on port ${port}`);  