/* eslint @typescript-eslint/no-var-requires: "off" */
const tenant = process.env.VUE_APP_TENANT || "default";
const locale = process.env.VUE_APP_I18N_LOCALE || "en";
const fallbackLocale = process.env.VUE_APP_I18N_FALLBACK_LOCALE || "en";

module.exports = {
  transpileDependencies: ["vuetify"],
  publicPath: "./",
  configureWebpack: {
    output: {
      chunkFilename: "[id].[contenthash].js",
      filename: "[hash].bundle.js",
    },
    devtool: 'eval-source-map'
  },

  // Caveat: https://joshuatz.com/posts/2019/vue-mixing-sass-with-scss-with-vuetify-as-an-example
  css: {
    extract: false,
    loaderOptions: {
      // Required for Vuetify - remove semi-colon
      sass: {
        additionalData: `
          @import "@tenantStyles/variables.scss"
        `,
      },
      // Required for normal scss - semi-colon included
      scss: {
        additionalData: `
          @import "@tenantStyles/variables.scss";
        `,
      },
    },
  },

  chainWebpack: (config) => {
    config.resolve.alias.set("@", "/src");
    config.resolve.alias.set("@tenant", `/src/tenant/${tenant}`);
    config.resolve.alias.set("@tenantRoutes", `/src/router/${tenant}`);
    config.resolve.alias.set("@tenantLayouts", `/src/tenant/${tenant}/layouts`);
    config.resolve.alias.set("@tenantPages", `/src/tenant/${tenant}/pages`);
    config.resolve.alias.set("@tenantAssets", `/src/tenant/${tenant}/assets`);
    config.resolve.alias.set("@tenantFonts", `/src/tenant/${tenant}/fonts`);
    config.resolve.alias.set("@tenantStyles", `/src/tenant/${tenant}/styles`);
    config.resolve.alias.set("@tenantLib", `/src/tenant/${tenant}/lib`);
    config.resolve.alias.set(
      "@tenantComponents",
      `/src/tenant/${tenant}/components`
    );
    config.resolve.alias.set("@tenantLocales", `/src/tenant/${tenant}/locales`);
    config.resolve.alias.set("@tenantTypes", `/src/tenant/${tenant}/types`);
    config.resolve.alias.set("@tenantStore", `/src/store/tenant/${tenant}`);
  },

  pluginOptions: {
    i18n: {
      locale,
      fallbackLocale,
      localeDir: "locales",
      enableInSFC: true,
    },
  },
};
