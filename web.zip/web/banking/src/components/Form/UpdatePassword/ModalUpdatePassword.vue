<template>
  <div>
    <OModalConfirmCancel
      id="loginUpdatePassword"
      cancelText="Cancel"
      dataIdCancelBtn="loginUpdatePasswordCancelBtn"
      @show="reset"
      @confirm="handleSubmit"
      @cancel="handleCancel"
      :loading="formIsLoading"
      :confirmDisabled="formChangePwdInvalid"
    >
      <template v-slot:header>{{
        $t("changePassword.headingUpdate")
      }}</template>
      <OText type="p">
        {{ $t("changePassword.rules") }}
      </OText>
      <OText type="p">
        {{ $t("changePassword.rule1") }}<br />
        {{ $t("changePassword.rule2") }}<br />
        {{ $t("changePassword.rule3") }}<br />
        {{ $t("changePassword.rule4") }}
      </OText>

      <OForm
        ref="form"
        @invalid="handleInvalid"
        :submit-text="$t('changePassword.updateBtn')"
        :hideActions="true"
        data-id="loginUpdatePasswordForm"
        :key="componentFormKey"
      >
        <OFormInput
          ref="currentPass"
          data-id="changePasswordCurrentPassword"
          v-bind="formConfig.currentPass"
          v-model.trim="formItems.currentPass"
        />
        <OFormInput
          ref="newPass"
          data-id="changePasswordNewPassword"
          v-bind="formConfig.newPass"
          v-model.trim="formItems.newPass"
        />
        <OFormInput
          ref="newPassConfirm"
          data-id="changePasswordConfirmNewPassword"
          v-bind="formConfig.newPassConfirm"
          v-model.trim="formItems.newPassConfirm"
        />
        <template #footer>
          <OAlert type="error" v-if="formIsError" dismissible>
            {{ formIsError }}
          </OAlert>
        </template>
      </OForm>
    </OModalConfirmCancel>

    <!-- OTP Verification Modal -->
    <OModalConfirmCancel
      id="changePasswordOtp"
      :loading="verifyOtp.loading"
      @confirm="handleOtpPasscode"
      @show="componentOtpKey += 1"
      dataIdConfirmBtn="changePasswordVerifyOTPBtn"
      dataIdCancelBtn="changePasswordCancelOTPBtn"
      :confirmDisabled="formOtpInvalid"
      :confirmText="$t('payees.modalOtpConfirm')"
    >
      <Otp
        ref="otp"
        @verified="handleOtpVerfified"
        :hideActions="true"
        :key="componentOtpKey"
      />
    </OModalConfirmCancel>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import { Action, namespace } from "vuex-class";
import {
  BaseStateInterface,
  PasswordPayloadInterface,
} from "@/types/store.types";

const userModule = namespace("userModule");
const otpModule = namespace("otpModule");

interface FormItem {
  name: string;
  rules: string;
  label?: string | unknown;
  hint?: string | unknown;
  type?: string;
  disabled?: boolean;
}

interface NewPassDetailsConfig {
  currentPass: FormItem;
  newPass: FormItem;
  newPassConfirm: FormItem;
}

interface AnyObject {
  [key: string]: any;
}

@Component({
  components: {
    OForm: () => import("@/components/lib/Form/OForm.vue"),
    OFormInput: () => import("@/components/lib/Form/OFormInput.vue"),
    OFormSelect: () => import("@/components/lib/Form/OFormSelect.vue"),
    OFormDOB: () => import("@/components/lib/Form/OFormDOB.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
    OAlign: () => import("@/components/lib/OAlign.vue"),
    OInfoCard: () => import("@/components/lib/OInfoCard.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OIcon: () => import("@/components/lib/OIcon.vue"),
    OButton: () => import("@/components/lib/OButton.vue"),
    OFilter: () => import("@/components/lib/OFilter.vue"),
    Otp: () => import("@/components/Form/Otp/Otp.vue"),
    OModalConfirmCancel: () =>
      import("@/components/lib/Modal/OModalConfirmCancel.vue"),
  },
})
export default class UpdatePassword extends Vue {
  formItems: AnyObject = {};
  formChangePwdInvalid = false;
  formOtpInvalid = false;
  passwordUpdated = false;
  componentFormKey = 0;
  componentOtpKey = 0;
  @userModule.State
  private noop!: BaseStateInterface;

  @otpModule.State
  public verifyOtp!: BaseStateInterface;

  @Action("userModule/CLEAR_NOOP")
  clearNoop!: () => string;

  @Action("userModule/UPDATE_USER_PASSWORD")
  updatePassword!: (payload: PasswordPayloadInterface) => string;

  get formConfig(): NewPassDetailsConfig {
    return {
      currentPass: {
        name: "currentPass",
        rules: "required|min:8",
        label: this.$t("changePassword.currentPassword"),
        type: "password",
      },
      newPass: {
        name: "newPassword",
        rules: "required|hasAtLeast8Chars|isEqualToCurrentpassword:@currentPass|hasPasswordComplexity",
        label: this.$t("changePassword.newPassword"),
        type: "password",
      },
      newPassConfirm: {
        name: "newPasswordConfirm",
        rules: "required|hasAtLeast8Chars|isNotEqualTo:@newPassword",
        label: this.$t("changePassword.newPasswordConfirm"),
        type: "password",
      },
    };
  }

  get formIsError() {
    return this.noop?.errorMessage;
  }

  get formIsLoading() {
    return this.noop?.loading;
  }

  get mapPayload(): PasswordPayloadInterface {
    return {
      oldPassword: this.formItems?.currentPass?.value.trim(),
      newPassword: this.formItems?.newPass?.value.trim(),
    };
  }

  handleOtpPasscode(): void {
    (this.$refs.otp as Vue & { handleSubmit: () => void }).handleSubmit();
  }

  async handleOtpVerfified(): Promise<void> {
    this.$modal.hide("changePasswordOtp");
    try {
      await this.updatePassword(this.mapPayload);
      this.passwordUpdated = true;
      this.$emit("passwordUpdated");
    } catch (e) {
      throw new Error(e);
    }
  }

  handleInvalid(invalid: boolean): void {
    this.formChangePwdInvalid = invalid;
  }

  async handleSubmit(): Promise<void> {
    try {
      await (this.$refs.form as Vue & { validate: () => void }).validate();
      if (this.formChangePwdInvalid) return;
      this.$modal.show("changePasswordOtp");
    } catch (e) {
      console.log(e);
    }
  }

  handleCancel() {
    this.formItems = {};
    (this.$refs.form as Vue & { reset: () => void }).reset();
    this.$modal.hide("loginUpdatePassword");
  }

  reset() {
    this.componentFormKey += 1;
    this.formItems = {};
    this.clearNoop();
  }
}
</script>

