<template>
  <UnauthenticatedOtp
    @verified="handleVerified"
    @toggleForm="emitToggleForm"
    v-bind="otpConfig"
  >
    <template v-slot:actions="{ loading, invalid }">
      <slot name="actions" :loading="loading" :invalid="invalid" />
    </template>
  </UnauthenticatedOtp>
</template>

<script lang="ts">
import { Component, Prop, Vue } from "vue-property-decorator";

@Component({
  components: {
    UnauthenticatedOtp: () =>
      import("@/components/Form/Otp/UnauthenticatedOtp.vue"),
  },
})
export default class OtpForm extends Vue {
  @Prop() private inputColor!: string;
  @Prop() private textColor!: string;
  @Prop({ default: undefined }) private messageColor!: string;
  @Prop({ default: false }) private messageBold!: boolean;

  get otpConfig(): {
    inputColor: string;
    textColor: string;
    messageColor: string;
    messageBold: boolean;
  } {
    return {
      inputColor: this.inputColor,
      textColor: this.textColor,
      messageColor: this.messageColor,
      messageBold: this.messageBold,
    };
  }

  emitToggleForm(val): void {
    this.$emit("toggleForm", val);
  }

  handleVerified(redirectPathname: string): void {
    this.$router.push({ path: redirectPathname });
  }
}
</script>
