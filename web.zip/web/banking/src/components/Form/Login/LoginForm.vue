<template>
  <div id="wrapper">
    <!-- <OAlign align="center" align-md="left" vertical v-feature:canCreateAccount>
      <OText type="p" class="mb-4" :color="textColor">
        {{ $t("login.createAccountQuestion") }}
        <a data-id="loginFormCreateAcctLnk" href="/">{{
          $t("login.createAccountQuestionCreate")
        }}</a></OText
      >
    </OAlign> -->
    <OForm
      ref="form"
      @submit="handleSubmit"
      @cancel="handleCancel"
      :loading="userCredentialsLoading"
      :submitText="`${$t('login.proceedBtnText')}`"
      :errorAll="true"
      :btn-group-fill="true"
      data-id="loginForm"
    >
      <OFormInput
        ref="loginId"
        data-id="loginFormLoginId"
        v-bind="formConfig.loginId"
        v-model.trim="formItems.loginId"
        :mask="`${mask}`"
        @click.native="clearUserCredentials"
        onblur
        tabindex="0"
      />
      <OFormInput
        ref="emailAddress"
        data-id="loginFormEmailAddress"
        v-bind="formConfig.emailAddress"
        v-model.trim="formItems.emailAddress"
        @click.native="clearUserCredentials"
      />
      <OFormInput
        ref="password"
        data-id="loginFormPassword"
        v-bind="formConfig.password"
        v-model.trim="formItems.password"
        @appendClick="showPass = !showPass"
        @click.native="clearUserCredentials"
      />
      <template v-slot:actions="{ loading, invalid }">
        <slot name="actions" :loading="loading" :invalid="invalid" />
      </template>
      <template #footer>
        <OAlert type="error" v-if="userCredentialsError" dismissible>
            {{ $t("login.loginError") }}
        </OAlert>
        <OAlign align="center">
          <OText type="p" v-feature:canResetPassword :color="textColor"
            >{{ $t("login.troubleLoggingIn") }}
            <OLink
              data-id="loginFormResetPwdLnk"
              @click.native="emitToggleForm('ResetPasswordForm')"
              >{{ $t("login.passwordReset") }}</OLink
            ></OText
          >
        </OAlign>
      </template>
    </OForm>    
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from "vue-property-decorator";
import { BaseStateInterface } from "@/types/store.types";
import { Action, namespace } from "vuex-class";
import {
  OpenBankingContext,
  UserLoginRequest,
} from "@/store/modules/authenticationModule";
import { TokensContext } from "@/omnicore-lib/src/services/http/TenantTokenBasedService";

const authenticationModule = namespace("authenticationModule");
const openBankingModule = namespace("openBankingModule");

interface InputConfig {
  name: string;
  rules?: string;
  label?: string | unknown;
  required?: boolean;
  preSelected?: unknown;
  type?: string;
  clearable?: boolean;
  hint?: string | unknown;
  appendIcon?: string;
  disabled?: boolean;
  counter?: number;
  error?: boolean;
  placeholder?: string;
  backgroundColor?: string;
  messageColor?: string;
  labelColor?: string;
  messageBold?: boolean;
  outsideLabel?: boolean;
}

interface LoginConfig {
  loginId: InputConfig;
  emailAddress: InputConfig;
  password: InputConfig;
}

interface AnyObject {
  [key: string]: any;
}

@Component({
  components: {
    OForm: () => import("@/components/lib/Form/OForm.vue"),
    OFormInput: () => import("@/components/lib/Form/OFormInput.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
    OAlign: () => import("@/components/lib/OAlign.vue"),
    OLink: () => import("@/components/lib/OLink.vue"),
  },
})
export default class LoginForm extends Vue {
  @Prop() private inputColor!: string;
  @Prop() private textColor!: string;
  @Prop() private labelColor!: string;
  @Prop({ default: undefined }) private messageColor!: string;
  @Prop({ default: false }) private messageBold!: boolean;
  @Prop({ default: false }) private outsideLabel!: boolean;
  @Prop({ default: 9 }) private loginIdLength!: number;

  formItems: AnyObject = {};
  showPass = false;

  @authenticationModule.State
  public userLoginSession!: BaseStateInterface;

  @authenticationModule.State
  public serviceError!: BaseStateInterface;

  @openBankingModule.State
  public postOpenBankingConsentErrorResponse!: BaseStateInterface;

  @Action("authenticationModule/GET_USER_LOGIN_SESSION")
  getUserLoginSession!: (UserLoginRequest) => string;

  @Action("authenticationModule/CLEAR_USER_CREDENTIALS")
  clearUserCredentials!: () => string;

  @Action("authenticationModule/CLEAR_SERVICE_ERROR")
  clearServiceError!: () => string;

  @Action("openBankingModule/POST_OPEN_BANKING_CONSENT_ERROR")
  postOpenBankingConsentError!: (payload) => BaseStateInterface;

  timer: ReturnType<typeof setInterval> | undefined = undefined;

  get userCredentialsLoading(): boolean {
    return this.userLoginSession.loading;
  }

  get userCredentialsError(): string | null {
    return this.userLoginSession.errorMessage;
  }

  get mask(): string {
    return "#".repeat(this.loginIdLength);
  }

  get isError() {
    return this.userLoginSession?.errorMessage;
  }

  get openBankingId(): string | null {
    return this.$route?.params?.openbankingid;
  }

  get isOpenBankingRequest(): boolean {
    return !(this.openBankingId === null || this.openBankingId === undefined);
  }

  get redirectUrlOnError(): string {
    return this.postOpenBankingConsentErrorResponse?.data?.redirectUrl;
  }

  private mapPayload(): UserLoginRequest {
    return {
      tenantName: process.env.VUE_APP_TENANT,
      credentials: {
        personId: this.formItems?.loginId?.value.trim(),
        username: this.formItems?.emailAddress?.value.trim(),
        password: this.formItems?.password?.value.trim(),
      },
      context: {
        openBanking: this.GetOpenBankingContext(),
      },
    };
  }

  private GetOpenBankingContext(): OpenBankingContext | null {
    if (
      this.openBankingId === null ||
      this.openBankingId === undefined ||
      this.$route?.params?.openbankingaction === null ||
      this.$route?.params?.openbankingaction === undefined
    ) {
      return null;
    }

    return {
      id: this.$route.params.openbankingid,
      action: this.$route.params.openbankingaction,
    };
  }

  get formConfig(): LoginConfig {
    return {
      loginId: {
        name: "loginId",
        rules: `required|length:${this.loginIdLength}|integer`,
        label: this.$t("login.loginId"),
        hint: this.$t("login.digitId"),
        error: !!this.userCredentialsError,
        backgroundColor: this.inputColor,
        messageColor: this.messageColor,
        messageBold: this.messageBold,
        labelColor: this.labelColor,
      },
      emailAddress: {
        name: "emailAddress",
        rules: "required|email",
        label: this.$t("login.emailAddress"),
        type: "email",
        error: !!this.userCredentialsError,
        backgroundColor: this.inputColor,
        messageColor: this.messageColor,
        messageBold: this.messageBold,
        outsideLabel: this.outsideLabel,
        labelColor: this.labelColor,
      },
      password: {
        name: "password",
        rules: "required",
        label: this.$t("login.password"),
        type: this.showPass ? "text" : "password",
        appendIcon: this.showPass ? "mdi-eye" : "mdi-eye-off",
        error: !!this.userCredentialsError,
        backgroundColor: this.inputColor,
        messageColor: this.messageColor,
        messageBold: this.messageBold,
        outsideLabel: this.outsideLabel,
        labelColor: this.labelColor,
      },
    };
  }

  mounted() {
    this.clearServiceError();
    this.$nextTick(() => {
      setTimeout(() => {
        /* do nothing */
      }, 500);
    });
  }

  handleCancel(): void {
    (this.$refs.form as Vue & { reset: () => void }).reset();
  }

  handleReset(): void {
    this.formItems = {};
  }

  emitToggleForm(form: string): void {
    this.$emit("toggleForm", form);
  }

  executeRedirect(redirectUrl: string) {
    window.location.href = redirectUrl;
  }

  async handleSubmit(): Promise<void> {
    try {
      TokensContext.instance.clearTokens();
      await this.getUserLoginSession(this.mapPayload());
      this.emitToggleForm("OtpForm");
    } catch (e) {
      console.log(e);
      await this.handleOpenBankingError(e);
    }
  }

  async handleOpenBankingError(e): Promise<void> {
    if (this.isOpenBankingRequest && this.isError) {
      await this.postOpenBankingConsentError({
        openBankingId: this.openBankingId,
        reason: "Login failed " + e,
        tenantName: process.env.VUE_APP_TENANT,
      });
      this.timer = setInterval(
        this.executeRedirect,
        5000,
        this.redirectUrlOnError
      );
    }
  }
}
</script>
