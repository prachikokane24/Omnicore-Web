<template>
  <div>
    <OAlign align="center" align-md="left">
      <OText
        type="p"
        class="mb-4"
        :color="textColor"
        :text="$t('resetPassword.troubleLoggingIn')"
      />
    </OAlign>
    <OForm
      ref="form"
      @submit="handleSubmit"
      @cancel="handleCancel"
      :loading="resetUserCredentialsLoading"
      :submitText="$t('resetPassword.resetPasswordBtn')"
      :cancelText="`← ${$t('resetPassword.cancelBtnText')}`"
      :btn-group-fill="true"
      data-id="resetForm"
    >
      <OFormInput
        data-id="resetFormLoginId"
        ref="loginId"
        v-bind="formConfig.loginId"
        v-model.trim="formItems.loginId"
        :background-color="inputColor"
        :mask="`${mask}`"
        onblur
        tabindex="0"
      />
      <OFormInput
        v-bind="formConfig.emailAddress"
        v-model.trim="formItems.emailAddress"
        ref="email"
        data-id="resetFormEmailAddress"
        :background-color="inputColor"
      />
      <template v-slot:actions="{ loading, invalid }">
        <slot name="actions" :loading="loading" :invalid="invalid" />
      </template>
      <template #footer>
        <OAlert type="error" v-if="resetUserCredentialsError">
          {{ $t("resetPassword.errorMessage") }}
        </OAlert>
        <OAlert type="success" v-if="isValidEmail">
          {{ $t("resetPassword.successMessage") }}
        </OAlert>
      </template>
    </OForm>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from "vue-property-decorator";
import { BaseStateInterface } from "@/types/store.types";
import { Action, namespace } from "vuex-class";
import { ResetPayload } from "@/store/modules/userModule";

const userModule = namespace("userModule");

interface InputConfig {
  name: string;
  rules?: string;
  label?: string | unknown;
  required?: boolean;
  preSelected?: unknown;
  type?: string;
  clearable?: boolean;
  hint?: string | unknown;
  appendIcon?: string;
  disabled?: boolean;
  counter?: number;
  error?: boolean;
  placeholder?: string;
  backgroundColor?: string;
  messageColor?: string;
  labelColor?: string;
  messageBold?: boolean;
  outsideLabel?: boolean;
}

interface ResetPasswordConfig {
  emailAddress: InputConfig;
  loginId: InputConfig;
}

interface AnyObject {
  [key: string]: any;
}

@Component({
  components: {
    OForm: () => import("@/components/lib/Form/OForm.vue"),
    OFormInput: () => import("@/components/lib/Form/OFormInput.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
    OAlign: () => import("@/components/lib/OAlign.vue"),
    OLink: () => import("@/components/lib/OLink.vue"),
  },
})
export default class ResetForm extends Vue {
  @Prop() private inputColor!: string;
  @Prop() private textColor!: string;
  @Prop({ default: undefined }) private messageColor!: string;
  @Prop({ default: false }) private messageBold!: boolean;
  @Prop({ default: 9 }) private loginIdLength!: number;
  @Prop() private labelColor!: string;
  @Prop({ default: false }) private outsideLabel!: boolean;

  formItems: AnyObject = {};
  isValidEmail = false;

  @userModule.State
  public resetUserCredentials!: BaseStateInterface;

  @Action("userModule/RESET_USER_CREDENTIALS")
  requestUserCredentials!: (ResetPayload) => string;

  get resetUserCredentialsData(): unknown {
    return this.resetUserCredentials?.data;
  }

  get resetUserCredentialsLoading(): boolean {
    return this.resetUserCredentials?.loading;
  }

  get resetUserCredentialsError(): string | null {
    return this.resetUserCredentials?.errorMessage;
  }

  get mask(): string {
    return "#".repeat(this.loginIdLength);
  }

  mounted(): void {
    this.$nextTick(() => {
      setTimeout(() => {
        (this.$refs.loginId as Vue & { setFocus: () => void }).setFocus();
      }, 500);
    });
  }

  get mapPayload(): ResetPayload {
    return {
      accountNumber: this.formItems?.loginId?.value,
      email: this.formItems?.emailAddress?.value,
      tenantName: process.env.VUE_APP_TENANT
    };
  }

  get formConfig(): ResetPasswordConfig {
    return {
      loginId: {
        name: "loginId",
        rules: `required|length:${this.loginIdLength}|integer`,
        label: this.$t("login.loginId"),
        hint: this.$t("login.digitId"),
        error: !!this.resetUserCredentialsError,
        backgroundColor: this.inputColor,
        messageColor: this.messageColor,
        messageBold: this.messageBold,
        labelColor: this.labelColor,
      },
      emailAddress: {
        name: "emailAddress",
        rules: "required|email",
        label: this.$t("login.emailAddress"),
        type: "email",
        error: !!this.resetUserCredentialsError,
        backgroundColor: this.inputColor,
        messageColor: this.messageColor,
        messageBold: this.messageBold,
        outsideLabel: this.outsideLabel,
        labelColor: this.labelColor,
      },
    };
  }

  handleCancel(): void {
    this.emitToggleForm();
  }

  emitToggleForm(): void {
    this.$emit("toggleForm", "LoginForm");
  }

  async handleSubmit(): Promise<void> {
    try {
      await this.requestUserCredentials(this.mapPayload);
      this.isValidEmail = true;
      (this.$refs.form as Vue & { reset: () => void }).reset();
    } catch (e) {
      console.log(e);
    }
  }
}
</script>
