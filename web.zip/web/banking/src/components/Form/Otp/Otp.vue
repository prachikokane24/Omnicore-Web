<template>
  <div>
    <OAlign align="center" align-md="left">
      <OText
        type="p"
        class="mb-4"
        v-html="$t('Otp.messageP1')"
        :color="textColor"
      />
    </OAlign>
    <OForm
      ref="form"
      data-id="otpForm"
      @submit="handleSubmit"
      @cancel="handleCancel"
      @invalid="handleInvalid"
      :loading="verifyOtpLoading"
      :submitText="`${$t('Otp.submitBtnText')}`"
      :cancelText="`${$t('Otp.cancelBtnText')}`"
      :btn-group-fill="true"
      :hideActions="hideActions"
    >
      <OFormInput
        v-bind="formConfig.otpCode"
        v-model="formItems.otpCode"
        ref="otpCode"
        :mask="'######'"
        data-id="otpFormPasscode"
      />
      <template v-slot:actions="{ loading, invalid }">
        <slot name="actions" :loading="loading" :invalid="invalid" />
      </template>
      <template #footer>
        <OAlign align="center" align-md="left">
          <OText type="p" :color="textColor">
            {{ $t("Otp.notReceivedOtp") }}
            <template v-if="disabledOtpRequest">
              <span>
                {{ $t("Otp.notReceivedOtpLinkTimer") }}
              </span>
              <span class="primary--text"
                >{{ countDown }}{{ $t("Otp.notReceivedOtpSeconds") }}</span
              >
            </template>
            <OLink
              xsmall
              @click.native="handleSendOTP"
              :color="textColor"
              v-else
              >{{ $t("Otp.notReceivedOtpLink") }}</OLink
            >
          </OText>
        </OAlign>
        <OAlert type="error" v-if="verifyOtpError">
          {{ $t("Otp.invalidPassword") }}
        </OAlert>
      </template>
    </OForm>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from "vue-property-decorator";
import { BaseStateInterface } from "@/types/store.types";
import { Action, namespace } from "vuex-class";
const otpModule = namespace("otpModule");

interface InputConfig {
  name: string;
  rules?: string;
  label?: unknown;
  required?: boolean;
  preSelected?: unknown;
  type?: string;
  clearable?: boolean;
  hint?: string;
  appendIcon?: string;
  disabled?: boolean;
  counter?: number;
  maxlength?: number;
  pattern?: string;
  placeholder?: string;
  backgroundColor: string;
  messageColor: string;
  messageBold: boolean;
}

interface OtpCodeConfig {
  otpCode: InputConfig;
}

interface VerifyOtpPayload {
  sessionId: string;
  code: string;
}

interface AnyObject {
  [key: string]: any;
}

@Component({
  components: {
    OButton: () => import("@/components/lib/OButton.vue"),
    OForm: () => import("@/components/lib/Form/OForm.vue"),
    OFormInput: () => import("@/components/lib/Form/OFormInput.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
    OAlign: () => import("@/components/lib/OAlign.vue"),
    OLink: () => import("@/components/lib/OLink.vue"),
  },
})
export default class OtpForm extends Vue {
  @Prop({ default: false }) private hideActions!: boolean;
  @Prop() private inputColor!: string;
  @Prop() private textColor!: string;
  @Prop({ default: undefined }) private messageColor!: string;
  @Prop({ default: false }) private messageBold!: boolean;

  formItems: AnyObject = {};
  isValidEmail = false;
  countDown = 60;
  hasSubmitted = false;

  @otpModule.State
  public sendOtp!: BaseStateInterface;

  @otpModule.State
  public verifyOtp!: BaseStateInterface;

  @otpModule.State
  public userOtpSession!: BaseStateInterface;

  @otpModule.State
  public userAccessTokenResponse!: BaseStateInterface;

  @Action("otpModule/CLEAR_OTP")
  clearOtp!: () => string;

  @Action("otpModule/SEND_OTP")
  sendOtpCode!: () => string;

  @Action("otpModule/VERIFY_OTP")
  verifyOtpCode!: (VerifyOtpPayload) => BaseStateInterface;

  get verifyOtpLoading(): boolean {
    return this.verifyOtp.loading || this.userAccessTokenResponse.loading;
  }
  get verifyOtpError(): boolean {
    return this.verifyOtp?.data?.otpResult == false && this.hasSubmitted;
  }
  get verifyOtpSessionId(): string {
    return this.sendOtp?.data?.sessionId;
  }
  get otpPassCode(): string {
    return this.formItems?.otpCode?.value;
  }

  get formConfig(): OtpCodeConfig {
    return {
      otpCode: {
        name: "otp",
        rules: "required|length:6|integer",
        label: this.$t("Otp.labelInput"),
        type: "number",
        backgroundColor: this.inputColor,
        messageColor: this.messageColor,
        messageBold: this.messageBold,
        // eslint-disable-next-line
        maxlength: 6,
        counter: 6,
      },
    };
  }

  get disabledOtpRequest(): boolean {
    return this.countDown > 0 ? true : false;
  }

  // sendOTP(): void {
  //   alert("ddfdf");
  //   this.clearOtp();
  //   this.countDownTimer();
  //   this.$nextTick(() => {
  //     setTimeout(() => {
  //       (this.$refs.otpCode as Vue & { setFocus: () => void }).setFocus();
  //     }, 500);
  //   });
  // }

  mounted() {
    this.handleSendOTP();
  }

  resetTimer(): void {
    this.countDown = 60;
    this.countDownTimer();
  }

  countDownTimer(): void {
    if (this.countDown > 0) {
      setTimeout(() => {
        this.countDown -= 1;
        this.countDownTimer();
      }, 1000);
    }
  }

  handleCancel(): void {
    this.clearOtp();
    this.emitToggleForm();
  }

  handleInvalid(val: boolean): void {
    this.$emit("invalid", val);
  }

  emitToggleForm(): void {
    this.$emit("toggleForm", "LoginForm");
  }

  handleSendOTP(): void {
    try {
      this.countDownTimer();
      this.resetTimer();
      this.clearOtp();
      this.sendOtpCode();
      // this.$nextTick(() => {
      //   (this.$refs.form as Vue & { reset: () => void }).reset();
      // });
    } catch (e) {
      console.log(e);
    }
  }

  async handleSubmit(): Promise<void> {
    try {
      this.hasSubmitted = true;
      const otpVerificationResponse = await this.verifyOtpCode({
        sessionId: this.verifyOtpSessionId,
        code: this.formItems?.otpCode?.value || "",
      });
      if (otpVerificationResponse.data.otpResult) {
        this.$emit("verified");
      } else if (otpVerificationResponse.data.otpError) {
        throw new Error("Otp verification error");
      }
    } catch (e) {
      console.log(e);
    }
  }
}
</script>
<style lang="scss">
/* Chrome, Safari, Edge, Opera */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

/* Firefox */
input[type="number"] {
  -moz-appearance: textfield;
}
</style>
