<template>
  <div>
    <OAlign align="center" align-md="left">
      <OText
        type="p"
        class="mb-4"
        v-html="$t('Otp.messageP1')"
        :color="textColor"
      />
    </OAlign>
    <OForm
      ref="form"
      data-id="otpForm"
      @submit="handleSubmit"
      @cancel="handleCancel"
      @invalid="handleInvalid"
      :loading="verifyOtpLoading"
      :submitText="`${$t('Otp.submitBtnText')}`"
      :cancelText="`${$t('Otp.cancelBtnText')}`"
      :btn-group-fill="true"
      :hideActions="hideActions"
    >
      <OFormInput
        v-bind="formConfig.otpCode"
        v-model="formItems.otpCode"
        ref="otpCode"
        :mask="'######'"
        data-id="otpFormPasscode"
      />
      <template v-slot:actions="{ loading, invalid }">
        <slot name="actions" :loading="loading" :invalid="invalid" />
      </template>
      <template #footer>
        <OAlign align="center" align-md="left">
          <OText type="p" :color="textColor">
            {{ $t("Otp.notReceivedOtp") }}
            <template v-if="disabledOtpRequest">
              <span>
                {{ $t("Otp.notReceivedOtpLinkTimer") }}
              </span>
              <span class="primary--text"
                >({{ countDown }}{{ $t("Otp.notReceivedOtpSeconds") }})</span
              >
            </template>
            <OLink
              xsmall
              @click.native="handleSendOTP"
              :color="textColor"
              v-else
              >{{ $t("Otp.notReceivedOtpLink") }}</OLink
            >
          </OText>
        </OAlign>
        <OAlert type="error" v-if="verifyOtpError">
          {{ $t("Otp.invalidPassword") }}
        </OAlert>
      </template>
    </OForm>
    <ModalUpdatePassword @passwordUpdated="handleRedirect" />
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from "vue-property-decorator";
import { BaseStateInterface } from "@/types/store.types";
import { Action, namespace } from "vuex-class";
import {
  UserLoginRequest,
  OtpVerifyRequest,
  OpenBankingContext,
  ResendOtpUserTokenRequest,
} from "@/store/modules/authenticationModule";
const authenticationModule = namespace("authenticationModule");

interface InputConfig {
  name: string;
  rules?: string;
  label?: unknown;
  required?: boolean;
  preSelected?: unknown;
  type?: string;
  clearable?: boolean;
  hint?: string;
  appendIcon?: string;
  disabled?: boolean;
  counter?: number;
  maxlength?: number;
  pattern?: string;
  placeholder?: string;
  backgroundColor: string;
  messageColor: string;
  messageBold: boolean;
}

interface OtpCodeConfig {
  otpCode: InputConfig;
}

interface VerifyOtpPayload {
  sessionId: string;
  verificationCode: string;
}

interface AnyObject {
  [key: string]: any;
}

@Component({
  components: {
    OButton: () => import("@/components/lib/OButton.vue"),
    OForm: () => import("@/components/lib/Form/OForm.vue"),
    OFormInput: () => import("@/components/lib/Form/OFormInput.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
    OAlign: () => import("@/components/lib/OAlign.vue"),
    OLink: () => import("@/components/lib/OLink.vue"),
    ModalUpdatePassword: () =>
      import("@/components/Form/UpdatePassword/ModalUpdatePassword.vue"),
  },
})
export default class UnauthenticatedOtpForm extends Vue {
  @Prop({ default: false }) private hideActions!: boolean;
  @Prop() private inputColor!: string;
  @Prop() private textColor!: string;
  @Prop({ default: undefined }) private messageColor!: string;
  @Prop({ default: false }) private messageBold!: boolean;

  formItems: AnyObject = {};
  isValidEmail = false;
  countDown = 60;

  @authenticationModule.State
  public userCredentials!: BaseStateInterface;

  @authenticationModule.State
  public userLoginSession!: BaseStateInterface;

  @authenticationModule.State
  public userAccessTokenResponse!: BaseStateInterface;

  @authenticationModule.State
  public noop!: BaseStateInterface;

  @Action("authenticationModule/RESEND_OTP")
  sendOtpCode!: (payload: ResendOtpUserTokenRequest) => BaseStateInterface;

  @Action("authenticationModule/VERIFY_OTP")
  verifyOtp!: (payload) => BaseStateInterface;

  @Action("authenticationModule/CHECK_FIRST_LOGIN")
  checkFirstLogin!: () => any;

  @Action("authenticationModule/CLEAR_USER_ACCESS_TOKEN")
  clearAccessToken!: () => BaseStateInterface;

  get verifyOtpLoading(): boolean {
    return (
      this.userLoginSession.loading ||
      this.userAccessTokenResponse.loading ||
      this.noop.loading
    );
  }

  get verifyOtpError(): string | null {
    return this.userAccessTokenResponse.errorMessage;
  }

  get verifyOtpSessionId(): string {
    return (
      new URL(this.userLoginSession?.data?.redirectUrl).searchParams.get(
        "sessionid"
      ) ?? ""
    );
  }

  get redirectPath(): string {
    var url = new URL(this.userLoginSession?.data?.redirectUrl);
    return (
      url.pathname + "/" + (url.searchParams.get("redirectids") ?? "") ?? ""
    );
  }

  get userLoginRequest(): UserLoginRequest {
    let userLoginRequest: UserLoginRequest = {
      tenantName: this.userCredentials.data.tenantName,
      credentials: {
        username: this.userCredentials.data.credentials.username,
        password: this.userCredentials.data.credentials.password,
        personId: this.userCredentials.data.credentials.personId,
      },
      context: {
        openBanking: this.GetOpenBankingContext(),
      },
    };
    return userLoginRequest;
  }

  private GetOpenBankingContext(): OpenBankingContext | null {
    let openBanking = this.userCredentials?.data?.context?.openBanking;
    if (openBanking === null) {
      return null;
    }

    if (openBanking.id === null || openBanking.action === null) {
      return null;
    }

    return {
      id: this.userCredentials.data.context.openBanking.id,
      action: this.userCredentials.data.context.openBanking.action,
    };
  }

  mounted(): void {
    this.countDownTimer();
    this.$nextTick(() => {
      setTimeout(() => {
        // (this.$refs.otpCode as Vue & { setFocus: () => void }).setFocus();
      }, 500);
    });
  }

  get formConfig(): OtpCodeConfig {
    return {
      otpCode: {
        name: "otp",
        rules: "required|length:6|integer",
        label: this.$t("Otp.labelInput"),
        type: "number",
        backgroundColor: this.inputColor,
        messageColor: this.messageColor,
        messageBold: this.messageBold,
        maxlength: 6,
        counter: 6,
      },
    };
  }

  get disabledOtpRequest(): boolean {
    return this.countDown > 0 ? true : false;
  }

  mapPayload(): OtpVerifyRequest {
    return {
      context: {
        otpSessionId: this.verifyOtpSessionId,
      },
      otpPassCode: this.formItems?.otpCode?.value,
    };
  }

  resetTimer(): void {
    this.countDown = 30;
    this.countDownTimer();
  }

  countDownTimer(): void {
    if (this.countDown > 0) {
      setTimeout(() => {
        this.countDown -= 1;
        this.countDownTimer();
      }, 1000);
    }
  }

  handleCancel(): void {
    this.clearAccessToken();
    this.emitToggleForm();
  }

  handleInvalid(val: boolean): void {
    this.$emit("invalid", val);
  }

  emitToggleForm(): void {
    this.$emit("toggleForm", "LoginForm");
  }

  async handleSendOTP(): Promise<void> {
    try {
      this.clearAccessToken();
      this.resetTimer();
      (this.$refs.form as Vue & { reset: () => void }).reset();
      this.sendOtpCode({ sessionId: this.verifyOtpSessionId });
    } catch (e) {
      console.log(e);
    }
  }

  async handleFirstLogin() {
    try {
      const response = await this.checkFirstLogin();
      if (response?.data?.actionType == "changePassword") {
        this.$modal.show("loginUpdatePassword");
        return;
      }
      this.handleRedirect();
    } catch (e) {
      console.log(e);
    }
  }

  async handleSubmit(): Promise<void> {
    try {
      let payload = this.mapPayload();
      await this.verifyOtp(payload);
      await this.handleFirstLogin();
    } catch (e) {
      console.log(e);
    }
  }

  handleRedirect() {
    this.$emit("verified", this.redirectPath);
  }
}
</script>
<style lang="scss">
/* Chrome, Safari, Edge, Opera */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

/* Firefox */
input[type="number"] {
  -moz-appearance: textfield;
}
</style>
