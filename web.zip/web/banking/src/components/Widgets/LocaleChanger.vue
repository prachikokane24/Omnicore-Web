<template>
  <div class="locale-changer">
    <select v-model="$i18n.locale">
      <option v-for="(lang, i) in langs" :key="`Lang${i}`" :value="lang">
        {{ lang }}
      </option>
      {{
        logoLight
      }}
    </select>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
// import locales from "@tenantLocales/index.ts";
@Component({
  components: {
    // OSelect: () => import("@/components/lib/OSelect.vue"),
  },
})
export default class LocaleChanger extends Vue {
  //private langs = locales;
}
</script>
