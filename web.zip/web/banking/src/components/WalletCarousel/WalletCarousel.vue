<template>
  <div>
    <carousel-3d
      @after-slide-change="onAfterSlideChange"
      :perspective="0"
      :width="size.width"
      :height="size.height"
      :controls-visible="mapItems.length > 1"
      :border="0"
      :display="3"
      :count="mapItems.length"
      ref="carousel"
      v-if="mapItems.length > 0"
    >
      <slide v-for="(item, i) in mapItems" :index="i" :key="i">
        <template slot-scope="{ index, isCurrent, leftIndex, rightIndex }">
          <figure>
            <img
              :data-index="index"
              :class="{
                current: isCurrent,
                onLeft: leftIndex >= 0,
                onRight: rightIndex >= 0,
              }"
              :src="require(`@tenantAssets/cards/card.png`)"
              v-if="item.walletType == 'card'"
              class="card__image"
              :style="imageStyles(item.status)"
              @click="handleStatusModal(item.status)"
            />
            <div
              v-else
              class="card"
              :style="`background-color: #${item.data.color}; color: #${item.data.textColor};`"
            >
              <img
                :data-index="index"
                :class="{
                  current: isCurrent,
                  onLeft: leftIndex >= 0,
                  onRight: rightIndex >= 0,
                }"
                :src="require(`@/assets/cards/blank.png`)"
                style="visibility: hidden"
                class="card__image"
              />
              <div class="card__title">
                <img
                  :src="
                    item.data.icon
                      ? require(`@tenantAssets/wallet-icons/${item.data.icon}.svg`)
                      : require(`@tenantAssets/wallet-icons/fa-wallet.svg`)
                  "
                  class="card__icon"
                  :alt="item.icon"
                />
                <OAlign align="center">
                  <OText
                    size="large"
                    align="center"
                    data-id="carouselWalletName"
                  >
                    <strong>{{
                      item.figcaption | capsFirstLetter | truncate(20)
                    }}</strong>
                  </OText>
                  <OText
                    size="large"
                    align="center"
                    data-id="carouselWalletBalance"
                  >
                    Balance:
                    {{ item.data.availableBalance.minorUnits | currency }}
                  </OText>
                </OAlign>
              </div>
            </div>
            <figcaption v-if="item.figcaption && item.walletType == 'card'">
              <OAlign align="center">
                <OText size="md" bold>
                  {{ item.figcaption | capsFirstLetter }}

                  <span v-if="item.status == 'locked'" class="warning--text"
                    >- Card Frozen</span
                  >
                  <span
                    class="warning--text"
                    v-else-if="item.status !== 'active'"
                    >- Card Inactive</span
                  >
                </OText>
              </OAlign>
            </figcaption>
          </figure>
        </template>
      </slide>
    </carousel-3d>
    <OModalConfirmCancel
      id="statusModal"
      :hideConfirmBtn="true"
      :cancelText="$t('manageCard.cancelBtnText')"
    >
      <template v-slot:header>{{ $t("manageCard.modalTitle") }}</template>
      <OAlert type="info" class="mt-4"
        ><OText type="div" size="sm" medium
          ><strong>{{ $t("manageCard.orderReplacement") }}</strong></OText
        ></OAlert
      >
    </OModalConfirmCancel>
  </div>
</template>

<script lang="ts">
/* Wallet Types 
2 - main card wallet,
8 - Savings,
12 - Youth
*/
import { mapGetters } from "vuex";
import { Carousel3d, Slide } from "vue-carousel-3d";
import { Component, Vue, Watch } from "vue-property-decorator";
import { Action } from "vuex-class";

@Component({
  components: {
    OText: () => import("@/components/lib/OText.vue"),
    OAlign: () => import("@/components/lib/OAlign.vue"),
    OIcon: () => import("@/components/lib/OIcon.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
    OModalConfirmCancel: () =>
      import("@/components/lib/Modal/OModalConfirmCancel.vue"),
    Carousel3d,
    Slide,
  },
  computed: {
    ...mapGetters("summaryModule", {
      getSelectedUserAccountWallets: "getSelectedUserAccountWallets",
      getAccountDetails: "getAccountDetails",
    }),
  },
})
export default class WalletCarousel extends Vue {
  getAccountDetails!: any;
  getSelectedUserAccountWallets!: any;
  reissueTypes = ["blocked", "lost", "stolen"];

  @Action("summaryModule/UPDATE_SELECTED_WALLET")
  updateSelectedWallet!: (payload) => string;

  // This causes weird bug
  // @Watch("mapItems")
  // onMapItemsChange(): void {
  //   this.updateWallet();
  // }

  created(): void {
    this.$EventBus.$on("changeWallet", this.goToSlide);
    this.updateWallet();    
  }

  handleStatusModal(status) {
    if (!this.reissueTypes.includes(status)) return;
    this.$modal.show("statusModal");
  }

  imageStyles(status) {
    if (status == "active") return {};
    if (this.reissueTypes.includes(status))
      return {
        filter: "grayscale(100%) brightness(120%)",
        cursor: "pointer",
      };
    return {
      filter: "grayscale(100%) brightness(120%)",
    };
  }

  get size(): { width: number; height: number } {
    return {
      width: this.$vuetify.breakpoint.xs ? 250 : 280,
      height: this.$vuetify.breakpoint.xs ? 200 : 210,
    };
  }

  get mapItems(): {
    id: string;
    walletType: string;
    figcaption: string;
    data: string;
  } {
    return (
      this.getSelectedUserAccountWallets?.wallets?.map((wallet) => {
        return {
          id: wallet.walletId,
          walletType: wallet.walletType,
          figcaption: wallet.nickName,
          status: this.getAccountDetails?.accountStatus,
          data: wallet,
        };
      }) || []
    );
  }

  updateWallet(): void {
    const defaultWallet = this.getSelectedUserAccountWallets?.wallets[0];
    if (defaultWallet) {
      this.updateSelectedWallet(defaultWallet);
    }
  }

  onAfterSlideChange(index: number): void {
    try {      
      this.updateSelectedWallet(
        this.getSelectedUserAccountWallets?.wallets[index]
      ); 
      this.$EventBus.$emit("updateAccountBalance", "CarouselChanged");
    } catch (e) {
      console.log(e);
    }
  }

  goToSlide(index): void {
    (this.$refs.carousel as Vue & { goSlide: (index) => void }).goSlide(index);
  }
}
</script>

<style lang="scss" scoped>
.carousel-3d-slide {
  background-color: transparent;
  border-width: 0;
  &:not(.current) {
    //opacity: 0.5 !important;
    filter: blur(2px);
  }
}
::v-deep .prev {
  color: var(--v-primary-base) !important;
}

::v-deep .next {
  color: var(--v-primary-base) !important;
}
.card {
  border-radius: 5px;
  //box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.28);
  border: 1px solid rgba(255, 255, 255, 0.3);
  background-color: var(--v-primary-base);
  &__title {
    color: white;
    position: absolute;
    bottom: 50px;
    width: 100%;
    padding: 10px;
    text-align: center;
    z-index: 100;
  }

  &__image {
    display: block;
    border: 1px solid rgba(255, 255, 255, 0.3);
    border-radius: 5px;
    //box-shadow: 0px 3px 6px 0px rgba(0, 0, 0, 0.28);
    margin-bottom: 8px;
  }
  &__icon {
    width: 100%;
    max-width: 70px;
  }
}
figcaption {
  color: #000;
}

div.carousel-3d-container {
  background: #fff !important;
}

</style>
