<template>
  <div class="account-card" :style="$vuetify.breakpoint.lgAndDown ? '' : 'height:250px;'">
    <div class="account-card-row even">
      <table class="account-card-holder">
        <tr>
          <th>
            <OText>{{ $t("accountInfo.accountHolder") }}:</OText>
          </th>
          <td>
            <OText v-if="accountDetails.accountHolders">{{
              accountDetails.accountHolders[0].name
            }}</OText>
          </td>
        </tr>
      </table>
    </div>
    <div class="account-card-row">
      <div class="account-card--col1">
        <table class="account-card-balance">
          <tr>
            <th>
              <OText>{{
                isMainWallet
                  ? $t("accountInfo.availableBalance")
                  : $t("accountInfo.savingsBalance")
              }}:</OText>
              <OText size="sm" v-if="isMainWallet">{{
                $t("accountInfo.accountBalance")
              }}:</OText>
            </th>
            <td>
              <OText bold>{{
                accountDetails.availableBalance | currency
              }}</OText>
              <OText size="sm" v-if="isMainWallet">{{
                accountDetails.accountBalance | currency
              }}</OText>
            </td>
          </tr>
        </table>
      </div>
      <div class="account-card--col2" v-if="$vuetify.breakpoint.mdAndUp">
        <table
          class="account-card-details"
          :style="{ visibility: isSavingsWallet ? 'hidden' : 'visible' }"
        >
          <tr>
            <th>
              <OText size="sm" align="left">{{
                $t("accountInfo.accountSortCode")
              }}:</OText>
            </th>
            <td>
              <OText size="sm">{{ accountDetails.accountSortCode | formattedSortCode }}</OText>
            </td>
          </tr>
          <tr>
            <th>
              <OText size="sm" align="left">{{
                $t("accountInfo.accountNumber")
              }}:</OText>
            </th>
            <td>
              <OText size="sm">{{ accountDetails.accountAccountNumber }}</OText>
            </td>
          </tr>
        </table>
      </div>
    </div>
    <div
      class="account-card-row even"
      v-if="$vuetify.breakpoint.smAndDown && isMainWallet"
    >
      <div class="account-card--col1">
        <table class="account-pending-details mr-4">
          <tr>
            <th>
              <OText size="sm" medium>{{
                $t("accountInfo.accountSortCode")
              }}</OText>
            </th>
            <td>
              <OText size="sm">{{ accountDetails.accountSortCode }}</OText>
            </td>
          </tr>
        </table>
        <table class="account-pending-details">
          <tr>
            <th>
              <OText size="sm" medium>{{
                $t("accountInfo.accountNumber")
              }}</OText>
            </th>
            <td>
              <OText size="sm">{{ accountDetails.accountAccountNumber }}</OText>
            </td>
          </tr>
        </table>
      </div>
    </div>
    <div
      class="account-card-row even"
      v-if="isSavingsWallet && accountDetails.savingsTargetAmount"
    >
      <div class="account-card--col1">
        <table
          class="account-pending-details mr-4"
          v-if="accountDetails.savingsTargetAmount"
        >
          <tr>
            <th>
              <OText size="sm" medium>{{
                $t("accountInfo.targetBalance")
              }}</OText>
            </th>
            <td>
              <OText size="sm">{{
                accountDetails.savingsTargetAmount | currency
              }}</OText>
            </td>
          </tr>
        </table>
        <table
          class="account-pending-details"
          v-if="accountDetails.savingsTargetDate"
        >
          <tr>
            <th>
              <OText size="sm" medium>{{ $t("accountInfo.targetDate") }}</OText>
            </th>
            <td>
              <OText size="sm"
                >{{ accountDetails.savingsTargetDate | date("shortmonth") }}
              </OText>
            </td>
          </tr>
        </table>
      </div>
    </div>
    <div class="account-card-row even" v-if="isMainWallet">
      <div class="account-card--col1">
        <table class="account-pending-details mr-4">
          <tr>
            <th>
              <OText size="sm" medium>{{ $t("accountInfo.ending") }}</OText>
            </th>
            <td>
              <OText size="sm">{{ accountDetails.accountCardNoEnding }}</OText>
            </td>
          </tr>
        </table>
        <table class="account-pending-details">
          <tr>
            <th>
              <OText size="sm" medium>{{ $t("accountInfo.exp") }}</OText>
            </th>
            <td>
              <OText size="sm">{{ accountDetails.accountCardExpiry }}</OText>
            </td>
          </tr>
        </table>
      </div>
    </div>
    <div class="account-card-row d-none" v-if="isMainWallet">
      <div class="account-card--col1">
        <table class="account-pending-details mr-4">
          <tr>
            <th>
              <OText size="sm" medium>{{
                $t("accountInfo.pendingCredits")
              }}</OText>
            </th>
            <td>
              <OText size="sm">{{
                accountDetails.pendingCredits | currency
              }}</OText>
            </td>
          </tr>
        </table>
        <table class="account-pending-details">
          <tr>
            <th>
              <OText size="sm" medium>{{
                $t("accountInfo.directDebits")
              }}</OText>
            </th>
            <td>
              <OText size="sm"
                >{{ accountDetails.pendingDebits | currency }}
              </OText>
            </td>
          </tr>
        </table>
      </div>
    </div>
    <div class="account-card-row">
      <div class="account-card-actions">
        <OButtonGroup :fluid="true">
          <OButton
            block
            v-if="!isSavingsWallet"
            @click="
              isReissue ? $modal.show('reissueCard') : $modal.show('manageCard')
            "
            data-id="manageCardButton"
            color="primary"
            >{{
              isReissue
                ? $t("accountInfo.reissueCardBtn")
                : $t("accountInfo.manageCardBtn")
            }}
          </OButton>
          <OButton
            block
            outlined
            v-if="isSavingsWallet"
            @click="handleShowWallet('edit')"
            data-id="editWalletButton"
            >{{ $t("accountInfo.editCardBtn") }}</OButton
          >
          <OButton
            block
            outlined
            @click="handleShowWallet('add')"
            data-id="addWalletButton"
            >{{ $t("accountInfo.addCardBtn") }}</OButton
          >
        </OButtonGroup>
      </div>
    </div>

    <OModalConfirmCancel
      v-bind="modalConfig"
      @confirm="handleSaveWallet"
      :confirmText="
        editWallet
          ? $t('editWallet.modalSubmitBtn')
          : $t('addWallet.modalSubmitBtn')
      "
      :dataIdConfirmBtn="editWallet ? 'editConfirmBtn' : 'addConfirmBtn'"
      :dataIdCancelBtn="editWallet ? 'editCancelBtn' : 'addCancelBtn'"
      id="walletModal"
    >
      <template v-slot:header>{{
        editWallet ? $t("editWallet.modalTitle") : $t("addWallet.modalTitle")
      }}</template>
      <OAlert type="warning" v-if="hasMaxWallets && !this.editWallet"
        ><OText type="div" size="sm" medium
          ><strong>{{
            $t("accountInfo.maxWallets", { maxWallets: 5 })
          }}</strong></OText
        ></OAlert
      >
      <OForm
        v-bind="formConfig.settings"
        @invalid="formWalletInvalid = $event"
        ref="form"
        v-show="!hasMaxWallets || this.editWallet"
      >
        <OFormInput
          data-id="walletName"
          v-bind="formConfig.walletName"
          v-model.trim="formItems.walletName"
        />
        <OFormRadioTab
          data-id="walletColor"
          v-bind="formConfig.walletColor"
          v-model="formItems.walletColor"
        />
        <OFormRadioTab
          data-id="walletIcon"
          v-bind="formConfig.walletIcon"
          v-model="formItems.walletIcon"
        />

        <OText>{{ $t("addWallet.setGoalLabel") }}:</OText>
        <OFormInput
          data-id="walletTargetAmount"
          v-bind="formConfig.walletTargetAmount"
          v-model.trim="formItems.walletTargetAmount"
        />
        <OFormDatePicker
          data-id="walletTargetDate"
          v-bind="formConfig.walletTargetDate"
          v-model="formItems.walletTargetDate"
        />
      </OForm>
      <OAlert type="error" v-if="walletErrorMessage"
        ><OText type="div" size="sm" medium
          ><strong>{{ walletErrorMessage }}</strong></OText
        ></OAlert
      >
    </OModalConfirmCancel>
    <OModalConfirm
      id="walletModalConfirmed"
      :message="
        editWallet
          ? $t('editWallet.editWalletSuccess')
          : $t('addWallet.addWalletSuccess')
      "
    />
    <OModalManageCard />
    <OModalReissueCard />
    <ModalInstantPayment id="instantPayment" />
    <ModalInstantTransfer id="instantTransfer" />
  </div>
</template>

<script lang="ts">
import { mapGetters } from "vuex";
import { Component, Prop, Vue } from "vue-property-decorator";
import { BaseStateInterface } from "@/types/store.types";
import {
  parseMonetaryAmount,
  createDefaultMonetaryAmount,
} from "@/types/monetaryAmount";
import { Action, namespace } from "vuex-class";

// eslint-disable-next-line
let { walletColors, walletIcons } = require(`@tenantLib/const`);

const summaryModule = namespace("summaryModule");
const walletModule = namespace("walletModule");

interface AnyObject {
  [key: string]: any;
}

@Component({
  components: {
    OText: () => import("@/components/lib/OText.vue"),
    OAlign: () => import("@/components/lib/OAlign.vue"),
    OForm: () => import("@/components/lib/Form/OForm.vue"),
    OFormRadioTab: () => import("@/components/lib/Form/OFormRadioTab.vue"),
    OFormInput: () => import("@/components/lib/Form/OFormInput.vue"),
    OFormDatePicker: () => import("@/components/lib/Form/OFormDatePicker.vue"),
    OButtonGroup: () => import("@/components/lib/OButtonGroup.vue"),
    OModalConfirmCancel: () =>
      import("@/components/lib/Modal/OModalConfirmCancel.vue"),
    OModalConfirm: () => import("@/components/lib/Modal/OModalConfirm.vue"),
    OModalManageCard: () =>
      import("@/components/AccountDetails/Modals/ModalManageCard.vue"),
    OModalReissueCard: () =>
      import("@/components/AccountDetails/Modals/ModalReissueCard.vue"),
    OButton: () => import("@/components/lib/OButton.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
    ModalInstantPayment: () =>
      import("@/components/InstantPayments/ModalInstantPayment.vue"),
    ModalInstantTransfer: () =>
      import("@/components/InstantPayments/ModalInstantTransfer.vue"),
  },
  computed: {
    ...mapGetters("summaryModule", {
      getAccountDetails: "getAccountDetails",
      getSelectedUserAccountWallets: "getSelectedUserAccountWallets",
    }),
  },
})
export default class AccountDetails extends Vue {
  @Prop({ default: false }) private loading!: boolean;

  @summaryModule.State
  private selectedWallet!: any;

  @walletModule.State
  private walletDetails!: BaseStateInterface;

  @walletModule.State
  private noop!: BaseStateInterface;  

  @Action("walletModule/EMPTY_WALLET")
  getEmptyWallet!: () => void;

  @Action("walletModule/GET_WALLET")
  getWalletDetails!: (id) => string;

  @Action("walletModule/UPDATE_WALLET")
  updateWalletDetails!: (updatePayload) => string;

  @Action("walletModule/CREATE_WALLET")
  createWallet!: (createPayload) => string;

  @Action("walletModule/CLEAR_NOOP")
  clearNoop!: () => string;

  @Action("summaryModule/UPDATE_SELECTED_WALLET_BALANCE")
  updateSelectedWalletBalance!: (payload) => string;

  getAccountDetails!: any;
  getSelectedUserAccountWallets!: any;
  formWalletInvalid = false;
  editWallet = false;
  reissueTypes = ["blocked", "lost", "stolen"];

  formItems: AnyObject = {
    walletName: {},
  };

  isEmpty = (input: any) => !input || !input.trim();

  created() {
    this.$EventBus.$on("updateAccountBalance", this.updateAccountBalance);
  } 

  get isMainWallet(): boolean {
    return this.selectedWallet?.walletType == "card";
  }

  get isSavingsWallet(): boolean {
    return this.selectedWallet?.walletType == "savings";
  }

  get isReissue(): boolean {
    return this.reissueTypes.includes(this.getAccountDetails?.accountStatus);
  }

  get walletIsLoading() {
    return this.walletDetails?.loading || this.noop?.loading;
  }

  get walletErrorMessage() {
    return this.walletDetails?.errorMessage || this.noop?.errorMessage;
  }

  get hasMaxWallets() {
    return this.getSelectedUserAccountWallets?.walletCount > 5;
  }

  get modalConfig() {
    return {
      loading: this.walletIsLoading,
      disabled: this.walletIsLoading,
      confirmDisabled: this.formWalletInvalid,
      confirmText: this.editWallet
        ? this.$t("editWallet.modalSubmitBtn")
        : this.$t("addWallet.modalSubmitBtn"),
      hideConfirmBtn: this.hasMaxWallets && !this.editWallet,
    };
  }

  get formConfig() {
    const wallet = this.walletDetails?.data?.wallet;
    const zero = 0;
    return {
      settings: {
        loading: this.walletIsLoading,
        disabled: this.walletIsLoading || this.walletErrorMessage,
        dataId: this.editWallet ? "editWallet" : "addWallet",
        confirmDisabled: this.formWalletInvalid,
        hideActions: true,
      },
      walletName: {
        name: "walletName",
        rules: `required|min:1|max:25|alphaNoChar|checkSpaces|isNotIn:${this.walletNames}`,
        label: this.$t("addWallet.walletNameLabel"),
        hint: this.$t("addWallet.walletNameHint"),
        preSelected: this.editWallet ? wallet?.nickName : undefined,
        disabled: this.walletIsLoading,
      },
      walletColor: {
        name: "color",
        label: this.$t("addWallet.chooseColorLabel"),
        items: walletColors,
        preSelected: this.editWallet ? wallet?.color : walletColors[0].value,
        disabled: this.walletIsLoading,
      },
      walletIcon: {
        name: "icon",
        label: this.$t("addWallet.chooseIconLabel"),
        items: this.mapWalletIcons,
        preSelected: this.editWallet
          ? wallet?.icon
          : this.mapWalletIcons[0].value,
        disabled: this.walletIsLoading,
      },
      walletTargetAmount: {
        name: "targetAmount",
        rules:
          `money:${wallet?.savingsTargetAmount?.scale}:.|between:1,7500|` +
          this.isRequired,
        placeholder: zero.toFixed(wallet?.savingsTargetAmount?.scale || 0),
        label: this.$t("addWallet.targetAmount"),
        preSelected: this.editWallet
          ? wallet?.savingsTargetAmount?.majorUnits
          : undefined,
        disabled: this.walletIsLoading,
        clearable: true,
      },
      walletTargetDate: {
        name: "targetDate",
        label: this.$t("addWallet.targetDate"),
        preSelected: this.editWallet ? wallet?.savingsTargetDate : undefined,
        rules: this.isRequired,
        disabled: this.walletIsLoading,
        clearable: true,
      },
    };
  }

  get walletNames() {
    if (this.editWallet) {
      const selectedNickName = this.selectedWallet.nickName;

      return this.getSelectedUserAccountWallets?.wallets?.map(wallet => wallet.nickName)
        .filter(function (nickName) { return nickName !== selectedNickName });
    }
    return this.getSelectedUserAccountWallets?.wallets?.map(wallet => wallet.nickName)
  }

  get mapWalletIcons(): [
    {
      value: string;
      icon: string;
    }
  ] {
    return (
      walletIcons.map((item) => {
        item.color = this.$vuetify.theme.themes.light.primary;
        return item;
      }) || []
    );
  }

  get mapPayload() {
    const scale =
      this.walletDetails?.data?.wallet?.savingsTargetAmount?.scale || 0;
    const currency = this.walletDetails?.data?.wallet?.savingsTargetAmount
      ?.currency;

    return {
      id: this.selectedWallet.walletId,
      nickName: this.formItems.walletName.value,
      savingsTargetDate: this.formItems.walletTargetDate.value,
      savingsTargetAmount: parseMonetaryAmount(
        this.formItems.walletTargetAmount.value,
        currency,
        scale
      ),
      colourRef: this.formItems.walletColor.value,
      iconRef: this.formItems.walletIcon.value,
    };
  }

  get accountDetails(): {
    accountHolders: any[];
    availableBalance:number;
    accountBalance: number;
    accountSortCode: string;
    accountAccountNumber: number;
    accountCardNoEnding: number;
    accountCardExpiry: string;
    pendingCredits: number;
    pendingDebits: number;
    savingsTargetDate: number;
    savingsTargetAmount: string;
  } {
    return {
      accountHolders: this.getAccountDetails?.accountHolders,
      availableBalance: this.getAccountDetails?.availableBalance,
      accountBalance: this.getAccountDetails?.accountBalance,
      accountSortCode: this.isEmpty(this.getAccountDetails?.accountSortCode) ? "Pending" : this.getAccountDetails?.accountSortCode,
      accountCardNoEnding: this.getAccountDetails?.accountCardNoEnding,
      accountCardExpiry: this.getAccountDetails?.accountCardExpiry,
      accountAccountNumber: this.isEmpty(this.getAccountDetails?.accountAccountNumber) ? "Pending" : this.getAccountDetails?.accountAccountNumber,
      pendingCredits: this.getAccountDetails?.pendingCredits,
      pendingDebits: this.getAccountDetails?.pendingDebits,
      savingsTargetDate: this.getAccountDetails?.savingsTargetDate,
      savingsTargetAmount: this.getAccountDetails?.savingsTargetAmount,
    };
  }

  get isRequired() {
    return (!this.formItems?.walletTargetAmount?.value &&
      this.formItems?.walletTargetDate?.value) ||
      (this.formItems?.walletTargetAmount?.value &&
        !this.formItems?.walletTargetDate?.value)
      ? "|required"
      : "";
  }
  
  async updateAccountBalance(value){   
    await this.getWalletDetails(this.selectedWallet?.walletId);      
    this.updateSelectedWalletBalance(this.walletDetails);
  }

  async handleSaveWallet(): Promise<void> {
    const scale =
      this.walletDetails?.data?.wallet?.savingsTargetAmount?.scale || 0;
    const currency = this.$t("currency.currency");
    const savingsTargetAmount = this.formItems?.walletTargetAmount?.value;
    const payload: any = {
      nickName: this.formItems?.walletName?.value,
      savingsTargetDate: this.formItems?.walletTargetDate?.value,
      savingsTargetAmount: savingsTargetAmount
        ? parseMonetaryAmount(
            this.formItems?.walletTargetAmount?.value,
            currency,
            scale
          )
        : null,
      colourRef: this.formItems?.walletColor?.value,
      iconRef: this.formItems?.walletIcon?.value || "",
    };    

    if (this.editWallet) {
      payload.id = this.selectedWallet.walletId;
      try {
        await this.updateWalletDetails(payload);
        this.confirmed();
      } catch (e) {
        console.log(e);
      }
    } else {
      payload.walletType = "savings";
      payload.currencyCode = currency;
      try {
        await this.createWallet(payload);
        this.confirmed();
      } catch (e) {
        console.log(e);
      }
    }
  }

  confirmed() {
    this.$emit("updated");
    this.$modal.hide("walletModal");
    this.$modal.show("walletModalConfirmed");
  }

  async handleShowWallet(type: string): Promise<void> {
    this.formItems = {};
    this.editWallet = false;
    this.clearNoop();
    this.$modal.show("walletModal");
    if (type == "edit") {
      this.editWallet = true;
      try {
        await this.getWalletDetails(this.selectedWallet?.walletId);
      } catch (e) {
        console.log(e);
      }
    } else {
      this.$nextTick(() => {
        (this.$refs.form as Vue & { reset: () => void }).reset();
      });
      try {
        await this.getEmptyWallet();
      } catch (e) {
        console.log(e);
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.account-card {
  display: flex;
  flex-direction: column;
  width: 100%;
  background-color: white;
  border-radius: 10px;
  letter-spacing: 1px;
  &-row {
    display: flex;
    flex-direction: row;
    padding: 10px 20px;
  }
  &-row.even {
    background: #f6f6f6 !important
  }
  &-row.even:first-of-type {
    border-radius: 10px;
  }
  &-row:not(:first-of-type) {
    border-top: 1px solid var(--v-border-base);
  }
  &--col1,
  &--col2 {
    display: flex;
  }
  &--col1 {
    flex: 1;
  }
  table {
    th {
      text-align: left;
    }

    &.account-card-holder {
      th {
        min-width: 200px;
      }
      td {
        font-weight: 600;
        column-span: all;
      }
    }
    &.account-card-balance {
      th,
      td {
        vertical-align: middle;
      }
      th {
        min-width: 200px;
      }
      td.top{
        vertical-align: top;
      }            
      th > span.account-balance, td > span.account-balance{
        opacity: 0.5;       
        font-weight: 600;       
      }
      th > span.text-body-2, td > span.text-body-2 {        
        padding-top: 20px 
      }
    }
    &.account-pending-details {
      display: flex;
      th {
        font-weight: 400;
        padding-right: 8px;
        width: 105px;
      }
      &--col1 {
        margin-right: 0px;
      }
      td {
        width: 75px;
      }
    }
    &.account-pending-details:not(:first-of-type) th {
      width: 85px;
    }
    &.account-pending-details:not(:first-of-type) td {
      width: 200px;
    }
    &.account-card-details {
      th {
        padding-left: 20px;
      }
      td {
        padding-left: 5px;
      }
    }
  }
  &-actions {
    padding-top: 3px;
    width: 100%;
  }
  &-actions > div.wrapper > div {
    min-width: 100px;
  }
}
</style>
