<template>
  <div>
    <OModalConfirmCancel
      id="reportCardStolen"
      @confirm="handleConfirm"
      @show="reset"
      :confirmText="$t('manageCard.stolen.stolenCardBtn')"
      :loading="noop.loading"
    >
      <template v-slot:header>{{
        $t("manageCard.stolen.stolenCardTitle")
      }}</template>
      <OText type="p"
        >{{
          $t("manageCard.stolen.stolenCardText", { card: cardNumberEnding })
        }}
      </OText>
      <OAlert type="warning" class="mt-4"
        ><OText type="div" size="sm" medium
          ><strong>{{ $t("manageCard.stolen.stolenCardWarn") }}</strong></OText
        ></OAlert
      >
      <OAlert type="error" class="mt-4" v-if="errorMessage"
        ><OText type="div" size="sm" medium
          ><strong>{{ errorMessage }}</strong></OText
        ></OAlert
      >
    </OModalConfirmCancel>
    <OModalConfirmCancel
      id="reportCardStolenConfirmed"
      @confirm="handleUpdated"
      :confirm-text="$t('manageCard.stolen.stolenCardConfirmBtn')"
      hide-cancel-btn
    >
      <template v-slot:header>{{
        $t("manageCard.stolen.stolenConfirmTitle")
      }}</template
      >{{ $t("manageCard.stolen.stolenCardConfirm") }}</OModalConfirmCancel
    >
  </div>
</template>
<script lang="ts">
import { mapGetters } from "vuex";
import { Component, Vue } from "vue-property-decorator";
import { Action, namespace } from "vuex-class";
import { BaseStateInterface } from "@/types/store.types";

const summaryModule = namespace("summaryModule");
const cardModule = namespace("cardModule");

@Component({
  components: {
    OModalConfirmCancel: () =>
      import("@/components/lib/Modal/OModalConfirmCancel.vue"),
    OModalConfirm: () => import("@/components/lib/Modal/OModalConfirm.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
    OText: () => import("@/components/lib/OText.vue"),
  },
  computed: {
    ...mapGetters("summaryModule", {
      getAccountDetails: "getAccountDetails",
    }),
  },
})
export default class ModalReportCardStolen extends Vue {
  getAccountDetails!: any;

  @Action("cardModule/UPDATE_CARD_STATUS")
  updateCardStatus!: (id) => string;

  @Action("cardModule/CLEAR_NOOP")
  clearNoop!: () => string;

  @cardModule.State
  private noop!: any;

  get errorMessage() {
    return this.noop.errorMessage;
  }

  get cardNumberEnding() {
    return this.getAccountDetails?.accountCardNoEnding;
  }

  handleUpdated() {
    this.$modal.hide("reportCardStolen");
    this.$emit("updated");
  }

  async handleConfirm() {
    try {
      await this.updateCardStatus({
        cardId: this.getAccountDetails?.accountDeviceId,
        cardStatus: "reportStolen",
      });
    } catch (e) {
      return;
    }
    this.$modal.hide("manageCard");
    this.$modal.hide("reportCardStolen");
    this.$modal.show("reportCardStolenConfirmed");
  }

  reset() {
    this.clearNoop();
  }
}
</script>
