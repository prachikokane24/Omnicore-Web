<template>
  <div>
    <OModalConfirmCancel
      id="reissueCard"
      @confirm="handleConfirm"
      @show="reset"
      :confirmText="$t('manageCard.reissue.confirmText')"
      :loading="noop.loading"
    >
      <template v-slot:header>{{ $t("manageCard.reissue.title") }}</template>
      <OText type="p" v-html="$t('manageCard.reissue.bodyText')" />
      <OText
        v-if="reissueFee && reissueFee.feeAmount !== 0"
        type="p"
        v-html="$t('manageCard.reissue.feeText')"
      />
      <OText v-if="reissueFee && reissueFee.feeAmount !== 0" size="xl" bold>{{
        reissueFee.feeAmount | currency
      }}</OText>

      <OAlert type="error" class="mt-4" v-if="errorMessage"
        ><OText type="div" size="sm" medium
          ><strong>{{ errorMessage }}</strong></OText
        ></OAlert
      >
    </OModalConfirmCancel>
    <OModalConfirm
      id="reissueCardConfirmed"
      :message="$t('manageCard.reissue.reissueConfirmTitle')"
    />
  </div>
</template>
<script lang="ts">
import { mapGetters } from "vuex";
import { Component, Vue } from "vue-property-decorator";
import { Action, namespace } from "vuex-class";
import { BaseStateInterface } from "@/types/store.types";
import { Fee } from "@/types/common.types";

const cardModule = namespace("cardModule");
const feesModule = namespace("feesModule");

@Component({
  components: {
    OModalConfirmCancel: () =>
      import("@/components/lib/Modal/OModalConfirmCancel.vue"),
    OModalConfirm: () => import("@/components/lib/Modal/OModalConfirm.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
    OText: () => import("@/components/lib/OText.vue"),
  },
  computed: {
    ...mapGetters("summaryModule", {
      getAccountDetails: "getAccountDetails",
    }),
  },
})
export default class ModalReissueCard extends Vue {
  getAccountDetails!: any;

  @Action("summaryModule/GET_ACCOUNT_SUMMARY")
  getAccountSummary!: () => string;

  reissueFee: Fee = {
    feeGroupID: 0,
    feeGroupName: '',
    feeAmount: 0
  };

  currency = this.$t("currency.currency");
  
  @Action("feesModule/GET_FEES")
  getFees!: () => BaseStateInterface;

  @Action("cardModule/REISSUE_CARD")
  reissueCard!: (id) => string;

  @Action("cardModule/CLEAR_NOOP")
  clearNoop!: () => string;

  @cardModule.State
  private noop!: any;

  get errorMessage() {
    return this.noop.errorMessage;
  }

  async mounted(): Promise<void> {
    try {
      const response = await this.getFees();
      this.reissueFee = response?.data?.fees.find(
        (f) => f.feeGroupName === "Cardreplacementfee"
      );
    } catch (e) {
      return;
    }
  }

  handleConfirmed() {
    this.$modal.hide("reportCardStolen");
    this.$emit("updated");
  }

  async handleConfirm() {
    try {
      await this.reissueCard({
        cardId: this.getAccountDetails?.accountDeviceId,
      });
    } catch (e) {
      return;
    }
    this.$modal.hide("reissueCard");
    this.$modal.show("reissueCardConfirmed");

    setTimeout(() => {
      this.getAccountSummary();
    }, 2600);
  }

  reset() {
    this.clearNoop();
  }
}
</script>
