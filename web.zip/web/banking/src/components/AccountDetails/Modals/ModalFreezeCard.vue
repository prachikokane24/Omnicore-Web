<template>
  <div>
    <OModalConfirmCancel
      id="freezeCard"
      @confirm="handleConfirm"
      @show="reset"
      :confirmText="$t('manageCard.freeze.freezeCardBtn')"
      :loading="noop.loading"
    >
      <template v-slot:header>{{
        $t("manageCard.freeze.freezeCardTitle")
      }}</template>
      <OText type="p"
        >{{
          $t("manageCard.freeze.freezeCardText", {
            card: this.cardNumberEnding,
          })
        }}
      </OText>
      <OAlert type="warning" class="mt-4"
        ><OText type="div" size="sm" medium
          ><strong>{{ $t("manageCard.freeze.freezeCardWarn") }}</strong></OText
        ></OAlert
      >
      <OAlert type="error" class="mt-4" v-if="errorMessage"
        ><OText type="div" size="sm" medium
          ><strong>{{ errorMessage }}</strong></OText
        ></OAlert
      >
    </OModalConfirmCancel>
    <OModalConfirm
      id="freezeCardConfirmed"
      :message="$t('manageCard.freeze.freezeCardConfirm')"
    />
  </div>
</template>
<script lang="ts">
import { mapGetters } from "vuex";
import { Component, Vue } from "vue-property-decorator";
import { Action, namespace } from "vuex-class";
import { BaseStateInterface } from "@/types/store.types";

const summaryModule = namespace("summaryModule");
const cardModule = namespace("cardModule");

@Component({
  components: {
    OModalConfirmCancel: () =>
      import("@/components/lib/Modal/OModalConfirmCancel.vue"),
    OModalConfirm: () => import("@/components/lib/Modal/OModalConfirm.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
    OText: () => import("@/components/lib/OText.vue"),
  },
  computed: {
    ...mapGetters("summaryModule", {
      getAccountDetails: "getAccountDetails",
    }),
  },
})
export default class ModalFreezeCard extends Vue {
  getAccountDetails!: any;
  @Action("cardModule/UPDATE_CARD_STATUS")
  updateCardStatus!: (id) => string;

  @Action("cardModule/CLEAR_NOOP")
  clearNoop!: () => string;

  @cardModule.State
  private noop!: any;

  get errorMessage() {
    return this.noop.errorMessage;
  }

  get cardNumberEnding() {
    return this.getAccountDetails?.accountCardNoEnding;
  }

  async handleConfirm() {
    try {
      await this.updateCardStatus({
        cardId: this.getAccountDetails?.accountDeviceId,
        cardStatus: "freeze",
      });
    } catch (e) {
      return;
    }
    this.$modal.hide("manageCard");
    this.$modal.hide("freezeCard");
    this.$modal.show("freezeCardConfirmed");
    setTimeout(() => {
      this.$emit("updated");
    }, 2500);
  }

  reset() {
    this.clearNoop();
  }
}
</script>
