<template>
  <div>
    <v-overlay :value="isLoading" :absolute="true" opacity="0.2">
      <ODot v-if="isLoading" class="loader" aria-role="presentation" />
    </v-overlay>
    <OModalConfirmCancel
      id="viewPin"
      @show="reset"
      :confirmText="$t('manageCard.freeze.unfreezeCardBtn')"
      :loading="noop.loading"
      cancel-text="Close"
      hide-confirm-btn
    >
      <template v-slot:header>{{ $t("manageCard.pin.title") }}</template>
      <OText type="p"
        >{{ $t("manageCard.pin.viewPin", { card: cardNumberEnding }) }}
      </OText>
      <div class="fade">
        <div class="fadecycle1">
          <div :class="{'reveal': revealed === 0}">
            <span>{{ cardPIN.charAt(0) }}</span>
          </div>
          <div :class="{'reveal': revealed === 1}">
            <span>{{ cardPIN.charAt(1) }}</span>
          </div>
          <div :class="{'reveal': revealed === 2}">
            <span>{{ cardPIN.charAt(2) }}</span>
          </div>
          <div :class="{'reveal': revealed === 3}">
            <span>{{ cardPIN.charAt(3) }}</span>
          </div>
        </div>
        <div class="fadecycle2">
          <div @click="showOtp(0)">
            <span><OIcon icon="lock" color="white" /></span>
          </div>
          <div @click="showOtp(1)">
            <span><OIcon icon="lock" color="white" /></span>
          </div>
          <div @click="showOtp(2)">
            <span><OIcon icon="lock" color="white" /></span>
          </div>
          <div @click="showOtp(3)">
            <span><OIcon icon="lock" color="white" /></span>
          </div>
        </div>
      </div>
      <OText type="p">{{ $t("manageCard.pin.hint") }} </OText>
    </OModalConfirmCancel>
    <!-- OTP Verification Modal -->
    <OModalConfirmCancel
      id="otpPin"
      @confirm="handleOtpPasscode"
      @show="componentOtpKey += 1"
      :loading="verifyOtp.loading"
      :confirmDisabled="formOtpInvalid"
      :confirmText="$t('manageCard.modalOtpConfirm')"
      dataIdConfirmBtn="viewPINOTPVerifyBtn"
      dataIdCancelBtn="viewPINOTPCancelBtn"
    >
      <Otp
        ref="otpPin"
        @verified="handleOtpVerfified"
        @invalid="handleOtpFormInvalid"
        :hideActions="true"
        :key="componentOtpKey"
      />
    </OModalConfirmCancel>
  </div>
</template>
<script lang="ts">
import { mapGetters } from "vuex";
import { Component, Vue } from "vue-property-decorator";
import { Action, namespace } from "vuex-class";
import { BaseStateInterface } from "@/types/store.types";
import ODot from "../../lib/Loader/ODot.vue";

const summaryModule = namespace("summaryModule");
const cardModule = namespace("cardModule");
const otpModule = namespace("otpModule");

@Component({
  components: {
    OModalConfirmCancel: () =>
      import("@/components/lib/Modal/OModalConfirmCancel.vue"),
    OModalConfirm: () => import("@/components/lib/Modal/OModalConfirm.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OButton: () => import("@/components/lib/OButton.vue"),
    Otp: () => import("@/components/Form/Otp/Otp.vue"),
    OIcon: () => import("@/components/lib/OIcon.vue"),
    ODot
  },
  computed: {
    ...mapGetters("summaryModule", {
      getAccountDetails: "getAccountDetails",
    }),
  },
})
export default class ModalFreezeCard extends Vue {
  componentOtpKey = 0;
  formOtpInvalid = false;
  getAccountDetails!: any;
  cardPIN = "";
  otpConfirmed = false;
  revealIndex?: null|number = null;
  revealed?: null|number = null;
  cachePin = "";
  isLoading = false;

  @Action("cardModule/GET_CARD_PIN")
  getCardPin!: ({ cardId: string }) => BaseStateInterface;

  @Action("cardModule/CLEAR_NOOP")
  clearNoop!: () => string;

  @otpModule.State
  public verifyOtp!: BaseStateInterface;

  @cardModule.State
  private noop!: any;

  get errorMessage() {
    return this.noop.errorMessage;
  }

  get cardNumberEnding() {
    return this.getAccountDetails?.accountCardNoEnding;
  }

  showOtp(idx: number): void {
    this.revealIndex = idx;
    if (!this.otpConfirmed) {
      this.$modal.show("otpPin");
    } else {
      this.handleOtpVerfified();
    }
    this.$nextTick(() => {
      (this.$refs.otpPin as Vue & { clearOtp: () => void }).clearOtp();
    });
  }

  handleOtpFormInvalid(invalid: boolean): void {
    this.formOtpInvalid = invalid;
  }

  handleOtpPasscode(): void {
    this.$nextTick(() => {
      (this.$refs.otpPin as Vue & { handleSubmit: () => void }).handleSubmit();
    });
  }

  async handleOtpVerfified(): Promise<void> {
    this.$modal.show("viewPin");
    this.$modal.hide("otpPin");
    try {
      if (this.cachePin !== "") {
        this.cardPIN = this.cachePin;
      }
      if (this.cardPIN === "") {
        this.isLoading = true;
        const response = await this.getCardPin({
          cardId: this.getAccountDetails?.accountDeviceId,
        });
        this.cardPIN = response?.data?.pin;
        this.cachePin = this.cardPIN;
        this.otpConfirmed = true;
        this.clearNoop();
        this.isLoading = false;
      }
      this.revealed = this.revealIndex;
      setTimeout(() => {
        this.cardPIN = "";
        this.revealIndex = null;
        this.revealed = null;
      }, 3000);
    } catch (e) {
      return;
    }
  }

  reset() {
    this.cardPIN = "";
    this.clearNoop();
  }
}
</script>
<style lang="scss" scoped>
.fade {
  position: relative;
  display: block;
  height: 60px;
}
.fadecycle1,
.fadecycle2 {
  display: flex;
  flex-direction: row;
  position: relative;
  width: 100%;
}
.fadecycle1 {
  position: absolute;
  left: 0;
  top: 0;
  z-index: 1;
}
.fadecycle {
  position: relative;
  opacity: 0;
  width: 50px;
  border-radius: 10px;
  line-height: 50px;
  text-align: center;
  color: white;
  font-weight: bold;
  font-size: 25px;
  background: none;
  cursor: pointer;
}
.fadecycle1 > div {
  position: relative;
  opacity: 0;
  width: 50px;
  border-radius: 10px;
  line-height: 50px;
  text-align: center;
  color: white;
  font-weight: bold;
  font-size: 25px;
  background: none;
  background: var(--v-success-base);
  margin-right: 5px;
  cursor: pointer;
}
.fadecycle2 {
  position: absolute;
  left: 0;
  top: 0;
  z-index: 0;
  cursor: pointer;
}
.fadecycle2 > div {
  width: 50px;
  border-radius: 10px;
  line-height: 50px;
  text-align: center;
  color: white;
  font-weight: bold;
  font-size: 25px;
  background: var(--v-primary-base);
  margin-right: 5px;
  cursor: pointer;
}

// Animation settings
$totalTime: 2s;
$items: 4;
$animationSpeed: 2;

// Calculate animation time in seconds (how long the fade lasts)
$animationTime: 0s + $totalTime / ($items * $animationSpeed * 2);
// Calculate show time in seconds (how long the element is displayed)
$showTime: (3s + $totalTime - ($animationTime * $items)) / $items;

// Set animation for each element
.fadecycle1 > div.reveal {
  animation: fadeinout 2s linear 0s;
}

// Calculate percentages of the display time for keyframes
$animationPercentage: 0% + 100 * (($animationTime / $totalTime));
$showPercentage: 0% + 100 * ($showTime / $totalTime);

@keyframes fadeinout {
  0% {
    opacity: 0;
  }
  #{$animationPercentage},
  #{$animationPercentage + $showPercentage} {
    opacity: 1;
    background: var(--v-secondary-base);
  }
  #{$showPercentage + $animationPercentage * 2},
  100% {
    opacity: 0;
  }
}
</style>