<template>
  <div>
    <OModalConfirmCancel
      id="manageCard"
      :hideConfirmBtn="true"
      :cancelText="$t('manageCard.cancelBtnText')"
      dataIdCancelBtn="manageCardCancelBtn"
    >
      <template v-slot:header>{{ $t("manageCard.modalTitle") }}</template>
      <OAlert type="info" class="mt-4" v-if="isLost"
        ><OText type="div" size="sm" medium
          ><strong>{{ $t("manageCard.cardLost") }}</strong></OText
        ></OAlert
      >
      <OAlert type="info" class="mt-4" v-else-if="isStolen"
        ><OText type="div" size="sm" medium
          ><strong>{{ $t("manageCard.cardStolen") }}</strong></OText
        ></OAlert
      >
      <OAlert type="info" class="mt-4" v-else-if="isUnknown"
        ><OText type="div" size="sm" medium
          ><strong>{{ $t("manageCard.cardInactive") }}</strong></OText
        ></OAlert
      >
      <OActionList
        v-bind="actionListConfig"
        @itemClick="handleItemClick"
        v-else
      />
    </OModalConfirmCancel>
    <ModalUnFreezeCard @updated="handleUpdated" v-if="isFrozen" />
    <ModalFreezeCard @updated="handleUpdated" v-else />
    <ModalReportCardStolen @updated="handleUpdated" />
    <ModalReportCardLost @updated="handleUpdated" />
    <ModalPIN @updated="handleUpdated" />
  </div>
</template>
<script lang="ts">
import { mapGetters } from "vuex";
import { Component, Vue } from "vue-property-decorator";
import { Action, namespace } from "vuex-class";
import { BaseStateInterface } from "@/types/store.types";

// interface AnyObject {
//   [key: string]: any;
// }

interface ActionList {
  key: string;
  title: string;
  subtitle: string;
  icon: string;
  action: () => void;
}

const summaryModule = namespace("summaryModule");

@Component({
  components: {
    OModalConfirmCancel: () =>
      import("@/components/lib/Modal/OModalConfirmCancel.vue"),
    OModalConfirm: () => import("@/components/lib/Modal/OModalConfirm.vue"),
    ModalFreezeCard: () =>
      import("@/components/AccountDetails/Modals/ModalFreezeCard.vue"),
    ModalUnFreezeCard: () =>
      import("@/components/AccountDetails/Modals/ModalUnFreezeCard.vue"),
    ModalReportCardStolen: () =>
      import("@/components/AccountDetails/Modals/ModalReportCardStolen.vue"),
    ModalReportCardLost: () =>
      import("@/components/AccountDetails/Modals/ModalReportCardLost.vue"),
    ModalPIN: () => import("@/components/AccountDetails/Modals/ModalPIN.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OForm: () => import("@/components/lib/Form/OForm.vue"),
    OFormInput: () => import("@/components/lib/Form/OFormInput.vue"),
    OFormSelect: () => import("@/components/lib/Form/OFormSelect.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
    Otp: () => import("@/components/Form/Otp/Otp.vue"),
    OActionList: () => import("@/components/lib/OActionList.vue"),
  },
  computed: {
    ...mapGetters("summaryModule", {
      getAccountDetails: "getAccountDetails",
    }),
  },
})
export default class ModalManageCard extends Vue {
  getAccountDetails!: any;

  @Action("summaryModule/GET_ACCOUNT_SUMMARY")
  getAccountSummary!: () => string;

  get cardStatus(): string {
    return this.getAccountDetails?.accountStatus;
  }

  get verified(): boolean {
    return ["unknown", "active", "locked", "lost", "stolen"].includes(
      this.cardStatus
    );
  }

  get isUnknown(): boolean {
    const accepted = ["unknown", "active", "locked", "lost", "stolen"].includes(
      this.cardStatus
    );
    return this.cardStatus === "unknown" || !accepted;
  }

  get isFrozen(): boolean {
    return this.cardStatus == "locked";
  }

  get isLost(): boolean {
    return this.cardStatus === "lost";
  }

  get isStolen(): boolean {
    return this.cardStatus === "stolen";
  }

  get isActive(): boolean {
    return this.cardStatus === "active";
  }

  get actionListConfig(): {
    items: ActionList[];
  } {
    return {
      items: [
        {
          key: "freezeCard",
          // eslint-disable-next-line @typescript-eslint/ban-ts-comment
          // @ts-ignore
          title: this.isFrozen
            ? this.$t("manageCard.freeze.unfreezeTitle")
            : this.$t("manageCard.freeze.freezeTitle"),
          // eslint-disable-next-line @typescript-eslint/ban-ts-comment
          // @ts-ignore
          subtitle: this.isFrozen
            ? this.$t("manageCard.freeze.unfreezeSubtext")
            : this.$t("manageCard.freeze.freezeSubtext"),
          icon: this.isFrozen ? "snowflakeOff" : "snowflake",
          action: () =>
            this.isFrozen
              ? this.handleToggleUnFreezeCard()
              : this.handleToggleFreezeCard(),
        },
        {
          key: "reportStolen",
          title: "Report Stolen",
          subtitle: "Report your card stolen",
          icon: "alert",
          action: () => this.handleReportCardStolen(),
        },
        {
          key: "reportLost",
          title: "Report Lost",
          subtitle: "Report your card lost",
          icon: "alert",
          action: () => this.handleReportCardLost(),
        },
        // {
        //   key: "orderReplacement",
        //   title: "Order Replacement/Additional Card",
        //   subtitle: "Order an additional or replacement card",
        //   icon: "creditCardSync",
        //   action: () => this.handleOrderReplacement(),
        // },
        // {
        //   key: "cardNumber",
        //   title: "Card Number",
        //   subtitle: "View your full card number for this card",
        //   icon: "numeric",
        //   action: () => this.handleOrderReplacement(),
        // },
        {
          key: "pinNumber",
          title: "View Card PIN",
          subtitle: "View your full PIN for this card",
          icon: "eye",
          action: () => this.handleViewPin(),
        },
      ],
    };
  }

  handleUpdated(): void {
    this.$modal.hide("manageCard");
    this.getAccountSummary();
  }

  handleToggleFreezeCard(): void {
    this.$modal.show("freezeCard");
  }

  handleToggleUnFreezeCard(): void {
    this.$modal.show("unfreezeCard");
  }

  handleReportCardStolen(): void {
    this.$modal.show("reportCardStolen");
  }

  handleReportCardLost(): void {
    this.$modal.show("reportCardLost");
  }

  handleViewPin(): void {
    this.$modal.show("viewPin");
  }

  handleConfirm(): void {
    this.$modal.hide("manageCard");
  }

  handleItemClick(action): void {
    action();
  }
}
</script>
