<template>
  <div>
    <OModalConfirmCancel
      id="reportCardLost"
      @confirm="handleConfirm"
      @show="reset"
      :confirmText="$t('manageCard.lost.lostCardBtn')"
      :loading="noop.loading"
    >
      <template v-slot:header>{{
        $t("manageCard.lost.lostCardTitle")
      }}</template>
      <OText type="p"
        >{{ $t("manageCard.lost.lostCardText", { card: cardNumberEnding }) }}
      </OText>
      <OAlert type="warning" class="mt-4"
        ><OText type="div" size="sm" medium
          ><strong>{{ $t("manageCard.lost.lostCardWarn") }}</strong></OText
        ></OAlert
      >
      <OAlert type="error" class="mt-4" v-if="errorMessage"
        ><OText type="div" size="sm" medium
          ><strong>{{ errorMessage }}</strong></OText
        ></OAlert
      >
    </OModalConfirmCancel>
    <OModalConfirmCancel
      id="reportCardLostConfirmed"
      @confirm="handleUpdated"
      :confirm-text="$t('manageCard.lost.lostCardConfirmBtn')"
      hide-cancel-btn
    >
      <template v-slot:header>{{
        $t("manageCard.lost.lostConfirmTitle")
      }}</template
      >{{ $t("manageCard.lost.lostCardConfirm") }}</OModalConfirmCancel
    >
  </div>
</template>
<script lang="ts">
import { mapGetters } from "vuex";
import { Component, Vue } from "vue-property-decorator";
import { Action, namespace } from "vuex-class";
import { BaseStateInterface } from "@/types/store.types";

const summaryModule = namespace("summaryModule");
const cardModule = namespace("cardModule");

@Component({
  components: {
    OModalConfirmCancel: () =>
      import("@/components/lib/Modal/OModalConfirmCancel.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
    OText: () => import("@/components/lib/OText.vue"),
  },
  computed: {
    ...mapGetters("summaryModule", {
      getAccountDetails: "getAccountDetails",
    }),
  },
})
export default class ModalReportCardLost extends Vue {
  getAccountDetails!: any;
  @Action("cardModule/UPDATE_CARD_STATUS")
  updateCardStatus!: (id) => string;

  @Action("cardModule/CLEAR_NOOP")
  clearNoop!: () => string;

  @cardModule.State
  private noop!: any;

  get errorMessage() {
    return this.noop.errorMessage;
  }

  get cardNumberEnding() {
    return this.getAccountDetails?.accountCardNoEnding;
  }

  handleUpdated() {
    this.$modal.hide("reportCardLostConfirmed");
    this.$emit("updated");
  }

  async handleConfirm() {
    try {
      await this.updateCardStatus({
        cardId: this.getAccountDetails?.accountDeviceId,
        cardStatus: "reportLost",
      });
    } catch (e) {
      console.log(e);
      return;
    }
    this.$modal.hide("manageCard");
    this.$modal.hide("reportCardLost");
    this.$modal.show("reportCardLostConfirmed");
  }

  reset() {
    this.clearNoop();
  }
}
</script>
