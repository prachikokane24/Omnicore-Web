<template>
  <div>
    <transition name="fade">
      <v-overlay v-if="isLoadingData" v-bind="overlayConfig" class="overlay">
        <v-progress-circular
          indeterminate
          size="64"
          color="primary"
        ></v-progress-circular>
      </v-overlay>
    </transition>
    <slot :getAccountSummary="getAccountSummary" v-if="!isLoadingData" />
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import { BaseStateInterface } from "@/types/store.types";
import { Action, namespace } from "vuex-class";

const summaryModule = namespace("summaryModule");

@Component({})
export default class AccountSummaryData extends Vue {
  isLoading = true;

  @summaryModule.State
  private accountSummary!: BaseStateInterface;

  @Action("summaryModule/GET_ACCOUNT_SUMMARY")
  getAccountSummary!: () => string;

  @Action("summaryModule/UPDATE_SELECTED_ACCOUNT_ID")
  updateSelectedAccountId!: () => number;

  created() {
    this.$EventBus.$on("changeAccount", this.updateSelectedAccountId);
  }

  get overlayConfig(): {
    value: boolean;
    zIndex: number;
    color: string;
    opacity: number;
  } {
    return {
      value: this.isLoadingData,
      zIndex: 10000,
      color: "primary",
      opacity: 0,
    };
  }

  get isLoadingData(): boolean {
    return this.accountSummary?.loading || this.isLoading;
  }

  async mounted(): Promise<void> {
    try {
      await this.getAccountSummary();
      setTimeout(() => {
        this.isLoading = false;
      }, 500);
    } catch (e) {
      console.log(e);
    }
  }
}
</script>

<style lang="scss" scoped>
.overlay {
  display: flex;
  flex-direction: column;
  text-align: center;
  background-color: white;
  color: var(--v-primary-base);
  &__text {
    margin-top: 20px;
    color: black;
  }
}
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s ease;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}
</style>
