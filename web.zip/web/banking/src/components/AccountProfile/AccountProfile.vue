<template>
  <OProfile v-bind="profileConfig">
    <OText
      :size="$vuetify.breakpoint.smAndUp ? 'md' : 'xs'"
      :style="{ lineHeight: $vuetify.breakpoint.mdAndUp ? 'auto' : '16px' }"
      class="mb-0 text-left"
      ><strong>{{ accountDetails.fullname }}</strong>
      <br class="d-flex" />
      <span class="mt-1"
        >{{ $t("accountInfo.loginId") }}: {{ accountNumber }}</span
      >
    </OText>
    <!-- <OText
      type="small"
      size="xs"
      align="right"
      :style="{ lineHeight: $vuetify.breakpoint.smAndUp ? 'auto' : '16px' }"
      >{{ $t("accountInfo.lastLogin") }}:
      {{ accountDetails.lastLogin | date("longtime") }}</OText
    > -->
  </OProfile>
</template>

<script lang="ts">
import { mapGetters } from "vuex";
import { Component, Prop, Vue } from "vue-property-decorator";
import { Action, namespace } from "vuex-class";
import { BaseStateInterface } from "@/types/store.types";
const userModule = namespace("userModule");

@Component({
  components: {
    OProfile: () => import("@/components/lib/OProfile.vue"),
    OAlign: () => import("@/components/lib/OAlign.vue"),
    OText: () => import("@/components/lib/OText.vue"),
  },
  computed: {
    ...mapGetters("authenticationModule", {
      getUserCredentials: "getUserCredentials"
    }),
  },
})
export default class AccountProfile extends Vue {
  @Prop() textColor!: string;
  @Prop() avatarColor!: string;
  @Prop() avatarTextColor!: string;
  @Prop() avatarImage!: string;
  @Prop() dark!: boolean;
  
  @userModule.State
  private userDetails!: BaseStateInterface;

  getUserCredentials!: any;

  get accountNumber(): string {
    return this.getUserCredentials?.loginId;
  }

  get profileConfig(): {
    avatarImage: string;
    avatarColor: string;
    avatarTextColor: string;
    textColor: string;
    dark: boolean;
  } {
    return {
      avatarImage: this.userDetails?.data?.user?.userDetails?.avatarImage,
      avatarColor: this.avatarColor,
      avatarTextColor: this.avatarTextColor,
      textColor: this.textColor,
      dark: this.dark,
    };
  }

  get personId() {
    if (this.userDetails?.data)
      return JSON.parse(atob(this.userDetails?.data?.personId));
    return {};
  }

  get accountDetails(): {
    login: { id: string; is: string; rt: string };
    fullname: string;
    lastLogin: string;    
  } {
    return {
      login: this.personId,
      fullname:
        this.userDetails?.data?.firstName +
        " " +
        this.userDetails?.data?.lastName,
      lastLogin: this.userDetails?.data?.lastLogin,     
    };
  }
}
</script>
