<template>
<div>
    <ODataTablePaginatorAsync
      :page-count="pageCount"
      :page-index="pageParams.pageIndex"
      :disabled="contactCentreInbox.loading"
      @change="handlePageChange"
    >
      <ODataTable
        v-bind="tableConfig"      
        :loading="contactCentreInbox.loading"
        class="contact-centre"
      >
      <template #filter>
          <OFilter @change="handleFilterChange" :filterConfig="filterConfig" />
        </template>
        <template v-slot:date="{ cell }">
          {{ cell | date }}
        </template>
        <template v-slot:subject="{ cell }">
          <OText medium>
            {{ cell }}
          </OText>
        </template>
        <template v-slot:status="{ cell }">
          <OText medium>
            {{ cell }}
          </OText>
        </template>
        <template v-slot:action="{ row }">
          <OButton @click="handleViewMessage(row)" outlined x-small>
            {{ $t("contactCentre.viewMessageBtn") }}
          </OButton>
        </template>
      </ODataTable>
    </ODataTablePaginatorAsync>   
</div>
</template>


<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import { BaseStateInterface } from "@/types/store.types";
import { Action, namespace } from "vuex-class";
const contactCentreModule = namespace("contactCentreModule");

@Component({
  components: {
    ODataTable: () => import("@/components/lib/DataTable/ODataTable.vue"),
    ODataTablePaginatorAsync: () => import("@/components/lib/DataTable/ODataTablePaginatorAsync.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OButton: () => import("@/components/lib/OButton.vue"),
    OFilter: () => import("@/components/lib/OFilter.vue"),    
  },
})

export default class ContactCentre extends Vue {
  filterItems: any = {};
  pageParams = {
    pageIndex: 0,
    pageLimit: 5,
    contact: "all"    
  };
  headers = [
    { text: "Date", key: "date", },
    { text: "Subject", key: "subject" },
    { text: "Status", key: "status" },
    { text: "Actions", key: "action" },
  ];

  @contactCentreModule.State
  public contactCentreInbox!: BaseStateInterface;

  // mapActions
  @Action("contactCentreModule/GET_USER_CONTACT_CENTRE_INBOX_MESSAGES")
  getUserContactCentreInboxMessages!: (payload) => string;

  get filterConfig() {
    return [
      {
        name: "contact",
        type: "select",
        label: "From",
        preSelected: "all",
        items: [
          {
            id: 1,
            label: "All",
            value: "all",
          },
          {
            id: 2,
            label: "Customer Service",
            value: "customer-service",
          },
          {
            id: 3,
            label: "Me",
            value: "user",
          },
        ],
      },
    ];
  }

  get tableConfig() {
    return {
      heading: this.$t("contactCentre.title"),
      headers: this.headers,
      items: this.contactCentreInbox?.data,
    };
  }

  get pageCount(): number {
    const itemCount: number =
    this.contactCentreInbox?.data?.totalCount || 0;
    const { pageLimit } = this.pageParams;
    return Math.ceil(itemCount / pageLimit);
  }

  get mappedQueryParams(): { offset: number; limit: number; contact: string } {
    return {
      offset: this.pageParams.pageIndex * this.pageParams.pageLimit,
      limit: 5,
      contact: "all",
    };
  }

  get loading() { return this.contactCentreInbox?.loading }

  mounted() {
    this.getUserContactCentreInboxMessages(this.mappedQueryParams);
  }

  handleFilterChange(val: any): void {
    this.pageParams.contact = val?.contact?.value;
    this.getUserContactCentreInboxMessages(this.mappedQueryParams);
  }

  handlePageChange(val: number): void {
    this.pageParams.pageIndex = val;
    this.getUserContactCentreInboxMessages(this.mappedQueryParams);
  }

  handleViewMessage({ id: number }): void {
    //switch between components pass message id
  }
};
</script>

<style lang="scss" scoped>
  .contact-centre {
    background-color: white;
  }
</style>
