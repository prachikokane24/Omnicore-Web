<template>
  <div ref="anchorTop">
    <ODataTablePaginatorAsync
      :page-count="pageCount"
      :page-number="pageParams.pageNumber"
      :disabled="userTransactions.loading"
      @change="handlePageChange"
    >
      <ODataTable
        v-bind="tableConfig"
        @cellClick="handleCellClick"
        @rowClick="handleRowClick"
        :loading="userTransactions.loading"
        class="transactions"
      >
        <template #filter>
          <div style="display: flex; height: 38px">
            <div style="max-width: 135px; margin-right: 5px">
              <OFormDatePicker
                data-id=""
                v-bind="formConfig.fromDate"
                v-model="formItems.fromDate"
                @input="handleDateChange"
                v-if="filterType == 'custom'"
                hide-details
                dense
                small
              />
            </div>
            <div style="max-width: 130px">
              <OFormDatePicker
                data-id=""
                v-bind="formConfig.toDate"
                v-model="formItems.toDate"
                @input="handleDateChange"
                v-if="filterType == 'custom'"
                hide-details
                dense
                small
              />
            </div>
            <div style="max-width: 170px">
              <OFilter
                @change="handleFilterChange"
                :filterConfig="filterConfig"
              />
            </div>
          </div>
        </template>
        <template
          v-slot:summary="{ headers }"
          v-if="pendingTransactions.length > 0"
        >
          <TransactionsSummary
            :headers="headers"
            :items="pendingTransactions"
            @handleShowDetails="handleShowDetails"
            :loading="userTransactions.loading"
          />
        </template>
        <template v-slot:transactionDate="{ cell }">
          {{ cell | date }}</template
        >
        <template v-slot:description="{ row }" :id="row.id">
          <OText>{{ row.description }}</OText>
          <div
            :id="'fxRateDetailId_' + row.id"
            data-show="false"
            v-if="row.originAmount && row.fxRate"
          >
            <span v-if="
              row.originAmount &&
              row.fxRate &&
              row.value.currency != row.originAmount.currency
            ">
              {{ row.originAmount.currency }}
              {{ row.originAmount.minorUnits | currencyFloat }} / FX Rate =
              {{ row.fxRate }}
            </span>
            <span>
              {{ row.detail }}
              {{ row.transactionType }}
            </span>
          </div>
        </template>
        <template v-slot:value="{ row }">
          <OText
            medium
            v-credit-debit="{
              amount: row.value.minorUnits,
              creditColor: `${$vuetify.theme.themes.light.success}`,
            }"
          >
            <span v-if="row.value.minorUnits > 0">+</span
            >{{ row.value.minorUnits | currency }}
          </OText> 
        </template>
        <!--
        N.B. This is a temporary fix for a running balance issue... 
        <template v-slot:balance="{ cell }">
          {{ cell.minorUnits | currency }}
        </template> 
        -->
        <template v-slot:action="{ row }">
          <OIcon
            icon="eye"
            type="button"
            :opacity="0.5"
            @click.native="() => handleShowDetails(row.id)"
          />
        </template>
      </ODataTable>
    </ODataTablePaginatorAsync>
    <div class="download-transactions">
      <OIcon
        icon="fileExcel"
        color="primary"
        type="button"
        @click.native="() => handleDownloadCsvClick()"
        v-if="downloadCsvLinkEnabled"
      />
    </div>
  </div>
</template>

<script lang="ts">
import moment from "moment";
import { Component, Vue, Watch, Prop } from "vue-property-decorator";
import { BaseStateInterface } from "@/types/store.types";
import { Action, namespace } from "vuex-class";
import { mapGetters } from "vuex";
import Papa from "papaparse";

const transactionModule = namespace("transactionModule");
const summaryModule = namespace("summaryModule");

interface InputConfig {
  name: string;
  rules?: string;
  label?: string | unknown;
  parentLabel?: string | unknown;
  required?: boolean;
  items?: any;
  preSelected?: unknown;
  type?: string;
  clearable?: boolean;
  hint?: string | unknown;
  placeholder?: string | unknown;
  appendIcon?: string;
  inputValue?: string;
  disabled?: boolean;
  counter?: number;
  error?: boolean;
  loading?: boolean;
  value?: string;
  prefix?: string;
  hideDetails?: boolean | string;
  dense?: boolean;
  small?: boolean;
  outlined?: boolean;
  preview?: boolean;
  previewValuePrefix?: unknown | string;
  persistentHint?: boolean;
  minDate?: string;
  maxDate?: string;
  dateFormat?: string;
}

interface FormConfig {
  fromDate: InputConfig;
  toDate: InputConfig;
}
interface AnyObject {
  [key: string]: any;
}

interface CsvData {
  Date: string;
  Description: string;
  Detail: string;
  Value: string;
  Balance: string;
}

@Component({
  components: {
    OFormDatePicker: () => import("@/components/lib/Form/OFormDatePicker.vue"),
    ODataTable: () => import("@/components/lib/DataTable/ODataTable.vue"),
    ODataTablePaginatorAsync: () =>
      import("@/components/lib/DataTable/ODataTablePaginatorAsync.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OFilter: () => import("@/components/lib/OFilter.vue"),
    OIcon: () => import("@/components/lib/OIcon.vue"),
    OFormSelect: () => import("@/components/lib/Form/OFormSelect.vue"),
    TransactionsSummary: () =>
      import(
        "@/components/TabSections/Transactions/Summary/TransactionsSummary.vue"
      ),
  },
  computed: {
    ...mapGetters("transactionModule", {
      getTransactionsCsvData: "getTransactionsCsvData",
    }),
  },
})
export default class Transactions extends Vue {
  @Prop() private tabClicked!: boolean;
  @Prop() private cmp!: string;

  filterType = null;
  formItems: AnyObject = {};

  pageParams = {
    pageNumber: 1,
    pageSize: 15,
  };

  filterParams = {
    fromDate: "2000-01-01",
    toDate: "",
  };

  headers = [
    {
      text: "Date",
      align: "start",
      sortable: false,
      key: "transactionDate",
      default: "-",
    },
    { text: "Description", key: "description" },
    { text: "Value", key: "value" },
    // { text: "Balance", key: "balance" },
    { text: "View", key: "action", hideMobile: false },
  ];

  @transactionModule.State
  public userTransactions!: BaseStateInterface;

  @transactionModule.State
  public exportUserTransactions!: BaseStateInterface;  

  @summaryModule.State
  public selectedWallet!: BaseStateInterface;

  @Action("transactionModule/GET_USER_TRANSACTIONS")
  getUserTransactions!: (payload) => string;

  @Action("transactionModule/GET_EXPORT_USER_TRANSACTIONS")
  getExportUserTransactions!: (payload) => string;

  getTransactionsCsvData!: any;


  get formConfig(): FormConfig {
    return {
      fromDate: {
        name: "fromDate",
        label: "Start Date",
        dense: true,
        hideDetails: true,
        small: true,
        outlined: true,
        minDate: moment().subtract(89, "days").format("YYYY-MM-DD"),
        maxDate:
          this?.formItems?.toDate?.value || moment().format("YYYY-MM-DD"),
        dateFormat: "DD/MM/YYYY",
      },
      toDate: {
        name: "toDate",
        label: "End Date",
        dense: true,
        hideDetails: true,
        small: true,
        outlined: true,
        minDate:
          this?.formItems?.fromDate?.value ||
          moment().subtract(89, "days").format("YYYY-MM-DD"),
        maxDate: moment().format("YYYY-MM-DD"),
        dateFormat: "DD/MM/YYYY",
      },
    };
  }

  get filterConfig() {
    return [
      {
        name: "fromDate",
        type: "select",
        label: "Period",
        preSelected: "2000-01-01",
        maxWidth: "170px",
        items: [
          {
            id: 1,
            label: "All time",
            value: "2000-01-01",
          },
          {
            id: 2,
            label: "Last Month",
            value: moment().subtract(1, "months").format("YYYY-MM-DD"),
          },
          {
            id: 3,
            label: "Last 2 Months",
            value: moment().subtract(2, "months").format("YYYY-MM-DD"),
          },
          {
            id: 4,
            label: "Last 3 Months",
            value: moment().subtract(3, "months").format("YYYY-MM-DD"),
          },
          {
            id: 5,
            label: "Custom",
            value: "custom",
          },
        ],
      },
    ];
  }

  get pendingTransactions() {
    localStorage.setItem("accountBalance",  JSON.stringify(this.userTransactions?.data?.transactions[0]?.balance));
    return this.userTransactions?.data?.pendingTransactions || [];
  }

  get tableConfig(): {
    heading: string | any;
    headers: any[];
    items: any[];
  } {
    const transactions = this.userTransactions?.data?.transactions.map((e, i) => { e.id = i; return e; });
    return {
      heading: this.$t("transactions.title"),
      headers: this.headers,
      items: transactions,
    };
  }

  get pageSize(): number {
    return (
      this.userTransactions?.data?.paginationData?.pageSize ||
      this.pageParams.pageSize
    );
  }

  get pageCount(): number {
    return this.userTransactions?.data?.paginationData?.pageCount || 0;
  }

  get mapPageParamsPayload(): any {
    return {
      pageNumber: this.pageParams.pageNumber,
      pageSize: this.pageSize,
      fromDate: this.filterParams.fromDate,
      toDate: this.filterParams.toDate,
    };
  }

  get mapExportParamsPayload(): any {
    return {
        pageNumber: 1,
        pageSize: 10000,
        fromDate: this.filterParams.fromDate,
        toDate: this.filterParams.toDate,
      };
  }

  get downloadCsvLinkEnabled(): boolean {    
    return this.userTransactions?.data?.transactions.length > 0 || false;
  }

  get mappedTransactionsCsvData(): CsvData {
    const currencySymbol = this.$t("currency.currencySymbol");

    return this.getTransactionsCsvData.map((item) => {
      return {
        Date: item.Date,
        Description: item.Description,
        Detail: item.Detail,
        Value: currencySymbol + item.Value,
        Balance: currencySymbol + item.Balance,
      };
    });
  }

  created(): void {
    console.log("Transactions Mounted");
    if (this.tabClicked) {
      this.getUserTransactions(this.mapPageParamsPayload);
    }
     
    this.$EventBus.$on("updateAccountBalance", this.refreshUserTransaction);
  }

  destroyed(): void {
    this.$EventBus.$off('updateAccountBalance');
  }

    async refreshUserTransaction(value) {
      if(value === "CarouselChanged") {
        this.pageParams.pageNumber = 1;
      }   
     this.getUserTransactions(this.mapPageParamsPayload);
  }

  handlePageChange(val: number): void {
    var element: any = this.$refs["anchorTop"];
    var top = element.offsetTop;
    window.scrollTo(0, top);
    this.pageParams.pageNumber = val;    
    this.getUserTransactions(this.mapPageParamsPayload);
  }

  handleDateChange(val: any): void {
    this.pageParams.pageNumber = 1;
    this.filterParams.fromDate =
      this.formItems?.fromDate?.value || this.filterParams.fromDate;
    this.filterParams.toDate =
      this.formItems?.toDate?.value || this.filterParams.toDate;
    this.getUserTransactions(this.mapPageParamsPayload);
  }

  handleFilterChange(val: any): void {
    const value = val?.fromDate?.value;
    this.filterType = value;
    if (value !== "custom") {
      this.pageParams.pageNumber = 1;
      this.filterParams.fromDate = val?.fromDate?.value;
      this.filterParams.toDate = "";      
      this.getUserTransactions(this.mapPageParamsPayload);
      return;
    }
    this.formItems = {};
  }

  handleShowDetails(id: string): void {
    var elFxRateDetail = document.getElementById("fxRateDetailId_" + id);
    var val = elFxRateDetail?.getAttribute("data-show");
    var newVal = val == "true" ? "false" : "true";
    elFxRateDetail?.setAttribute("data-show", newVal);
  }

  handleCellClick(val): void {
    console.log("cell", val); // eslint-disable-line
  }

  handleRowClick(val): void {
    console.log("row", val); // eslint-disable-line
  }

  async handleDownloadCsvClick() {
    await this.getExportUserTransactions(this.mapExportParamsPayload);
    this.downloadCsv();
  }

  downloadCsv(): void {
    let csvdata = Papa.unparse(this.mappedTransactionsCsvData);
    const BOM = "\uFEFF"; 
    csvdata = BOM + csvdata;
    let blob = new Blob([csvdata], { type: "text/csv;encoding:utf-8" });
    var csvUrl = window.webkitURL.createObjectURL(blob);
    let filename = `Transactions_${moment().format("YYYYMMDD_hhmmss")}.csv`;

    let element = document.createElement("a");

    element.setAttribute("href", csvUrl);
    element.setAttribute("download", filename);

    element.style.display = "none";
    document.body.appendChild(element);

    element.click();
    document.body.removeChild(element);
  }
}
</script>
<style lang="scss" scoped>
[data-show="false"] {
  display: none;
}
[data-show="true"] {
  display: block;
}

.download-transactions {
  display: flex;
  width: 100%;
  flex-direction: row;
  justify-content: right;
  align-items: center;
  text-align: left;
  padding: 15px 10px;
}
</style>
