<template>
  <tbody :class="{ expanded: isClosed }">
    <tr @click="toggleSummary" :isClosed="isClosed">
      <td class="text-center">
        <OText size="sm" icon="clock" bold>
          {{ $t("transactions.pendingTransactionsTitle") }}
        </OText>
        <OText class="mt-2 mb-2" align="center"
          >Balance: {{ availableBalance | currency }}
        </OText>
        <OButton xsmall :icon="isClosed ? 'eye' : 'close'" :block="false">
          <template v-if="isClosed">{{
            $t("transactions.pendingViewBtn")
          }}</template>
          <template v-else>{{ $t("transactions.pendingCloseBtn") }}</template>
        </OButton>
      </td>
    </tr>
    <tr
      v-for="(row, j) in items"
      :key="`row_${j}`"
      @click="handleRowClick(row)"
      @keypress.enter="handleRowClick(row)"
      v-show="!isClosed"
      class="summary-row"
    >
      <template v-for="(header, k) in headers">
        <td
          :key="k"
          @click="handleCellClick(row[header.key])"
          :data-label="$scopedSlots[header.key] ? header.text : ''"
          class="body-2"
        >
          <slot
            v-if="$scopedSlots[header.key]"
            :name="`${header.key}`"
            :cell="row[header.key]"
            :row="row"
            :headers="headers"
            :index="j"
          />
          <template v-else>{{ row[header.key] || header.default }}</template>
        </td>
      </template>
    </tr>
  </tbody>
</template>
<script>
import OText from "@/components/lib/OText.vue";
import OButton from "@/components/lib/OButton.vue";
export default {
  name: "TransactionsSummary",
  components: {
    OText,
    OButton,
  },
  props: {
    headers: {
      type: Array,
      default: () => [],
    },
    items: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      isClosed: true,
    };
  },
  computed: {
    colspan() {
      return this.headers?.length - 3;
    },
    availableBalance() {
    if (localStorage.getItem("accountBalance")) {
        let pendingTransactionSum = this.items.reduce((prevVal, elem) => {
            return prevVal + elem.value.minorUnits || 0;
        }, 0);

        let balance = JSON.parse(localStorage.getItem("accountBalance"));
        return balance.minorUnits + pendingTransactionSum;
    }
    return 1;
    },
  },
  methods: {
    toggleSummary() {
      this.isClosed = !this.isClosed;
    },
    handleRowClick(row) {
      this.$emit("rowClick", row);
    },
    handleCellClick(cell) {
      this.$emit("cellClick", cell);
    },
  },
};
</script>
<style lang="scss" scoped>
table {
  border: 0;
  width: 100%;
  border-collapse: collapse;
  td {
    display: block;
    padding: 0 10px;
    clear: both;
  }
  tbody {
    tr {
      background-color: var(--v-tablerow-base);
    }
  }
  thead {
    border: none;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
  }
  tr {
    display: block;
    padding: 10px 0;
    background-color: var(--v-tablerow-base);
    border-bottom: 1px solid white;
  }
  tr.summary-row td {
    display: block;
    text-align: right;
    padding: 0 10px;
  }
  td::before {
    content: attr(data-label);
    float: left;
    font-weight: bold;
  }
  td:last-child {
    border-bottom: 0;
  }
  caption {
    text-align: left;
    padding: 15px 0 15px 15px;
  }
}
</style>
