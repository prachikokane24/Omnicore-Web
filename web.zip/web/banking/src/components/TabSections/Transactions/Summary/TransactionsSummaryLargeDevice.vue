<template>
  <tbody :class="{ expanded: !isClosed }">
    <tr @click="toggleSummary" :isClosed="isClosed">
      <td :colspan="colspan" scope="row" class="pt-2 pb-2">
        <OText type="h3" size="sm" icon="clock" bold>
          {{ $t("transactions.pendingTransactionsTitle") }}
        </OText>
      </td>
      <td>
        <OText size="sm" bold v-if="isClosed"
          >{{ totalValue | currency }}
        </OText>
      </td>
      <td>
        <OText size="sm" bold v-if="isClosed"
          >{{ availableBalance | currency }}
        </OText>
      </td>
      <td>
        <OIcon :icon="isClosed ? 'plusCircleOutline' : 'minus'" />
      </td>
    </tr>
    <tr
      v-for="(row, j) in items"
      :key="`row_${j}`"
      @click="handleRowClick(row)"
      @keypress.enter="handleRowClick(row)"
      v-show="!isClosed"
    >
      <template v-for="(header, k) in headers">
        <td :key="k" @click="handleCellClick(row[header.key])" class="body-2">
          <slot
            v-if="$scopedSlots[header.key]"
            :name="`${header.key}`"
            :cell="row[header.key]"
            :row="row"
            :headers="headers"
            :index="j"
          />
          <template v-else>{{ row[header.key] || header.default }}</template>
        </td>
      </template>
    </tr>
    <tr v-if="!isClosed">
      <td :colspan="headers.length" class="spacer"></td>
    </tr>
  </tbody>
</template>
<script>
import OText from "@/components/lib/OText.vue";
import OIcon from "@/components/lib/OIcon.vue";
export default {
  name: "TransactionsSummary",
  components: {
    OText,
    OIcon,
  },
  props: {
    headers: {
      type: Array,
      default: () => [],
    },
    items: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      isClosed: true,
    };
  },
  computed: {
    colspan() {
      return this.headers?.length - 3;
    },
    availableBalance() {
    if (localStorage.getItem("accountBalance")) {
        let pendingTransactionSum = this.items.reduce((prevVal, elem) => {
            return prevVal + elem.value.minorUnits || 0;
        }, 0);

        let balance = JSON.parse(localStorage.getItem("accountBalance"));
        return balance.minorUnits + pendingTransactionSum;
    }
    return 100;
},
    totalValue() {
      return this.items.reduce((prevVal, elem) => {
        return prevVal + elem.value.minorUnits || 0;
      }, 0);
    },
  },
  methods: {
    toggleSummary() {
      this.isClosed = !this.isClosed;
    },
    handleRowClick(row) {
      this.$emit("rowClick", row);
    },
    handleCellClick(cell) {
      this.$emit("cellClick", cell);
    },
  },
};
</script>
<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";
.spacer {
  border-top: 5px solid var(--v-tablerow-base);
  background-color: white;
  height: 20px;
}
tbody.expanded {
  tr {
    background-color: var(--v-tablerow-base);
    padding-bottom: 10px;
  }
}
tr:first-of-type {
  cursor: pointer;
}
tr:last-child th:first-child {
  padding-left: 10px;
  @media #{map-get($display-breakpoints, 'md-and-up')} {
    padding-left: 20px;
  }
  @media #{map-get($display-breakpoints, 'lg-and-up')} {
    padding-left: 30px;
  }
}
tr:last-child th:last-child {
  padding-left: 10px;
  @media #{map-get($display-breakpoints, 'md-and-up')} {
    padding-left: 20px;
  }
  @media #{map-get($display-breakpoints, 'lg-and-up')} {
    padding-left: 30px;
  }
}
td:first-child {
  padding-left: 10px;
  @media #{map-get($display-breakpoints, 'md-and-up')} {
    padding-left: 20px;
  }
  @media #{map-get($display-breakpoints, 'lg-and-up')} {
    padding-left: 30px;
  }
}
td:last-child {
  padding-left: 10px;
  @media #{map-get($display-breakpoints, 'md-and-up')} {
    padding-left: 20px;
  }
  @media #{map-get($display-breakpoints, 'lg-and-up')} {
    padding-left: 30px;
  }
}
td {
  padding: 8px 10px;
  width: 5%;
  vertical-align: top;
}
th {
  padding: 8px 10px;
  text-transform: uppercase;
  text-align: left;
}
</style>
