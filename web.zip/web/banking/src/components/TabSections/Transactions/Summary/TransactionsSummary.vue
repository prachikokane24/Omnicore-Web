<template>
  <component :is="component" v-bind="[$attrs]">
    <template v-slot:transactionDate="{ cell }">
      {{ cell | date }}
    </template>
    <template v-slot:description="{ row }">
      <OText> {{ row.description }} </OText>
      <div
        :id="'fxRateDetailId_' + row.id"
        data-show="false"
        v-if="row.originAmount && row.fxRate"
      >
        {{ row.originAmount.currency }}
        {{ row.originAmount.minorUnits | currencyFloat }} / FX Rate =
        {{ row.fxRate }}
      </div>
    </template>
    <template v-slot:value="{ cell }">
      <OText
        size="sm"
        medium
        v-credit-debit="{
          amount: cell.minorUnits,
          creditColor: `${$vuetify.theme.themes.light.success}`,
        }"
        ><span v-if="cell.minorUnits > 0">+</span
        >{{ cell.minorUnits | currency }}
      </OText>
    </template>
    <!--
    N.B. This is a temporary fix for a running balance issue... 
    <template v-slot:balance="{ row }">
      <OText  v-if="row.balance && row.balance.minorUnits">
        {{ row.balance.minorUnits | currency }}
      </OText>
    </template>
    -->
    <template v-slot:action="{ row }">
      <OIcon icon="eye" type="button" :opacity="0.5" @click.native="() =>
      handleShowDetails(row.id)" v-if="row.originAmount && row.fxRate &&
      row.value.currency != row.originAmount.currency" />
    </template>
  </component>
</template>
<script lang="ts">
import { Component, Prop, Vue } from "vue-property-decorator";
@Component({
  components: {
    OIcon: () => import("@/components/lib/OIcon.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    TransactionsSummaryLargeDevice: () =>
      import(
        "@/components/TabSections/Transactions/Summary/TransactionsSummaryLargeDevice.vue"
      ),
    TransactionsSummarySmallDevice: () =>
      import(
        "@/components/TabSections/Transactions/Summary/TransactionsSummarySmallDevice.vue"
      ),
  },
})
export default class TransactionsSummary extends Vue {
  get component() {
    return this.$vuetify.breakpoint.xsOnly
      ? "TransactionsSummarySmallDevice"
      : "TransactionsSummaryLargeDevice";
  }
  handleShowDetails(id) {

    var elFxRateDetail = document.getElementById("fxRateDetailId_" + id);
    var val = elFxRateDetail?.getAttribute("data-show");
    var newVal = val == "true" ? "false" : "true";
    elFxRateDetail?.setAttribute("data-show", newVal);
  }
}
</script>
<style lang="scss" scoped>
[data-show="false"] {
  display: none;
}
[data-show="true"] {
  display: block;
}
</style>
