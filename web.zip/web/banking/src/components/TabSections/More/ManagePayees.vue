<template>
  <OInfoCard :title="$t('payees.managePayees')">
    <OText type="p">{{ $t("payees.intro") }}</OText>
    <OAlert type="error" :outlined="true"
      ><OText type="div" size="sm" medium
        ><span v-html="$t('payees.scamMessage')" /></OText
    ></OAlert>
    <OAlign align="end">
      <OButton
        type="button"
        data-id="addPayeeBtn"
        class="mb-2"
        @click="handleAddPayee"
        >{{ $t("payees.addPayeeBtn") }}</OButton
      >
    </OAlign>
    <ODataTablePaginatorAsync
      :page-count="pageCount"
      :page-number="pageParams.pageNumber"
      :disabled="noop.loading"
      @change="handlePageChange"
      ref="anchorTop"
    >
      <ODataTable
        v-bind="tableConfig"
        :loading="userPayees.loading"
        header-size="xs"
        header-weight="medium"
        data-id="payeeTable"
      >
        <template v-slot:name="{ cell }">
          <OText size="sm">{{ cell | titleCase }}</OText>
        </template>
        <template v-slot:bankDetails="{ row }">
          <OText size="sm">{{ row.bankDetails | formattedBankDetails }}</OText>
        </template>
        <template v-slot:reference="{ row }">
          <OText size="sm">{{ row.reference | truncate(10) }}</OText>
        </template>
        <template v-slot:action="{ row }">
          <OButton
            type="button"
            @click.native="
              () =>
                handleCancelPayee({
                  payeeId: row.payeeId,
                  payeeName: row.name,
                })
            "
            block
            outlined
            x-small
          >
            {{ $t("payees.cancelBtn") }}
          </OButton>
        </template>
      </ODataTable>
    </ODataTablePaginatorAsync>
    <OModalAddPayee id="addPayee" ref="addPayee" @confirm="handleConfirmed" />
    <OModalCancelPayee
      id="cancelPayee"
      :payee="payee"
      @confirm="handleConfirmed"
    />
  </OInfoCard>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import { Action, namespace } from "vuex-class";
import { BaseStateInterface } from "@/types/store.types";

const payeeModule = namespace("payeeModule");

@Component({
  components: {
    OAlert: () => import("@/components/lib/OAlert.vue"),
    OAlign: () => import("@/components/lib/OAlign.vue"),
    OInfoCard: () => import("@/components/lib/OInfoCard.vue"),
    ODataTable: () => import("@/components/lib/DataTable/ODataTable.vue"),
    ODataTablePaginatorAsync: () =>
      import("@/components/lib/DataTable/ODataTablePaginatorAsync.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OButton: () => import("@/components/lib/OButton.vue"),
    OModalAddPayee: () =>
      import("@/components/TabSections/More/Modals/ModalAddPayee.vue"),
    OModalCancelPayee: () =>
      import("@/components/TabSections/More/Modals/ModalCancelPayee.vue"),
  },
})
export default class ManagePayees extends Vue {
  payee = {
    payeeId: null,
    payeeName: null,
  };
  pageParams = {
    pageNumber: 1,
    pageSize: 5,
  };
  headers = [
    {
      text: this.$t("payees.payeeName"),
      align: "start",
      sortable: false,
      key: "name",
      default: "-",
    },
    { text: this.$t("payees.bankDetails"), key: "bankDetails" },
    { text: this.$t("payees.reference"), key: "reference" },
    { text: this.$t("payees.action"), key: "action" },
  ];

  @Action("payeeModule/GET_USER_PAYEES")
  getUserPayees!: (payload) => string;

  @payeeModule.State
  private noop!: BaseStateInterface;

  @payeeModule.State
  public userPayees!: BaseStateInterface;

  get formIsLoading(): boolean {
    return this.noop?.loading;
  }

  get tableConfig() {
    return {
      headers: this.headers,
      items: this.userPayees?.data?.payees,
    };
  }

  get pageSize(): number {
    return (
      this.userPayees?.data?.paginationData?.pageSize ||
      this.pageParams.pageSize
    );
  }

  get pageCount(): number {
    return this.userPayees?.data?.paginationData?.pageCount || 0;
  }

  get mapPageParamsPayload(): {
    pageNumber: number;
    pageSize: number;
  } {
    return {
      pageNumber: this.pageParams.pageNumber,
      pageSize: this.pageSize,
    };
  }

  created(): void {
    this.getUserPayees(this.mapPageParamsPayload);
  }

  handlePageChange(val: number): void {
    var element: any = this.$refs["anchorTop"];
    var top = element.offsetTop;
    window.scrollTo(0, top);
    this.pageParams.pageNumber = val;
    this.getUserPayees(this.mapPageParamsPayload);
  }

  handleFilterChange() {
    this.pageParams.pageNumber = 1;
    this.getUserPayees(this.mapPageParamsPayload);
  }

  handleAddPayee(): void {
    this.$modal.show("addPayee");
  }

  handleCancelPayee(payee): void {
    this.payee = payee;
    this.$modal.show("cancelPayee");
  }

  handleConfirmed(): void {
    this.pageParams.pageNumber = 1;
    this.getUserPayees(this.mapPageParamsPayload);
  }
}
</script>

<style lang="scss" scoped></style>
