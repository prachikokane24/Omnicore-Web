<template>
  <div>
    <OModalConfirmCancel
      :confirmDisabled="formPayeeInvalid"
      :loading="formIsLoading"
      :confirmText="
        formPreview
          ? $t('payees.modalConfirmBtn')
          : $t('payees.modalContinueBtn')
      "
      :id="id"
      @confirm="handleConfirm"
      @cancel="handleCancel"
      @show="reset"
      dataIdConfirmBtn="addPayeeConfirmBtn"
      dataIdCancelBtn="addPayeeCancelBtn"
    >
      <template v-slot:header>{{ $t("payees.modalAddPayeeTitle") }}</template>
      <OText type="p" class="mb-2" v-if="formPreview">
        <OAlert type="error" :outlined="true"
          ><OText type="span" size="sm" medium>{{
            $t("payees.modalUnverifiedText")
          }}</OText></OAlert
        >
      </OText>
      <OText type="p" v-if="!formPreview"
        ><span v-html="$t('payees.modalAddPayeeText')"
      /></OText>
      <OForm
        :loading="formIsLoading"
        data-id="addPayeeloginForm"
        @invalid="handlePayeeFormInvalid"
        hide-actions
        ref="form"
        inline
        :key="componentFormKey"
      >
        <OFormSelect
          data-id="addPayeeType"
          v-bind="formConfig.payeeType"
          v-model="formItems.payeeType"
        />
        <OFormInput
          data-id="addPayeeFirstName"
          v-if="recipientType == 'Person'"
          v-bind="formConfig.payeeFirstName"
          v-model="formItems.payeeFirstName"
        />
        <OFormInput
          data-id="addPayeeLastName"
          v-if="recipientType == 'Person'"
          v-bind="formConfig.payeeLastName"
          v-model="formItems.payeeLastName"
        />
        <OFormInput
          data-id="addPayeeCompany"
          v-if="recipientType == 'Company'"
          v-bind="formConfig.payeeCompany"
          v-model="formItems.payeeCompany"
        />
        <OFormInput
          data-id="addPayeeSortCode"
          v-bind="formConfig.sortCode"
          v-model="formItems.sortCode"
        />
        <OFormInput
          data-id="addPayeeAccountNo"
          v-bind="formConfig.accountNo"
          v-model="formItems.accountNo"
        />
        <OFormInput
          data-id="addPayeeReference"
          v-bind="formConfig.payeeReference"
          v-model="formItems.payeeReference"
        />
      </OForm>
      <OButton
        data-id=""
        @click="formPreview = false"
        v-if="formPreview"
        icon="pencil"
        iconSize="xSmall"
        color="secondary"
        class="mb-2"
        >{{ $t("scheduledtransfers.modalEditBtn") }}</OButton
      >
      <OAlert type="error" v-if="formErrorMessage"
        ><OText type="div" size="sm" medium
          ><strong>{{ formErrorMessage }}</strong></OText
        ></OAlert
      >
    </OModalConfirmCancel>

    <!-- Warning Modal -->
    <OModalConfirmCancel
      id="unverified"
      @confirm="showOtp"
      :confirmText="$t('payees.modalUnverifiedConfirm')"
    >
      <template v-slot:header>{{ $t("payees.modalUnverifiedTitle") }}</template>
      <OText type="p" class="mb-2"
        ><span v-html="$t('payees.modalUnverifiedText')"
      /></OText>
      <OAlert type="error" :outlined="true"
        ><OText type="p" size="sm" medium>{{
          $t("payees.scamMessage")
        }}</OText></OAlert
      >
    </OModalConfirmCancel>

    <!-- OTP Verification Modal -->
    <OModalConfirmCancel
      id="otp"
      @confirm="handleOtpPasscode"
      @show="componentOtpKey += 1"
      :loading="verifyOtp.loading"
      :confirmDisabled="formOtpInvalid"
      :confirmText="$t('payees.modalOtpConfirm')"
      dataIdConfirmBtn="addPayeeOTPVerifyBtn"
      dataIdCancelBtn="addPayeeOTPCancelBtn"
    >
      <Otp
        ref="otp"
        @verified="handleOtpVerfified"
        @invalid="handleOtpFormInvalid"
        :hideActions="true"
        :key="componentOtpKey"
      />
    </OModalConfirmCancel>

    <!-- Confirmed Modal -->
    <OModalConfirm
      id="addPayeeConfirmed"
      :message="$t('payees.createdMessage')"
    />
  </div>
</template>
<script lang="ts">
import { Component, Vue, Prop } from "vue-property-decorator";
import { Action, namespace } from "vuex-class";
import { BaseStateInterface } from "@/types/store.types";

interface AnyObject {
  [key: string]: any;
}

interface InputConfig {
  name: string;
  rules?: string;
  label?: string | unknown;
  required?: boolean;
  items?: any[];
  preSelected?: unknown;
  type?: string;
  clearable?: boolean;
  hint?: string | unknown;
  appendIcon?: string;
  disabled?: boolean;
  counter?: number;
  error?: boolean;
  maxlength?: number;
  preview?: boolean;
  inline?: boolean;
  outsideLabel?: boolean;
  mask?: string;
}

interface FormConfig {
  payeeType: InputConfig;
  payeeFirstName: InputConfig;
  payeeLastName: InputConfig;
  payeeCompany: InputConfig;
  sortCode: InputConfig;
  accountNo: InputConfig;
  payeeReference: InputConfig;
}

interface FormPayload {
  payeeType: string;
  reference: string;
  firstName?: string;
  lastName?: string;
  companyName?: string;
  bankSortCode: number;
  bankAccountNo: number;
  payeeReference: string;
  bankName: null;
}

const payeeModule = namespace("payeeModule");
const otpModule = namespace("otpModule");

@Component({
  inheritAttrs: false,
  components: {
    OModalConfirmCancel: () =>
      import("@/components/lib/Modal/OModalConfirmCancel.vue"),
    OModalConfirm: () => import("@/components/lib/Modal/OModalConfirm.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OButton: () => import("@/components/lib/OButton.vue"),
    OForm: () => import("@/components/lib/Form/OForm.vue"),
    OFormInput: () => import("@/components/lib/Form/OFormInput.vue"),
    OFormSelect: () => import("@/components/lib/Form/OFormSelect.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
    Otp: () => import("@/components/Form/Otp/Otp.vue"),
  },
})
export default class ModalAddPayee extends Vue {
  @Prop() private id!: string;

  componentFormKey = 0;
  componentOtpKey = 0;
  formItems: AnyObject = {};
  formPayeeInvalid = false;
  formOtpInvalid = false;
  formPreview = false;

  @payeeModule.State
  private noop!: BaseStateInterface;

  @otpModule.State
  public verifyOtp!: BaseStateInterface;

  @Action("payeeModule/ADD_USER_PAYEE")
  addUserPayee!: (payload) => string;

  @Action("payeeModule/CLEAR_NOOP")
  clearNoop!: () => string;

  get recipientType() {
    return this.formItems?.payeeType?.value || null;
  }

  get formIsLoading(): boolean {
    return this.noop?.loading;
  }

 get formErrorMessage() {
        if (this.noop?.errorStatus == "400" && this.noop?.errorMessage?.includes("Resource already exists")) {
            if (this.accountNo == "" && this.sortCode == "" && this.firstName == "" && this.lastName == "") {
    
                this.accountNo = this.formItems?.accountNo?.value;
                this.sortCode = this.formItems?.sortCode?.value;
                this.firstName = this.formItems?.payeeFirstName?.value;
                this.lastName = this.formItems?.payeeLastName?.value;
                this.formPayeeInvalid = true;
                } 
                else {
                this.handlePayeeFormInvalid(this.formPayeeInvalid);
                if (!this.isDuplicatePayee() && this.isFormValid())
                    return "";
                }


            return "Please amend the set up details or use the existing payee record for your transaction.";

        }
    
     return this.noop?.errorMessage;
  }


  get formConfig(): FormConfig {
    return {
      payeeType: {
        name: "payeeType",
        rules: "required",
        label: this.$t("payees.formAddPayeeTypeLabel"),
        items: [
          {
            label: this.$t("payees.selectPerson"),
            value: "Person",
          },
          {
            label: this.$t("payees.selectCompany"),
            value: "Company",
          },
        ],
        preview: this.formPreview,
        inline: this.formPreview ? true : false,
      },
      payeeFirstName: {
        name: "payeeFirstName",
        rules: "required|min:2|max:50|alphachar",
        label: this.$t("payees.formAddPayeeFirstNameLabel"),
        preview: this.formPreview,
        inline: this.formPreview ? true : false,
      },
      payeeLastName: {
        name: "payeeName",
        rules: "required|min:2|max:50|alphachar",
        label: this.$t("payees.formAddPayeeLastNameLabel"),
        preview: this.formPreview,
        inline: this.formPreview ? true : false,
      },
      payeeCompany: {
        name: "payeeCompany",
        rules: "required|min:2|max:50|alphachar",
        label: this.$t("payees.formAddPayeeCompanyLabel"),
        preview: this.formPreview,
        inline: this.formPreview ? true : false,
        mask: "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        counter: 50,
      },
      sortCode: {
        name: "sortCode",
        rules: "required|sortCode",
        label: this.$t("payees.formAddPayeeSortLabel"),
        hint: this.$t("payees.formHintPayeeSortCode"),
        preview: this.formPreview,
        inline: this.formPreview ? true : false,
        mask: "##-##-##",
      },
      accountNo: {
        name: "accountNo",
        rules: "required|accountNo|numeric",
        label: this.$t("payees.formAddPayeeAccLabel"),
        hint: this.$t("payees.formHintPayeeAccNo"),
        preview: this.formPreview,
        inline: this.formPreview ? true : false,
        mask: "########",
      },
      payeeReference: {
        name: "payeeReference",
        rules: "required|min:2|max:18|alphachar",
        label: this.$t("payees.formAddPayeeRefLabel"),
        hint: this.$t("payees.formHintPayeereference"),
        preview: this.formPreview,
        maxlength: 18,
        counter: 18,
        inline: this.formPreview ? true : false,
      },
    };
  }

  get mappedAddPayee() {
    return this.formItems;
  }

  get mapPayload(): FormPayload {
    let type = this.formItems?.payeeType?.value;
    if (type == "Company") {
      return {
        payeeType: this.formItems?.payeeType?.value,
        reference: this.formItems?.payeeReference?.value,
        companyName: this.formItems?.payeeCompany?.value,
        bankSortCode: this.formItems?.sortCode?.value.replace(/[-]/g, ""),
        bankAccountNo: this.formItems?.accountNo?.value,
        payeeReference: this.formItems?.payeeReference?.value,
        bankName: null,
      };
    }
    return {
      payeeType: this.formItems?.payeeType?.value,
      reference: this.formItems?.payeeReference?.value,
      firstName: this.formItems?.payeeFirstName?.value,
      lastName: this.formItems?.payeeLastName?.value,
      bankSortCode: this.formItems?.sortCode?.value.replace(/[-]/g, ""),
      bankAccountNo: this.formItems?.accountNo?.value,
      payeeReference: this.formItems?.payeeReference?.value,
      bankName: null,
    };
  }

  // showUnverifiedStatus(): void {
  //   this.$modal.hide("addPayee");
  //   this.$modal.show("unverified");
  // }

  showOtp(): void {
    this.$modal.show("otp");
    this.$modal.hide("unverified");
    (this.$refs.otp as Vue & { clearOtp: () => void }).clearOtp();
  }

 
  accountNo  = "";
  sortCode   = "";
  firstName  = "";
  lastName   = "";

  isDuplicatePayee(): boolean {
      return this.accountNo !== "" && this.accountNo == this.formItems?.accountNo?.value &&
        this.sortCode !== "" && this.sortCode == this.formItems?.sortCode?.value &&
        this.firstName !== "" && this.firstName == this.formItems?.payeeFirstName?.value &&
        this.lastName !== "" && this.lastName == this.formItems?.payeeLastName?.value;
}

  isFormValid(): boolean {
      return this.formItems?.accountNo?.value.length >= 7 && this.formItems?.sortCode?.value.length == 8 &&
        this.formItems?.payeeFirstName?.value.length > 2 && this.formItems?.payeeLastName?.value.length > 2;
}

  handlePayeeFormInvalid(invalid: boolean): void {
    if (this.isDuplicatePayee()) {
        this.formPayeeInvalid = true;

    } else if (this.isFormValid()) {
        this.formPayeeInvalid = false;

    } else {

        this.formPayeeInvalid = invalid;
    }
}

  handleOtpFormInvalid(invalid: boolean): void {
    this.formOtpInvalid = invalid;
  }

  handleOtpPasscode(): void {
    this.$nextTick(() => {
      (this.$refs.otp as Vue & { handleSubmit: () => void }).handleSubmit();
    });
  }

  async handleOtpVerfified(): Promise<void> {
    this.$modal.hide("otp");
    try {
      if (this.formPayeeInvalid) {
        await (this.$refs.form as Vue & { validate: () => void }).validate();
      }
      await this.addUserPayee(this.mapPayload);
      this.$modal.show("addPayeeConfirmed");
      this.$modal.hide("addPayee");
      this.$emit("confirm");
    } catch (e) {
      throw new Error(e);
    }
  }

  async handleConfirm(): Promise<void> {
    try {
      await (this.$refs.form as Vue & { validate: () => void }).validate();
      if (this.formPayeeInvalid) return;
      if (this.formPreview) {
        this.$modal.show("otp");
        return;
      }
      this.formPreview = true;
    } catch (e) {
      throw new Error(e);
    }
  }

  handleCancel() {
    this.$emit("cancel");
  }

  async reset() {
    this.componentFormKey += 1;
    this.formItems = {};
    this.formPreview = false;
    this.clearNoop();
  }
}
</script>