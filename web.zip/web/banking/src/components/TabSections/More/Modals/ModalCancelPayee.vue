<template>
  <div>
    <OModalConfirmCancel
      v-bind="[$attrs, $props]"
      @confirm="handleConfirm"
      @show="reset"
      :loading="noop.loading"
      :error-message="errorMessage"
      dataIdConfirmBtn="deletePayeeConfirmBtn"
      dataIdCancelBtn="deletePayeeCancelBtn"
      dataIdError="errorDeletePayee"
      dataIdWarning="warningDeletePayee"
    >
      <template v-slot:header>{{ $t("payees.cancelModalHeading") }}</template>
      <OText type="p">
        {{ $t("payees.cancelModalContent", { payee: payee.payeeName }) }}</OText
      >
    </OModalConfirmCancel>
    <OModalConfirm
      id="cancelPayeeConfirmed"
      :message="$t('payees.cancelledMessage')"
    />
  </div>
</template>
<script lang="ts">
import { Component, Prop, Vue } from "vue-property-decorator";
import { Action, namespace } from "vuex-class";
import { BaseStateInterface } from "@/types/store.types";

const payeeModule = namespace("payeeModule");

@Component({
  inheritAttrs: false,
  components: {
    OModalConfirmCancel: () =>
      import("@/components/lib/Modal/OModalConfirmCancel.vue"),
    OModalConfirm: () => import("@/components/lib/Modal/OModalConfirm.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
  },
})
export default class ModalCancelPayee extends Vue {
  @Prop() private payee!: {
    payeeId: string;
    payeeName: string;
  };

  @Action("payeeModule/DELETE_USER_PAYEE")
  deleteUserPayee!: (id) => number;

  @Action("payeeModule/CLEAR_NOOP")
  clearNoop!: () => string;

  @payeeModule.State
  public noop!: BaseStateInterface;

  get errorMessage() {
    return this.noop.errorMessage;
  }

  async handleConfirm(): Promise<void> {
    try {
      await this.deleteUserPayee(this.payee.payeeId);
      this.$modal.hide("cancelPayee");
      this.$modal.show("cancelPayeeConfirmed");
      this.$emit("confirm");
    } catch (e) {
      console.log(e);
    }
  }

  async reset() {
    this.clearNoop();
  }
}
</script>
