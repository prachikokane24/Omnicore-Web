<template>
  <div>OpenBanking</div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from "vue-property-decorator";
@Component({})
export default class OpenBanking extends Vue {}
</script>

<style lang="scss" scoped></style>
