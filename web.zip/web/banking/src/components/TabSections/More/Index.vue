<template>
  <OTabsVertical :items="items" v-model="selectedTab" @change="handleChange">
    <template v-slot:default>
      <component :is="selectedTab" />
    </template>
  </OTabsVertical>
</template>
<script lang="ts">
import { Vue, Component } from "vue-property-decorator";
@Component({
  components: {
    OTabsVertical: () => import("@/components/lib/OTabsVertical.vue"),
    PersonalDetails: () =>
      import("@/components/TabSections/More/PersonalDetails.vue"),
    MarketingPreferences: () =>
      import("@/components/TabSections/More/MarketingPreferences.vue"),
    CommunicationPreferences: () =>
      import("@/components/TabSections/More/CommunicationPreferences.vue"),
    OpenBanking: () => import("@/components/TabSections/More/OpenBanking.vue"),
    ManagePayees: () =>
      import("@/components/TabSections/More/ManagePayees.vue"),
    ChangePassword: () =>
      import("@/components/TabSections/More/ChangePassword.vue"),
  },
})
export default class More extends Vue {
  selectedTab = "ManagePayees";
  items = [
    // {
    //   name: "Communication Preferences",
    //   cmp: "CommunicationPreferences",
    // },
    // {
    //   name: "Open Banking",
    //   cmp: "OpenBanking",
    // },
    {
      name: "Manage Payees",
      cmp: "ManagePayees",
    },
    {
      name: "Marketing Preferences",
      cmp: "MarketingPreferences",
    },
    {
      name: "Personal Details",
      cmp: "PersonalDetails",
    },
    {
      name: "Change Password",
      cmp: "ChangePassword",
    },
  ];
  handleChange(selectedTab: {
    type: string;
    value: string;
    tabName: string;
  }): void {
    this.selectedTab = selectedTab.value;
  }
}
</script>
