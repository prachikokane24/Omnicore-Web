<template>
  <OInfoCard :title="$t('personalDetails.heading')">
    <v-row>
      <v-col cols="12" :md="7">
        <OForm
          ref="form"
          @submit="handleSubmit"
          @cancel="handleCancel"
          :loading="formIsLoading"
          :submitText="$t('personalDetails.submitBtn')"
          :hideCancelBtn="true"
          :hideSubmitBtn="isPwRequired"
          :disableSubmitBtn="!isPwRequired"
          data-id="personalDetailsForm"
          max-width="600"
          class="mb-4"
          :key="componentFormKey"
        >
          <OFormInput
            ref="email"
            data-id="personalDetailsFormEmail"
            v-bind="formConfig.email"
            v-model.trim="formItems.email"
            @appendClick="handleAppendClick('email')"
          />
          <OFormInput
            ref="email"
            data-id="personalDetailsFormEmailConfirm"
            v-bind="formConfig.emailConfirm"
            v-model.trim="formItems.emailConfirm"
            v-if="isChangedEmail"
          />
          <OFormInput
            ref="mobilePhone"
            data-id=""
            v-bind="formConfig.mobilePhone"
            v-model.trim="formItems.mobilePhone"
             @appendClick="handleAppendClick('mobilePhone')"
          />
          <OFormInput
            ref="mobilePhoneConfirm"
            data-id=""
            v-bind="formConfig.mobilePhoneConfirm"
            v-model.trim="formItems.mobilePhoneConfirm"
            v-if="isChangedMobile"
          />
          <OSheet
            color="amber lighten-5"
            elevation="2"
            class="pt-5 pl-5 pb-5 pr-5 mb-5"
            v-if="isPwRequired"
          >
            <p>{{ $t("changePassword.passwordUpdateText") }}:</p>
            <OFormInput
              ref="password"
              data-id=""
              v-bind="formConfig.password"
              v-model.trim="formItems.password"
              prependIcon="mdi-lock"
            />
          </OSheet>
          <template #footer>
            <OAlert
              type="success"
              v-if="formSuccessMsg"
              dismissible
              data-id="personalDetailsSuccessMsg"
            >
              {{ $t("personalDetails.successfullyUpdated") }}
            </OAlert>
            <OAlert type="error" v-if="formIsError" dismissible>
              {{ formIsError }}
            </OAlert>
          </template>
        </OForm>
      </v-col>
      <v-col cols="12" :md="4">
        <v-divider class="mb-4 d-flex d-sm-none"></v-divider>
        <OText type="h5" class="mb-2">{{
          $t("personalDetails.addressLabel")
        }}</OText>
        <OText type="address" class="address"
          ><span v-for="(item, i) in address" :key="i">{{ item }}<br /> </span
        ></OText>
      </v-col>
    </v-row>
    <!-- OTP Verification Modal -->
    <OModalConfirmCancel
      id="otp"
      @confirm="handleOtpPasscode"
      @show="componentOtpKey += 1"
      dataIdConfirmBtn="personalDetailsVerifyOTPBtn"
      dataIdCancelBtn="personalDetailsCancelOTPBtn"
      :loading="verifyOtp.loading"
      :confirmDisabled="formOtpInvalid"
      :confirmText="$t('payees.modalOtpConfirm')"
    >
      <Otp
        ref="otp"
        @verified="handleOtpVerfified"
        @invalid="handleOtpFormInvalid"
        :hideActions="true"
        :key="componentOtpKey"
      />
    </OModalConfirmCancel>
  </OInfoCard>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import { Action, namespace } from "vuex-class";
import router from "../../../router/index";
import { TokensContext } from "@/omnicore-lib/src/services/http/TenantTokenBasedService";
import {
  BaseStateInterface,
  PersonalDetailsPayloadInterface,
} from "@/types/store.types";
import { log } from "util";

const userModule = namespace("userModule");
const otpModule = namespace("otpModule");

interface FormItem {
  items?: any[];
  title?: string;
  name: string;
  rules: string;
  label?: string | unknown;
  hint?: string | unknown;
  preSelected?: string;
  type?: string;
  disabled?: boolean;
  outsideLabel?: boolean;
  inline?: boolean;
  inlineIcon?: string;
  minLabelWidth?: number;
  persistentHint?: boolean;
  appendIcon?: string;
}

interface PersonalDetailsConfig {
  title: FormItem;
  email: FormItem;
  emailConfirm: FormItem;
  password: FormItem;
  firstName: FormItem;
  lastName: FormItem;
  dob: FormItem;
  homePhone: FormItem;
  mobilePhone: FormItem;
  mobilePhoneConfirm: FormItem;
  addressLine1: FormItem;
  addressLine2: FormItem;
  addressLine3: FormItem;
  postalCode: FormItem;
  country: FormItem;
}

interface AnyObject {
  [key: string]: any;
}

@Component({
  components: {
    OModalConfirmCancel: () =>
      import("@/components/lib/Modal/OModalConfirmCancel.vue"),
    OForm: () => import("@/components/lib/Form/OForm.vue"),
    OFormInput: () => import("@/components/lib/Form/OFormInput.vue"),
    OFormSelect: () => import("@/components/lib/Form/OFormSelect.vue"),
    OFormDOB: () => import("@/components/lib/Form/OFormDOB.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
    OAlign: () => import("@/components/lib/OAlign.vue"),
    OInfoCard: () => import("@/components/lib/OInfoCard.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OIcon: () => import("@/components/lib/OIcon.vue"),
    OButton: () => import("@/components/lib/OButton.vue"),
    OFilter: () => import("@/components/lib/OFilter.vue"),
    OSheet: () => import("@/components/lib/OSheet.vue"),
    Otp: () => import("@/components/Form/Otp/Otp.vue"),
  },
})
export default class PersonalDetails extends Vue {
  formItems: AnyObject = {};
  formSuccessMsg = false;
  formInvalid = false;
  formOtpInvalid = false;
  componentFormKey = 0;
  componentOtpKey = 0;
  incorrectPasswordAttemptCounter = 0;
  incorrectPasswordAttempt = 2;

  titles = [
    "Mr",
    "Mrs",
    "Master",
    "Miss",
    "Ms",
    "Mx",
    "Canon",
    "Capt",
    "Brns",
    "Cdr",
    "Cllr",
    "Col",
    "Corp",
    "Dame",
    "Dr",
    "Hon",
    "Lady",
    "Laird",
    "Lcpl",
    "Lord",
    "Lt Col",
    "Major",
    "Pastor",
    "Prof",
    "Rev",
    "Rt Hon",
    "Sir",
    "Sister",
    "Sq Ldr",
    "Ven",
    "Wngcm",
  ];

  @userModule.State
  private personalDetails!: BaseStateInterface;

  @userModule.State
  private noop!: BaseStateInterface;

  @otpModule.State
  public verifyOtp!: BaseStateInterface;

  @Action("userModule/CLEAR_NOOP")
  clearNoop!: () => string;

  @Action("userModule/GET_PERSONAL_DETAILS")
  getPersonalDetails!: () => string;

  @Action("userModule/UPDATE_PERSONAL_DETAILS")
  updatePersonalDetails!: (payload: PersonalDetailsPayloadInterface) => string;

  get address() {
    return [
      this.personalDetails?.data?.customerDetails?.address?.line1,
      this.personalDetails?.data?.customerDetails?.address?.line2,
      this.personalDetails?.data?.customerDetails?.address?.line3,
      this.personalDetails?.data?.customerDetails?.address?.postalCode,
      this.personalDetails?.data?.customerDetails?.address?.country,
    ];
  }

  get formConfig(): PersonalDetailsConfig {
    return {
      title: {
        name: "title",
        rules: "required",
        label: this.$t("personalDetails.title"),
        items: this.titles,
        inline: true,
        preSelected: this.titles[0], // "Mr"
      },
      email: {
        name: "email",
        type: "email",
        rules: `required|email`,
        label: this.$t("personalDetails.email"),
        preSelected: this.personalDetails?.data?.customerDetails?.email,
        disabled: this.formIsLoading,
        inline: true,
        inlineIcon: "email",
        minLabelWidth: 180,
        appendIcon: "mdi-pencil",
      },
      emailConfirm: {
        name: "emailConfirm",
        type: "email",
        rules: `required|email|isNotEqualTo:@email`,
        label: this.$t("personalDetails.emailConfirm"),
        hint: this.$t("personalDetails.emailConfirmHint"),
        disabled: this.formIsLoading,
        inline: true,
        inlineIcon: "email",
        minLabelWidth: 180,
      },
      password: {
        name: "password",
        rules: "required|min:8",
        label: this.$t("changePassword.password"),
        hint: this.$t("changePassword.passwordHint"),
        type: "password",
      },
      firstName: {
        name: "firstName",
        rules: "required|min:2|max:200",
        label: this.$t("personalDetails.firstName"),
        preSelected: this.personalDetails?.data?.customerDetails?.firstName,
        disabled: this.formIsLoading,
        inline: true,
      },
      lastName: {
        name: "lastName",
        rules: "required|min:2|max:200",
        label: this.$t("personalDetails.lastName"),
        preSelected: this.personalDetails?.data?.customerDetails?.lastName,
        disabled: this.formIsLoading,
        inline: true,
      },
      dob: {
        name: "dob",
        rules: "required",
        label: this.$t("personalDetails.dob"),
        type: "select",
        preSelected: this.personalDetails?.data?.customerDetails?.dob,
        disabled: this.formIsLoading,
        inline: true,
      },
      homePhone: {
        name: "homePhone",
        rules: "required|min:2|max:200",
        label: this.$t("personalDetails.homePhone"),
        preSelected: this.personalDetails?.data?.customerDetails?.homePhone,
        disabled: this.formIsLoading,
        inline: true,
      },
      mobilePhone: {
        name: "mobilePhone",
        rules: "required|min:8|max:13|countryCode",
        label: this.$t("personalDetails.mobilePhone"),
        preSelected: this.personalDetails?.data?.customerDetails?.mobilePhone,
        disabled: this.formIsLoading,
        inlineIcon: "phone",
        inline: true,
        hint: "Must be country code prefix format e.g +447957123456",
        minLabelWidth: 180,
        appendIcon: "mdi-pencil",
      },
      mobilePhoneConfirm: {
        name: "mobilePhoneConfirm",
        rules: "required|min:8|max:13|countryCode|mobileNumberIsNotEqualToMobileConfirmField:@mobilePhone",
        label: this.$t("personalDetails.mobilePhoneConfirm"),
        disabled: this.formIsLoading,
        inlineIcon: "phone",
        inline: true,
        hint: "Please confirm your new mobile number",
        minLabelWidth: 180,
      },
      addressLine1: {
        name: "addressLine1",
        rules: "required|min:2|max:200",
        label: this.$t("personalDetails.addressLine1"),
        preSelected: this.personalDetails?.data?.customerDetails?.address
          ?.line1,
        disabled: this.formIsLoading,
        inline: true,
      },
      addressLine2: {
        name: "addressLine2",
        rules: "min:2|max:200",
        label: this.$t("personalDetails.addressLine2"),
        preSelected: this.personalDetails?.data?.customerDetails?.address
          ?.line2,
        disabled: this.formIsLoading,
        inline: true,
      },
      addressLine3: {
        name: "addressLine3",
        rules: "required|min:2|max:200",
        label: this.$t("personalDetails.addressLine3"),
        preSelected: this.personalDetails?.data?.customerDetails?.address
          ?.line3,
        disabled: this.formIsLoading,
        inline: true,
      },
      postalCode: {
        name: "addresspc",
        rules: "required|min:2|max:200",
        label: this.$t("personalDetails.postalCode"),
        hint: "This is a hint",
        preSelected: this.personalDetails?.data?.customerDetails?.address
          ?.postalCode,
        disabled: this.formIsLoading,
        inline: true,
      },
      country: {
        name: "country",
        rules: "required|min:2|max:200",
        label: this.$t("personalDetails.country"),
        items: this.countryList,
        preSelected: this.personalDetails?.data?.customerDetails?.address
          ?.country,
        disabled: this.formIsLoading,
        inline: true,
      },
    };
  }

  get formIsError() {
    return this.noop?.errorMessage;
  }

  get formIsLoading() {
    return this.noop?.loading;
  }

  get countryList() {
    return JSON.parse(JSON.stringify(this.$t("countries"))).map((country) => {
      return {
        label: country.label,
        value: country.alpha2Code,
      };
    });
  }

  get isChangedMobile() {
    return this.formItems?.mobilePhone?.valueChanged;
  }

  get isChangedEmail() {
    return this.formItems?.email?.valueChanged;
  }

  get isPwRequired() {
    return (
      (this.isChangedMobile || this.isChangedEmail) &&
      (this.formItems?.mobilePhoneConfirm || this.formItems?.emailConfirm)
    );
  }

  get mapPayload(): PersonalDetailsPayloadInterface {
    return {
      email: this.formItems?.email?.value,
      mobilePhone: this.formItems?.mobilePhone?.value,
      passwordForVerification: this.formItems?.password?.value,
      validateOnly: false
    };
  }

  created(): void {
    try {
      this.clearNoop();
      this.getPersonalDetails();
    } catch (e) {
      console.log(e);
    }
  }

  handleOtpFormInvalid(invalid: boolean): void {
    this.formOtpInvalid = invalid;
  }

  handleOtpPasscode(): void {
   
      (this.$refs.otp as Vue & { handleSubmit: () => void }).handleSubmit();
   
  }

async handleOtpVerfified(): Promise<void> {
    this.$modal.hide("otp");
    try {
      const payload = this.mapPayload;
      payload.validateOnly = false;
      
      this.incorrectPasswordAttemptCounter = 0;

      await this.updatePersonalDetails(payload);
      this.formSuccessMsg = true;
    } catch (e) {
      throw new Error(e);
    }
  }

  async handleSubmit(): Promise<void> {
    try {

      const payload = this.mapPayload;
      payload.validateOnly = true;

      if (this.incorrectPasswordAttemptCounter >= this.incorrectPasswordAttempt) {
        TokensContext.instance.clearTokens();
        router().push({ name: "SessionExpired" });
      }
      else {
        await this.updatePersonalDetails(this.mapPayload);
      }
      try {
        await (this.$refs.form as Vue & { validate: () => void }).validate();
        this.$modal.show("otp");
      }
      catch (e) {
        this.incorrectPasswordAttemptCounter++;
        this.formSuccessMsg = false;
        console.log(e);
      }

    } catch (e) {
      this.incorrectPasswordAttemptCounter++;
      this.formSuccessMsg = false;
      throw new Error(e);
    }
  }

  handleCancel() {
    this.formItems = {};
    (this.$refs.form as Vue & { reset: () => void }).reset();
  }

  handleAppendClick(element){
    var actualElement = this.$refs[element];
    (actualElement as Vue & { setFocus: () => void }).setFocus();
  }

  reset() {
    this.componentFormKey += 1;
    this.formItems = {};
    this.clearNoop();
  }
}
</script>

<style lang="scss" scoped>
.address {
  font-style: normal;
}
</style>
