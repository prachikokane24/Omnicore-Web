<template>
  <OInfoCard :title="$t('marketing.marketingPreferences')">
    <OText type="p">{{ $t("marketing.intro") }}</OText>
    <div
      v-for="{ questionId, question, optedIn } in mapQuestions"
      :key="questionId"
    >
      <OFormSwitch
        v-model="formItems[questionId]"
        :name="`q${questionId}`"
        :preSelected="optedIn == 'allowed' ? true : false"
        :label="question"
        :hide-details="true"
        @change="handleSubmit"
      /><br />
    </div>
  </OInfoCard>
</template>

<script lang="ts">
import { mapGetters } from "vuex";
import { Component, Vue, Watch } from "vue-property-decorator";
import { Action, namespace } from "vuex-class";
import { BaseStateInterface } from "@/types/store.types";
const marketingPreferencesModule = namespace("marketingPreferencesModule");

interface AnyObject {
  [key: string]: any;
}

interface FormItem {
  title?: string;
  name: string;
  rules: string;
  label?: string | unknown;
  hint?: string | unknown;
  preSelected?: string;
  disabled?: boolean;
  inset?: boolean;
}

interface MarketingConfig {
  offersUs: FormItem;
  offersOthers: FormItem;
}

@Component({
  components: {
    OFormSwitch: () => import("@/components/lib/Form/OFormSwitch.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OInfoCard: () => import("@/components/lib/OInfoCard.vue"),
  },
})
export default class MarketingPreferences extends Vue {
  @marketingPreferencesModule.State
  marketingPreferences!: BaseStateInterface;

  @marketingPreferencesModule.State
  noop!: BaseStateInterface;

  @Action("marketingPreferencesModule/GET_MARKETING_PREFERENCES")
  getMarketingPreferences!: () => string;

  @Action("marketingPreferencesModule/UPDATE_MARKETING_PREFERENCES")
  updateMarketingPreferences!: (payload) => string;

  formItems: AnyObject = {};

  created() {
    this.getMarketingPreferences();
  }

  get formIsLoading(): boolean {
    return this.marketingPreferences?.loading || this.noop?.loading;
  }

  get mapQuestions() {
    return this.marketingPreferences?.data?.marketingPreferences || [];
  }

  get mapPayload() {
    const items = this.formItems;
    const payload = Object.keys(items).map((key, index) => {
      return {
        questionId: parseInt(key),
        optedIn: items[key]["value"] ? "allowed" : "notallowed",
        optedInChannels: ["email"],
      };
    });
    return {
      marketingPreferences: payload,
    };
  }

  async handleSubmit() {
    try {
      await this.$nextTick();
      await this.updateMarketingPreferences(this.mapPayload);
    } catch (e) {
      console.log(e);
    }
  }
}
</script>



