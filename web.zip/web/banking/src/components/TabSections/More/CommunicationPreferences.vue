<template>
  <div>Communication Preferences</div>
</template>

<script lang="ts">
import { Vue, Component } from "vue-property-decorator";
@Component({})
export default class CommunicationPreferences extends Vue {}
</script>

<style lang="scss" scoped></style>
