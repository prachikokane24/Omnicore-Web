<template>
  <OInfoCard :title="$t('changePassword.heading')">
    <div v-if="!passwordUpdated">
      <OText type="p">
        {{ $t("changePassword.rules") }}
      </OText>
      <OText type="p">
        {{ $t("changePassword.rule1") }}<br />
        {{ $t("changePassword.rule2") }}<br />
        {{ $t("changePassword.rule3") }}<br />
        {{ $t("changePassword.rule4") }}
      </OText>
    </div>
    <OAlert
      type="success"
      v-if="passwordUpdated"
      data-id="changePasswordSuccessMsg"
      ><OText size="sm" medium>{{
        $t("changePassword.confirm")
      }}</OText></OAlert
    >
    <OForm
      ref="form"
      @submit="handleSubmit"
      @cancel="handleCancel"
      :submit-text="$t('changePassword.updateBtn')"
      :loading="formIsLoading"
      data-id="changePasswordForm"
      max-width="600"
      v-else
    >
      <OFormInput
        ref="currentPass"
        data-id="changePasswordCurrentPassword"
        v-bind="formConfig.currentPass"
        v-model.trim="formItems.currentPass"
      />
      <OFormInput
        ref="newPass"
        data-id="changePasswordNewPassword"
        v-bind="formConfig.newPass"
        v-model.trim="formItems.newPass"
      />
      <OFormInput
        ref="newPassConfirm"
        data-id="changePasswordConfirmNewPassword"
        v-bind="formConfig.newPassConfirm"
        v-model.trim="formItems.newPassConfirm"
      />
      <template #footer>
        <OAlert type="error" v-if="formIsError" dismissible>
          {{ formIsError }}
        </OAlert>
      </template>
    </OForm>

    <!-- OTP Verification Modal -->
    <OModalConfirmCancel
      id="otpChangePwd"
      :loading="verifyOtp.loading"
      @confirm="handleOtpPasscode"
      dataIdConfirmBtn="changePasswordVerifyOTPBtn"
      dataIdCancelBtn="changePasswordCancelOTPBtn"
      :confirmDisabled="formOtpInvalid"
      :confirmText="$t('payees.modalOtpConfirm')"
    >
      <Otp
        ref="otpChangePwd"
        @verified="handleOtpVerfified"
        :hideActions="true"
      />
    </OModalConfirmCancel>
  </OInfoCard>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import { Action, namespace } from "vuex-class";
import {
  BaseStateInterface,
  PasswordPayloadInterface,
} from "@/types/store.types";

const userModule = namespace("userModule");
const otpModule = namespace("otpModule");

interface FormItem {
  name: string;
  rules: string;
  label?: string | unknown;
  hint?: string | unknown;
  type?: string;
  disabled?: boolean;
}

interface NewPassDetailsConfig {
  currentPass: FormItem;
  newPass: FormItem;
  newPassConfirm: FormItem;
}

interface AnyObject {
  [key: string]: any;
}

@Component({
  components: {
    OForm: () => import("@/components/lib/Form/OForm.vue"),
    OFormInput: () => import("@/components/lib/Form/OFormInput.vue"),
    OFormSelect: () => import("@/components/lib/Form/OFormSelect.vue"),
    OFormDOB: () => import("@/components/lib/Form/OFormDOB.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
    OAlign: () => import("@/components/lib/OAlign.vue"),
    OInfoCard: () => import("@/components/lib/OInfoCard.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OIcon: () => import("@/components/lib/OIcon.vue"),
    OButton: () => import("@/components/lib/OButton.vue"),
    OFilter: () => import("@/components/lib/OFilter.vue"),
    Otp: () => import("@/components/Form/Otp/Otp.vue"),
    OModalConfirmCancel: () =>
      import("@/components/lib/Modal/OModalConfirmCancel.vue"),
  },
})
export default class ChangePassword extends Vue {
  formItems: AnyObject = {};
  formOtpInvalid = false;
  passwordUpdated = false;
  
  @userModule.State
  private noop!: BaseStateInterface;

  @otpModule.State
  public verifyOtp!: BaseStateInterface;

  @Action("userModule/CLEAR_NOOP")
  clearNoop!: () => string;

  @Action("userModule/UPDATE_USER_PASSWORD")
  updatePassword!: (payload: PasswordPayloadInterface) => string;

  get formConfig(): NewPassDetailsConfig {
    return {
      currentPass: {
        name: "currentPass",
        rules: "required|min:8",
        label: this.$t("changePassword.currentPassword"),
        type: "password",
      },
      newPass: {
        name: "newPassword",
        rules: `required|hasAtLeast8Chars|isEqualToCurrentpassword:@currentPass|hasPasswordComplexity`,        
        label: this.$t("changePassword.newPassword"),
        type: "password",
      },
      newPassConfirm: {
        name: "newPasswordConfirm",
        rules: "required|hasAtLeast8Chars|isNotEqualTo:@newPassword",
        label: this.$t("changePassword.newPasswordConfirm"),
        type: "password",
      },
    };
  }

  get formIsError() {   
    return this.noop?.errorMessage;
  }

  get formIsLoading() {
    return this.noop?.loading;
  }

  get mapPayload(): PasswordPayloadInterface {
    return {
      oldPassword: this.formItems?.currentPass?.value,
      newPassword: this.formItems?.newPass?.value,
      validateOnly: false
    };
  }

  mounted(): void{
    this.clearNoop(); 
  }
  
  handleOtpPasscode(): void {
    (this.$refs.otpChangePwd as Vue & {
      handleSubmit: () => void;
    }).handleSubmit();
  }

  async handleOtpVerfified(): Promise<void> {
    this.$modal.hide("otpChangePwd");
    try {
      const payload = this.mapPayload;
      payload.validateOnly = false;
      await this.updatePassword(payload);
      this.passwordUpdated = true;
    } catch (e) {
      throw new Error(e);
    }
  }

  async handleSubmit(): Promise<void> {
    try {
      const payload = this.mapPayload;
      payload.validateOnly = true;
      await this.updatePassword(payload);
      try {
        await (this.$refs.form as Vue & { validate: () => void }).validate();
        this.$modal.show("otpChangePwd");
      } catch (e) {
        console.log(e);
      }
    } catch (e) {     
      throw new Error(e);
    }
  }

  handleCancel() {
    this.formItems = {};   
    (this.$refs.form as Vue & { reset: () => void }).reset(); // dive into the form component and clear the form data     
  }
}
</script>

