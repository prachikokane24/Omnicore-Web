<template>
  <div>
    <OModalConfirmCancel
      v-bind="[$attrs, $props]"
      @confirm="handleConfirm"
      @cancel="handleCancel"
      @show="handleClear"
    >
      <template v-slot:header>{{
        $t("directdebits.cancelModalHeading")
      }}</template>
      <OText type="p" class="pb-3"
        ><span v-html="$t('directdebits.cancelModalContent')"
      /></OText>
      <ODefinitionList :items="listItems">
        <template v-slot:amount="{ value }">{{ value | currency }}</template>
        <template v-slot:lastPaidDate="{ value }">{{
          value | date("long")
        }}</template>
        <template v-slot:reference="{ value }">{{
          value | capsFirstLetter
        }}</template>
      </ODefinitionList>
      <OAlert type="error" class="mt-4" v-if="formError"
        ><OText type="div" size="sm" medium
          ><strong>{{ $t("directdebits.modalCancelError") }}</strong></OText
        ></OAlert
      >
    </OModalConfirmCancel>
    <OModalConfirm
      id="cancelDirectDebitConfirmed"
      :message="$t('directdebits.cancelMessage')"
    />
  </div>
</template>
<script lang="ts">
import { Component, Vue, Prop } from "vue-property-decorator";
import { Action, namespace } from "vuex-class";
import { BaseStateInterface } from "@/types/store.types";
import { DirectDebitPayload } from "@/types/common.types";

const directDebitModule = namespace("directDebitModule");

@Component({
  components: {
    OModalConfirmCancel: () =>
      import("@/components/lib/Modal/OModalConfirmCancel.vue"),
    OModalConfirm: () => import("@/components/lib/Modal/OModalConfirm.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    ODefinitionList: () => import("@/components/lib/ODefinitionList.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
  },
})
export default class ModalCancelStandingOrder extends Vue {
  @Prop() directDebit!: DirectDebitPayload;

  @directDebitModule.State
  public noop!: BaseStateInterface;

  @Action("directDebitModule/DELETE_USER_DIRECT_DEBIT")
  deleteDirectDebit!: (id) => string;

  @Action("directDebitModule/CLEAR_NOOP")
  clearNoop!: () => string;

  get formError(): string | null {
    return this.noop.errorMessage;
  }

  get listItems() {
    return [
      {
        key: "payee",
        title: this.$t("directdebits.modalPayeeName"),
        value: this.directDebit?.payeeName,
      },
      {
        key: "amount",
        title: this.$t("directdebits.modalAmountLabel"),
        value: this.directDebit?.amount?.minorUnits,
      },
      {
        key: "lastPaidDate",
        title: this.$t("directdebits.modalLastPaid"),
        value: this.directDebit?.lastPaidDate,
      },
      {
        key: "reference",
        title: this.$t("directdebits.modalReference"),
        value: this.directDebit?.reference,
      },
    ];
  }

  async handleConfirm(): Promise<void> {
    try {
      await this.deleteDirectDebit(this.directDebit.id);
      this.$modal.hide("cancelDirectDebit");
      this.$modal.show("cancelDirectDebitConfirmed");
      this.$emit("confirm");
    } catch (e) {
      throw new Error(e);
    }
  }

  handleCancel(): void {
    this.$emit("cancel");
  }

  handleClear(): void {
    this.clearNoop();
    this.$emit("show");
  }
}
</script>
