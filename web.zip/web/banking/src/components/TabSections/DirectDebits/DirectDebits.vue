<template>
  <div ref="anchorTop">
    <ODataTablePaginatorAsync
      :page-count="pageCount"
      :page-number="pageParams.pageNumber"
      :disabled="userDirectDebits.loading"
      @change="handlePageChange"
    >
      <ODataTable
        v-bind="tableConfig"
        :loading="userDirectDebits.loading"
        class="direct-debits"
      >
        <!-- <template #actions>
          <OButton @click="handleCreate" icon="plusCircleOutline">
            {{ $t("directdebits.createBtn") }}
          </OButton>
        </template> -->
        <!-- <template #filter>
          <OFilter @change="handleFilterChange" :filterConfig="filterConfig" />
        </template> -->
        <template v-slot:lastPaidDate="{ cell }">
          {{ cell | date }}
        </template>
        <template v-slot:nickname="{ cell }">
          <OText medium>
            {{ cell | capsFirstLetter }}
          </OText>
        </template>
        <template v-slot:payeeName="{ cell }">
          <OText medium>
            {{ cell | capsFirstLetter | truncate(20) }}
          </OText>
        </template>
        <template v-slot:reference="{ cell }">
          <OText medium>
            {{ cell | capsFirstLetter | truncate(20) }}
          </OText>
        </template>
        <template v-slot:amount="{ cell }">
          <span v-if="cell && cell.minorUnits">
            {{ cell.minorUnits | currency }}
          </span>
          <span v-else>N/A</span>
        </template>
        <template v-slot:status>
          {{ "Active" | capsFirstLetter }}
        </template>
        <template v-slot:action="{ row }">
          <OButton @click="handleCancel(row)"
            block
            outlined
            x-small
          >
            {{ $t("directdebits.cancelBtn") }}
          </OButton>
        </template>
      </ODataTable>
    </ODataTablePaginatorAsync>
    <!-- Cancel Direct Debit -->
    <ModalCancelDirectDebit
      id="cancelDirectDebit"
      @confirm="handleConfirmed"
      @cancel="handleCancelled"
      v-bind="cancelConfig"
    />
    <!-- Create/Update Direct Debit Modal -->
    <!-- <ModalCreateUpdateDirectDebit
      id="createEditDirectDebit"
      @confirm="handleConfirmed"
      @cancel="handleCancelled"
      v-bind="updateConfig"
    /> -->
  </div>
</template>

<script lang="ts">
import moment from "moment";
import { mapGetters } from "vuex";
import { Component, Vue } from "vue-property-decorator";
import { BaseStateInterface } from "@/types/store.types";
import { DirectDebitPayload, DirectDebitModal } from "@/types/common.types";
import { Action, namespace } from "vuex-class";
import OButton from "@/components/lib/OButton.vue";

const summaryModule = namespace("summaryModule");
const directDebitModule = namespace("directDebitModule");

interface FilterConfig {
  id: string;
  label: string;
  value: string;
}

@Component({
  components: {
    ODataTable: () => import("@/components/lib/DataTable/ODataTable.vue"),
    ODataTablePaginatorAsync: () =>
      import("@/components/lib/DataTable/ODataTablePaginatorAsync.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OFilter: () => import("@/components/lib/OFilter.vue"),
    OIcon: () => import("@/components/lib/OIcon.vue"),
    OFormSelect: () => import("@/components/lib/Form/OFormSelect.vue"),
    ModalCancelDirectDebit: () => import("./Modals/ModalCancelDirectDebit.vue"),
    ModalCreateUpdateDirectDebit: () =>
      import("./Modals/ModalCreateUpdateDirectDebit.vue"),
    OButton,
  },
  computed: {
    ...mapGetters("summaryModule", {
      getSelectedUserAccountWallets: "getSelectedUserAccountWallets",
    }),
  },
})
export default class DirectDebits extends Vue {
  getSelectedUserAccountWallets!: any;
  directDebit = null as any;

  pageParams = {
    pageNumber: 1,
    pageSize: 15,
  };

  filterParams = {
    walletId: "",
  };

  headers = [
    {
      text: this.$t("directdebits.table.lastPaid"),
      key: "lastPaidDate",
    },
    { text: this.$t("directdebits.table.nickName"), key: "nickname" },
    { text: this.$t("directdebits.table.payeeName"), key: "payeeName" },
    { text: this.$t("directdebits.table.reference"), key: "reference" },
    { text: this.$t("directdebits.table.amount"), key: "amount" },
    { text: this.$t("directdebits.table.status"), key: "status" },
    { key: "action" },
  ];

  // mapState
  @summaryModule.State
  public accountSummary!: BaseStateInterface;

  @directDebitModule.State
  public userDirectDebits!: BaseStateInterface;

  @directDebitModule.State
  public noop!: BaseStateInterface;

  // mapActions
  @Action("directDebitModule/GET_USER_DIRECT_DEBITS")
  getUserDirectDebits!: (payload) => string;

  get filterConfig() {
    return [
      {
        name: "wallet",
        type: "select",
        label: "Filter By Wallet",
        preSelected: 0,
        maxWidth: "170px",
        items: this.mapWalletItems,
      },
    ];
  }

  get mapWalletItems(): Array<FilterConfig> {
    let allWallets = [
      {
        walletId: "",
        nickName: `${this.$t("directdebits.filterAllWallets")}`,
      },
    ];
    let wallets = this.getSelectedUserAccountWallets.wallets;
    const menuItems = allWallets.concat(wallets);
    return (
      menuItems.map(({ walletId, nickName }) => {
        return {
          id: walletId,
          label: nickName,
          value: walletId,
        };
      }) || []
    );
  }

  get cancelConfig(): DirectDebitModal {
    return {
      loading: this.noop?.loading,
      cancelText: this.$t("directdebits.cancelBtnModal"),
      directDebit: this.directDebit,
    };
  }
  get updateConfig(): DirectDebitModal {
    return {
      loading: this.noop?.loading,
      cancelText: this.$t("directdebits.cancelBtnModal"),
      directDebit: this.directDebit,
    };
  }

  get tableConfig() {
    return {
      heading: this.$t("directdebits.title"),
      headers: this.headers,
      items: this.mapAccounts,
    };
  }

  get pageSize(): number {
    return (
      this.userDirectDebits?.data?.paginationData?.pageSize ||
      this.pageParams.pageSize
    );
  }

  get pageCount(): number {
    return this.userDirectDebits?.data?.paginationData?.pageCount || 0;
  }

  get mapAccounts() {
    return this.userDirectDebits?.data?.directDebits?.map((item) => {
      const account =
        Object.values(this.accountSummary?.data?.accounts).find(
          (o: any) => o.accountNumber === item.fromWalletName
        ) || {};
      return {
        ...item,
        account: account,
      };
    });
  }

  get mapPageParamsPayload(): {
    pageNumber: number;
    pageSize: number;
    walletId: string;
  } {
    return {
      pageNumber: this.pageParams.pageNumber,
      pageSize: this.pageSize,
      walletId: this.filterParams.walletId,
    };
  }

  created(): void {
    this.getUserDirectDebits(this.mapPageParamsPayload);
  }

  handleCreate() {
    this.$modal.show("createEditDirectDebit");
  }

  handleCancel({
    id,
    payeeName,
    fromAccount,
    lastPaidDate,
    amount,
    reference,
    status,
  }: DirectDebitPayload): void {
    this.directDebit = {
      id,
      payeeName,
      fromAccount,
      lastPaidDate,
      amount,
      reference,
      status,
    };
    this.$modal.show("cancelDirectDebit");
  }

  handlePageChange(val: number): void {
    var element: any = this.$refs["anchorTop"];
    var top = element.offsetTop;
    window.scrollTo(0, top);
    this.pageParams.pageNumber = val;
    this.getUserDirectDebits(this.mapPageParamsPayload);
  }

  handleFilterChange(val: {
    wallet: {
      value: string;
    };
  }): void {
    this.pageParams.pageNumber = 1;
    this.filterParams.walletId = val.wallet.value;
    this.getUserDirectDebits(this.mapPageParamsPayload);
  }

  handleConfirmed(): void {
    this.pageParams.pageNumber = 1;
    this.getUserDirectDebits(this.mapPageParamsPayload);
  }

  handleCancelled(): void {
    this.getUserDirectDebits(this.mapPageParamsPayload);
  }
}
</script>
<style lang="scss" scoped>
.direct-debits {
  background-color: white;
}
</style>
