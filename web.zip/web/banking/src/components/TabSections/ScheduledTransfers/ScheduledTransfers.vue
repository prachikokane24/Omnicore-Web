<template>
  <div ref="anchorTop">
    <ODataTablePaginatorAsync
      :page-count="pageCount"
      :page-number="pageParams.pageNumber"
      :disabled="userScheduledTransfers.loading"
      @change="handlePageChange"
    >
      <ODataTable
        v-bind="tableConfig"
        @cellClick="handleCellClick"
        @rowClick="handleRowClick"
        :loading="userScheduledTransfers.loading"
        class="scheduled-orders"
      >
        <template #actions>
          <OButton @click="handleCreate" icon="plusCircleOutline">
            {{ $t("scheduledtransfers.createBtn") }}
          </OButton>
        </template>
        <template #filter>
          <OFilter @change="handleFilterChange" :filterConfig="filterConfig" />
        </template>
        <template v-slot:nextDate="{ cell }">
          {{ cell | date }}
        </template>
        <template v-slot:fromWalletName="{ cell }">
          <OText medium>
            {{ cell | capsFirstLetter | truncate(20) }}
          </OText>
        </template>
        <template v-slot:toWalletName="{ cell }">
          <OText medium>
            {{ cell | capsFirstLetter | truncate(20) }}
          </OText>
        </template>
        <template v-slot:amount="{ cell }">
          {{ cell.minorUnits | currency }}
        </template>
        <template v-slot:frequency="{ cell }">
          {{ cell | capsFirstLetter }}
        </template>
        <template v-slot:reference="{ cell }">
          {{ cell | capsFirstLetter }}
        </template>
        <template v-slot:action="{ row }">
          <OButtonGroup :fluid="true">
            <OButton @click="handleCancel(row)"
              block
              outlined
              x-small
            >
              {{ $t("scheduledtransfers.cancelBtn") }}
            </OButton>
            <OButton @click="handleEdit(row)"
              block
              outlined
              x-small
            >
              {{ $t("scheduledtransfers.editBtn") }}
            </OButton>
          </OButtonGroup>
        </template>
      </ODataTable>
    </ODataTablePaginatorAsync>
    <!-- Cancel Modal -->
    <ModalCancelScheduledTransfer
      id="cancelScheduledTransfer"
      @confirm="handleConfirmed"
      @cancel="handleCancelled"
      @show="handleShow"
      v-bind="cancelConfig"
    />
    <!-- Create/Edit Modal -->
    <ModalCreateEditScheduledTransfer
      id="createEditScheduledTransfer"
      @confirm="handleConfirmed"
      @cancel="handleCancelled"
      @show="handleShow"
      v-bind="updateConfig"
    />
  </div>
</template>

<script lang="ts">
import moment from "moment";
import { mapGetters } from "vuex";
import { Component, Vue } from "vue-property-decorator";
import { BaseStateInterface } from "@/types/store.types";
import {
  ScheduledTransferPayload,
  ScheduledTransferModal,
} from "@/types/common.types";
import { Action, namespace } from "vuex-class";
import OButton from "@/components/lib/OButton.vue";
import OButtonGroup from "@/components/lib/OButtonGroup.vue";
const scheduledTransferModule = namespace("scheduledTransferModule");

interface FilterConfig {
  id: string;
  label: string;
  value: string;
}

@Component({
  components: {
    ODataTable: () => import("@/components/lib/DataTable/ODataTable.vue"),
    ODataTablePaginatorAsync: () =>
      import("@/components/lib/DataTable/ODataTablePaginatorAsync.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OFilter: () => import("@/components/lib/OFilter.vue"),
    OIcon: () => import("@/components/lib/OIcon.vue"),
    OFormSelect: () => import("@/components/lib/Form/OFormSelect.vue"),
    OModalConfirmCancel: () =>
      import("@/components/lib/Modal/OModalConfirmCancel.vue"),
    ModalCancelScheduledTransfer: () =>
      import("./Modals/ModalCancelScheduledTransfer.vue"),
    ModalCreateEditScheduledTransfer: () =>
      import("./Modals/ModalCreateEditScheduledTransfer.vue"),
    OButton,
    OButtonGroup,
  },
  computed: {
    ...mapGetters("summaryModule", {
      getSelectedUserAccountWallets: "getSelectedUserAccountWallets",
    }),
  },
})
export default class ScheduledTransfers extends Vue {
  getSelectedUserAccountWallets!: any;
  modalEditScheduledTransferKey = 0;
  scheduledTransfer = null as any;
  isEdit = false;

  pageParams = {
    pageNumber: 1,
    pageSize: 15,
  };

  filterParams = {
    walletId: "",
  };

  headers = [
    {
      text: this.$t("scheduledtransfers.headerDueDate"),
      key: "nextDate",
    },
    {
      text: this.$t("scheduledtransfers.headerTransferFrom"),
      key: "fromWalletName",
    },
    {
      text: this.$t("scheduledtransfers.headerTransferTo"),
      key: "toWalletName",
    },
    { text: this.$t("scheduledtransfers.headerAmount"), key: "amount" },
    { text: this.$t("scheduledtransfers.headerFrequency"), key: "frequency" },
    { text: this.$t("scheduledtransfers.headerReference"), key: "paymentNote" },
    { text: "", key: "action" },
  ];

  // mapState
  @scheduledTransferModule.State
  public userScheduledTransfers!: BaseStateInterface;

  @scheduledTransferModule.State
  public userScheduledTransfer!: BaseStateInterface;

  @scheduledTransferModule.State
  public userDeleteScheduledTransfer!: BaseStateInterface;

  @scheduledTransferModule.State
  public noop!: BaseStateInterface;

  // mapActions
  @Action("scheduledTransferModule/GET_USER_SCHEDULED_TRANSFERS")
  getUserScheduledTransfers!: (payload) => string;

  @Action("scheduledTransferModule/GET_USER_SCHEDULED_TRANSFER")
  getUserScheduledTransfer!: (payload) => string;

  @Action("scheduledTransferModule/DELETE_USER_SCHEDULED_TRANSFER")
  deleteUserScheduledTransfer!: (id) => string;

  @Action("scheduledTransferModule/CLEAR_DELETE_SCHEDULED_TRANSFER")
  clearUserScheduledTransfer!: () => string;

  get filterConfig() {
    return [
      {
        name: "wallet",
        type: "select",
        label: "Filter By Wallet",
        preSelected: 0,
        maxWidth: "170px",
        items: this.mapWalletItems,
      },
    ];
  }

  get mapWalletItems(): Array<FilterConfig> {
    let allWallets = [
      {
        walletId: "",
        nickName: `${this.$t("scheduledtransfers.filterAllWallets")}`,
      },
    ];
    let wallets = this.getSelectedUserAccountWallets.wallets;
    const menuItems = allWallets.concat(wallets);
    return (
      menuItems.map(({ walletId, nickName }) => {
        return {
          id: walletId,
          label: nickName,
          value: walletId,
        };
      }) || []
    );
  }

  get cancelConfig(): ScheduledTransferModal {
    return {
      loading: this.noop?.loading,    
      cancelText: this.$t("scheduledtransfers.cancelBtnModal"),
      isEdit: this.isEdit,
      scheduledTransfer: this.scheduledTransfer,
    };
  }

  get updateConfig(): ScheduledTransferModal {
    return {
      loading: this.noop?.loading,     
      cancelText: this.$t("scheduledtransfers.cancelBtnModal"),
      isEdit: this.isEdit,
      scheduledTransfer: this.scheduledTransfer,
    };
  }

  get tableConfig() {
    return {
      heading: this.$t("scheduledtransfers.title"),
      headers: this.headers,
      items: this.userScheduledTransfers?.data?.scheduledTransfers,
    };
  }

  get pageSize(): number {
    return (
      this.userScheduledTransfers?.data?.paginationData?.pageSize ||
      this.pageParams.pageSize
    );
  }

  get pageCount(): number {
    return this.userScheduledTransfers?.data?.paginationData?.pageCount || 0;
  }

  get mapPageParamsPayload(): {
    pageNumber: number;
    pageSize: number;
    walletId: string;
  } {
    return {
      pageNumber: this.pageParams.pageNumber,
      pageSize: this.pageSize,
      walletId: this.filterParams.walletId,
    };
  }

  created(): void {
    this.getUserScheduledTransfers(this.mapPageParamsPayload);
  }

  handleCreate() {
    this.isEdit = false;
    this.$modal.show("createEditScheduledTransfer");
  }

  handleCancel({
    id,
    nextDate,
    startDate,
    endDate,
    fromWalletName,
    toWalletName,
    amount,
    frequency,
  }: ScheduledTransferPayload) {
    this.scheduledTransfer = {
      id,
      nextDate,
      endDate,
      fromWalletName,
      toWalletName,
      amount,
      frequency,
    };
    this.isEdit = false;

    this.$modal.show("cancelScheduledTransfer");
  }

  handleEdit({
    id,
    nextDate,
    startDate,
    endDate,
    toWalletId,
    toWalletName,
    fromWalletId,
    fromWalletName,
    paymentNote,
    amount,
    frequency,
  }: ScheduledTransferPayload): void {
    this.scheduledTransfer = {
      id,
      nextDate,
      endDate,
      startDate,
      toWalletId,
      toWalletName,
      fromWalletId,
      fromWalletName,
      paymentNote,
      amount,
      frequency,
    };
    this.isEdit = true;
    this.$modal.show("createEditScheduledTransfer");
  }

  handlePageChange(val: number): void {
    var element: any = this.$refs["anchorTop"];
    var top = element.offsetTop;
    window.scrollTo(0, top);
    this.pageParams.pageNumber = val;
    this.getUserScheduledTransfers(this.mapPageParamsPayload);
  }

  handleFilterChange(val: {
    wallet: {
      value: string;
    };
  }): void {
    this.pageParams.pageNumber = 1;
    this.filterParams.walletId = val.wallet.value;
    this.getUserScheduledTransfers(this.mapPageParamsPayload);
  }

  handleConfirmed(): void {
    this.getUserScheduledTransfers(this.mapPageParamsPayload);
  }

  handleCancelled(): void {
    this.getUserScheduledTransfers(this.mapPageParamsPayload);
  }

  handleShow(): void {
    this.clearUserScheduledTransfer();
  }

  handleCellClick(val: unknown): void {
    // console.log("cell", val); // eslint-disable-line
  }
  handleRowClick(val: unknown): void {
    //console.log("row", val); // eslint-disable-line
  }
}
</script>
<style lang="scss" scoped>
.standing-orders {
  background-color: white;
}
</style>
