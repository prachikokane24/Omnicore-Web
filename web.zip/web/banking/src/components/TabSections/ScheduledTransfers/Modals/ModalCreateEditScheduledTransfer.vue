<template>
  <div>
    <OModalConfirmCancel
      :confirmDisabled="!isEdit ? formScheduledTransferInvalid : false"
      :loading="formIsLoading"
      :error="formErrorMessage"
      :confirmText="
        formPreview
          ? $t('scheduledtransfers.modalConfirmBtn')
          : $t('scheduledtransfers.modalContinueBtn')
      "
      @confirm="handleConfirm"
      @show="reset"
      v-bind="[$attrs, $props]"
    >
      <template v-slot:header>{{
        isEdit
          ? $t("scheduledtransfers.modalHeadingEdit")
          : $t("scheduledtransfers.modalHeadingCreate")
      }}</template>
      <OText type="p" v-if="formPreview"
        ><span v-html="$t('scheduledtransfers.confirmModalContent')"
      /></OText>
      <OForm
        :loading="formIsLoading"
        data-id=""
        @invalid="handlePayeeFormInvalid"
        hide-actions
        ref="form"
        :key="componentFormKey"
      >
        <OFormSelect
          data-id=""
          v-bind="formConfig.from"
          v-model="formItems.from"
        />
        <OFormSelect 
          data-id="" 
          v-bind="formConfig.to" 
          v-model="formItems.to"  
        />
        <OFormInput
          data-id=""
          v-bind="formConfig.amount"
          v-model="formItems.amount"
        />
        <OFormInput
          data-id=""
          v-bind="formConfig.reference"
          v-model="formItems.reference"
        />
        <OFormDatePicker
          data-id=""
          v-bind="formConfig.startDate"
          v-model="formItems.startDate"
        />
        <OFormSelect
          data-id=""
          v-bind="formConfig.frequency"
          v-model="formItems.frequency"
        />
        <OFormCheckbox
          data-id=""
          v-bind="formConfig.isForever"
          v-model="formItems.isForever"
        />
        <OFormDatePicker
          data-id=""
          v-bind="formConfig.endDate"
          v-model="formItems.endDate"
          v-if="!isForever"
        />
      </OForm>
      <OButton
        data-id=""
        @click="formPreview = false"
        v-if="formPreview"
        icon="pencil"
        iconSize="xSmall"
        color="secondary"
        class="mb-2"
        >{{ $t("scheduledtransfers.modalEditBtn") }}</OButton
      >
    <OAlert type="error" v-if="formErrorMessage"
        ><OText type="div" size="sm" medium
          ><strong>{{ $t("scheduledtransfers.modalError") }}</strong></OText
        ></OAlert>   
    </OModalConfirmCancel>

    <OModalConfirm
      id="createEditConfirmed"
      :message="$t('scheduledtransfers.createdMessage')"
    />

    <OModalConfirmCancel
      id="createEditUpdated"
      :hideConfirmBtn="true"
      :cancelText="$t(`scheduledtransfers.cancelBtnModal`)"
    >
      <template v-slot:header>{{
        $t("scheduledtransfers.sscheduledTransferUpdated")
      }}</template>
      <OText type="p">{{ $t("scheduledtransfers.updatedMessage") }} </OText>
    </OModalConfirmCancel>
  </div>
</template>
<script lang="ts">
import { mapGetters } from "vuex";
import { Component, Prop, Vue } from "vue-property-decorator";
import {
  BaseStateInterface,
  ScheduledTransferCreatedPayloadInterface,
} from "@/types/store.types";
import { Action, namespace } from "vuex-class";
import { convertToMinorUnits } from "@/libs/utils";
import moment from "moment";

interface AnyObject {
  [key: string]: any;
}

interface InputConfig {
  name: string;
  rules?: string;
  label?: string | unknown;
  parentLabel?: string | unknown;
  required?: boolean;
  items?: any;
  preSelected?: unknown;
  type?: string;
  clearable?: boolean;
  hint?: string | unknown;
  placeholder?: string | unknown;
  appendIcon?: string;
  inputValue?: string;
  disabled?: boolean;
  counter?: number;
  error?: boolean;
  loading?: boolean;
  value?: string;
  prefix?: string;
  hideDetails?: boolean;
  dense?: boolean;
  preview?: boolean;
  previewValuePrefix?: unknown | string;
  persistentHint?: boolean;
}

interface FormConfig {
  from: InputConfig;
  to: InputConfig;
  amount: InputConfig;
  reference: InputConfig;
  startDate: InputConfig;
  frequency: InputConfig;
  endDate: InputConfig;
  isForever: InputConfig;
}

interface FormPayload {
  fromWalletId: string;
  toWalletId: string;
  amount: {
    MinorUnits: unknown;
    Currency: unknown;
  };
  paymentNote?: string;
  startDate: string;
  frequency: string;
  endDate?: string;
}

const scheduledTransferModule = namespace("scheduledTransferModule");
const walletModule = namespace("walletModule");

@Component({
  components: {
    OModalConfirmCancel: () =>
      import("@/components/lib/Modal/OModalConfirmCancel.vue"),
    OModalConfirm: () => import("@/components/lib/Modal/OModalConfirm.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OLink: () => import("@/components/lib/OLink.vue"),
    OIcon: () => import("@/components/lib/OIcon.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
    OButton: () => import("@/components/lib/OButton.vue"),
    OForm: () => import("@/components/lib/Form/OForm.vue"),
    OFormInput: () => import("@/components/lib/Form/OFormInput.vue"),
    OFormCheckbox: () => import("@/components/lib/Form/OFormCheckbox.vue"),
    OFormSelect: () => import("@/components/lib/Form/OFormSelect.vue"),
    OFormDatePicker: () => import("@/components/lib/Form/OFormDatePicker.vue"),
    Otp: () => import("@/components/Form/Otp/Otp.vue"),
  },
  computed: {
    ...mapGetters("summaryModule", {
      getSelectedUserAccountWallets: "getSelectedUserAccountWallets",
    }),
  },
})
export default class ModalCancelScheduledTransfer extends Vue {
  @Prop() private loading!: boolean;
  @Prop() private scheduledTransfer!: any;
  @Prop() private isEdit!: boolean;

  getSelectedUserAccountWallets!: any;

  componentFormKey = 0;
  componentOtpKey = 0;
  formItems: AnyObject = {};
  formScheduledTransferInvalid = false;
  formPreview = false;  

  @scheduledTransferModule.State
  private noop!: BaseStateInterface;

  @walletModule.State
  private walletDetails!: BaseStateInterface;

  @Action("scheduledTransferModule/CREATE_USER_SCHEDULED_TRANSFER")
  createUserScheduledTransfer!: (
    payload
  ) => ScheduledTransferCreatedPayloadInterface;

  @Action("scheduledTransferModule/UPDATE_USER_SCHEDULED_TRANSFER")
  updateUserScheduledTransfer!: (
    payload
  ) => ScheduledTransferCreatedPayloadInterface;

  @Action("scheduledTransferModule/CLEAR_NOOP")
  clearNoop!: () => string;

  get isForever(): boolean {
    return this.formItems?.isForever?.value;
  }

  get formIsLoading(): boolean {
    return this.noop?.loading || this.loading;
  }

  get formErrorMessage() {
    return this.noop?.errorMessage;
  }

  get mapWallets(): {
    id: string;
    label: string;
    value: string;
  } {
    return (
      this.getSelectedUserAccountWallets?.wallets.map(
        ({ walletId, nickName }) => {
          return {
            id: walletId,
            label: nickName,
            value: walletId,
          };
        }
      ) || []
    );
  }

  get mapPayload(): FormPayload {  
    let endDate = {};
    let id = {};

    if(this.isForever) {
      endDate = { endDate: null };
    } else if (this.formItems?.endDate?.value) {
      endDate = { endDate: this.formItems?.endDate?.value };
    }  
    if (this.scheduledTransfer?.id) {
      id = { id: this.scheduledTransfer.id };
    }
    return {
      ...id,
      ...endDate,
      fromWalletId: this.formItems?.from?.value ? this.formItems?.from?.value: this.scheduledTransfer?.fromWalletId ,
      toWalletId: this.formItems?.to?.value ? this.formItems?.to?.value: this.scheduledTransfer?.toWalletId ,
      amount: {
        MinorUnits: convertToMinorUnits(this.formItems?.amount?.value),
        Currency: this.$t("currency.currency"),
      },
      frequency: this.formItems?.frequency?.value,
      startDate: this.formItems?.startDate?.value,
      paymentNote: this.formItems?.reference?.value,
    };
  }

  get formConfig(): FormConfig {
    return {
      from: {
        name: "from",
        rules: "required",
        label: this.$t("scheduledtransfers.modalFromLabel"),
        items: this.mapWallets,
        loading: this.loading,
        preview: this.formPreview,
        preSelected: this.isEdit ? this.scheduledTransfer?.fromWalletId : null,
      },
      to: {
        name: "to",
        rules: "required|isEqualTo:@from",
        label: this.$t("scheduledtransfers.modalToLabel"),
        items: this.mapWallets,
        loading: this.loading,
        preview: this.formPreview,
        preSelected: this.isEdit ? this.scheduledTransfer?.toWalletId : null,
      },
      amount: {
        name: "amount",
        rules: `required|money:${this.$t("currency.scale")}:${this.$t(
          "currency.separator"
        )}|between:1,1000000`,
        label: this.$t("scheduledtransfers.modalAmountLabel"),
        placeholder: this.$n(0),
        loading: this.loading,
        clearable: true,
        preview: this.formPreview,
        previewValuePrefix: this.$t("currency.currencySymbol"),
        preSelected: this.isEdit
          ? this.scheduledTransfer?.amount?.majorUnits
          : null,
      },
      reference: {
        name: "reference",
        rules: "alphaNoChar|max:18",
        label: this.$t("scheduledtransfers.modalReference"),
        loading: this.loading,
        clearable: true,
        preview: this.formPreview,
        preSelected: this.isEdit ? this.scheduledTransfer?.paymentNote : null,
      },
      startDate: {
        name: "startDate",
        label: this.$t("scheduledtransfers.modalStartDate"),
        rules: "required",
        clearable: true,
        preview: this.formPreview,
        preSelected: this.isEdit ? this.scheduledTransfer?.startDate : null,
      },
      frequency: {
        name: "frequency",
        rules: "required",
        label: this.$t("scheduledtransfers.modalFrequency"),
        items: [
          {
            value: "daily",
            label: this.$t("scheduledtransfers.frequencyDaily"),
          },
          {
            value: "weekly",
            label: this.$t("scheduledtransfers.frequencyWeekly"),
          },
          {
            value: "monthly",
            label: this.$t("scheduledtransfers.frequencyMonthly"),
          },
          {
            value: "quarterly",
            label: this.$t("scheduledtransfers.frequencyQuarterly"),
          },
          {
            value: "annually",
            label: this.$t("scheduledtransfers.frequencyAnnually"),
          },
        ],
        loading: this.loading,
        preview: this.formPreview,
        preSelected: this.isEdit ? this.scheduledTransfer?.frequency : null,
      },
      isForever: {
        name: "isForever",
        parentLabel: this.$t("scheduledtransfers.modalEndDate") + ":",
        label: this.$t("scheduledtransfers.modalIsForever"),
        preview: this.formPreview,
        preSelected: this.isEdit
          ? this.scheduledTransfer?.endDate
            ? false
            : true
          : true,
      },
      endDate: {
        name: "endDate",
        label: this.$t("scheduledtransfers.modalEndDateChoose"),        
        rules: this.isForever ? "" : "required|dateIsPast:"+ moment(this.formItems?.startDate?.value).format('DD-MM-YYYY'),
        clearable: true,
        preview: this.formPreview,
        preSelected: this.isEdit ? this.scheduledTransfer?.endDate : null,
      },
    };
  }

  handlePayeeFormInvalid(invalid: boolean): void {
    this.formScheduledTransferInvalid = invalid;
  }

  async handleConfirm(): Promise<void> {
    try {
      await (this.$refs.form as Vue & { validate: () => void }).validate();
      if (this.formScheduledTransferInvalid) return;
      if (this.formPreview) {

        // this.handleOtpVerfified(); // bypass OTP for now
        if (this.isEdit) {       
          await this.updateUserScheduledTransfer(this.mapPayload);
          this.$modal.show("createEditUpdated");
        } else {
          await this.createUserScheduledTransfer(this.mapPayload);
          this.$modal.show("createEditConfirmed");
        }
        this.$modal.hide("createEditScheduledTransfer");
        this.$emit("confirm");

        return;
      }
      this.formPreview = true;
    } catch (e) {
      throw new Error(e);
    }
  }

  async reset() {
    this.componentFormKey += 1;
    this.formItems = {};
    this.formPreview = false;
    this.clearNoop();
  }
}
</script>
