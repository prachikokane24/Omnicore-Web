<template>
  <div>
    <OModalConfirmCancel
      v-bind="[$attrs, $props]"
      @confirm="handleConfirm"
      @cancel="handleCancel"
      @show="handleClear"
    >
      <template v-slot:header>{{
        $t("scheduledtransfers.cancelModalHeading")
      }}</template>
      <OText type="p"
        ><span v-html="$t('scheduledtransfers.cancelModalContent')"
      /></OText>
      <ODefinitionList :items="listItems">
        <template v-slot:fromWallet="{ value }">{{
          value | capsFirstLetter
        }}</template>
        <template v-slot:toWallet="{ value }">{{
          value | capsFirstLetter
        }}</template>
        <template v-slot:amount="{ value }">{{ value | currency }}</template>
        <template v-slot:nextDate="{ value }">{{
          value | date("long")
        }}</template>
        <template v-slot:frequency="{ value }">{{
          value | capsFirstLetter
        }}</template>
      </ODefinitionList>
      <OAlert type="error" class="mt-4" v-if="formError"
        ><OText type="div" size="sm" medium
          ><strong>{{
            $t("scheduledtransfers.modalCancelError")
          }}</strong></OText
        ></OAlert
      >
    </OModalConfirmCancel>
    <OModalConfirmCancel
      id="cancelScheduledTransferConfirmed"
      :cancelText="$t('scheduledtransfers.cancelBtnModalOk')"
      hide-confirm-btn
    >
      <template v-slot:header
        >{{ $t("scheduledtransfers.cancelConfirmHeading") }}
        <OIcon icon="tickCircle" color="success"
      /></template>
      <OText type="p"
        ><span
          v-html="
            $t('scheduledtransfers.cancelConfirmContent', {
              from: fromWallet,
              to: toWallet,
            })
          "
      /></OText>
    </OModalConfirmCancel>
  </div>
</template>
<script lang="ts">
import { Component, Prop, Vue } from "vue-property-decorator";
import { BaseStateInterface } from "@/types/store.types";
import { Action, namespace } from "vuex-class";
import { ScheduledTransferPayload } from "@/types/common.types";

const scheduledTransferModule = namespace("scheduledTransferModule");

@Component({
  components: {
    OModalConfirmCancel: () =>
      import("@/components/lib/Modal/OModalConfirmCancel.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OIcon: () => import("@/components/lib/OIcon.vue"),
    ODefinitionList: () => import("@/components/lib/ODefinitionList.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
  },
})
export default class ModalCancelScheduledTransfer extends Vue {
  @Prop() scheduledTransfer!: ScheduledTransferPayload;

  @scheduledTransferModule.State
  public noop!: BaseStateInterface;

  @Action("scheduledTransferModule/DELETE_USER_SCHEDULED_TRANSFER")
  deleteUserScheduledTransfer!: (id) => string;

  @Action("scheduledTransferModule/CLEAR_NOOP")
  clearNoop!: () => string;

  get formError(): string | null {
    return this.noop.errorMessage;
  }

  get fromWallet(): string | null {
    return this.scheduledTransfer?.fromWalletName || null;
  }

  get toWallet(): string | null {
    return this.scheduledTransfer?.toWalletName || null;
  }

  get listItems(): any {
    return [
      {
        key: "nextDate",
        title: this.$t("scheduledtransfers.headerDueDate"),
        value: this.scheduledTransfer?.nextDate,
      },
      {
        key: "fromWallet",
        title: this.$t("scheduledtransfers.headerTransferFrom"),
        value: this.scheduledTransfer?.fromWalletName,
      },
      {
        key: "toWallet",
        title: this.$t("scheduledtransfers.headerTransferTo"),
        value: this.scheduledTransfer?.toWalletName,
      },
      {
        key: "amount",
        title: this.$t("scheduledtransfers.headerAmount"),
        value: this.scheduledTransfer?.amount?.minorUnits,
      },
      {
        key: "frequency",
        title: this.$t("scheduledtransfers.headerFrequency"),
        value: this.scheduledTransfer?.frequency,
      },
    ];
  }

  async handleConfirm(id: number): Promise<void> {
    try {
      await this.deleteUserScheduledTransfer(this.scheduledTransfer.id);
      this.$modal.hide("cancelScheduledTransfer");
      this.$modal.show("cancelScheduledTransferConfirmed");
      this.$emit("confirm");
    } catch (e) {
      throw new Error(e);
    }
  }

  handleCancel(): void {
    this.$emit("cancel");
  }

  handleClear(): void {
    this.clearNoop();
    this.$emit("show");
  }
}
</script>
