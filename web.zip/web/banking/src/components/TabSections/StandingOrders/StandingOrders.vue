<template>
  <div ref="anchorTop">
    <ODataTablePaginatorAsync
      :page-count="pageCount"
      :page-number="pageParams.pageNumber"
      :disabled="userStandingOrders.loading"
      @change="handlePageChange"
    >
      <ODataTable
        v-bind="tableConfig"
        @cellClick="handleCellClick"
        @rowClick="handleRowClick"
        :loading="userStandingOrders.loading"
        class="standing-orders"
      >
        <template #actions>
          <OButton @click="handleCreate" icon="plusCircleOutline">
            {{ $t("standingorders.createBtn") }}
          </OButton>
        </template>
        <template #filter>
          <OFilter @change="handleFilterChange" :filterConfig="filterConfig" />
        </template>
        <template v-slot:nextDate="{ cell }">
          {{ cell | date }}
        </template>
        <template v-slot:recipientName="{ cell }">
          <OText medium>
            {{ cell | capsFirstLetter | truncate(20) }}
          </OText>
        </template>
        <template v-slot:fromWalletName="{ cell }">
          <OText medium>
            {{ cell | capsFirstLetter | truncate(20) }}
          </OText>
        </template>
        <template v-slot:amount="{ cell }">
          {{ cell.minorUnits | currency }}
        </template>
        <template v-slot:frequency="{ cell }">
          {{ cell | capsFirstLetter }}
        </template>
        <template v-slot:reference="{ cell }">
          {{ cell | capsFirstLetter }}
        </template>
        <template v-slot:action="{ row }">
          <OButtonGroup :fluid="true">
            <OButton @click="handleCancel(row)"             
              block
              outlined
              x-small
            >
              {{ $t("standingorders.cancelBtn") }}
            </OButton>
            <OButton @click="handleEdit(row)"
              block
              outlined
              x-small
            >
              {{ $t("standingorders.editBtn") }}
            </OButton>
          </OButtonGroup>
        </template>
      </ODataTable>
    </ODataTablePaginatorAsync>
    <!-- Cancel Modal -->
    <ModalCancelStandingOrder
      id="cancelStandingOrder"
      @confirm="handleConfirmed"
      @cancel="handleCancelled"
      @show="handleShow"
      v-bind="cancelConfig"
    />
    <!-- Create/Update Modal -->
    <ModalCreateEditStandingOrder
      id="createEditStandingOrder"
      @confirm="handleConfirmed"
      @cancel="handleCancelled"
      @show="handleShow"
      v-bind="updateConfig"
    />
  </div>
</template>

<script lang="ts">
import { mapGetters } from "vuex";
import { Component, Vue } from "vue-property-decorator";
import { BaseStateInterface } from "@/types/store.types";
import { StandingOrderPayload, StandingOrderModal } from "@/types/common.types";
import { Action, namespace } from "vuex-class";
import OButton from "@/components/lib/OButton.vue";
import OButtonGroup from "@/components/lib/OButtonGroup.vue";

const summaryModule = namespace("summaryModule");
const standingOrderModule = namespace("standingOrderModule");

interface FilterConfig {
  id: string;
  label: string;
  value: string;
}

@Component({
  components: {
    ODataTable: () => import("@/components/lib/DataTable/ODataTable.vue"),
    ODataTablePaginatorAsync: () =>
      import("@/components/lib/DataTable/ODataTablePaginatorAsync.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OFilter: () => import("@/components/lib/OFilter.vue"),
    OIcon: () => import("@/components/lib/OIcon.vue"),
    OFormSelect: () => import("@/components/lib/Form/OFormSelect.vue"),
    ModalCancelStandingOrder: () =>
      import("./Modals/ModalCancelStandingOrder.vue"),
    ModalCreateEditStandingOrder: () =>
      import("./Modals/ModalCreateEditStandingOrder.vue"),
    OButton,
    OButtonGroup,
  },
  computed: {
    ...mapGetters("summaryModule", {
      getSelectedUserAccountWallets: "getSelectedUserAccountWallets",
    }),
  },
})
export default class StandingOrders extends Vue {
  getSelectedUserAccountWallets!: any;
  modalEditStandingOrderKey = 0;
  standingOrder = null as any;
  isEdit = false;

  pageParams = {
    pageNumber: 1,
    pageSize: 15,
  };

  filterParams = {
    walletId: "",
  };

  headers = [
    {
      text: this.$t("standingorders.table.due"),
      key: "nextDate",
    },
    { text: this.$t("standingorders.table.payee"), key: "recipientName" },
    { text: this.$t("standingorders.table.payFrom"), key: "fromWalletName" },
    { text: this.$t("standingorders.table.amount"), key: "amount" },
    { text: this.$t("standingorders.table.frequency"), key: "frequency" },
    { text: this.$t("standingorders.table.reference"), key: "paymentNote" },
    { key: "action" },
  ];

  // mapState
  @summaryModule.State
  public accountSummary!: BaseStateInterface;

  @standingOrderModule.State
  public userStandingOrders!: BaseStateInterface;

  @standingOrderModule.State
  public noop!: BaseStateInterface;

  // mapActions
  @Action("standingOrderModule/GET_USER_STANDING_ORDERS")
  getUserStandingOrders!: (payload) => string;

  get filterConfig() {
    return [
      {
        name: "wallet",
        type: "select",
        label: "Filter By Wallet",
        preSelected: 0,
        maxWidth: "170px",
        items: this.mapWalletItems,
      },
    ];
  }

  get mapWalletItems(): Array<FilterConfig> {
    let allWallets = [
      {
        walletId: "",
        nickName: `${this.$t("standingorders.filterAllWallets")}`,
      },
    ];
    let wallets = this.getSelectedUserAccountWallets.wallets;
    const menuItems = allWallets.concat(wallets);
    return (
      menuItems.map(({ walletId, nickName }) => {
        return {
          id: walletId,
          label: nickName,
          value: walletId,
        };
      }) || []
    );
  }

  get cancelConfig(): StandingOrderModal {
    return {
      loading: this.noop?.loading,
      cancelText: this.$t("standingorders.cancelBtnModal"),
      isEdit: this.isEdit,
      standingOrder: this.standingOrder,
    };
  }

  get updateConfig(): StandingOrderModal {
    return {
      loading: this.noop?.loading,
      cancelText: this.$t("standingorders.cancelBtnModal"),
      isEdit: this.isEdit,
      standingOrder: this.standingOrder,
    };
  }

  get tableConfig() {
    return {
      heading: this.$t("standingorders.title"),
      headers: this.headers,
      items: this.mapAccounts,
    };
  }

  get pageSize(): number {
    return (
      this.userStandingOrders?.data?.paginationData?.pageSize ||
      this.pageParams.pageSize
    );
  }

  get pageCount(): number {
    return this.userStandingOrders?.data?.paginationData?.pageCount || 0;
  }

  get mapAccounts() {
    return this.userStandingOrders?.data?.standingOrders?.map((item) => {
      console.log(item);
      const account =
        Object.values(this.accountSummary?.data?.accounts).find(
          (o: any) => o.accountNumber === item.fromWalletName
        ) || {};
      return {
        ...item,
        account: account,
      };
    });
  }

  get mapPageParamsPayload(): {
    pageNumber: number;
    pageSize: number;
    walletId: string;
  } {
    return {
      pageNumber: this.pageParams.pageNumber,
      pageSize: this.pageSize,
      walletId: this.filterParams.walletId,
    };
  }

  created(): void {
    this.getUserStandingOrders(this.mapPageParamsPayload);
  }

  handleCreate() {
    this.isEdit = false;
    this.$modal.show("createEditStandingOrder");
  }

  handleCancel({
    id,
    nextDate,
    startDate,
    recipientName,
    fromWalletName,
    amount,
    frequency,
    account,
  }: StandingOrderPayload): void {
    this.standingOrder = {
      id,
      nextDate,
      recipientName,
      fromWalletName,
      amount,
      frequency,
      account,
    };
    this.isEdit = false;
    this.$modal.show("cancelStandingOrder");
  }

  handleEdit({
    id,
    nextDate,
    startDate,
    endDate,
    recipientId,
    recipientName,
    fromWalletId,
    fromWalletName,
    paymentNote,
    amount,
    frequency,
    account,
  }: StandingOrderPayload): void {
    this.standingOrder = {
      id,
      nextDate,
      startDate,
      endDate,
      recipientId,
      recipientName,
      fromWalletId,
      fromWalletName,
      paymentNote,
      amount,
      frequency,
      account,
    };
    this.isEdit = true;
    this.$modal.show("createEditStandingOrder");
  }

  handlePageChange(val: number): void {
    var element: any = this.$refs["anchorTop"];
    var top = element.offsetTop;
    window.scrollTo(0, top);
    this.pageParams.pageNumber = val;
    this.getUserStandingOrders(this.mapPageParamsPayload);
  }

  handleFilterChange(val: {
    wallet: {
      value: string;
    };
  }): void {
    this.pageParams.pageNumber = 1;
    this.filterParams.walletId = val.wallet.value;
    this.getUserStandingOrders(this.mapPageParamsPayload);
  }

  handleConfirmed(): void {
    this.pageParams.pageNumber = 1;
    this.getUserStandingOrders(this.mapPageParamsPayload);
  }

  handleCancelled(): void {
    this.isEdit = false;
    this.getUserStandingOrders(this.mapPageParamsPayload);
  }

  handleShow(): void {
    // this.clearUserStandingOrder();
  }

  handleCellClick(val: unknown): void {
    // console.log("cell", val); // eslint-disable-line
  }

  handleRowClick(val: unknown): void {
    // console.log("row", val); // eslint-disable-line
  }
}
</script>
<style lang="scss" scoped>
.standing-orders {
  background-color: white;
}
</style>
