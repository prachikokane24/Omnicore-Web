<template>
  <div>
    <OModalConfirmCancel
      v-bind="[$attrs, $props]"
      @confirm="handleConfirm"
      @cancel="handleCancel"
      @show="handleClear"
    >
      <template v-slot:header>{{
        $t("standingorders.cancelModalHeading")
      }}</template>
      <OText type="p" class="pb-3"
        ><span v-html="$t('standingorders.cancelModalContent')"
      /></OText>
      <ODefinitionList :items="listItems">
        <template v-slot:amount="{ value }">{{ value | currency }}</template>
        <template v-slot:nextDate="{ value }">{{
          value | date("long")
        }}</template>
        <template v-slot:frequency="{ value }">{{
          value | capsFirstLetter
        }}</template>
      </ODefinitionList>
      <OAlert type="error" class="mt-4" v-if="formError"
        ><OText type="div" size="sm" medium
          ><strong>{{ $t("standingorders.modalCancelError") }}</strong></OText
        ></OAlert
      >
    </OModalConfirmCancel>
    <OModalConfirm
      id="cancelStandingOrderConfirmed"
      :message="$t('standingorders.cancelMessage')"
    />
  </div>
</template>
<script lang="ts">
import { Component, Vue, Prop } from "vue-property-decorator";
import { Action, namespace } from "vuex-class";
import { BaseStateInterface } from "@/types/store.types";
import { StandingOrderPayload } from "@/types/common.types";

const standingOrderModule = namespace("standingOrderModule");

@Component({
  components: {
    OModalConfirmCancel: () =>
      import("@/components/lib/Modal/OModalConfirmCancel.vue"),
    OModalConfirm: () => import("@/components/lib/Modal/OModalConfirm.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    ODefinitionList: () => import("@/components/lib/ODefinitionList.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
  },
})
export default class ModalCancelStandingOrder extends Vue {
  @Prop() standingOrder!: StandingOrderPayload;

  @standingOrderModule.State
  public noop!: BaseStateInterface;

  @Action("standingOrderModule/DELETE_USER_STANDING_ORDER")
  deleteStandingOrder!: (id) => string;

  @Action("standingOrderModule/CLEAR_NOOP")
  clearNoop!: () => string;

  get formError(): string | null {
    return this.noop.errorMessage;
  }

  get listItems() {
    return [
      {
        title: this.$t("standingorders.modalToLabel"),
        value: this.standingOrder?.recipientName,
      },
      {
        title: this.$t("standingorders.modalFromLabel"),
        value: this.standingOrder?.fromWalletName,
      },
      {
        key: "amount",
        title: this.$t("standingorders.modalAmountLabel"),
        value: this.standingOrder?.amount?.minorUnits,
      },
      {
        key: "nextDate",
        title: this.$t("standingorders.modalDueDate"),
        value: this.standingOrder?.nextDate,
      },
      {
        key: "frequency",
        title: this.$t("standingorders.modalFrequency"),
        value: this.standingOrder?.frequency,
      },
    ];
  }

  async handleConfirm(): Promise<void> {
    try {
      await this.deleteStandingOrder(this.standingOrder.id);
      this.$modal.hide("cancelStandingOrder");
      this.$modal.show("cancelStandingOrderConfirmed");
      this.$emit("confirm");
    } catch (e) {
      throw new Error(e);
    }
  }

  handleCancel(): void {
    this.$emit("cancel");
  }

  handleClear(): void {
    this.clearNoop();
    this.$emit("show");
  }
}
</script>
