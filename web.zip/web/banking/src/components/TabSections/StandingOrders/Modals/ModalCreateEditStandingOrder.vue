<template>
  <div>
    <OModalConfirmCancel
      :confirmDisabled="!isEdit ? formStandingOrderInvalid : false"
      :loading="formIsLoading"
      :error="formErrorMessage"
      :confirmText="
        formPreview
          ? $t('standingorders.modalConfirmBtn')
          : $t('standingorders.modalContinueBtn')
      "
      @confirm="handleConfirm"
      @show="reset"
      v-bind="[$attrs, $props]"
    >
      <template v-slot:header>{{
        isEdit
          ? $t("standingorders.modalHeadingEdit")
          : $t("standingorders.modalHeadingCreate")
      }}</template>
      <OText type="p" v-if="formPreview"
        ><span v-html="$t('standingorders.confirmModalContent')"
      /></OText>
      <OForm
        :loading="formIsLoading"
        data-id=""
        @invalid="handlePayeeFormInvalid"
        hide-actions
        ref="form"
        :key="componentFormKey"
      >
        <OFormSelect
          data-id=""
          v-bind="formConfig.from"
          v-model="formItems.from"
        />
        <OFormSelect
          data-id=""
          v-bind="formConfig.to"
          v-model="formItems.to"
          class="mb-6"
          v-if="this.mapPayees"
          @change="handlePayeeChange"
        />
        <!-- <OText type="p" class="mb-4" v-if="!formPreview">
          <OLink data-id="" @click.native="handleAddPayee">
            <OIcon icon="plusCircleOutline" color="primary" />
            {{ $t("standingorders.addpayee") }}
          </OLink></OText
        > -->
        <OFormInput
          data-id=""
          v-bind="formConfig.amount"
          v-model="formItems.amount"
        />

        <OFormInput
          data-id=""
          v-bind="formConfig.reference"
          v-model="formItems.reference"
        />
        <OFormDatePicker
          data-id=""
          v-bind="formConfig.startDate"
          v-model="formItems.startDate"
        />
        <OFormSelect
          data-id=""
          v-bind="formConfig.frequency"
          v-model="formItems.frequency"
        />
        <OFormCheckbox
          data-id=""
          v-bind="formConfig.isForever"
          v-model="formItems.isForever"
        />
        <OFormDatePicker
          data-id=""
          v-bind="formConfig.endDate"
          v-model="formItems.endDate"
          v-if="!isForever"
        />
      </OForm>
      <OButton
        data-id=""
        @click="formPreview = false"
        v-if="formPreview"
        icon="pencil"
        iconSize="xSmall"
        color="secondary"
        class="mb-2"
        >{{ $t("standingorders.modalEditBtn") }}</OButton
      >
      <OAlert type="error" v-if="formErrorMessage"
        ><OText type="div" size="sm" medium
          ><strong>{{ formErrorMessage }}</strong></OText
        ></OAlert
      >
    </OModalConfirmCancel>

    <!-- OTP Verification Modal -->
    <OModalConfirmCancel
      id="otpStandingOrder"
      @confirm="handleOtpPasscode"
      @show="componentOtpKey += 1"
      :loading="verifyOtp.loading"
      :confirmDisabled="formOtpInvalid"
      :confirmText="$t('standingorders.modalOtpConfirm')"
    >
      <Otp
        ref="otpStandingOrder"
        @verified="handleOtpVerfified"
        @invalid="handleOtpFormInvalid"
        :hideActions="true"
        :key="componentOtpKey"
      />
    </OModalConfirmCancel>

    <OModalConfirm
      id="createEditConfirmed"
      :message="$t('standingorders.createdMessage')"
    />

    <OModalConfirmCancel
      id="createEditUpdated"
      :hideConfirmBtn="true"
      :cancelText="$t(`standingorders.cancelBtnModal`)"
    >
      <template v-slot:header>{{
        $t("standingorders.standingOrderUpdated")
      }}</template>
      <OText type="p">{{ $t("standingorders.updatedMessage") }} </OText>
    </OModalConfirmCancel>

    <ModalAddPayee
      id="standingOrderAddPayee"
      @confirm="handleConfirmed"
      @cancel="handleCancelAddPayee"
    />
  </div>
</template>
<script lang="ts">
import { mapGetters } from "vuex";
import { Component, Prop, Vue } from "vue-property-decorator";
import {
  BaseStateInterface,
  ScheduledTransferCreatedPayloadInterface,
} from "@/types/store.types";
import { Action, namespace } from "vuex-class";
import { convertToMinorUnits } from "@/libs/utils";
import moment from "moment";

interface AnyObject {
  [key: string]: any;
}

interface InputConfig {
  name: string;
  rules?: string;
  label?: string | unknown;
  parentLabel?: string | unknown;
  required?: boolean;
  items?: any;
  preSelected?: unknown;
  type?: string;
  clearable?: boolean;
  hint?: string | unknown;
  placeholder?: string | unknown;
  appendIcon?: string;
  inputValue?: string;
  disabled?: boolean;
  counter?: number;
  error?: boolean;
  loading?: boolean;
  value?: string;
  prefix?: string;
  hideDetails?: boolean;
  dense?: boolean;
  preview?: boolean;
  previewValuePrefix?: unknown | string;
}

interface FormConfig {
  from: InputConfig;
  to: InputConfig;
  amount: InputConfig;
  reference: InputConfig;
  startDate: InputConfig;
  frequency: InputConfig;
  endDate: InputConfig;
  isForever: InputConfig;
}

interface FormPayload {
  fromWalletId: string;
  recipientId: string;
  amount: {
    MinorUnits: number | string;
    Scale: unknown;
    Currency: unknown;
  };
  paymentNote?: string;
  startDate: string;
  frequency: string;
  endDate?: string;
}

const standingOrderModule = namespace("standingOrderModule");
const payeeModule = namespace("payeeModule");
const otpModule = namespace("otpModule");
const walletModule = namespace("walletModule");

@Component({
  components: {
    OModalConfirmCancel: () =>
      import("@/components/lib/Modal/OModalConfirmCancel.vue"),
    OModalConfirm: () => import("@/components/lib/Modal/OModalConfirm.vue"),
    ModalAddPayee: () =>
      import("@/components/TabSections/More/Modals/ModalAddPayee.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OLink: () => import("@/components/lib/OLink.vue"),
    OIcon: () => import("@/components/lib/OIcon.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
    OButton: () => import("@/components/lib/OButton.vue"),
    OForm: () => import("@/components/lib/Form/OForm.vue"),
    OFormInput: () => import("@/components/lib/Form/OFormInput.vue"),
    OFormCheckbox: () => import("@/components/lib/Form/OFormCheckbox.vue"),
    OFormSelect: () => import("@/components/lib/Form/OFormSelect.vue"),
    OFormDatePicker: () => import("@/components/lib/Form/OFormDatePicker.vue"),
    Otp: () => import("@/components/Form/Otp/Otp.vue"),
  },
  computed: {
    ...mapGetters("summaryModule", {
      getSelectedUserAccountWallets: "getSelectedUserAccountWallets",
    }),
  },
})
export default class ModalCancelScheduledTransfer extends Vue {
  @Prop() private loading!: boolean;
  @Prop() private standingOrder!: any;
  @Prop() private isEdit!: boolean;

  getSelectedUserAccountWallets!: any;

  componentFormKey = 0;
  componentOtpKey = 0;
  formItems: AnyObject = {};
  formStandingOrderInvalid = false;
  formOtpInvalid = false;
  formPreview = false;
  formIsForever = true;

  @standingOrderModule.State
  private noop!: BaseStateInterface;

  @standingOrderModule.State
  private userStandingOrder!: BaseStateInterface;

  @walletModule.State
  private walletDetails!: BaseStateInterface;

  @payeeModule.State
  private userPayees!: BaseStateInterface;

  @otpModule.State
  private verifyOtp!: BaseStateInterface;

  @Action("standingOrderModule/GET_USER_STANDING_ORDER")
  getStandingOrder!: (id) => boolean;

  @Action("payeeModule/GET_USER_PAYEES")
  getPayees!: () => BaseStateInterface;

  @Action("standingOrderModule/CREATE_USER_STANDING_ORDER")
  createUserStandingOrder!: (
    payload
  ) => ScheduledTransferCreatedPayloadInterface;

  @Action("standingOrderModule/UPDATE_USER_STANDING_ORDER")
  updateUserStandingOrder!: (
    payload
  ) => ScheduledTransferCreatedPayloadInterface;

  @Action("standingOrderModule/CLEAR_NOOP")
  clearNoop!: () => string;

  get isForever(): boolean {
    return this.formItems?.isForever?.value;
  }

  get formIsLoading(): boolean {
    return this.userPayees?.loading || this.noop?.loading || this.loading;
  }

  get formErrorMessage() {
    return this.userPayees?.errorMessage || this.noop?.errorMessage;
  }

  get mapWallets(): {
    id: string;
    label: string;
    value: string;
  } {
    return (
      this.getSelectedUserAccountWallets?.wallets.map(
        ({ walletId, nickName }) => {
          return {
            id: walletId,
            label: nickName,
            value: walletId,
          };
        }
      ) || []
    );
  }

  get mapPayees(): {
    id: string;
    label: string;
    value: string;
  }[] {
    const firstItem = [{ id: "0", label: "Add Payee", value: "0" }];

    let items =
      this.userPayees?.data?.payees.map(({ payeeId, name, bankDetails }) => {
        return {
          id: payeeId,
          label: name + " (" + Vue.filter('formattedBankDetails')(bankDetails) + ")",
          value: payeeId,
        };
      }) || [];

    return [...firstItem, ...items];
  }

  get mapPayload(): FormPayload {
    let endDate = {};
    let id = {};
    if(this.isForever) {
      endDate = { endDate: null };
    } else if (this.formItems?.endDate?.value) {
      endDate = { endDate: this.formItems?.endDate?.value };
    }
    if (this.standingOrder?.id) {
      id = { id: this.standingOrder.id };
    }
    return {
      ...id,
      ...endDate,
      fromWalletId: this.formItems?.from?.value,
      recipientId: this.formItems?.to?.value,
      amount: {
        MinorUnits: convertToMinorUnits(this.formItems?.amount?.value),
        Scale: this.$t("currency.scale"),
        Currency: this.$t("currency.currency"),
      },
      frequency: this.formItems?.frequency?.value,
      startDate: this.formItems?.startDate?.value,
      paymentNote: this.formItems?.reference?.value,
    };
  }

  get formConfig(): FormConfig {
    return {
      from: {
        name: "from",
        rules: "required",
        label: this.$t("standingorders.modalFromLabel"),
        items: this.mapWallets,
        loading: this.loading,
        preview: this.formPreview,
        preSelected: this.isEdit ? this.standingOrder?.fromWalletId : null,
      },
      to: {
        name: "to",
        rules: "required",
        label: this.$t("standingorders.modalToLabel"),
        items: this.mapPayees,
        loading: this.loading,
        hideDetails: true,
        disabled: !this.mapPayees,
        preview: this.formPreview,
        preSelected: this.isEdit ? this.standingOrder?.recipientId : null,
      },
      amount: {
        name: "amount",
        rules: `required|money:${this.$t("currency.scale")}:${this.$t(
          "currency.separator"
        )}|between:1,1000000`,
        label: this.$t("standingorders.modalAmountLabel"),
        placeholder: this.$n(0),
        loading: this.loading,
        clearable: true,
        preview: this.formPreview,
        previewValuePrefix: this.$t("currency.currencySymbol"),
        preSelected: this.isEdit
          ? this.standingOrder?.amount?.majorUnits
          : null,
      },
      reference: {
        name: "reference",
        rules: "alphaNoChar|max:18|required",
        label: this.$t("standingorders.modalReference"),
        loading: this.loading,
        clearable: true,
        preview: this.formPreview,
        preSelected: this.isEdit ? this.standingOrder?.paymentNote : null,
      },
      startDate: {
        name: "startDate",
        label: this.$t("standingorders.modalStartDate"),
        rules:"required",
        clearable: true,
        preview: this.formPreview,
        preSelected: this.isEdit ? this.standingOrder?.startDate : null,
      },
      frequency: {
        name: "frequency",
        rules: "required",
        label: this.$t("standingorders.modalFrequency"),
        items: [
          {
            value: "daily",
            label: this.$t("standingorders.frequencyDaily"),
          },
          {
            value: "weekly",
            label: this.$t("standingorders.frequencyWeekly"),
          },
          {
            value: "monthly",
            label: this.$t("standingorders.frequencyMonthly"),
          },
          {
            value: "quarterly",
            label: this.$t("standingorders.frequencyQuarterly"),
          },
          {
            value: "annually",
            label: this.$t("standingorders.frequencyAnnually"),
          },
        ],
        loading: this.loading,
        preview: this.formPreview,
        preSelected: this.isEdit ? this.standingOrder?.frequency : null,
      },
      isForever: {
        name: "isForever",
        parentLabel: this.$t("standingorders.modalEndDate") + ":",
        label: this.$t("standingorders.modalIsForever"),
        preview: this.formPreview,
        preSelected: this.isEdit
          ? this.standingOrder?.endDate
            ? false
            : true
          : true,
      },
      endDate: {
        name: "endDate",
        label: this.$t("standingorders.modalEndDateChoose"),
        rules: this.isForever ? "" : "required|dateIsPast:"+ moment(this.formItems?.startDate?.value).format('DD-MM-YYYY'),
        clearable: true,
        preview: this.formPreview,
        preSelected: this.isEdit ? this.standingOrder?.endDate : null,
      },
    };
  }

  async created() {
    try {
      await this.getPayees();
    } catch (e) {
      console.log(e);
    }
  }

  handlePayeeChange(change) {
    //console.log(change);
    // if selection is add payee then close modal and redirect to more tab  
    if (change.value === "0") {
      this.$modal.hide("createEditStandingOrder");
      this.$EventBus.$emit("changeTab", 4);
    }
  }

  handleAddPayee() {
    console.log(this.$modal);
    this.$modal.show("standingOrderAddPayee");
    //this.$modal.hide("createEditStandingOrder");
  }

  handleCancelAddPayee() {
    this.$modal.show("createEditStandingOrder");
    this.$modal.hide("standingOrderAddPayee");
  }

  handleConfirmed() {
    setTimeout(() => {
      this.getPayees();
      this.$modal.show("createEditStandingOrder");
    }, 1500);
  }

  handlePayeeFormInvalid(invalid: boolean): void {
    this.formStandingOrderInvalid = invalid;
  }

  handleOtpFormInvalid(invalid: boolean): void {
    this.formOtpInvalid = invalid;
  }

  handleOtpPasscode(): void {
    this.$nextTick(() => {
      (this.$refs.otpStandingOrder as Vue & {
        handleSubmit: () => void;
      }).handleSubmit();
    });
  }

  async handleOtpVerfified(): Promise<void> {
    this.$modal.hide("otpStandingOrder");
    try {
      if (this.formStandingOrderInvalid) {
        await (this.$refs.form as Vue & { validate: () => void }).validate();
      }
      if (this.isEdit) {
        await this.updateUserStandingOrder(this.mapPayload);
        this.$modal.show("createEditUpdated");
      } else {
        await this.createUserStandingOrder(this.mapPayload);
        this.$modal.show("createEditConfirmed");
      }
      this.$modal.hide("createEditStandingOrder");
      this.$emit("confirm");
    } catch (e) {
      throw new Error(e);
    }
  }

  async handleConfirm(): Promise<void> {
    try {
      await (this.$refs.form as Vue & { validate: () => void }).validate();
      if (this.formStandingOrderInvalid) return;
      if (this.formPreview) {
        this.$modal.show("otpStandingOrder");
        return;
      }
      this.formPreview = true;
    } catch (e) {
      throw new Error(e);
    }
  }

  async reset() {
    this.componentFormKey += 1;
    this.formItems = {};
    this.formPreview = false;
    this.clearNoop();
  }
}
</script>
