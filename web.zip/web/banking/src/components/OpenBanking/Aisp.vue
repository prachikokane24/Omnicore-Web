<template>
  <div>
    <h1>
      {{ $t("openBanking.aisp.name") | uppercase }} {{ thirdPartyProviderName }}
    </h1>
    <h2>{{ $t("openBanking.aisp.consent.title") }}</h2>
    <p>{{ $t("openBanking.aisp.consent.description") }}</p>
    <ODataTable v-bind="tableConfig" :loading="isLoading">
      <template v-slot:balances="{ row }">
        <div>
          <v-checkbox
            true-value="1"
            false-value="0"
            v-model="formItems.balances[row.id]"
            :name="`${row.id}`"
            :disabled="!row.isEditable"
          ></v-checkbox>
        </div>
      </template>
      <template v-slot:transactions="{ row }">
        <div>
          <v-checkbox
            true-value="1"
            false-value="0"
            v-model="formItems.transactions[row.id]"
            :name="`${row.id}`"
            :disabled="!row.isEditable"
          ></v-checkbox>
        </div>
      </template>
    </ODataTable>
    <OAlert v-if="isError" type="error" class="mt-4"
      ><OText type="div" size="sm" medium
        ><strong>{{ isError }}</strong></OText
      ></OAlert
    >
    <OButton :disabled="isLoading" :loading="isLoading" @click="handleSubmit()"
      >Submit</OButton
    >
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from "vue-property-decorator";
import { BaseStateInterface, StorePromiseInterface } from "@/types/store.types";
import { Action, namespace } from "vuex-class";
import OButton from "@/components/lib/OButton.vue";

const openBankingModule = namespace("openBankingModule");

@Component({
  components: {
    ODataTable: () => import("@/components/lib/DataTable/ODataTable.vue"),
    OFormCheckbox: () => import("@/components/lib/Form/OFormCheckbox.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OButton,
  },
})
export default class Aisp extends Vue {
  formItems = {
    balances: {},
    transactions: {},
  };

  headers = [
    {
      text: this.$t("openBanking.aisp.consent.accountNames"),
      key: "name",
    },
    {
      text: this.$t("openBanking.aisp.consent.balances"),
      key: "balances",
    },
    {
      text: this.$t("openBanking.aisp.consent.transactions"),
      key: "transactions",
    },
  ];

  timer: ReturnType<typeof setInterval> | undefined = undefined;

  // mapState
  @openBankingModule.State
  public getOpenBankingAispConsentResponse!: BaseStateInterface;

  @openBankingModule.State
  public postOpenBankingConsentErrorResponse!: BaseStateInterface;

  @openBankingModule.State
  public noop!: BaseStateInterface;

  // mapActions
  @Action("openBankingModule/GET_OPEN_BANKING_AISP_CONSENT")
  getOpenBankingAispConsent!: (payload) => BaseStateInterface;

  @Action("openBankingModule/POST_OPEN_BANKING_AISP_CONSENT")
  postOpenBankingAispConsent!: (payload) => BaseStateInterface;

  @Action("openBankingModule/POST_OPEN_BANKING_CONSENT_ERROR")
  postOpenBankingConsentError!: (payload) => BaseStateInterface;

  @Action("openBankingModule/CLEAR_NOOP")
  clearNoop!: () => string;

  get tableConfig() {
    return {
      headers: this.headers,
      items: this.items,
    };
  }

  get items() {
    return this.getOpenBankingAispConsentResponse?.data?.accounts || [];
  }

  get thirdPartyProviderName(): string {
    return this.getOpenBankingAispConsentResponse?.data?.thirdPartyProviderName;
  }

  get accountNumber(): string {
    return this.getOpenBankingAispConsentResponse?.data?.accountNumber;
  }

  get redirectUrl(): string {
    return this.getOpenBankingAispConsentResponse?.data?.redirectUrl;
  }

  get redirectUrlOnError(): string {
    return this.postOpenBankingConsentErrorResponse?.data?.redirectUrl;
  }

  get openBankingId(): string {
    return this.$route.params.openbankingid;
  }

  get isLoading(): boolean {
    return this.noop.loading || this.getOpenBankingAispConsentResponse.loading;
  }

  get isError() {
    return (
      this.noop?.errorMessage ||
      this.getOpenBankingAispConsentResponse?.errorMessage
    );
  }

  get mapPayload() {
    let accounts = this.items.map(({ id, name, identifiers }) => {
      return {
        id,
        name,
        forBalance: this.formItems?.balances[id] == "1" ? true : false,
        forTransactions: this.formItems?.transactions[id] == "1" ? true : false,
        identifiers: identifiers,
      };
    });
    return {
      accounts: accounts,
      openBankingId: this.openBankingId,
      accountNumber: this.accountNumber,
    };
  }

  executeRedirect(redirectUrl: string) {
    window.location.href = redirectUrl;
  }

  async handleSubmit(): Promise<void> {
    try {
      await this.postOpenBankingAispConsent(this.mapPayload);
      this.executeRedirect(this.redirectUrl);
    } catch (e) {
      console.log(e);
      await this.handleOpenBankingError(e);
    }
  }

  async handleOpenBankingError(e): Promise<void> {
    if (this.isError) {
      await this.postOpenBankingConsentError({
        openBankingId: this.openBankingId,
        reason: "Post aisp consent failed " + e,
        tenantName: process.env.VUE_APP_TENANT,
      });
      this.timer = setInterval(
        this.executeRedirect,
        5000,
        this.redirectUrlOnError
      );
    }
  }

  @Watch("items")
  mapItems() {
    return this.items.forEach((item) => {
      this.formItems.balances[item.id] = item.forBalance ? "1" : "0";
      this.formItems.transactions[item.id] = item.forTransactions ? "1" : "0";
    });
  }

  async mounted(): Promise<void> {
    this.clearNoop();
    await this.getOpenBankingAispConsent(this.openBankingId);
  }

  beforeUnmount() {
    clearInterval(this.timer);
  }
}
</script>
