<template>
  <div>
    <h1>PISP {{ thirdPartyProviderName }}</h1>
    <h2>Make a payment</h2>
    <pre>
      Payment amount:
      Fee:
      Total:
    </pre>
    <p>Select an account</p>
    <OFormSelect
      data-id=""
      v-bind="formConfig.accounts"
      v-model="formItems.account"
    />
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import { BaseStateInterface } from "@/types/store.types";
import { Action, namespace } from "vuex-class";
import OButton from "@/components/lib/OButton.vue";

const openBankingModule = namespace("openBankingModule");

@Component({
  components: {
    OFormSelect: () => import("@/components/lib/Form/OFormSelect.vue"),
  },
})
export default class Pisp extends Vue {
  formItems: any = {};

  // mapState
  @openBankingModule.State
  public getOpenBankingPispConsentResponse!: BaseStateInterface;

  @openBankingModule.State
  public noop!: BaseStateInterface;

  // mapActions
  @Action("openBankingModule/GET_OPEN_BANKING_PISP_CONSENT")
  getOpenBankingPispConsent!: (payload) => BaseStateInterface;

  @Action("openBankingModule/POST_OPEN_BANKING_PISP_CONSENT")
  postOpenBankingPispConsent!: (payload) => BaseStateInterface;

  @Action("openBankingModule/CLEAR_NOOP")
  clearNoop!: () => string;

  get formConfig() {
    return {
      accounts: {
        name: "account",
        rules: "required",
        label: "Account",
        items: this.items,
        loading: this.isLoading,
        preview: null,
      },
    };
  }

  get items() {
    return (
      this.getOpenBankingPispConsentResponse?.data?.accounts.map(
        ({ id, name }) => {
          return {
            id: id,
            label: name,
            value: id,
          };
        }
      ) || []
    );
  }

  get thirdPartyProviderName(): string {
    return this.getOpenBankingPispConsentResponse?.data?.thirdPartyProviderName;
  }

  get openBankingId(): string {
    return this.$route.params.openbankingid;
  }

  get isLoading(): boolean {
    return this.noop.loading || this.getOpenBankingPispConsentResponse.loading;
  }

  get isError() {
    return (
      this.noop?.errorMessage ||
      this.getOpenBankingPispConsentResponse?.errorMessage
    );
  }

  get mapPayload() {
    return {};
  }

  async handleSubmit(): Promise<void> {
    try {
      await this.postOpenBankingPispConsent(this.mapPayload);
    } catch (e) {
      console.log(e);
    }
  }

  mounted() {
    this.clearNoop();
    this.getOpenBankingPispConsent(this.openBankingId);
  }
}
</script>