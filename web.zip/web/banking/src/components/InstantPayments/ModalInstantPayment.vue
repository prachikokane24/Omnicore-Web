<template>
  <div>
    <OModalConfirmCancel
      :confirmDisabled="formInstantPaymentInvalid"
      :loading="formIsLoading"
      :error="formErrorMessage"
      :confirmText="
        formPreview
          ? $t('instantpayment.modalConfirmBtn')
          : $t('instantpayment.modalContinueBtn')
      "
      @confirm="handleConfirm"
      @show="show"
      v-bind="[$attrs, $props]"
    >
      <template v-slot:header>{{
        $t("instantpayment.modalHeadingCreate")
      }}</template>
      <OText type="p" v-if="formPreview"
        ><span v-html="$t('instantpayment.confirmModalContent')"
      /></OText>
      <OForm
        :loading="formIsLoading"
        data-id=""
        @invalid="handlePayeeFormInvalid"
        hide-actions
        ref="form"
        :key="componentFormKey"
      >
        <OFormSelect
          data-id="instantPaymentFromAccount"
          v-bind="formConfig.from"
          v-model="formItems.from"
        />
        <OFormSelect
          data-id="instantPaymentRecipient"
          v-bind="formConfig.to"
          v-model="formItems.to"
          class="mb-2"
          v-if="this.mapPayees"
        />
        <OText type="p" class="mb-4" v-if="!formPreview">
          <OLink
            data-id="instantPaymentAddPayee"
            @click.native="handleAddPayee"
          >
            <OIcon icon="plusCircleOutline" color="primary" />
            {{ $t("instantpayment.addpayee") }}
          </OLink></OText
        >
        <OFormInput
          data-id="instantPaymentAmount"
          v-bind="formConfig.amount"
          v-model="formItems.amount"
        />

        <OFormInput
          data-id="instantPaymentReference"
          v-bind="formConfig.reference"
          v-model="formItems.reference"
        />
      </OForm>
      <OButton
        data-id=""
        @click="formPreview = false"
        v-if="formPreview"
        icon="pencil"
        iconSize="xSmall"
        color="secondary"
        class="mb-2"
        >{{ $t("instantpayment.modalEditBtn") }}</OButton
      >
      <OAlert type="error" v-if="formErrorMessage"
        ><OText type="div" size="sm" medium
          ><strong>{{ $t("instantpayment.modalError") }}</strong></OText
        ></OAlert
      >
    </OModalConfirmCancel>

    <!-- OTP Verification Modal -->
    <OModalConfirmCancel
      id="instantPaymentOtp"
      @confirm="handleOtpPasscode"
      @show="componentOtpKey += 1"
      :loading="verifyOtp.loading"
      :confirmDisabled="formOtpInvalid"
      :confirmText="$t('instantpayment.modalOtpConfirm')"
    >
      <Otp
        id="instantPaymentOtp"
        ref="instantPaymentOtp"
        @verified="handleOtpVerfified"
        @invalid="handleOtpFormInvalid"
        :hideActions="true"
        :key="componentOtpKey"
      />
    </OModalConfirmCancel>

    <OModalConfirmCancel
      id="instantPaymentConfirmed"
      :hideConfirmBtn="true"
      :cancelText="$t(`instantpayment.confirmBtn`)"
    >
      <template v-slot:header>{{
        $t("instantpayment.createdHeader")
      }}</template>
      <OText type="p">{{ $t("instantpayment.createdMessage") }} </OText>
    </OModalConfirmCancel>

    <ModalAddPayee
      id="addPayee"
      @confirm="handleConfirmed"
      @cancel="handleCancelAddPayee"
    />
  </div>
</template>
<script lang="ts">
import { mapGetters } from "vuex";
import { Component, Prop, Vue } from "vue-property-decorator";
import {
  BaseStateInterface,
  InstantPaymentCreatePayloadInterface,
} from "@/types/store.types";
import { Action, namespace } from "vuex-class";
import { convertToMinorUnits } from "@/libs/utils";

interface AnyObject {
  [key: string]: any;
}

interface InputConfig {
  name: string;
  rules?: string;
  label?: string | unknown;
  parentLabel?: string | unknown;
  required?: boolean;
  items?: any;
  preSelected?: unknown;
  type?: string;
  clearable?: boolean;
  hint?: string | unknown;
  placeholder?: string | unknown;
  appendIcon?: string;
  inputValue?: string;
  disabled?: boolean;
  counter?: number;
  error?: boolean;
  loading?: boolean;
  value?: string;
  prefix?: string;
  hideDetails?: boolean;
  dense?: boolean;
  preview?: boolean;
  previewValuePrefix?: unknown | string;
}

interface FormConfig {
  from: InputConfig;
  to: InputConfig;
  amount: InputConfig;
  reference: InputConfig;
}

interface FormPayload {
  fromWalletId: string;
  recipientId: string;
  amount: {
    MinorUnits: number | string;
    Scale: unknown;
    Currency: unknown;
  };
  paymentNote?: string;
}

const instantPaymentModule = namespace("instantPaymentModule");
const payeeModule = namespace("payeeModule");
const otpModule = namespace("otpModule");
const walletModule = namespace("walletModule");

@Component({
  components: {
    OModalConfirmCancel: () =>
      import("@/components/lib/Modal/OModalConfirmCancel.vue"),
    OModalConfirm: () => import("@/components/lib/Modal/OModalConfirm.vue"),
    ModalAddPayee: () =>
      import("@/components/TabSections/More/Modals/ModalAddPayee.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OLink: () => import("@/components/lib/OLink.vue"),
    OIcon: () => import("@/components/lib/OIcon.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
    OButton: () => import("@/components/lib/OButton.vue"),
    OForm: () => import("@/components/lib/Form/OForm.vue"),
    OFormInput: () => import("@/components/lib/Form/OFormInput.vue"),
    OFormSelect: () => import("@/components/lib/Form/OFormSelect.vue"),
    Otp: () => import("@/components/Form/Otp/Otp.vue"),
  },
  computed: {
    ...mapGetters("summaryModule", {
      getSelectedUserAccountWallets: "getSelectedUserAccountWallets",
    }),
  },
})
export default class ModalInstantPayment extends Vue {
  @Prop() private loading!: boolean;

  getSelectedUserAccountWallets!: any;

  componentFormKey = 0;
  componentOtpKey = 0;
  formItems: AnyObject = {};
  formInstantPaymentInvalid = false;
  formOtpInvalid = false;
  formPreview = false;

  @instantPaymentModule.State
  private noop!: BaseStateInterface;

  @walletModule.State
  private walletDetails!: BaseStateInterface;

  @payeeModule.State
  private userPayees!: BaseStateInterface;

  @otpModule.State
  private verifyOtp!: BaseStateInterface;

  @Action("payeeModule/GET_USER_PAYEES")
  getPayees!: () => BaseStateInterface;

  @Action("instantPaymentModule/CREATE_INSTANT_PAYMENT")
  createUserInstantPayment!: (payload) => InstantPaymentCreatePayloadInterface;

  @Action("instantPaymentModule/CLEAR_NOOP")
  clearNoop!: () => string;

  get formIsLoading(): boolean {
    return this.userPayees?.loading || this.noop?.loading || this.loading;
  }

  get formErrorMessage() {
    return this.userPayees?.errorMessage || this.noop?.errorMessage;
  }

  get mapWallets(): {
    id: string;
    label: string;
    value: string;
  } {
    return (
      this.getSelectedUserAccountWallets?.wallets?.map(
        ({ walletId, nickName }) => {
          return {
            id: walletId,
            label: nickName,
            value: walletId,
          };
        }
      ) || []
    );
  }

  get mapPayees(): {
    id: string;
    label: string;
    value: string;
  } {
    return (
      this.userPayees?.data?.payees?.map(({ payeeId, name, bankDetails }) => {
        return {
          id: payeeId,
          label: name + " (" + Vue.filter('formattedBankDetails')(bankDetails) + ")",
          value: payeeId,
        };
      }) || []
    );
  }

  get mapPayload(): FormPayload {
    let payload = {};
    if (this.formItems?.endDate?.value) {
      payload = { endDate: this.formItems?.endDate?.value };
    }
    return {
      ...payload,
      fromWalletId: this.formItems?.from?.value,
      recipientId: this.formItems?.to?.value,
      amount: {
        MinorUnits: convertToMinorUnits(this.formItems?.amount?.value),
        Scale: this.$t("currency.scale"),
        Currency: this.$t("currency.currency"),
      },
      paymentNote: this.formItems?.reference?.value,
    };
  }

  get formConfig(): FormConfig {
    return {
      from: {
        name: "from",
        rules: "required",
        label: this.$t("instantpayment.modalFromLabel"),
        items: this.mapWallets,
        loading: this.loading,
        preview: this.formPreview,
      },
      to: {
        name: "to",
        rules: "required",
        label: this.$t("instantpayment.modalToLabel"),
        items: this.mapPayees,
        loading: this.loading,
        hideDetails: true,
        disabled: !this.mapPayees,
        preview: this.formPreview,
      },
      amount: {
        name: "amount",
        rules: `required|money:${this.$t("currency.scale")}:${this.$t(
          "currency.separator"
        )}|between:1,1000000`,
        label: this.$t("instantpayment.modalAmountLabel"),
        placeholder: this.$n(0),
        loading: this.loading,
        clearable: true,
        preview: this.formPreview,
        previewValuePrefix: this.$t("currency.currencySymbol"),
      },
      reference: {
        name: "reference",
        rules: "alphaNoChar|max:18",
        label: this.$t("instantpayment.modalReference"),
        loading: this.loading,
        clearable: true,
        preview: this.formPreview,
      },
    };
  }

  handleAddPayee() {
    this.$modal.hide("instantPayment");
    this.$modal.show("addPayee");
  }

  handleCancelAddPayee() {
    this.$modal.show("instantPayment");
    this.$modal.hide("addPayee");
  }

  handleConfirmed() {
    setTimeout(() => {
      this.getPayees();
      this.$modal.show("instantPayment");
    }, 1500);
  }

  handlePayeeFormInvalid(invalid: boolean): void {
    this.formInstantPaymentInvalid = invalid;
  }

  handleOtpFormInvalid(invalid: boolean): void {
    this.formOtpInvalid = invalid;
  }

  handleOtpPasscode(): void {
    this.$nextTick(() => {
      (this.$refs.instantPaymentOtp as Vue & {
        handleSubmit: () => void;
      }).handleSubmit();
    });
  }

  async handleOtpVerfified(): Promise<void> {
    this.$modal.hide("instantPaymentOtp");
    try {
      if (this.formInstantPaymentInvalid) {
        await (this.$refs.form as Vue & { validate: () => void }).validate();
      }
      await this.createUserInstantPayment(this.mapPayload);
      this.$modal.show("instantPaymentConfirmed");
      this.$modal.hide("instantPayment");
      this.$emit("confirm");
    } catch (e) {
      throw new Error(e);
    }
  }

  async handleConfirm(): Promise<void> {
    try {
      await (this.$refs.form as Vue & { validate: () => void }).validate();
      if (this.formInstantPaymentInvalid) return;
      if (this.formPreview) {
        this.$modal.show("instantPaymentOtp");
        return;
      }
      this.formPreview = true;
    } catch (e) {
      throw new Error(e);
    }
  }

  show() {
    this.getPayees();
    this.reset();
  }

  reset() {
    this.componentFormKey += 1;
    this.formItems = {};
    this.formPreview = false;
    this.clearNoop();
  }
}
</script>
