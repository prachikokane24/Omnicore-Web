<template>
  <div>
    <OModalConfirmCancel
      :confirmDisabled="formInstantTransferInvalid"
      :loading="formIsLoading"
      :error="formErrorMessage"
      :confirmText="
        formPreview
          ? $t('instanttransfer.modalConfirmBtn')
          : $t('instanttransfer.modalContinueBtn')
      "
      @confirm="handleConfirm"
      @show="reset"
      v-bind="[$attrs, $props]"
    >
      <template v-slot:header>{{
        $t("instanttransfer.modalHeadingCreate")
      }}</template>
      <OText type="p" v-if="formPreview"
        ><span v-html="$t('instanttransfer.confirmModalContent')"
      /></OText>
      <OForm
        :loading="formIsLoading"
        data-id=""
        @invalid="handlePayeeFormInvalid"
        hide-actions
        ref="form"
        :key="componentFormKey"
      >
        <OFormSelect
          data-id="instantTransferFromAccount"
          v-bind="formConfig.from"
          v-model="formItems.from"
        />
        <OFormSelect
          data-id="instantTransferToAccount"
          v-bind="formConfig.to"
          v-model="formItems.to"
        />
        <OFormInput
          data-id="instantTransferAmount"
          v-bind="formConfig.amount"
          v-model="formItems.amount"
        />
        <OFormInput
          data-id="instantTransferReference"
          v-bind="formConfig.reference"
          v-model="formItems.reference"
        />
      </OForm>
      <OButton
        data-id=""
        @click="formPreview = false"
        v-if="formPreview"
        icon="pencil"
        iconSize="xSmall"
        color="secondary"
        class="mb-2"
        >{{ $t("instanttransfer.modalEditBtn") }}</OButton
      >
      <OAlert type="error" v-if="formErrorMessage"
        ><OText type="div" size="sm" medium
          ><strong>{{ $t("instanttransfer.modalError") }}</strong></OText
        ></OAlert
      >
    </OModalConfirmCancel>

    <!-- OTP Verification Modal -->
    <OModalConfirmCancel
      id="instantTransferOtp"
      @confirm="handleOtpPasscode"
      @show="componentOtpKey += 1"
      :loading="verifyOtp.loading"
      :confirmDisabled="formOtpInvalid"
      :confirmText="$t('instanttransfer.modalOtpConfirm')"
    >
      <Otp
        ref="instantTransferOtp"
        @verified="handleOtpVerfified"
        @invalid="handleOtpFormInvalid"
        :key="componentOtpKey"
        :hideActions="true"
      />
    </OModalConfirmCancel>

    <!-- Create / Update Confirmed Modal --->
    <OModalConfirm
      id="instantTransferConfirmed"
      :message="$t('instanttransfer.createdMessage')"
    />
  </div>
</template>
<script lang="ts">
import { mapGetters } from "vuex";
import { Component, Prop, Vue } from "vue-property-decorator";
import {
  BaseStateInterface,
  InstantTransferCreatePayloadInterface,
} from "@/types/store.types";
import { Action, namespace } from "vuex-class";
import { convertToMinorUnits } from "@/libs/utils";

interface AnyObject {
  [key: string]: any;
}

interface InputConfig {
  name: string;
  rules?: string;
  label?: string | unknown;
  parentLabel?: string | unknown;
  required?: boolean;
  items?: any;
  preSelected?: unknown;
  type?: string;
  clearable?: boolean;
  hint?: string | unknown;
  placeholder?: string | unknown;
  appendIcon?: string;
  inputValue?: string;
  disabled?: boolean;
  counter?: number;
  error?: boolean;
  loading?: boolean;
  value?: string;
  prefix?: string;
  hideDetails?: boolean;
  dense?: boolean;
  preview?: boolean;
  previewValuePrefix?: unknown | string;
  persistentHint?: boolean;
}

interface FormConfig {
  from: InputConfig;
  to: InputConfig;
  amount: InputConfig;
  reference: InputConfig;
}

interface FormPayload {
  fromWalletId: string;
  toWalletId: string;
  amount: {
    MinorUnits: unknown;
    Currency: unknown;
  };
  paymentNote?: string;
}

const instantPaymentModule = namespace("instantPaymentModule");
const payeeModule = namespace("payeeModule");
const otpModule = namespace("otpModule");
const walletModule = namespace("walletModule");

@Component({
  components: {
    OModalConfirmCancel: () =>
      import("@/components/lib/Modal/OModalConfirmCancel.vue"),
    OModalConfirm: () => import("@/components/lib/Modal/OModalConfirm.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OLink: () => import("@/components/lib/OLink.vue"),
    OIcon: () => import("@/components/lib/OIcon.vue"),
    OAlert: () => import("@/components/lib/OAlert.vue"),
    OButton: () => import("@/components/lib/OButton.vue"),
    OForm: () => import("@/components/lib/Form/OForm.vue"),
    OFormInput: () => import("@/components/lib/Form/OFormInput.vue"),
    OFormCheckbox: () => import("@/components/lib/Form/OFormCheckbox.vue"),
    OFormSelect: () => import("@/components/lib/Form/OFormSelect.vue"),
    Otp: () => import("@/components/Form/Otp/Otp.vue"),
  },
  computed: {
    ...mapGetters("summaryModule", {
      getSelectedUserAccountWallets: "getSelectedUserAccountWallets",
    }),
  },
})
export default class ModalCancelInstantPayment extends Vue {
  @Prop() private loading!: boolean;

  getSelectedUserAccountWallets!: any;

  componentFormKey = 0;
  componentOtpKey = 0;
  formItems: AnyObject = {};
  formInstantTransferInvalid = false;
  formOtpInvalid = false;
  formPreview = false;

  @instantPaymentModule.State
  private noop!: BaseStateInterface;

  @walletModule.State
  private walletDetails!: BaseStateInterface;

  @otpModule.State
  private verifyOtp!: BaseStateInterface;

  @Action("instantPaymentModule/CREATE_INSTANT_TRANSFER")
  createUserInstantPayment!: (payload) => InstantTransferCreatePayloadInterface;

  @Action("instantPaymentModule/CLEAR_NOOP")
  clearNoop!: () => string;

  get isForever(): boolean {
    return this.formItems?.isForever?.value;
  }

  get formIsLoading(): boolean {
    return this.noop?.loading || this.loading;
  }

  get formErrorMessage() {
    return this.noop?.errorMessage;
  }

  get mapWallets(): {
    id: string;
    label: string;
    value: string;
  } {
    return (
      this.getSelectedUserAccountWallets?.wallets?.map(
        ({ walletId, nickName }) => {
          return {
            id: walletId,
            label: nickName,
            value: walletId,
          };
        }
      ) || []
    );
  }

  get mapPayload(): FormPayload {
    let payload = {};
    if (this.formItems?.endDate?.value) {
      payload = { endDate: this.formItems?.endDate?.value };
    }
    return {
      ...payload,
      fromWalletId: this.formItems?.from?.value,
      toWalletId: this.formItems?.to?.value,
      amount: {
        MinorUnits: convertToMinorUnits(this.formItems?.amount?.value),
        Currency: this.$t("currency.currency"),
      },
      paymentNote: this.formItems?.reference?.value,
    };
  }

  get formConfig(): FormConfig {
    return {
      from: {
        name: "from",
        rules: "required",
        label: this.$t("instanttransfer.modalFromLabel"),
        items: this.mapWallets,
        loading: this.loading,
        preview: this.formPreview,
      },
      to: {
        name: "to",
        rules: "required|isEqualTo:@from",
        label: this.$t("instanttransfer.modalToLabel"),
        items: this.mapWallets,
        loading: this.loading,
        preview: this.formPreview,
      },
      amount: {
        name: "amount",
        rules: `required|money:${this.$t("currency.scale")}:${this.$t(
          "currency.separator"
        )}|between:1,1000000`,
        label: this.$t("instanttransfer.modalAmountLabel"),
        placeholder: this.$n(0),
        loading: this.loading,
        clearable: true,
        preview: this.formPreview,
        previewValuePrefix: this.$t("currency.currencySymbol"),
      },
      reference: {
        name: "reference",
        rules: "alphaNoChar|max:18",
        label: this.$t("instanttransfer.modalReference"),
        loading: this.loading,
        clearable: true,
        preview: this.formPreview,
      },
    };
  }

  handlePayeeFormInvalid(invalid: boolean): void {
    this.formInstantTransferInvalid = invalid;
  }

  handleOtpFormInvalid(invalid: boolean): void {
    this.formOtpInvalid = invalid;
  }

  handleOtpPasscode(): void {
    this.$nextTick(() => {
      (this.$refs.instantTransferOtp as Vue & {
        handleSubmit: () => void;
      }).handleSubmit();
    });
  }

  async handleOtpVerfified(): Promise<void> {
    this.$modal.hide("instantTransferOtp");
    try {
      if (this.formInstantTransferInvalid) {
        await (this.$refs.form as Vue & { validate: () => void }).validate();
      }
      await this.createUserInstantPayment(this.mapPayload);
      this.$modal.show("instantTransferConfirmed");
      this.$modal.hide("instantTransfer");
      this.$emit("confirm");
      
      this.$EventBus.$emit("updateAccountBalance", "singleTransferComplete");
    } catch (e) {
      throw new Error(e);
    }
  }

  async handleConfirm(): Promise<void> {
    try {
      await (this.$refs.form as Vue & { validate: () => void }).validate();
      if (this.formInstantTransferInvalid) return;
      if (this.formPreview) {
        this.handleOtpVerfified(); // skip OTP for now
        return;
      }
      this.formPreview = true;
    } catch (e) {
      throw new Error(e);
    }
  }

  reset() {
    this.componentFormKey += 1;
    this.formItems = {};
    this.formPreview = false;
    this.clearNoop();
  }
}
</script>
