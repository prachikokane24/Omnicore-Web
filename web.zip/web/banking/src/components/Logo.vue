<template>
  <OLogo v-bind="logoMap" />
</template>
<script lang="ts">
import { Component, Vue, Prop } from "vue-property-decorator";

interface logo {
  logoLight: unknown;
  logoDark: unknown;
  dark: boolean;
  maxWidth: string | number;
}
@Component({
  components: {
    OLogo: () => import("@/components/lib/OLogo.vue"),
  },
})
export default class Onboarding extends Vue {
  @Prop({ default: "logo" }) private logo!: string;
  @Prop({ default: false }) private dark!: boolean;
  @Prop() private maxWidth!: string;

  public logoLightImg = require(`@tenantAssets/${this.logo}.svg`);
  public logoDarkImg = require(`@tenantAssets/${this.logo}-dark.svg`);

  get logoMap(): logo {
    return {
      logoLight: this.logoLightImg,
      logoDark: this.logoDarkImg,
      dark: this.dark,
      maxWidth: this.maxWidth,
    };
  }
}
</script>
