<template>
  <v-alert v-bind="$props" elevation="0">
    <slot />
  </v-alert>
</template>
<script>
export default {
  props: {
    type: {
      type: String,
      default: "info",
    },
    color: {
      type: String,
    },
    icon: {
      type: [String, Boolean],
      default: undefined,
    },
    dark: {
      type: Boolean,
      default: false,
    },
    prominent: {
      type: Boolean,
      default: false,
    },
    text: {
      type: Boolean,
      default: false,
    },
    dense: {
      type: Boolean,
      default: false,
    },
    border: {
      type: String,
      default: "left",
    },
    outlined: {
      type: Boolean,
      default: false,
    },
    dismissible: {
      type: Boolean,
      default: false,
    },
    transition: {
      type: String,
      default: undefined,
    },
  },
};
</script>
