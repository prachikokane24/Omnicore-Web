<template>
  <div>
    <ValidationProvider name="checkbox" :rules="rules">
      <v-checkbox v-model="formValue" :label="label" />
    </ValidationProvider>
  </div>
</template>

<script>
import { ValidationProvider, extend } from "vee-validate";
import { required, max } from "vee-validate/dist/rules";
extend("required", {
  ...required,
  message: "This field is required",
});
extend("max", {
  ...max,
  message: "This max",
});
export default {
  name: "FormCheckbox",
  props: {
    rules: {
      type: String,
      default: "",
    },
    label: {
      type: [String],
      default: "",
    },
  },
  components: {
    ValidationProvider,
  },
  data: () => ({
    formValue: null,
  }),
  watch: {
    async formValue() {
      this.emitInput();
    },
  },
  methods: {
    async emitInput() {
      this.$emit("input", {
        type: "input",
        value: this.formValue,
        label: this.label,
      });
    },
  },
};
</script>

<style lang="scss" scoped></style>
