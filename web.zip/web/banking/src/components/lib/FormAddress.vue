<template>
  <div>
    <FormInput
      v-bind="formConfig.line1"
      v-model="formItems.line1"
      @input="emitChange"
    />
    <FormInput
      v-bind="formConfig.line2"
      v-model="formItems.line2"
      @input="emitChange"
    />
    <FormInput
      v-bind="formConfig.line3"
      v-model="formItems.line3"
      @input="emitChange"
    />
    <FormInput
      v-bind="formConfig.postalCode"
      v-model="formItems.postalCode"
      @input="emitChange"
    />
  </div>
</template>

<script>
import FormInput from "./FormInput";
export default {
  name: "FormAddress",
  components: {
    FormInput,
  },
  data() {
    return {
      formItems: {},
    };
  },
  props: {
    label: {
      type: [String],
      default: "",
    },
  },
  computed: {
    formConfig() {
      return {
        line1: {
          label: "Address line 1",
          rules: "required",
        },
        line2: {
          label: "Address line 2",
        },
        line3: {
          label: "Address line 3",
        },
        postalCode: {
          label: "Postcode",
          rules: "required",
        },
      };
    },
  },
  methods: {
    async emitChange() {
      const { line1, line2, line3, postalCode } = this.formItems;
      this.$emit("input", {
        type: "input",
        value: {
          line1,
          line2,
          line3,
          postalCode,
        },
        label: "Address",
      });
    },
  },
};
</script>

<style lang="scss" scoped></style>
