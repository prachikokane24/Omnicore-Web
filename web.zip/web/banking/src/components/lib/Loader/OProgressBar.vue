<template>
  <div></div>
</template>

<script>
export default {
  name: "OProgressBar",
  props: {
    loading: {
      type: Boolean,
      default: false,
    },
    height: {
      type: Number,
      default: 6,
    },
    indeterminate: {
      type: Boolean,
      default: true,
    },
  },
};
</script>
