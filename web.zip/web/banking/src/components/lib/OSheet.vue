<template>
  <v-sheet
    :color="color"
    :elevation="elevation"
    :height="height"
    :width="width"
  >
    <slot
  /></v-sheet>
</template>
<script>
export default {
  name: "OSheet",
  props: {
    color: {
      type: String,
      default: "white",
    },
    elevation: {
      type: Number,
      default: 0,
    },
    height: {
      type: String,
      default: "auto",
    },
    width: {
      type: String,
      default: "auto",
    },
  },
};
</script>
