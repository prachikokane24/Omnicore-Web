<template>
  <v-navigation-drawer :value="value" @input="handleChange" app class="nav">
    <OButton
      icon="menu"
      rounded
      fab
      x-small
      color="secondary"
      class="close d-lg-none"
      @click="handleChange"
    />
    <div class="logo-wrapper">
      <Logo />
    </div>
    <v-list dense expand>
      <!-- ACCOUNT ACTIONS -->
      <!--
      <v-list-group no-action prepend-icon="mdi-wallet" value="true">
        <template v-slot:activator>
          <v-list-item-title>Select Account</v-list-item-title>
        </template>
        <OAccountActions />
      </v-list-group>
      -->
      <!-- QUICK ACTIONS -->
      <v-list-group no-action prepend-icon="mdi-comment-outline" value="true">
        <template v-slot:activator>
          <v-list-item-title><h4>Quick Actions</h4></v-list-item-title>
        </template>
        <OQuickActions />
      </v-list-group>

      <v-divider inset vertical class="d-none d-sm-block"></v-divider>
      <!-- LOGOUT ACTIONS -->
      <v-list>
        <OLogoutActions />
      </v-list>
    </v-list>
    <v-container>
      <h4>Important Links</h4>
      <OImportantLinks />
    </v-container>
  </v-navigation-drawer>
</template>
<script>
import OQuickActions from "../Widgets/OQuickActions";
//import OAccountActions from "../Widgets/OAccountActions";
import OLogoutActions from "../Widgets/OLogoutActions";
import Logo from "@/components/Logo.vue";
import OButton from "../OButton.vue";
const OImportantLinks = () => import(`../Widgets/tenant-specific/${process.env.VUE_APP_TENANT}/OImportantLinks.vue`);
export default {
  name: "ONav",
  props: ["value"],
  components: {
    //OAccountActions,
    OQuickActions,
    OImportantLinks,
    OLogoutActions,
    OButton,
    Logo,
  },
  methods: {
    handleChange(val = false) {
      this.$emit("input", val);
    },
  },
};
</script>
<style lang="scss" scoped>
.nav {
  border-radius: 10px;
  margin: 20px 0 20px 20px;
  max-height: calc(100% - 5%) !important;
  transition: none;
  box-shadow: 8px 8px 10px var(--v-primary-base);
}
.logo-wrapper {
  margin: 20px;
}
.close {
  margin: 10px 10px 0 0;
  text-align: right;
}

.v-list > .container {
  position: absolute;
  bottom: 0;
  left: 0;
}

.v-list > .container > span {
  margin-left: 5px;
}

#important-links {
  margin-left: 6px !important;
}

h4 {
  color: #000;
  letter-spacing: 1px;
  font-size: 0.8em;
}

.v-list {
  flex-grow: 1;
}
</style>
