<template>
  <v-footer app>
    <slot />
  </v-footer>
</template>
<script>
export default {
  name: "OFooter",
  props: {
    color: {
      type: String,
      default: "primary",
    },
  },
};
</script>
