<template>
  <div class="top-bar">
    <OButton icon="menu" @click="handleClick" :color="color" />
    <div class="top-bar__items">
      <div class="top-bar__items-left">
        <slot name="alignLeft"></slot>
      </div>
      <div class="top-bar__items-right">
        <slot name="alignRight"></slot>
      </div>
    </div>
  </div>
</template>
<script>
import OButton from "../OButton";
export default {
  name: "OTopBar",
  components: {
    OButton,
  },
  props: {
    isOpen: {
      type: Boolean,
    },
    color: {
      type: String,
      default: "white",
    },
  },
  methods: {
    handleClick() {
      this.$emit("change", !this.isOpen);
    },
  },
};
</script>
<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";
.top-bar {
  display: flex;
  align-items: center;
  background-color: white;
  box-shadow: 8px 8px 10px var(--v-primary-base);

  padding: 15px;
  &__items {
    display: flex;
    justify-content: space-between;
    width: 100%;
    &-left {
      margin-left: 10px;
    }
  }
}
</style>
