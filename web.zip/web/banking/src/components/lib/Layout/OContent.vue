<template>
  <v-main class="main" :style="containerStyles">
    <slot />
  </v-main>
</template>
<script>
export default {
  name: "OContent",
  props: {
    maxWidth: {
      type: String,
      default: "1400px",
    },
    color: {
      type: String,
    },
    fixed: {
      type: Boolean,
      default: false,
    },
  },
  computed: {
    containerStyles() {
      return {
        maxWidth: this.maxWidth,
        backgroundColor: this.color,
        position: this.fixed ? "fixed" : "relative",
      };
    },
  },
};
</script>
<style lang="scss" scoped>
.main {
  transition: none;
}
</style>
