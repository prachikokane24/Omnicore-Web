<template>
  <ValidationObserver ref="observer" v-slot="{ invalid, validate }">
    <OValidationWatcher :invalid="invalid" @invalid="handleInvalid">
      <v-form
        ref="form"
        @submit.prevent="handleSubmit(validate)"
        class="form"
        :class="formClasses"
        :id="id"
        :data-id="dataId"
        :style="{ maxWidth: maxWidth ? maxWidth + 'px' : '' }"
      >
        <slot name="header" />
        <slot name="default" />
        <slot name="footer" />
        <slot
          name="actions"
          :loading="loading"
          :invalid="invalid"
          v-if="!hideActions"
        >
          <OButtonGroup :fluid="btnGroupFluid" :fill="btnGroupFill">
            <template v-if="!hideCancelBtn">
              <OLink
                @click.native="handleCancel"
                v-if="cancelBtnType == 'link'"
                class="link"
              >
                {{ cancelText }}</OLink
              >
              <OButton
                large
                outlined
                block
                @click="handleCancel"
                type="button"
                :data-id="`${dataId}CancelButton`"
                v-else
                >{{ cancelText }}</OButton
              >
            </template>
            <OButton
              block
              :loading="loading"
              :disabled="loading || invalid || disableSubmitBtn"
              :data-id="`${dataId}SubmitButton`"
              large
              type="submit"
              >{{ submitText }}</OButton
            >
          </OButtonGroup>
        </slot>
      </v-form>
    </OValidationWatcher>
  </ValidationObserver>
</template>
<script>
import { ValidationObserver } from "vee-validate";
import OButtonGroup from "../OButtonGroup";
import OButton from "../OButton";
import OLink from "../OLink";
import OValidationWatcher from "./OValidationWatcher";
export default {
  inheritAttrs: false,
  components: {
    ValidationObserver,
    OButtonGroup,
    OButton,
    OLink,
    OValidationWatcher,
  },
  props: {
    id: {
      type: String,
      default: undefined,
    },
    dataId: {
      type: String,
      default: undefined,
    },
    loading: {
      type: Boolean,
      default: false,
    },
    dataLoading: {
      type: Boolean,
      default: false,
    },
    cancelText: {
      type: String,
      default: "Cancel",
    },
    cancelBtnType: {
      type: String,
      default: "btn",
      validator: (value) => value.includes("btn", "link"),
    },
     disableSubmitBtn: {
      type: Boolean,
      default: false,
    },
    disableCancelBtn: {
      type: Boolean,
      default: false,
    },
    hideCancelBtn: {
      type: Boolean,
      default: false,
    },
    cancelArrowRight: {
      type: Boolean,
      default: false,
    },
    cancelArrowLeft: {
      type: Boolean,
      default: false,
    },
    submitArrowRight: {
      type: Boolean,
      default: false,
    },
    submitArrowLeft: {
      type: Boolean,
      default: false,
    },
    submitText: {
      type: String,
      default: "Submit",
    },
    arrowLeft: {
      type: Boolean,
      default: false,
    },
    arrowRight: {
      type: Boolean,
      default: false,
    },
    hideActions: {
      type: Boolean,
      default: false,
    },
    inline: {
      type: Boolean,
      default: false,
    },
    btnGroupFluid: {
      type: Boolean,
      default: false,
    },
    btnGroupFill: {
      type: Boolean,
      default: false,
    },
    maxWidth: {
      type: [Number, String],
    },
  },
  computed: {
    formClasses() {
      return {
        inline: this.inline,
      };
    },
  },
  methods: {
    handleCancel() {
      this.$emit("cancel");
    },
    handleInvalid(invalid) {
      this.$emit("invalid", invalid);
    },
    async handleSubmit(validate) {
      const isValid = await this.$refs.observer.validate();
      if (!isValid) return;
      this.$emit("submit");
    },
    async validate() {
      return await this.$refs.observer.validate();
    },
    reset() {
      this.$refs.form.reset();
      this.$refs.observer.reset();
      this.$emit("reset");
    },
  },
};
</script>

<style lang="scss" scoped>
.inline {
  display: flex;
  flex-direction: row;
  flex-direction: column;
}
.link {
  flex: 1;
  text-align: center;
  align-self: center;
  font-weight: bold;
}
.arrow-left::before {
  content: "←";
}
.arrow-right::after {
  content: "→";
}
</style>
