<template>
  <div class="mb-4">
    <p class="mb-1">{{ label }}:</p>
    <ValidationProvider :name="label" :rules="rules">
      <div class="colors" :style="styleObject">       
        <div v-for="(item, index) in items" :key="index">
          <v-radio-group v-model="formValue" class="mt-0 mb-0 pb-0" dense>
            <v-radio
              :id="`a${item.value}${index}`"
              :name="name"
              :ref="`${name}${index}`"
              :value="item.value"
              :data-id="dataId"
              :disabled="disabled || loading"
              :tabindex="tabIndex || undefined"
              @input="handleChanged"
              dense
            >
              <template v-slot:label>
                <span
                  :class="
                    getDefaultWalletIconValueIfNullOrEmpty(formValue) === getDefaultWalletIconValueIfNullOrEmpty(item.value) ? 'label label--selected' : 'label'
                  "
                  :for="`a${item.value}${index}`"
                  :style="`background-color: ${addHash(item.color)}`"
                >
                  <img :src="item.icon" :alt="item.icon" v-if="item.icon" />
                  <OIcon icon="tick" class="tick" />
                </span>
              </template>
            </v-radio>
          </v-radio-group>
        </div>
      </div>
    </ValidationProvider>
  </div>
</template>

<script>
import { ValidationProvider } from "vee-validate";
import OIcon from "../OIcon.vue";
export default {
  name: "OFormRadioTab",
  components: {
    ValidationProvider,
    OIcon,
  },
  props: {
    loading: {
      type: Boolean,
      required: false,
    },

     disabled: {
      type: Boolean,
      required: false,
    },
    label: {
      type: String,
      required: true,
    },
    rules: {
      type: String,
      required: false,
    },
    name: {
      type: String,
      required: true,
    },
    folder: {
      type: String,
    },
    preSelected: {
      type: String,
    },
    items: {
      type: Array,
      require: true,
    },
    tabIndex: {
      type: Number,
    },
    dataId: {
      type: String,
      default: undefined,
    },
  },
  watch: {
    preSelected() {
      this.preSelectItem();
    },
    async formValue() {
      this.emitInput();
    },
  },
  mounted() {
    this.preSelectItem();
  },
  data() {
    return {
      formValue: null,
    };
  },
  computed: {
    styleObject() {
      return { opacity: this.loading || this.disabled ? '0.5' : "1" }
    }
  },
  methods: {
    async handleChanged() {
      this.emitInput();
    },
    preSelectItem() {
      if (this.preSelected) {
        this.formValue = this.preSelected;
      }
    },
    emitInput() {
      this.$emit("input", {
        type: "radio",
        value: this.formValue || null, // BUG in vuetify where if you pass a null value to a v-radio it returns it as zero 0. Be careful when changing this line.
        label: "colors",
      });
    },
    addHash(color) {
      const hash = color;
      const char = hash.charAt(0);
      return char == "#" ? `${color}` : `#${color}`;
    },
    //  BUG in vuetify where if you pass a null value to a v-radio it returns it as zero 0
    getDefaultWalletIconValueIfNullOrEmpty(value) {
      if (!value || value.length === 0) return "0";
      else return value;
    }
  },
};
</script>

<style lang="scss" scoped>
::v-deep .v-radio > div {
  display: none !important;
}

.colors {
  display: flex;
  flex-flow: wrap;
  width: 100%;
}
.icon {
  color: white;
  display: block;
}
.label {
  display: flex;
  flex-wrap: wrap;
  width: 50px;
  height: 50px;
  margin-right: 10px;
  margin-bottom: 5px;
  cursor: pointer;
  transition: scale 0.2s;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 5px;
  border-radius: 3px;
  img {
    width: 100%;
    max-width: 32px;
    opacity: 0.7;
  }
  span {
    display: block;
    width: 100%;
    height: 100%;
    transition: transform 0.2s ease-in-out;
  }
  &--selected {
    border-width: 2px;
    border-color: white;
    img {
      opacity: 0.3;
    }
    .tick {
      display: block;
    }
  }
}
.tick {
  position: absolute;
  top: 10px;
  color: white;
  display: none;
}
</style>
