<template>
  <div class="wrapper" :class="{ loading: loading }">
    <label
      :for="id"
      class="d-flex mb-1"
      :class="labelClasses"
      v-if="this.inline && $vuetify.breakpoint.xs"
      >{{ labelRequired }}</label
    >
    <ODefinitionList :items="previewItems" v-if="preview" :inline="inline" />
    <ValidationProvider
      :name="label"
      :rules="rules"
      :vid="name"
      v-slot="{ changed, errors }"
      v-else
    >
      <OValidationWatcher :changed="changed" @pristine="handleChanged">
        <v-text-field
          v-model="formValue"
          :ref="name"
          :id="id"
          :data-id="dataId"
          :counter="counter > 0 ? counter : false"
          :required="required"
          :error-messages="
            onblur ? (errors && hasBlur ? errors : undefined) : errors
          "
          :label="!inline ? labelRequired : undefined"
          :type="type"
          :clearable="clearable"
          :appendIcon="appendIcon"
          :prependIcon="prependIcon"
          :hint="hint"
          :disabled="disabled || loading"
          :readonly="preview"
          :placeholder="!placeholder ? ' ' : placeholder"
          :error="error"
          :outlined="preview == true ? false : outlined"
          :filled="preview == true ? false : filled"
          :maxlength="maxlength"
          :pattern="pattern"
          :loading="loading"
          :autocomplete="autocomplete"
          :autofocus="autofocus"
          :background-color="backgroundColor"
          :prefix="prefix"
          :hideDetails="hideDetails"
          @click:append="handleAppendClick"
          @blur="onBlur"
          :tabindex="tabIndex || undefined"
          :persistentHint="persistentHint"
          v-mask="`${mask}`"
          dense
        >
          <template v-if="inline && $vuetify.breakpoint.smAndUp" #prepend>
            <div
              class="prepend"
              :style="{ minWidth: minLabelWidth ? minLabelWidth + 'px' : '' }"
            >
              <OIcon
                :icon="inlineIcon"
                class="prepend__icon"
                v-if="inlineIcon"
              />
              <span class="prepend__label">{{ labelRequired }}</span>
            </div>
          </template>
          <template #message="{ message }">
            <span
              :class="messageClasses"
              :style="{ fontWeight: messageBold ? 'bold' : 'normal' }"
              >{{ message }}</span
            >
          </template>
        </v-text-field>
      </OValidationWatcher>
    </ValidationProvider>
  </div>
</template>

<script>
import { ValidationProvider, Validator } from "vee-validate";
import OIcon from "../OIcon.vue";
import ODefinitionList from "../ODefinitionList.vue";
import OValidationWatcher from "./OValidationWatcher";
export default {
  components: {
    ValidationProvider,
    ODefinitionList,
    OIcon,
    OValidationWatcher
  },
  props: {
    id: {
      type: String,
      default: undefined,
    },
    dataId: {
      type: String,
      default: undefined,
    },
    rules: {
      type: String,
    },
    counter: {
      type: [Number, String],
      default: "max",
    },
    name: {
      type: String,
      required: true,
    },
    label: {
      type: String,
      default: undefined,
    },
    required: {
      type: Boolean,
      default: false,
    },
    backgroundColor: {
      type: String,
    },
    disabled: {
      type: Boolean,
      default: false,
    },
    autofocus: {
      type: Boolean,
      default: false,
    },
    preSelected: {
      type: [String, Number],
    },
    preview: {
      type: Boolean,
      default: false,
    },
    previewValuePrefix: {
      type: String,
      default: ""
    },
    persistentHint: {
      type: Boolean,
      default: false,
    },
    prefix: {
      type: String,
    },
    loading: {
      type: Boolean,
      default: false,
    },
    maxlength: {
      type: Number,
      default: undefined,
    },
    filled: {
      type: Boolean,
      default: true,
    },
    outlined: {
      type: Boolean,
      default: false,
    },
    dense: {
      type: Boolean,
      default: false,
    },
     hideDetails: {
      type: [Boolean,String],
      default: false,
    },
    type: {
      type: String,
      default: "text",
    },
    clearable: {
      type: Boolean,
      default: false,
    },
    appendIcon: {
      type: String,
    },
    prependIcon: {
      type: String,
    },
    hint: {
      type: String,
    },
    placeholder: {
      type: String,
    },
    error: {
      type: Boolean,
      default: false,
    },
    pattern: {
      type: String,
      default: undefined,
    },
    rounded: {
      type: String,
      default: "rounded-0",
    },
    onblur: {
      type: Boolean,
      default: false,
    },
    autocomplete: {
      type: Boolean,
      default: false,
    },
    messageBold: {
      type: Boolean,
      default: false,
    },
    messageColor: {
      type: String,
    },
    labelColor: {
      type: String,
      default: "text",
    },
    inline: {
      type: Boolean,
      default: false,
    },
    inlineIcon: {
      type: String,
    },
    tabIndex: {
      type: Number,
    },
    minLabelWidth: {
      type: Number,
      default: 140,
    },
    mask: {
      type: [String],
      default: ''
    },
  },
  mounted() {
    this.preSelectItem();
  },
  watch: {
    preSelected() {
      this.preSelectItem();
    },
    async formValue() {
      this.emitInput();
    },
  },
  data() {
    return {
      formValue: "",
      hasBlur: false,
      hasChanged: false
    };
  },
  computed: {
    previewItems() {
      return [{
          key: this.name,
          title: this.label,
          value: (this.formValue) ? `${this.previewValuePrefix}${this.formValue}` : "-",
        }]
     },
    labelRequired() {
      if (!this.label) return;
      return `${this.label} ${this.isRequired ? "" : "(optional)"}`;
    },
    isRequired() {
      if (!this.rules) return false;
      return this.rules.includes("required");
    },
    messageClasses() {
      return {
        [`${this.messageColor}--text`]: this.messageColor,
      };
    },
    labelClasses() {
      return {
        [`${this.labelColor}--text`]: this.labelColor,
      };
    },
  },

  methods: {
    onBlur() {
      if (!this.onblur) return;
      this.hasBlur = true;
    },
    handleAppendClick() {
      this.$emit("appendClick");
    },
    handleChanged(val) {
      this.hasChanged;
    },
    async emitInput() {
      this.$emit("input", {
        type: "input",
        value: this.formValue,
        label: this.label,
        valueChanged: this.preSelected !== this.formValue
      });
    },
    preSelectItem() {
      if (this.preSelected) {
        this.formValue = this.preSelected;
      }
    },
    setFocus() {
      this.$refs[this.name].focus();
    },
  },
};
</script>

<style lang="scss">
input:-webkit-autofill,
input:-webkit-autofill:hover,
input:-webkit-autofill:focus,
textarea:-webkit-autofill,
textarea:-webkit-autofill:hover,
textarea:-webkit-autofill:focus,
select:-webkit-autofill,
select:-webkit-autofill:hover,
select:-webkit-autofill:focus {
  border-color: transparent;
  -webkit-box-shadow: 0 0 0px 1000px transparent inset;
  transition: background-color 5000s ease-in-out 0s;
}
.wrapper {
  transition: opacity 1s;
}
.loading {
  opacity: 0.3;
}
.prepend {
  display: flex;
  align-items: center;
  &__icon {
    margin-right: 10px;
  }
  &__label {
    white-space: nowrap;
  }
}
.v-messages__message {
  line-height: inherit !important;
}
</style>
