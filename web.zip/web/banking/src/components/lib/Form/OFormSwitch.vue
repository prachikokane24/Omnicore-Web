<template>
  <div class="wrapper" :class="{ loading: loading }">
    <label
      :for="id"
      class="d-flex mb-1"
      :class="labelClasses"
      v-if="outsideLabel || (this.inline && $vuetify.breakpoint.xs)"
      >{{ labelRequired }}</label
    >
    <ValidationProvider :name="label" :rules="rules">
      <v-switch
        slot-scope="{ errors }"
        v-model="formValue"
        :name="name"
        :ref="name"
        :id="id"
        :data-id="dataId"
        :error-messages="
          onblur ? (errors && hasBlur ? errors : undefined) : errors
        "
        :label="!outsideLabel ? labelRequired : undefined"
        :hint="hint"
        :disabled="disabled || loading"
        :error="error"
        :dense="dense"
        :loading="loading"
        :background-color="backgroundColor"
        :color="color"
        @click:append="handleAppendClick"
        @blur="onBlur"
        :tabindex="tabIndex || undefined"
        :hide-details="hideDetails"
        :inset="inset"
        :class="{ 'ma-0 pa-0': noMargin }"
        @change="$emit('change')"
      >
        <template v-if="inline && $vuetify.breakpoint.smAndUp" #prepend>
          <div
            class="prepend"
            :style="{ minWidth: minLabelWidth ? minLabelWidth + 'px' : '' }"
          >
            <OIcon :icon="inlineIcon" class="prepend__icon" v-if="inlineIcon" />
            <span class="prepend__label">{{ labelRequired }}</span>
          </div>
        </template>
        <template #message="{ message }">
          <span
            :class="messageClasses"
            :style="{ fontWeight: messageBold ? 'bold' : 'normal' }"
            >{{ message }}</span
          >
        </template>
      </v-switch>
    </ValidationProvider>
  </div>
</template>

<script>
import { ValidationProvider } from "vee-validate";
import OIcon from "../OIcon.vue";

export default {
  name: "OFormSwitch",
  components: {
    ValidationProvider,
    OIcon,
  },
  props: {
    id: {
      type: String,
      default: undefined,
    },
    dataId: {
      type: String,
      default: undefined,
    },
    rules: {
      type: String,
    },
    name: {
      type: String,
      required: true,
    },
    label: {
      type: String,
      default: undefined,
    },
    backgroundColor: {
      type: String,
    },
    color: {
      type: String,
      default: "primary",
    },
    disabled: {
      type: Boolean,
      default: false,
    },
    preSelected: {
      type: [String, Number, Boolean],
    },
    loading: {
      type: Boolean,
      default: false,
    },
    dense: {
      type: Boolean,
      default: true,
    },
    inset: {
      type: Boolean,
      default: true,
    },
    hideDetails: {
      type: Boolean,
      default: false,
    },
    hint: {
      type: String,
    },
    error: {
      type: Boolean,
      default: false,
    },
    onblur: {
      type: Boolean,
      default: false,
    },
    autocomplete: {
      type: Boolean,
      default: false,
    },
    messageBold: {
      type: Boolean,
      default: false,
    },
    messageColor: {
      type: String,
    },
    labelColor: {
      type: String,
      default: "text",
    },
    outsideLabel: {
      type: Boolean,
      default: false,
    },
    inline: {
      type: Boolean,
      default: false,
    },
    inlineIcon: {
      type: String,
    },
    tabIndex: {
      type: Number,
    },
    minLabelWidth: {
      type: Number,
      default: 100,
    },
    noMargin: {
      type: Boolean,
      default: false,
    },
  },
  mounted() {
    this.preSelectItem();
  },
  watch: {
    preSelected() {
      this.preSelectItem();
    },
    async formValue() {
      this.emitInput();
    },
  },
  data() {
    return {
      formValue: "",
      hasBlur: false,
    };
  },
  computed: {
    labelRequired() {
      if (!this.label) return;
      return `${this.label} ${this.isRequired ? "*" : ""}`;
    },
    isRequired() {
      if (!this.rules) return false;
      return this.rules.includes("required");
    },
    messageClasses() {
      return {
        [`${this.messageColor}--text`]: this.messageColor,
      };
    },
    labelClasses() {
      return {
        [`${this.labelColor}--text`]: this.labelColor,
      };
    },
  },

  methods: {
    onBlur() {
      if (!this.onblur) return;
      this.hasBlur = true;
    },
    handleAppendClick() {
      this.$emit("appendClick");
    },
    async emitInput() {
      this.$emit("input", {
        type: "input",
        value: this.formValue,
        label: this.label,
      });
    },
    preSelectItem() {
      if (this.preSelected) {
        this.formValue = this.preSelected;
      }
    },
    setFocus() {
      this.$refs[this.name].focus();
    },
  },
};
</script>

<style lang="scss" scoped>
input:-webkit-autofill,
input:-webkit-autofill:hover,
input:-webkit-autofill:focus,
textarea:-webkit-autofill,
textarea:-webkit-autofill:hover,
textarea:-webkit-autofill:focus,
select:-webkit-autofill,
select:-webkit-autofill:hover,
select:-webkit-autofill:focus {
  border-color: transparent;
  -webkit-box-shadow: 0 0 0px 1000px transparent inset;
  transition: background-color 5000s ease-in-out 0s;
}
.wrapper {
  display: inline-block;
  transition: opacity 1s;
}
.loading {
  opacity: 0.3;
}
.prepend {
  display: flex;
  align-items: center;
  &__icon {
    margin-right: 10px;
  }
  &__label {
    white-space: nowrap;
  }
}
</style>
