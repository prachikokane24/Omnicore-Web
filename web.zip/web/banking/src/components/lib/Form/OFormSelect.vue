<template>
  <div class="wrapper" :class="{ loading: loading }">
    <label
      :for="id"
      class="d-flex mb-1"
      :class="labelClasses"
      v-if="this.inline && $vuetify.breakpoint.xs && !parentLabelRequired"
      >{{ labelRequired }}</label
    >

    <ODefinitionList :items="previewItems" :inline="inline" v-if="preview" />
    <ValidationProvider :name="label" :vid="name" :rules="rules" v-else>
      <v-select
        slot-scope="{ errors }"
        @change="handleChange"
        :id="id"
        :data-id="dataId"
        :disabled="disabled || loading"
        :error="error"
        :required="required"
        :error-messages="
          onblur ? (errors && hasBlur ? errors : undefined) : errors
        "
        :value="formValue"
        :items="items"
        :label="label"
        :item-text="itemText"
        :item-value="itemValue"
        :filled="filled"
        :solo="solo"
        :rounded="rounded"
        :outlined="outlined"
        :hide-details="hideDetails"
        :hint="hint"
        :class="[sizeClasses]"
        :small="small"
        :background-color="backgroundColor"
        :placeholder="placeholder"
        :loading="loading"
        dense
        menu-props="auto"
      >
        <template v-if="inline && $vuetify.breakpoint.smAndUp" #prepend>
          <div
            class="prepend"
            :style="{ minWidth: minLabelWidth ? minLabelWidth + 'px' : '' }"
          >
            <OIcon :icon="inlineIcon" class="prepend__icon" v-if="inlineIcon" />
            <span class="prepend__label" v-if="parentLabelRequired">{{
              parentLabelRequired
            }}</span>
            <span class="prepend__label" v-else>{{ labelRequired }}</span>
          </div>
        </template>
        <template #message="{ message }">
          <span
            :class="messageClasses"
            :style="{ fontWeight: messageBold ? 'bold' : 'normal' }"
            >{{ message }}</span
          >
        </template>
      </v-select>
    </ValidationProvider>
  </div>
</template>
<script>
import { ValidationProvider } from "vee-validate";
import ODefinitionList from "../ODefinitionList.vue";
export default {
  name: "OFormSelect",
  inheritAttrs: false,
  components: {
    ValidationProvider,
    ODefinitionList
  },
  props: {
    id: {
      type: String,
      default: undefined,
    },
    dataId: {
      type: String,
      default: undefined,
    },
    rules: {
      type: String,
      default: "",
    },
    name: {
      type: [String],
      default: "",
    },
    label: {
      type: [String],
      default: "",
    },
    parentLabel: {
      type: [String],
      default: "",
    },
    hint: {
      type: [String],
      default: "",
    },
    placeholder: {
      type: String,
    },
    error: {
      type: Boolean,
      default: false,
    },
    items: {
      type: [Array],
      default: () => [],
    },
    disabled: {
      type: [Boolean],
      default: false,
    },
    required: {
      type: [Boolean],
      default: false,
    },
    preSelected: {
      type: [Number, String],
    },
     preview: {
      type: [Boolean],
      default: false,
    },
    filled: {
      type: [Boolean],
      default: true,
    },
    rounded: {
      type: [Boolean],
      default: false,
    },
     onblur: {
      type: Boolean,
      default: false,
    },
    outlined: {
      type: [Boolean],
      default: false,
    },
    solo: {
      type: [Boolean],
      default: false,
    },
    dense: {
      type: [Boolean],
      default: true,
    },
    itemText: {
      type: [String],
      default: "label",
    },
    itemValue: {
      type: [String],
      default: "value",
    },
    backgroundColor: {
      type: [String],
      default: undefined,
    },
    hideDetails: {
      type: [Boolean],
      default: false,
    },
    small: {
      type: [Boolean],
      default: false,
    },
    loading: {
      type: [Boolean],
      default: false,
    },
    messageBold: {
      type: Boolean,
      default: false,
    },
    messageColor: {
      type: String,
    },
    labelColor: {
      type: String,
      default: "text",
    },
    // outsideLabel: {
    //   type: Boolean,
    //   default: false,
    // },
    inline: {
      type: Boolean,
      default: false,
    },
    inlineIcon: {
      type: String,
    },
    tabIndex: {
      type: Number,
    },
    minLabelWidth: {
      type: Number,
      default: 140,
    },
  },
  watch: {
    preSelected() {
      this.preSelectItem();
    },
  },
  data() {
    return {
      formValue: "",
    };
  },
  computed: {
    previewItems() {
      return [{
          key: this.name,
          title: this.label,
          value: (this.formValue) ? this.items.find(item => item.value === this.formValue).label : "-",
        }]
    },
    labelRequired() {
      if(this.label) {
         return `${this.label} ${this.isRequired ? "*" : ""}`;
      }
      return null;
    },
    parentLabelRequired() {
      if(this.parentLabel) {
         return `${this.parentLabel} ${this.isRequired ? "*" : ""}`;
      }
      return null;
    },
    isRequired() {
      if (!this.rules) return false;
      return this.rules.includes("required");
    },
    sizeClasses() {
      return {
        [`subtitle-2`]: this.small,
      };
    },
    labelClasses() {
      return {
        [`${this.labelColor}--text`]: this.labelColor,
      };
    },
    messageClasses() {
      return {
        [`${this.messageColor}--text`]: this.messageColor,
      };
    },
  },
  mounted() {
    this.$nextTick(() => {
      this.preSelectItem();
    });
  },
  methods: {
    async handleChange(val) {
      this.formValue = val;
      this.emitChange();
    },
    async emitChange() {
      const data = {
        type: "select",
        value: this.formValue,
        label: this.label,
      };
      this.$emit("input", data);
      this.$emit("change", data);
    },
    preSelectItem() {
      if (this.preSelected !== "") {
        this.formValue = this.preSelected;
      } else {
        this.formValue = this.items[0].value;
      }
    },
  },
};
</script>
<style lang="scss" scoped>
.wrapper {
  transition: opacity 1s;
}
.loading {
  opacity: 0.3;
}
</style>
