<template>
  <div>
    <div v-if="preview">
      <ODefinitionList :items="previewItems" v-if="formValue == true" />
    </div>
    <ValidationProvider :name="label" :vid="name" :rules="rules" v-else>
      <label
        :for="id"
        class="d-flex mb-1"
        :class="labelClasses"
        v-if="this.inline && $vuetify.breakpoint.xs"
        >{{ labelRequired }}</label
      >
      <!-- <label :for="id" class="mb-1" v-else-if="parentLabel">{{
        labelRequired
      }}</label> -->
      <v-checkbox class="mt-0" v-model="formValue" :label="label">
        <template v-if="inline && $vuetify.breakpoint.smAndUp" #prepend>
          <div
            class="prepend"
            :style="{ minWidth: minLabelWidth ? minLabelWidth + 'px' : '' }"
          >
            <OIcon :icon="inlineIcon" class="prepend__icon" v-if="inlineIcon" />
            <span class="prepend__label">{{ labelRequired }}</span>
          </div>
        </template>
        <template #message="{ message }">
          <span
            :class="messageClasses"
            :style="{ fontWeight: messageBold ? 'bold' : 'normal' }"
            >{{ message }}</span
          >
        </template>
      </v-checkbox>
    </ValidationProvider>
  </div>
</template>

<script>
import { ValidationProvider } from "vee-validate";
import ODefinitionList from "../ODefinitionList.vue";
export default {
  name: "OCheckbox",
  components: {
    ODefinitionList,
    ValidationProvider,
  },
  props: {
    id: {
      type: String,
      default: undefined,
    },
    dataId: {
      type: String,
      default: undefined,
    },
    rules: {
      type: String,
    },
    preview: {
      type: [Boolean],
      default: false,
    },
    parentLabel: {
      type: String,
    },
    label: {
      type: String,
    },
    name: {
      type: String,
    },
    dark: {
      type: Boolean,
      default: false,
    },
    noMargin: {
      type: Boolean,
      default: false,
    },
    hideDetails: {
      type: Boolean,
      default: false,
    },
    disabled: {
      type: Boolean,
      default: false,
    },
    preSelected: {
      type: Boolean,
      default: false,
    },
    inputValue: {
      type: [String, Number],
    },
    dense: {
      type: Boolean,
      default: false,
    },
    messageBold: {
      type: Boolean,
      default: false,
    },
    messageColor: {
      type: String,
    },
    labelColor: {
      type: String,
      default: "text",
    },
    // outsideLabel: {
    //   type: Boolean,
    //   default: false,
    // },
    inline: {
      type: Boolean,
      default: false,
    },
    inlineIcon: {
      type: String,
    },
    tabIndex: {
      type: Number,
    },
    minLabelWidth: {
      type: Number,
      default: 140,
    },
  },
  data() {
    return {
      formValue: null,
    };
  },
  computed: {
    previewItems() {
      return [{
          key: this.name,
          title: this.parentLabel,
          value: (this.formValue) ? this.label : "-",
        }]
   },
    labelRequired() {
      if (!this.parentLabel) return;
      return `${this.parentLabel} ${this.isRequired ? "*" : ""}`;
    },
    isRequired() {
      if (!this.rules) return false;
      return this.rules.includes("required");
    },
    messageClasses() {
      return {
        [`${this.messageColor}--text`]: this.messageColor,
      };
    },
    labelClasses() {
      return {
        [`${this.labelColor}--text`]: this.labelColor,
      };
    },
  },
  watch: {
    preSelected() {
      this.preSelectItem();
    },
    formValue() {
      this.emitInput();
    },
  },
  methods: {
    async handleChanged() {
     this.emitInput();
    },
    preSelectItem() {
      if (typeof this.preSelected == "boolean") {
       this.$nextTick(() => {
        this.formValue = (this.preSelected==true) ? 1 : 0
        })
      }
    },
    emitInput() {
      this.$emit("input", {
        type: "checkbox",
        value: this.formValue,
        label: this.label,
      });
    },
  },
  mounted() {
    this.preSelectItem();
  },
};
</script>
