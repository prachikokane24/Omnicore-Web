<template>
  <div class="wrapper" :class="{ loading: loading }">
    <label
      :for="id"
      class="d-flex mb-1"
      :class="labelClasses"
      v-if="this.inline && $vuetify.breakpoint.xs"
      >{{ labelRequired }}</label
    >
    <ODefinitionList :items="previewItems" v-if="preview" :inline="inline" />
    <ValidationProvider :name="label" :rules="rules" v-else>
      <v-row>
        <v-col class="d-flex" :cols="$vuetify.breakpoint.xs ? 4 : ''">
          <OFormSelect
            v-model="formItems.day"
            :label="dayLabel"
            :parent-label="parentLabel"
            :items="days"
            :outlined="preview == true ? false : outlined"
            :filled="preview == true ? false : filled"
            :data-id="dataIdDay"
            :inline="inline"
            :rules="[...rules, '']"
          />
        </v-col>
        <v-col class="d-flex" :cols="$vuetify.breakpoint.xs ? 4 : 3">
          <OFormSelect
            v-model="formItems.month"
            :label="monthLabel"
            :items="months"
            @input="emitChange"
            :outlined="preview == true ? false : outlined"
            :filled="preview == true ? false : filled"
            :data-id="dataIdMonth"
            :rules="[...rules, '']"
          />
        </v-col>
        <v-col class="d-flex" :cols="$vuetify.breakpoint.xs ? 4 : 3">
          <OFormSelect
            v-model="formItems.year"
            :label="yearLabel"
            :items="years"
            @input="emitChange"
            :outlined="preview == true ? false : outlined"
            :filled="preview == true ? false : filled"
            :data-id="dataIdYear"
            :rules="[...rules, '']"
          />
        </v-col>
      </v-row>
    </ValidationProvider>
  </div>
</template>
<script>
import OFormSelect from "./OFormSelect.vue";
export default {
  name: "FormDOB",
  components: {
    OFormSelect,
  },
  props: {
    name: {
      type: String,
      required: true,
    },

    label: {
      type: String,
      default: undefined,
    },
    rules: {
      type: String,
    },
    dataIdDay: {
      type: String,
    },
    dataIdMonth: {
      type: String,
    },
    dataIdYear: {
      type: String,
    },
    loading: {
      type: Boolean,
      default: false,
    },
    preview: {
      type: Boolean,
      default: false,
    },
    filled: {
      type: Boolean,
      default: true,
    },
    outlined: {
      type: Boolean,
      default: false,
    },
    messageBold: {
      type: Boolean,
      default: false,
    },
    dayLabel: {
      type: String,
      default: "Day"
    },
    monthLabel: {
      type: String,
       default: "Month"
    },
    yearLabel: {
      type: String,
       default: "Year"
    },
    messageColor: {
      type: String,
    },
    labelColor: {
      type: String,
      default: "text",
    },
    inline: {
      type: Boolean,
      default: false,
    },
    inlineIcon: {
      type: String,
    },
    tabIndex: {
      type: Number,
    },
    minLabelWidth: {
      type: Number,
      default: 140,
    },
  },
  data() {
    return {
      formItems: { },
    };
  },
  computed: {
    labelRequired() {
      if (!this.label) return;
      return `${this.label} ${this.isRequired ? "*" : ""}`;
    },
    isRequired() {
      if (!this.rules) return false;
      return this.rules.includes("required");
    },
    labelClasses() {
      return {
        [`${this.labelColor}--text`]: this.labelColor,
      };
    },
    messageClasses() {
      return {
        [`${this.messageColor}--text`]: this.messageColor,
      };
    },
    previewItems() {
      return [{
          key: this.name,
          title: this.label,
          value: (this.formItems) ? `${this.formItems.day} ${this.formItems.month} ${this.formItems.year}` : "-",
        }]
    },
    years() {
        let currentYear = new Date().getFullYear(), years = [];
        const endYear = 1910;  
        while (endYear <= currentYear) {
            years.push(currentYear--);
        }   
        return years;
    },
    months() {
      return [
        { value: '01', label: 'Jan' },
        { value: '02', label: 'Feb' },
        { value: '03', label: 'Mar' },
        { value: '04', label: 'Apr' },
        { value: '05', label: 'May' },
        { value: '06', label: 'June' },
        { value: '07', label: 'July' },
        { value: '08', label: 'Aug' },
        { value: '09', label: 'Sept' },
        { value: '10', label: 'Oct' },
        { value: '11', label: 'Nov' },
        { value: '12', label: 'Dec' },
      ]
    },
    days() {
      return Array.from(Array(32).keys()).slice(1);
    },
  },
  mounted() {
    this.preSelectItem();
  },
  watch: {
    preSelected() {
      this.preSelectItem();
    },
    async formItems() {
      this.emitChange();
    },
  },
  methods: {
    async emitChange() {
      this.$emit("input", {
        type: "input",
        value: {
          day: this.formItems.day,
          month: this.formItems.month,
          year: this.formItems.year,
        },
        label: this.label,
      });
    },
    preSelectItem() {
      if (this.preSelected) {
        this.formValue = this.preSelected;
      }
    },
  },
};
</script>
<style lang="scss" scoped>
.wrapper {
  transition: opacity 1s;
}
.loading {
  opacity: 0.3;
}
</style>