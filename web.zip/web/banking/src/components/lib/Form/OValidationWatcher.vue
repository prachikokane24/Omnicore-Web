<template>
  <div><slot /></div>
</template>
<script>
export default {
  name: "OValidationWatcher",
  props: ["invalid","errors","changed"],
  watch: {
    invalid: {
      immediate: true,
      handler() {
        this.$emit("invalid", this.invalid);
      },
    },
    errors: {
      immediate: true,
      handler() {
        this.$emit("errors", this.errors);
      },
    },
    changed: {
      immediate: true,
      handler() {
        this.$emit("changed", this.changed);
      },
    },
  },
};
</script>
