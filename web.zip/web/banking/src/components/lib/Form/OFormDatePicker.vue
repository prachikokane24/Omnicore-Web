<template>
  <div class="wrapper" :class="{ loading: loading }">
    <label
      :for="id"
      class="d-flex mb-1"
      :class="labelClasses"
      v-if="inline && $vuetify.breakpoint.xs"
      >{{ labelRequired }}</label
    >
    <ODefinitionList :items="previewItems" :inline="inline" v-if="preview" />
    <ValidationProvider
      :rules="isRequired ? 'required' : ''"
      :name="label"
      v-slot="{ errors }"
      v-else
    >
      <div class="input-wrapper">
        <div class="input-wrapper__click-mask" @click.stop="modal = true"></div>
        <v-text-field
          :ref="name"
          :value="computedDateFormattedMomentjs"
          :label="!inline ? labelRequired : undefined"
          :prepend-inner-icon="icon"
          :id="id"
          :data-id="dataId"
          :required="required"
          :error-messages="
            onblur
              ? errors && hasBlur
                ? [...errors, ...errorMessages]
                : undefined
              : [...errors, ...errorMessages]
          "
          :outlined="outlined"
          :filled="filled"
          :placeholder="!placeholder ? ' ' : placeholder"
          :hint="hint"
          :disabled="disabled || loading"
          :loading="loading"
          :clearable="clearable"
          @click:clear="date = null"
          @blur="onBlur"
          readonly
          dense
        >
          <template v-if="inline && $vuetify.breakpoint.smAndUp" #prepend>
            <div
              class="prepend"
              :style="{
                minWidth: minLabelWidth ? minLabelWidth + 'px' : '',
              }"
            >
              <OIcon
                :icon="inlineIcon"
                class="prepend__icon"
                v-if="inlineIcon"
              />
              <span class="prepend__label">{{ labelRequired }}</span>
            </div>
          </template>
          <template #message="{ message }">
            <span
              :class="messageClasses"
              :style="{ fontWeight: messageBold ? 'bold' : 'normal' }"
              >{{ message }}</span
            >
          </template>
        </v-text-field>
      </div>
    </ValidationProvider>
    <v-dialog
      ref="dialog"
      v-model="modal"
      :return-value.sync="date"
      persistent
      width="290px"
    >
      <ValidationProvider
        :name="label"
        :vid="name"
        :rules="rules"
        :ref="name"
        v-slot="{ errors }"
      >
        <OValidationWatcher :errors="errors" @errors="handleErrors">
          <v-date-picker
            v-model="date"
            locale="en-gb"
            :min="minDate"
            :max="maxDate"
          >
            <OButtonGroup fluid fill>
              <OButton @click="modal = false" outlined fluid block>
                {{ $t("date.cancelBtn") }}
              </OButton>
              <OButton @click="$refs.dialog.save(date)" fluid block>
                {{ $t("date.confirmBtn") }}
              </OButton>
            </OButtonGroup>
          </v-date-picker>
        </OValidationWatcher>
      </ValidationProvider>
    </v-dialog>
  </div>
</template>

<script>
import moment from "moment";
import { ValidationProvider } from "vee-validate";
import OButton from "../OButton";
import OButtonGroup from "../OButtonGroup";
import OValidationWatcher from "./OValidationWatcher";
import ODefinitionList from "../ODefinitionList.vue";
export default {
  name: "OFormDatePicker",
  components: {
    OButton,
    OButtonGroup,
    ValidationProvider,
    OValidationWatcher,
    ODefinitionList
  },
  props: {
    maxDate: {
      type: String,
    },
    minDate: {
      type: String,
      default: moment().format("YYYY-MM-DD"),
    },
    hideIcon: {
      type: Boolean,
      default: false,
    },
    offsetY: {
      type: Boolean,
      default: true,
    },
    loading: {
      type: Boolean,
      default: false,
    },
    preview: {
      type: Boolean,
      default: false,
    },
    onblur: {
      type: Boolean,
      default: false,
    },
    icon: {
      type: String,
      default: "mdi-calendar",
    },
    transition: {
      type: String,
      default: "scale-transition",
    },
    minWidth: {
      type: String,
      default: "auto",
    },
    id: {
      type: String,
      default: undefined,
    },
    dataId: {
      type: String,
      default: undefined,
    },
    rules: {
      type: String,
    },
    counter: {
      type: [Number, String],
      default: "max",
    },
    name: {
      type: String,
      default: "",
      required: true,
    },
    label: {
      type: String,
      default: undefined,
    },
    required: {
      type: Boolean,
      default: false,
    },
    disabled: {
      type: Boolean,
      default: false,
    },
    preSelected: {
      type: [String, Number],
    },
    clearable: {
      type: Boolean,
      default: false,
    },
    filled: {
      type: Boolean,
      default: true,
    },
    outlined: {
      type: Boolean,
      default: false,
    },
    dense: {
      type: Boolean,
      default: false,
    },
    placeholder: {
      type: String,
    },
    hint: {
      type: String,
    },
    error: {
      type: Boolean,
      default: false,
    },
    readonly: {
      type: Boolean,
      default: false,
    },
     messageBold: {
      type: Boolean,
      default: false,
    },
    messageColor: {
      type: String,
    },
    labelColor: {
      type: String,
      default: "text",
    },
    // outsideLabel: {
    //   type: Boolean,
    //   default: false,
    // },
    inline: {
      type: Boolean,
      default: false,
    },
    inlineIcon: {
      type: String,
    },
    tabIndex: {
      type: Number,
    },
    minLabelWidth: {
      type: Number,
      default: 140,
    },
    dateFormat: {
      type: String,
      default: "dddd, MMMM Do YYYY"
    }
  },
  data: () => ({
    modal: false,
    hasBlur: false,
    date: null,
    errorMessages: [],
    activator: true
  }),
  mounted() {
    if (this.preSelected) {
      this.preSelectItem();
    }
  },
  watch: {
    preSelected() {
      this.preSelectItem();
    },
    async date() {
      this.emitInput();
    },
    // date(val) {
    //   this.$emit("input", {
    //     type: "input",
    //     value: val,
    //     label: this.label,
    //   });
    // },
  },
  computed: {
    previewItems() {
      return [{
          key: this.name,
          title: this.label,
          value: (this.date) ? this.computedDateFormattedMomentjs : "-",
        }]
     },
    computedDateFormattedMomentjs() {
      return this.date ? moment(this.date).format(this.dateFormat) : '';
    },
    labelRequired() {
      if (!this.label) return;
      return `${this.label} ${this.isRequired ? "*" : ""}`;
    },
    isRequired() {
      if (!this.rules) return false;
      return this.rules.includes("required");
    },
    sizeClasses() {
      return {
        [`subtitle-2`]: this.small,
      };
    },
    labelClasses() {
      return {
        [`${this.labelColor}--text`]: this.labelColor,
      };
    },
    messageClasses() {
      return {
        [`${this.messageColor}--text`]: this.messageColor,
      };
    },
  },
  methods: {
    handleErrors(errors) {
      this.errorMessages = errors;
    },
    async emitInput() {
      this.$emit("input", {
        type: "input",
        value: this.date,
        label: this.label,
      });
    },
    preSelectItem() {
      if (this.preSelected !== "") {
        this.date = moment(this.preSelected).format("YYYY-MM-DD");
      }
    },
    setFocus() {
      this.$refs.input.focus();
    },
    onBlur() {
      if (!this.onblur) return;
      this.hasBlur = true;
    },
  },
};
</script>
<style lang="scss">
.wrapper {
  transition: opacity 1s;
}
.loading {
  opacity: 0.3;
}
input {
  color: #000 !important;
}
.v-text-field__prefix {
  position: absolute;
}
.prepend {
  display: flex;
  align-items: center;
  &__icon {
    margin-right: 10px;
  }
  &__label {
    white-space: nowrap;
  }
}
.input-wrapper {
  position: relative;
  &__click-mask {
    position: absolute;
    top: 0;
    left: 0;
    right: 30px;
    bottom: 0;
    z-index: 100000;
    cursor: pointer;
  }
}
</style>
