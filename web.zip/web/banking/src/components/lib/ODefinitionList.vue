<template>
  <div :class="items.length > 4 ? 'flex' : ''">
    <dl
      v-for="(item, index) in items"
      :key="index"
      :class="inline ? 'flex' : ''"
    >
      <dt
        :style="{
          color: titleColor,
          minWidth: minLabelWidth ? minLabelWidth + 'px' : '',
        }"
      >
        {{ item.title }}
      </dt>
      <dd>
        <slot
          v-if="$scopedSlots[item.key] && item.value"
          :name="`${item.key}`"
          :item="item"
          :value="item.value"
          :index="index"
        />
        <template v-else>
          {{ item.value || "-" }}
        </template>
      </dd>
    </dl>
  </div>
</template>
<script>
export default {
  name: "ODefinitionList",
  props: {
    items: {
      type: Array,
      required: true,
      default: () => [],
    },
    titleColor: {
      type: String,
      default: "#000",
    },
    inline: {
      type: Boolean,
      default: false,
    },
    minLabelWidth: {
      type: Number,
      default: 140,
    },
  },
};
</script>
<style lang="scss" scoped>
dt {
  font-weight: 600;
}
dd {
  margin-bottom: 20px;
}
.flex {
  display: flex;
  flex-wrap: wrap;
  dl {
    width: 50%;
  }
}
</style>
