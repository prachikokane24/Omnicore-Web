<template>
  <v-badge
    :bordered="bordered"
    :color="color"
    :content="content"
    :overlap="overlap"
  >
    <slot />
  </v-badge>
</template>

<script>
export default {
  props: {
    bordered: {
      type: Boolean,
      default: false,
    },
    overlap: {
      type: Boolean,
      default: false,
    },
    content: {
      type: String,
    },
    color: {
      type: String,
    },
  },
};
</script>

<style lang="scss" scoped></style>
