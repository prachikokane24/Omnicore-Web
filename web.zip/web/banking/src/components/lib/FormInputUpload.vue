<template>
  <div>
    Response:
    <pre>{{ response }}</pre>

    <v-file-input
      v-model="files"
      counter
      multiple
      show-size
      required="true"
    ></v-file-input>
    <br />
    <v-progress-linear :value="progress[0] || 0"></v-progress-linear>
    <br />
    <OButton
      @click="handleUpload"
      :loading="progress > 0 && progress < 100 ? true : false"
      x-large
      >Upload</OButton
    >
  </div>
</template>

<script>
import axios from "axios";
import OButton from "@/components/OButton";
export default {
  components: {
    OButton,
  },
  data() {
    return {
      files: [],
      progress: [],
      response: null,
    };
  },
  methods: {
    async handleUpload() {
      try {
        await Promise.all(
          this.files.map(async (file, index) => {
            await this.uploadFile(file, index);
          })
        );
      } catch (e) {
        console.log(e);
      }
    },
    async uploadFile(file, index) {
      this.progress = [0];
      return new Promise((resolve, reject) => {
        if (this.progress[index] !== 100) {
          const data = new FormData(); // https://developer.mozilla.org/en-US/docs/Web/API/FormData/Using_FormData_Objects
          data.append("image", file); // change to whatever property your endpoint expects { image: file }, or { file: file } / image: (binary)
          const config = {
            headers: {
              Authorization: "Client-ID 90ef1830bd083ba",
            },
            onUploadProgress: (progressEvent) => {
              let percentCompleted = Math.round(
                (progressEvent.loaded * 100) / progressEvent.total
              );
              this.$set(this.progress, index, percentCompleted);
            },
          };
          // Your request goes here
          axios
            .post("https://api.imgur.com/3/image", data, config)
            .then((response) => {
              this.response = response; // returns response from endpoint
              return resolve();
            })
            .catch((error) => {
              console.log(error);
              reject(error);
            });
        } else {
          resolve();
        }
      });
    },
  },
};
</script>
