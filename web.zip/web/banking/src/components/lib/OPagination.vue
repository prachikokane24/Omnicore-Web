<template>
  <div class="o-pagination">
    <v-pagination
      @input="handleInput"
      :value="pageNumber"
      :length="pageCount"
      :total-visible="totalVisible"
    />
  </div>
</template>
<script>
export default {
  name: "OPagination",
  props: {
    value: {
      type: Number,
      default: 0,
    },
    pageCount: {
      type: Number,
      default: 500,
    },
    totalVisible: {
      type: Number,
      default: 10,
    },
    disabled: {
      type: Boolean,
      default: false,
    },
  },
  computed: {
    pageNumber() {
      return this.value;
    },
  },
  methods: {
    handleInput(val) {
      this.$emit("change", val);
    },
  },
};
</script>
<style lang="scss" scoped>
.o-pagination {
  display: flex;
}
</style>
