<template>
  <div class="o-tabs-vertical">
    <div class="o-tabs-vertical__col-1">
      <OQuickView
        color="transparent"
        class="mb-0 rounded-lg"
        :items="mappedItems"
        :preSelected="preSelected"
        @change="handleQuickChange"
        v-if="$vuetify.breakpoint.smAndDown"
      />
      <ONavVertical
        :items="items"
        :preSelected="value"
        :icon="icon"
        :title="title"
        @change="handleChange"
        v-else
      />
    </div>
    <div class="o-tabs-vertical__col-2">
      <slot :componentKey="componentKey" />
    </div>
  </div>
</template>
<script>
import ONavVertical from "./ONavVertical";
import OQuickView from "./OQuickView";
export default {
  components: {
    ONavVertical,
    OQuickView,
  },
  props: {
    value: {
      type: String,
      required: true,
    },
    items: {
      type: Array,
      required: true,
    },
    icon: {
      type: String,
      default: "chevronRight",
    },
    title: {
      type: String,
    },
  },
  data() {
    return {
      componentKey: 0,
    };
  },
  computed: {
    preSelected() {
      return this.value;
    },
    mappedItems() {
      return this.items.map(({ name, cmp }) => {
        return {
          label: name,
          value: cmp,
        };
      });
    },
  },
  methods: {
    forceRerender() {
      this.componentKey += 1;
    },
    handleChange(val) {
      this.$emit("input", val);
    },
    handleQuickChange({ value }) {
      this.$emit("input", value);
    },
  },
};
</script>
<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";
.o-tabs-vertical {
  display: flex;
  flex-direction: column;
  @media #{map-get($display-breakpoints, 'md-and-up')} {
    flex-direction: row;
  }
  &__col-1 {
    box-shadow: 0 0 0 1px var(--v-border-base);
    background-color: var(--v-border-base);
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      background-color: transparent;
    }
  }
  &__col-1,
  &__col-2 {
    margin: 10px;
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      margin: 20px;
    }
  }
  &__col-2 {
    flex: 1;
  }
}
</style>
