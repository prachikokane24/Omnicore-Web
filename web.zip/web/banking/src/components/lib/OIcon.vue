<template>
  <v-icon
    v-bind="[$props]"
    :x-small="xSmall"
    :small="small"
    :large="large"
    :x-large="xLarge"
    :class="[colorClasses, underlineClasses]"
    :style="{ opacity: opacity }"
    :dark="dark"
    :fab="false"
  >
    {{ icons[icon] }}
  </v-icon>
</template>

<script>
const icons = {
  alert: "mdi-alert",
  accept: "mdi-checkbox-marked-circle",
  account: "mdi-account",
  pencil: "mdi-pencil",
  eye: "mdi-eye",
  plus: "mdi-plus",
  plusCircleOutline: "mdi-plus-circle-outline",
  minus: "mdi-minus",
  menu: "mdi-menu",
  clock: "mdi-clock-time-four-outline",
  arrowLeft: "mdi-arrow-left-bold-circle-outline",
  arrowRight: "mdi-arrow-right-bold-circle-outline",
  pointerLeft: "mdi-arrow-left",
  pointerRight: "mdi-arrow-right",
  close: "mdi-close",
  email: "mdi-email",
  closeCircle: "mdi-close-circle",
  chevronLeft: "mdi-chevron-left",
  chevronRight: "mdi-chevron-right",
  address: "mdi-home-outline",
  phone: "mdi-phone",
  wallet: "mdi-wallet",
  weatherSunny: "mdi-weather-sunny",
  tick: "mdi-check",
  tickCircle: "mdi-check-circle",
  lock: "mdi-lock",
  creditCardSync: "mdi-credit-card-sync",
  creditCard: "mdi-credit-card",
  numeric: "mdi-numeric",
  cursorPointer: "mdi-cursor-pointer",
  snowflake: "mdi-snowflake",
  snowflakeOff: "mdi-snowflake-off",
  fileExcel: "mdi-file-excel"
};

export default {
  name: "OIcon",
  props: {
    icon: {
      required: true,
      type: String,
      validator: (val) => {
        if (icons[val]) return true;
        console.error("Icon not found");
        return false;
      },
    },
    dark: {
      type: Boolean,
      default: false,
    },
    xSmall: {
      type: Boolean,
      default: false,
    },
    small: {
      type: Boolean,
      default: false,
    },
    large: {
      type: Boolean,
      default: false,
    },
    xLarge: {
      type: Boolean,
      default: false,
    },
    opacity: {
      type: Number,
      default: 1,
    },
    type: {
      type: String,
      default: undefined,
    },
    color: {
      type: String,
      default: undefined,
    },
    noUnderline: {
      type: Boolean,
      default: true,
    },
  },
  data() {
    return {
      icons: icons,
    };
  },
  computed: {
    colorClasses() {
      return {
        [`${this.color}--text`]: this.color,
      };
    },
    underlineClasses() {
      return {
        ["no-underline"]: this.noUnderline,
      };
    },
  },
};
</script>
<style lang="scss" scoped>
.no-underline {
  text-decoration: none;
}
</style>
