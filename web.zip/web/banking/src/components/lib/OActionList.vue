<template>
  <v-list>
    <v-list-item-group>
      <template v-if="items">
        <v-list-item
          v-for="(item, j) in items"
          :key="`item_${j}`"
          class="item"
          @click="handleItemClick(item)"
          @keypress.enter="handleItemClick(item)"
        >
          <v-list-item-avatar v-if="item.icon">
            <OIcon :icon="item.icon" large color="primary" />
          </v-list-item-avatar>
          <v-list-item-action>
            <v-list-item-content>
              <v-list-item-title>{{ item.title }}</v-list-item-title>
              <v-list-item-subtitle v-if="item.subtitle">{{
                item.subtitle
              }}</v-list-item-subtitle>
            </v-list-item-content>
          </v-list-item-action>
        </v-list-item>
      </template>
    </v-list-item-group>
    <!-- <v-list-item-group v-model="settings" multiple active-class="">
      <v-list-item>
        <template v-slot:default="{ active }">
          <v-list-item-action>
            <v-checkbox :input-value="active"></v-checkbox>
          </v-list-item-action>

          <v-list-item-content>
            <v-list-item-title>Notifications</v-list-item-title>
            <v-list-item-subtitle
              >Notify me about updates to apps or games that I
              downloaded</v-list-item-subtitle
            >
          </v-list-item-content>
        </template>
      </v-list-item>

      <v-list-item>
        <template v-slot:default="{ active }">
          <v-list-item-action>
            <v-checkbox :input-value="active"></v-checkbox>
          </v-list-item-action>

          <v-list-item-content>
            <v-list-item-title>Sound</v-list-item-title>
            <v-list-item-subtitle
              >Auto-update apps at any time. Data charges may
              apply</v-list-item-subtitle
            >
          </v-list-item-content>
        </template>
      </v-list-item>

      <v-list-item>
        <template v-slot:default="{ active }">
          <v-list-item-action>
            <v-checkbox :input-value="active"></v-checkbox>
          </v-list-item-action>

          <v-list-item-content>
            <v-list-item-title>Auto-add widgets</v-list-item-title>
            <v-list-item-subtitle
              >Automatically add home screen widgets when downloads
              complete</v-list-item-subtitle
            >
          </v-list-item-content>
        </template>
      </v-list-item>
    </v-list-item-group> -->
  </v-list>
</template>

<script>
import OIcon from "./OIcon.vue";
export default {
  name: "OActionList",
  components: {
    OIcon,
  },
  props: {
    items: {
      type: Array,
      required: true,
      default: () => [],
    },
  },
  methods: {
    handleItemClick(item) {
      this.$emit("itemClick", item.action);
    },
  },
};
</script>

<style lang="scss" scoped>
.text-wrap {
  //border-bottom: 1px solid grey;
}
</style>
