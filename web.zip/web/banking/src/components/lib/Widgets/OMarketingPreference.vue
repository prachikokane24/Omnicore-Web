<template>
  <div>
    <OText type="div" size="sm" medium
      ><span v-html="formConfig.questionText" />
    </OText>
    <v-container class="grey lighten-5">
      <v-row no-gutters>
        <v-col cols="12" sm="3">
          <OFormCheckbox
            v-bind="formConfig.denySMS"
            v-model="formItems.denySMS"
          ></OFormCheckbox>
        </v-col>
        <v-col cols="12" sm="3">
          <OFormCheckbox
            v-bind="formConfig.denyEmail"
            v-model="formItems.denyEmail"
          ></OFormCheckbox>
        </v-col>
        <v-col cols="12" sm="3">
          <OFormCheckbox
            v-bind="formConfig.denyPhone"
            v-model="formItems.denyPhone"
          ></OFormCheckbox>
        </v-col>
        <v-col cols="12" sm="3">
          <OFormCheckbox
            v-bind="formConfig.denyPost"
            v-model="formItems.denyPost"
          ></OFormCheckbox>
        </v-col>
      </v-row>
    </v-container>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch, Prop } from "vue-property-decorator";
import { BaseStateInterface } from "@/types/store.types";
import { Action, namespace } from "vuex-class";

@Component({
  components: {
    OFormCheckbox: () => import("@/components/lib/Form/OFormCheckbox.vue"),
    OText: () => import("@/components/lib/OText.vue"),
  },
  props: ["value"],

})
export default class MarketingPreferences extends Vue {
    value: any;
    formItems: any = {
    };
    initialSyncComplete = false;

    get initialData() {
      return {
        denySMS: this.value.optedInChannels?.includes('sms') ? false : true,
        denyEmail: this.value.optedInChannels?.includes('email') ? false : true,
        denyPhone: this.value.optedInChannels?.includes('phone') ? false : true,
        denyPost: this.value.optedInChannels?.includes('post') ? false : true,
      }
    }

    get formConfig() {
      return {
        denySMS: {
          name: "DenySMS",
          preSelected: this.initialData.denySMS,
          label: this.$t('marketing.formDenySMSLabel'),
          hint: this.$t('marketing.formDenySMSLabel'),
        },    
        denyEmail: {
          name: "denyEmail",
          preSelected: this.initialData.denyEmail,
          label: this.$t('marketing.formDenyEmailLabel'),
          hint: this.$t('marketing.formDenyEmailLabel'),
        },    
        denyPhone: {
          name: "DenyPhone",
          preSelected: this.initialData.denyPhone,
          label: this.$t('marketing.formDenyTelephoneLabel'),
          hint: this.$t('marketing.formDenyTelephoneLabel'),
        },    
        denyPost: {
          name: "DenyPost",
          preSelected: this.initialData.denyPost,
          label: this.$t('marketing.formDenyPostLabel'),
          hint: this.$t('marketing.formDenyPostLabel'),
        },    
        questionText: this.value.question,
        questionId: this.value.questionId,
      };
    }

    mapUpdatedValues(newValue) {
        var optedInChannels:string[] = [];
        if(!newValue.denySMS?.value) { optedInChannels.push("sms"); }
        if(!newValue.denyEmail?.value) { optedInChannels.push("email"); }
        if(!newValue.denyPhone?.value) { optedInChannels.push("phone"); }
        if(!newValue.denyPost?.value) { optedInChannels.push("post"); }
        var optedIn = optedInChannels.length > 0 ? "allowed" : "notAllowed";
        return {
          questionId: this.formConfig.questionId,
          question: this.formConfig.questionText,
          optedIn,
          optedInChannels
        }
    }
    @Watch("formItems", { deep: true })
    emitOnValueChanges() {
      if(!this.initialSyncComplete) {
        if((!this.initialData.denySMS || this.formItems.denySMS?.value) &&
           (!this.initialData.denyEmail || this.formItems.denyEmail?.value) &&
           (!this.initialData.denyPhone || this.formItems.denyPhone?.value) &&
           (!this.initialData.denyPost || this.formItems.denyPost?.value) )
           {
             // model has synced with intial data now, so start checking for changes
             this.initialSyncComplete = true;
           }
      }
      else
      {
        this.$emit('input', this.mapUpdatedValues(this.formItems));
      }
    }

}
</script>
