<template>
    <v-container ma-0 pa-0>
    </v-container>
</template>

<script lang="ts">

import Vue from "vue";
import OButton from "../OButton.vue";
import ODatePicker from "../ODatePicker.vue";
import OFormSelect from "../Form/OFormSelect.vue";
import OSheet from "../OSheet.vue";
import OFormInput from "../Form/OFormInput.vue";
import Component from "vue-class-component";
import { Prop } from "vue-property-decorator";

@Component({ components: { OFormSelect, OSheet, OFormInput, OButton, ODatePicker } })
export default class OAddPayeeAction extends Vue {
    @Prop() isPerformingAction?: boolean
}
</script>

