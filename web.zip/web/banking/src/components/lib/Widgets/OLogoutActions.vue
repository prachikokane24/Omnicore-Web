<template>
  <div>
    <v-list-item link @click="handleLogout">
      <v-list-item-icon>
        <v-icon>mdi-exit-to-app</v-icon>
      </v-list-item-icon>
      <v-list-item-title>Logout</v-list-item-title>
    </v-list-item>
  </div>
</template>
<script lang="ts">
import { Vue, Component } from "vue-property-decorator";

@Component({})
export default class OLogoutActions extends Vue {
  handleLogout() {
    this.$router.push({ name: "Logout" });
  }
}
</script>