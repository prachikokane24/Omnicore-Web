<template>
  <v-card ma-0 pa-0 elevation="0">
    <v-overlay :value="isLoading" :absolute="true" opacity="0.2">
      <ODot v-if="isLoading" class="loader" aria-role="presentation" />
    </v-overlay>
    <o-form-select
      :items="selectFrom"
      :disabled="isLoading"
      label="Select From"
      dense
      small
      solo
      outlined
      hide-details
      class="mb-2"
    />
    <o-form-select
      :items="transferTo"
      :disabled="isLoading"
      label="Transfer To"
      dense
      small
      solo
      outlined
      hide-details
      class="mb-2"
    />
    <o-form-input
      :disabled="isLoading"
      label="Amount"
      name="PaymentAmount"
      v-mask="'########.##'"
      dense
      small
      solo
      outlined
      hide-details
      class="mb-2"
    />
    <v-container v-if="showMoreOptions" ma-0 pa-0>
      <v-divider></v-divider>
      <o-form-select
        :items="transferFrequencies"
        :disabled="isLoading"
        label="Frequency"
        dense
        small
        solo
        outlined
        hide-details
        class="mb-2"
      />
      <o-date-picker
        label="Date"
        :disabled="isPerformingAction"
        dense
        outlined
        hide-details
      />
    </v-container>
    <v-container v-if="message !== ''">
      <OAlert
        :icon="
          messageType == 'success'
            ? 'mdi-check-circle-outline'
            : 'mdi-alert-circle-outline'
        "
        :type="messageType"
        >{{ message }}</OAlert
      >
    </v-container>
    <OButton hide-details block class="mb-2" @click="onMoreOption"
      >{{ showMoreOptions ? "Less" : "More" }} options</OButton
    >
    <OButton
      hide-details
      block
      class="mb-2"
      :loading="isLoading"
      @click="performAction"
      >Pay now</OButton
    >
  </v-card>
</template>

<script lang="ts">
import Vue from "vue";
import OButton from "../OButton.vue";
import ODatePicker from "../ODatePicker.vue";
import OFormSelect from "../Form/OFormSelect.vue";
import OSheet from "../OSheet.vue";
import ODot from "../Loader/ODot.vue";
import OFormInput from "../Form/OFormInput.vue";
import Component from "vue-class-component";
import { Prop } from "vue-property-decorator";
import OAlert from "../OAlert.vue";

@Component({
  components: {
    OFormSelect,
    OSheet,
    OFormInput,
    OButton,
    ODatePicker,
    ODot,
    OAlert,
  },
})
export default class OMakePaymentAction extends Vue {
  @Prop() isPerformingAction?: boolean;
  selectFrom = ["Wallet 1", "Wallet 2"];
  transferTo = ["Wallet 1", "Wallet 2"];
  transferFrequencies = ["One off", "Daily", "Weekly", "Monthly", "Yearly"];
  showMoreOptions = false;
  isLoading = false;
  message = "";
  messageType = "";

  onMoreOption() {
    this.showMoreOptions = !this.showMoreOptions;
  }

  performAction() {
    if (this.isLoading) {
      return;
    }

    // TODO: message display is copied on all actions
    // it needs to be extracted as a component
    this.isLoading = true;
    this.message = "";
    this.$emit("actionstatechanged", true);
    setTimeout(() => {
      this.isLoading = false;
      this.message = "Payment successful";
      this.messageType = "success";
      this.$emit("actionstatechanged", false);
    }, 3000);
  }
}
</script>
