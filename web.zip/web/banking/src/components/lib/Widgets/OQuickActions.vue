<template>
  <div class="ml-14">
    <v-list-item link @click="$modal.show('instantPayment')">
      <v-list-item-content>
        <v-list-item-title data-id="instantPaymentLink">&rarr; Make a single payment</v-list-item-title>
      </v-list-item-content>
    </v-list-item>
    <v-list-item link @click="$modal.show('instantTransfer')">
      <v-list-item-content>
        <v-list-item-title data-id="instantTransferLink"> &rarr; Make a single transfer</v-list-item-title>
      </v-list-item-content>
    </v-list-item>   
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

@Component({
  components: {
    OText: () => import("@/components/lib/OText.vue"),
    OAlign: () => import("@/components/lib/OAlign.vue") 
  },
})
export default class OAccountActions extends Vue {}
</script>
