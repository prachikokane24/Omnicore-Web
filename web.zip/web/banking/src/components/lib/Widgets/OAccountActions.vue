<template>
  <div class="ml-14">
    <v-list-item>
      <v-list-item-content>
        <v-list-item-title><b>My Accounts:</b></v-list-item-title>
      </v-list-item-content>
    </v-list-item>
    <div v-for="(item, key) in mapAccounts" :key="key">
      <v-list-item
        link
        class="ml-3"
        @click.native="changeAccount(item.accountId)"
        v-if="item.accountType == 'current' || item.accountType == 'joint'"
      >
        <v-list-item-content>
          <v-list-item-title>{{
            item.accountType | capsFirstLetter
          }}</v-list-item-title>
        </v-list-item-content>
      </v-list-item>
    </div>
    <div v-if="hasLinkedAccounts">
      <v-list-item>
        <v-list-item-content>
          <v-list-item-title><b>Linked Accounts:</b></v-list-item-title>
        </v-list-item-content>
      </v-list-item>
      <div v-for="(item, key) in mapAccounts" :key="key">
        <v-list-item
          link
          class="ml-3"
          @click.native="changeAccount(item.accountId)"
          v-if="item.accountType == 'youth'"
        >
          <v-list-item-content>
            <v-list-item-title>{{
              item.accountType | capsFirstLetter
            }}</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { mapGetters } from "vuex";
import { Component, Vue } from "vue-property-decorator";

@Component({
  components: {
    OText: () => import("@/components/lib/OText.vue"),
    OAlign: () => import("@/components/lib/OAlign.vue"),
  },
  computed: {
    ...mapGetters("summaryModule", {
      getAllUserAccountWallets: "getAllUserAccountWallets",
    }),
  },
})
export default class OAccountActions extends Vue {
  getAllUserAccountWallets!: any;

  get mapAccounts(): {
    accountType: string;
  } {
    return this.getAllUserAccountWallets?.map((account) => {
      return {
        accountId: account.accountId,
        accountType: account.accountType,
        wallets: account.wallets,
      };
    });
  }

  get hasLinkedAccounts(): boolean {
    return this.getAllUserAccountWallets?.filter(
      (obj) => obj.accountType === "youth"
    ).length;
  }

  changeAccount(accountId) {
    this.$EventBus.$emit("changeAccount", accountId);
  }
}
</script>
