<template>
  <div class="ml-14" id="important-links">
     <v-list-item v-for="link in links" :key="link.name">
      <v-list-item-content>
        <v-list-item-title> <a color="primary" :href="link.href" target="_blank"> {{ link.name }}</a>
        </v-list-item-title>
      </v-list-item-content>
    </v-list-item>

    <v-list-item v-for="link in linksWithImage" :key="link.name">
      <v-list-item-content>
        <v-list-item-title>
           <a :href="link.href" target="_blank">
            <v-img :src="link.img" :alt="link.alt" max-width="194" max-height="58">
            </v-img>      
          </a>
        </v-list-item-title>
      </v-list-item-content>
    </v-list-item>
    
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

@Component({
 
})
export default class OImportantLinks extends Vue {
   
links = [{
        name: 'Terms and Conditions',
        href: 'https://www.voxmoney.co.uk/terms-conditions/'
    },
    {
        name: 'Privacy Policy',
        href: 'https://www.voxmoney.co.uk/privacy-policy/'
    },
    {
        name: 'FAQs',
        href: 'https://www.voxmoney.co.uk/faqs'
    },
    {
        name: 'Contact Us',
        href: 'https://www.voxmoney.co.uk/contact/'
    }
]

linksWithImage = [

    {
        name: 'App Store',
        href: 'https://apps.apple.com/gb/app/vox-money/id1539396410/',
        img: 'https://cdn1.cronometer.com/2021/landing/ios-icon.svg',
        alt: "Apple App Store Icon"
    },
    {
        name: 'Google Play',
        href: 'https://play.google.com/store/apps/details?id=uk.co.voxmoney',
        img: 'https://cdn1.cronometer.com/2021/landing/android-icon.svg',
        alt: "Google Play App Store Icon"
    }
]
}
</script>