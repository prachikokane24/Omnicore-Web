<template>
  <div class="ml-14">
     <v-list-item v-for="link in links" :key="link.name">
      <v-list-item-content>
        <v-list-item-title> <a :href="link.href" rel="noreferrer noopener"> {{ link.name }}
    </a></v-list-item-title>
      </v-list-item-content>
    </v-list-item>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

@Component({
 
})
export default class OImportantLinks extends Vue {
     
   links = [{
        name: 'Terms and Conditions',
        href: 'https://www.mbsmoney.co.uk/terms-conditions/'
    },
    {
        name: 'Privacy Policy',
        href: 'https://www.mbsmoney.co.uk/privacy-policy/'
    },
    {
        name: 'FAQs',
        href: 'https://www.mbsmoney.co.uk/faqs'
    },
    {
        name: 'Contact Us',
        href: 'https://www.mbsmoney.co.uk/contact/'
    },
    {
        name: 'App Store',
        href: 'https://apps.apple.com/gb/app/vox-money/id1539396410/'
    },
    {
        name: 'Google Play',
        href: 'https://play.google.com/store/apps/details?id=uk.co.voxmoney'
    }
]
          

}
</script>
