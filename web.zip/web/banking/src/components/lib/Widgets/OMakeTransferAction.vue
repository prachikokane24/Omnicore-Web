<template>
    <v-card ma-0 pa-0 elevation="0">
        <v-overlay :value="isLoading" :absolute="true" opacity="0.2">
            <ODot v-if="isLoading" class="loader" aria-role="presentation" />
        </v-overlay>
        <!-- <OModalOTPCheck id="otpCheck" v-bind="[$attrs, $props]" v-on="$listeners" /> -->
        <o-form-select 
            :items="selectFrom"
            :items-text="(item) => str(item)"
            :items-value="(item) => str(item)"
            :disabled="isPerformingAction"
            v-model="selectedFrom"
            label="Select From"
            dense small solo outlined hide-details class="mb-2"  />
        <o-form-select 
            :items="transferTo" 
            :items-text="(item) => str(item)"
            :items-value="(item) => str(item)"            
            :disabled="isPerformingAction"
            v-model="selectedTo"
            label="Transfer To"
            dense small solo outlined hide-details class="mb-2" />
        <o-form-input 
            :disabled="isPerformingAction"
            label="Amount"
            name="TransferAmount"
            dense small solo outlined hide-details 
        />
        <o-form-input 
            :disabled="isPerformingAction"
            label="Payee reference"
            name="PayeeReference"
            dense small solo outlined hide-details 
        />
        <v-container v-if="message !== ''">
            <OAlert 
                :icon='messageType == "success" ? "mdi-check-circle-outline" : "mdi-alert-circle-outline"'
                :type="messageType"
                >{{ message }}</OAlert>
        </v-container>        
        <OButton small hide-details block class="mb-2" :loading="isLoading" @click="performAction">Transfer</OButton>
    </v-card>
</template>

<script lang="ts">

import Vue from "vue";
import OButton from "../OButton.vue";
import ODatePicker from "../ODatePicker.vue";
import OFormSelect from "../Form/OFormSelect.vue";
import OSheet from "../OSheet.vue";
import ODot from "../Loader/ODot.vue";
import OFormInput from "../Form/OFormInput.vue";
// import OModalOTPCheck from "../Modal/OModalOTPCheck.vue";
import Component from "vue-class-component";
import { Prop } from "vue-property-decorator";
import OAlert from "../OAlert.vue";

@Component({ components: { OFormSelect, OSheet, OFormInput, OButton, ODatePicker, ODot, OAlert } })
export default class OMakeTransferAction extends Vue {
    // todo: loading logo to say we are doign somethign

    @Prop() isPerformingAction?: boolean
    selectFrom: string[] = ["Wallet 1", "Wallet 2", "Card 1", "Card 2"]
    selectedFrom = "Wallet 1"

    transferTo: string [] = ["Wallet 1", "Wallet 2", "Card 1", "Card 2"]
    selectedTo = "Wallet 2"

    transferFrequencies = ["every week"]

    isLoading = false;
    message = "";
    messageType = "";


    performAction() {
        if (this.isLoading) {
            return;
        }
        // this.$modal.show("otpCheck");

        // TODO: message display is copied on all actions 
        // it needs to be extracted as a component
        this.isLoading = true;
        this.message = "";
        this.$emit("actionstatechanged", true);
        setTimeout(() => {
            this.isLoading = false;
            this.message = "Transfer successful";
            this.messageType = "success";
            this.$emit("actionstatechanged", false);
        }, 3000);
    }
}
</script>
<style scoped>
.message_error {
    color: red;
}
.message_ok {
    color: green;
}
</style>
