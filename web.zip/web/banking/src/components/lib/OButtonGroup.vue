<template>
  <div class="wrapper d-flex flex-wrap" :class="divClasses">
    <slot />
  </div>
</template>
<script>
export default {
  props: {
    left: {
      type: Boolean,
      default: false,
    },
    right: {
      type: Boolean,
      default: false,
    },
    center: {
      type: Boolean,
      default: false,
    },
    spaceBetween: {
      type: Boolean,
      default: false,
    },
    fluid: {
      type: Boolean,
      default: false,
    },
    fill: {
      type: Boolean,
      default: false,
    },
  },
  computed: {
    divClasses() {
      return {
        "d-flex-fluid": this.fluid,
        "d-flex-fill": this.fill,
        "justify-space-between": this.spaceBetween,
        "justify-start": this.left,
        "justify-center": this.center,
        "justify-end": this.right,
      };
    },
  },
};
</script>

<style lang="scss" scoped>
.wrapper {
  // margin-left: -5px;
  // margin-right: -5px;
  > button,
  > div {
    // margin: 0 5px;
    margin-bottom: 5px;
  }
  > button:not(:last-child),
  > div:not(:last-child) {
    margin-right: 10px;
  }
}
.d-flex-fluid {
  width: 100%;
}
.d-flex-fill {
  width: 100%;
  > div {
    flex: 1;
  }
}
</style>
