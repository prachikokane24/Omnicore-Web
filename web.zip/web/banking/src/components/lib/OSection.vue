<template>
  <div :style="styles" v-bind="$attrs">
    <slot />
  </div>
</template>
<script>
export default {
  name: "OSection",
  props: {
    color: {
      type: String,
      default: "",
    },
  },
  computed: {
    styles() {
      return {
        backgroundColor: this.colors[this.color],
      };
    },
    colors() {
      return {
        primary: this.$vuetify.theme.dark
          ? this.$vuetify.theme.themes.dark.primary
          : this.$vuetify.theme.themes.light.primary,
        secondary: this.$vuetify.theme.dark
          ? this.$vuetify.theme.themes.dark.secondary
          : this.$vuetify.theme.themes.light.secondary,
        tertairy: this.$vuetify.theme.dark
          ? this.$vuetify.theme.themes.dark.tertairy
          : this.$vuetify.theme.themes.light.tertairy,
      };
    },
  },
};
</script>
