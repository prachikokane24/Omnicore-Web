<template>
  <OSheet class="quick-view" :color="color">
    <OText size="sm" medium class="mb-2" v-if="title">{{ title }}</OText>
    <OForm hideActions>
      <OFormSelect
        @input="handleChange"
        :name="name"
        :items="items"
        :filled="filled"
        :preSelected="preSelected"
        @change="handleChange"
        hide-details
        hide-label
        outlined
        dense
        small
      />
    </OForm>
  </OSheet>
</template>
<script>
import OSheet from "./OSheet.vue";
import OForm from "./Form/OForm.vue";
import OFormSelect from "./Form/OFormSelect.vue";
export default {
  components: {
    OSheet,
    OForm,
    OFormSelect,
  },
  props: {
    title: {
      type: String,
    },
    items: {
      type: Array,
      required: true,
    },
    preSelected: {
      type: [Number, String],
      required: true,
    },
    filled: {
      type: Boolean,
      required: false,
    },
    name: {
      type: String,
      default: "tab",
    },
    color: {
      type: String,
      default: "white",
    },
  },
  methods: {
    handleChange(val) {
      this.$emit("change", val);
    },
  },
};
</script>
<style lang="scss" scoped>
.quick-view {
  z-index: 1;
  position: relative;
  padding: 15px 10px 15px 10px;
  margin-bottom: 20px;
}
</style>
