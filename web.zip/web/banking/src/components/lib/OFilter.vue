<template>
  <div>
    <OForm
      ref="filterForm"
      v-bind="[$attrs, $props]"
      v-on="$listeners"
      hideActions
      inline
    >
      <div
        v-for="(
          { name, type, label, preSelected, items, maxWidth }, key
        ) in filterConfigMapped"
        :key="key"
      >
        <OFormSelect
          v-if="type == 'select'"
          v-model="formItems[name]"
          @input="handleFilterChange"
          :name="name"
          :label="label"
          :items="items"
          :filled="false"
          :preSelected="preSelected"
          :style="{ 'max-width': maxWidth }"
          hide-details
          outlined
          dense
          small
          class="ml-2"
        />
      </div>
    </OForm>
  </div>
</template>

<script>
import OForm from "./Form/OForm";
import OFormSelect from "./Form/OFormSelect";
export default {
  inheritAttrs: false,
  components: {
    OForm,
    OFormSelect,
  },
  props: {
    filterConfig: {
      type: Array,
      require: true,
      default: () => [],
    },
    loading: {
      type: Boolean,
      default: false,
    },
    inline: {
      type: Boolean,
      default: false,
    },
    preSelected: {
      type: [Number, String],
      default: undefined,
    },
  },
  data() {
    return {
      formItems: {},
    };
  },
  watch: {
    formItems() {
      this.$emit("change", this.formItems);
    },
  },
  computed: {
    filterConfigMapped() {
      return this.filterConfig.map((item) => {
        item.maxWidth = item.maxWidth || "150px";
        return item;
      });
    },
  },
  methods: {
    handleFilterChange() {
      this.$emit("change", this.formItems);
    },
  },
};
</script>
<style lang="scss" scoped>
.form {
  display: flex;
  flex-direction: row;
}
</style>
