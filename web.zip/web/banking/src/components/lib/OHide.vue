<template>
  <div :class="divClasses" class="hide">
    <slot />
  </div>
</template>
<script>
export default {
  name: "OHide",
  props: {
    xs: {
      type: Boolean,
      default: false,
    },
    sm: {
      type: Boolean,
      default: false,
    },
    md: {
      type: Boolean,
      default: false,
    },
    lg: {
      type: Boolean,
      default: false,
    },
    xl: {
      type: Boolean,
      default: false,
    },
    xsUp: {
      type: Boolean,
      default: false,
    },
    smUp: {
      type: Boolean,
      default: false,
    },
    mdUp: {
      type: Boolean,
      default: false,
    },
    lgUp: {
      type: Boolean,
      default: false,
    },
    xlUp: {
      type: Boolean,
      default: false,
    },
    xsDown: {
      type: Boolean,
      default: false,
    },
    smDown: {
      type: Boolean,
      default: false,
    },
    mdDown: {
      type: Boolean,
      default: false,
    },
    lgDown: {
      type: Boolean,
      default: false,
    },
    xlDown: {
      type: Boolean,
      default: false,
    },
  },
  computed: {
    divClasses() {
      return {
        "d-none d-sm-block": this.xs,
        "d-sm-none d-md-block": this.sm,
        "d-md-none d-lg-block": this.md,
        "d-lg-none d-xl-block": this.lg,
        "d-xl-none": this.xl,
        "hidden-sm-and-up": this.smUp,
        "hidden-md-and-up": this.mdUp,
        "hidden-lg-and-up": this.lgUp,
        "hidden-xl-and-up": this.xlUp,
        "hidden-sm-and-down": this.smDown,
        "hidden-md-and-down": this.mdDown,
        "hidden-lg-and-down": this.lgDown,
        "hidden-xl-and-down": this.xlDown,
      };
    },
  },
};
</script>
<style lang="scss" scoped>
.hide {
  width: 100%;
}
</style>
