<template>
  <div>
    <OQuickView
      :items="mappedItems"
      class="mb-2 rounded-lg"
      :preSelected="tab"
      @change="handleChange"
      v-if="$vuetify.breakpoint.smAndDown"
    />
    <v-tabs
      v-model="tab"
      class="tabs rounded"
      show-arrows
      slider-color="transparent"
      slider-size="1"
      background-color="transparent"
      color="white"
      :ripple="false"
      @change="handleClickTab"
      v-else
    >
      <v-tab
        v-for="item in items"
        :key="item.tab"
        @change="forceRerender"
        :data-id="`${item.cmp}Tab`"
      >
        {{ item.name }}
      </v-tab>
    </v-tabs>
    <v-tabs-items v-model="tab" class="tab-items">
      <v-tab-item
        v-for="item in items"
        :key="item.name"
        :transition="false"
        :reverse-transition="false"
      >
        <slot
          :cmp="item.cmp"
          :componentKey="componentKey"
          v-if="item.cmp == items[tab].cmp"
        />
        <!-- NOTE: Remove == items[tab].cmp if buggy -->
      </v-tab-item>
    </v-tabs-items>
  </div>
</template>
<script>
import OQuickView from "./OQuickView.vue";
export default {
  name: "OTab",
  components: {
    OQuickView,
  },
  props: {
    items: {
      type: Array,
      default: () => [],
      required: true,
    },
  },
  data() {
    return {
      tab: 0,
      componentKey: 0,
    };
  },
  computed: {
    mappedItems() {
      return this.items.map((item, i) => {
        return {
          label: item.name,
          value: i,
        };
      });
    },
  },
  created() {    
    this.$EventBus.$on("changeTab", this.handleChangeTab);
  },
  methods: {
    handleChangeTab(value) {
      this.tab = value;
    },
    handleChange({ value }) {
      this.tab = value;
    },
    handleClickTab() {
      this.$EventBus.$emit("updateAccountBalance", "TabChanged");
      this.$emit("clickTab");
    },
    forceRerender() {
      this.componentKey += 1;
    },
  },
};
</script>
<style lang="scss" scoped>
.tabs {
  border-radius: 10px;
  z-index: 0;
}
.v-tab {
  background-color: var(--v-background-base);
  border-radius: 15px 15px 0 0;
  box-shadow: inset 0 0 0 1px var(--v-borderdark-base);
  text-transform: capitalize;
  &:before {
    border-radius: 15px 15px 0 0;
  }
  margin-right: 2px;
  font-size: 20px !important;
}
.v-tab--active {
  cursor: default;
  background: var(--v-primary-base);
  border-radius: 15px 15px 0 0;
  box-shadow: inset 0 0 0 1px var(--v-primary-base);
  color: white;
}

.v-tab:not(.v-tab--active):hover {
  background-color: var(--v-primary-base) !important;
  color: #fff !important;
}

::v-deep .v-slide-group__next {
  background: white;
  border-radius: 0 5px 0 0;
}
::v-deep .v-slide-group__prev {
  background: white;
  border-radius: 5px 0 0 0;
}
</style>
