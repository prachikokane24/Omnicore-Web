<template>
  <div>
    <ValidationObserver v-slot="{ invalid, validate }">
      <form @submit.prevent="handleSubmit(validate)">
        <FormCheckbox v-bind="formConfig.agree1" v-model="formItems.agree1" />
        <FormCheckbox v-bind="formConfig.agree2" v-model="formItems.agree2" />
        <OButton type="submit" :disabled="invalid" :loading="loading" x-large
          >Submit</OButton
        >
      </form>
    </ValidationObserver>
  </div>
</template>

<script>
import { ValidationObserver } from "vee-validate";
import FormCheckbox from "@/components/FormCheckbox";
import OButton from "@/components/OButton";
export default {
  name: "Step3",
  components: {
    FormCheckbox,
    OButton,
    ValidationObserver,
  },
  props: {
    loading: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      formItems: {},
    };
  },
  computed: {
    formConfig() {
      return {
        agree1: {
          rules: "required",
          label: "Agree 1",
        },
        agree2: {
          rules: "required",
          label: "Agree 2",
        },
      };
    },
  },
  watch: {
    async formItems() {
      this.emitInput();
    },
  },
  methods: {
    handleSubmit() {
      this.$emit("submit");
    },
    emitInput() {
      this.$emit("input", this.formItems);
    },
  },
};
</script>
