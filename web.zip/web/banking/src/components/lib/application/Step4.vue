<template>
  <div>
    <Alert color="success"
      >Thank you for your application! We have received your application for a
      current account and be in contact via email shortly.
    </Alert>
  </div>
</template>

<script>
import Alert from "../Alert";
export default {
  name: "Step4",
  components: {
    Alert,
  },
};
</script>
