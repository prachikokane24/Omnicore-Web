<template>
  <div>
    <ValidationObserver v-slot="{ invalid, validate }">
      <form @submit.prevent="handleSubmit(validate)">
        <FormInput
          v-bind="formConfig.countryOfBirth"
          v-model="formItems.countryOfBirth"
        />
        <FormInput
          v-bind="formConfig.townOfBirth"
          v-model="formItems.townOfBirth"
        />
        <OButton :disabled="invalid" @click="handleClick" x-large>Next</OButton>
      </form>
    </ValidationObserver>
  </div>
</template>

<script>
import { ValidationObserver } from "vee-validate";
import FormInput from "@/components/FormInput";
import OButton from "@/components/OButton";
export default {
  name: "Step2",
  components: {
    FormInput,
    OButton,
    ValidationObserver,
  },
  data() {
    return {
      formItems: {},
    };
  },
  computed: {
    formConfig() {
      return {
        countryOfBirth: {
          rules: "required",
          label: "Country of Birth",
          required: true,
        },
        townOfBirth: {
          rules: "required",
          label: "Town of Birth",
          required: true,
        },
      };
    },
  },
  watch: {
    async formItems() {
      this.emitInput();
    },
  },
  methods: {
    handleClick() {
      this.$emit("submit");
    },
    emitInput() {
      this.$emit("input", this.formItems);
    },
  },
};
</script>
