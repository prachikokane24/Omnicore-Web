<template>
  <div>
    <FormInputUpload v-model="formItems.upload" />

    <OButton @click="handleGetApp" :loading="userApplicationLoading" x-large
      >Get application</OButton
    >

    <ValidationObserver v-slot="{ invalid, validate }">
      <form @submit.prevent="handleSubmit(validate)">
        <FormInput
          v-bind="formConfig.firstName"
          v-model="formItems.firstName"
        />
        <FormInput
          v-bind="formConfig.secondName"
          v-model="formItems.secondName"
        />
        <FormDOB v-bind="formConfig.dob" v-model="formItems.dob" />
        <FormAddress v-model="formItems.address" />
        <FormCheckbox
          v-bind="formConfig.marketing"
          v-model="formItems.marketing"
        />
        <OButton :disabled="invalid" @click="handleClick" x-large>Next</OButton>
      </form>
    </ValidationObserver>
  </div>
</template>

<script>
import { mapActions, mapState } from "vuex";
import { ValidationObserver } from "vee-validate";
import FormInput from "../FormInput";
import FormCheckbox from "../FormCheckbox";
import FormDOB from "../FormDOB";
import FormAddress from "../FormAddress";
import OButton from "../OButton";
import FormInputUpload from "@/components/FormInputUpload";
export default {
  name: "Step1",
  components: {
    FormInput,
    FormCheckbox,
    FormDOB,
    FormAddress,
    OButton,
    ValidationObserver,
    FormInputUpload,
  },
  data() {
    return {
      formItems: {},
      result: {},
    };
  },
  computed: {
    ...mapState({
      userApplication: (state) => state.applicationModule.userApplication,
      userApplicationData: (state) =>
        state.applicationModule.userApplication.data,
      userApplicationLoading: (state) =>
        state.applicationModule.userApplication.loading,
    }),
    formConfig() {
      return {
        firstName: {
          rules: "required|max:10",
          counter: 10,
          label: "First name",
          required: true,
          preSelected: this.userApplicationData?.firstName,
        },
        secondName: {
          rules: "required|max:10",
          counter: 10,
          label: "Second name",
          required: true,
          preSelected: this.userApplicationData?.secondName,
        },
        dob: {
          rules: "required",
          label: "Date of birth",
          required: true,
        },
        marketing: {
          rules: "required",
          label: "Marketing Preferences",
        },
      };
    },
  },
  watch: {
    async formItems() {
      this.emitInput();
    },
  },
  methods: {
    ...mapActions({
      getApplication: "applicationModule/GET_APPLICATION",
      createApplication: "applicationModule/CREATE_APPLICATION",
    }),
    async handleGetApp() {
      try {
        this.http.get("/payees");
        await this.getApplication();
      } catch (e) {
        console.log(e);
      }
    },
    handleClick() {
      this.$emit("submit");
    },
    emitInput() {
      this.$emit("input", this.formItems);
    },
  },
  async mounted() {
    // try {
    //   let result;
    //   result = await this.omnioClient.post(
    //     "/v3/214341c1-14ca-4125-a78a-a96a11980c23",
    //     { john: "Hello" }
    //   );
    //   this.result = result.data;
    // } catch (e) {
    //   console.log(e);
    // }
    //this.$vuetify.theme.themes.light.success = "#000";
    //console.log(process.env);
  },
};
</script>

<style lang="scss" scoped>
.color {
  color: var(--v-accent-lighten2);
}
</style>
