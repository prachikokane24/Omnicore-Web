<template>
  <div>
    <v-row>
      <v-col class="d-flex" cols="3">
        <FormSelect
          v-model="formItems.day"
          :items="days"
          label="Day"
          @input="emitChange"
        />
      </v-col>
      <v-col class="d-flex" cols="3">
        <FormSelect
          v-model="formItems.month"
          :items="months"
          label="Month"
          @input="emitChange"
          filled
        />
      </v-col>
      <v-col class="d-flex" cols="3">
        <FormSelect
          v-model="formItems.year"
          :items="years"
          label="Year"
          @input="emitChange"
          filled
        />
      </v-col>
    </v-row>
  </div>
</template>

<script>
import FormSelect from "@/components/FormSelect.vue";
export default {
  name: "FormDOB",
  components: {
    FormSelect,
  },
  data() {
    return {
      formItems: {},
    };
  },
  computed: {
    years() {
      return ["1980", "1981", "1982"];
    },
    months() {
      return ["Jan", "Feb", "March"];
    },
    days() {
      return [1, 2, 3, 4, 5, 6];
    },
  },
  methods: {
    async emitChange() {
      this.$emit("input", {
        type: "input",
        value: {
          day: this.formItems.day,
          month: this.formItems.month,
          year: this.formItems.year,
        },
        label: this.label,
      });
    },
  },
};
</script>
