<template>
  <component
    v-bind:is="type"
    :class="[mediaClasses, classes, styleClasses, alignClasses, colorClasses]"
    class="block"
  >
    <OIcon v-if="icon" :icon="icon" class="mr-1" />
    <slot :class="styleClasses" />
    <span v-if="text" v-html="text"></span>
  </component>
</template>
<script>
import OIcon from "./OIcon.vue";
export default {
  name: "OText",
  components: {
    OIcon,
  },
  props: {
    type: {
      type: String,
      default: "span",
    },
    classes: {
      type: String,
      default: undefined,
    },
    icon: {
      type: String,
    },
    size: {
      type: String,
      default: undefined,
      // validator: (value) =>
      //   ["xs", "sm", "md", "lg", "xl", "xxl", "sl", "sxl", "sxxl"].includes(
      //     value
      //   ),
    },
    primary: {
      type: Boolean,
      default: false,
    },
    secondary: {
      type: Boolean,
      default: false,
    },
    tertairy: {
      type: Boolean,
      default: false,
    },
    black: {
      type: Boolean,
      default: false,
    },
    bold: {
      type: Boolean,
      default: false,
    },
    medium: {
      type: Boolean,
      default: false,
    },
    regular: {
      type: Boolean,
      default: false,
    },
    light: {
      type: Boolean,
      default: false,
    },
    thin: {
      type: Boolean,
      default: false,
    },
    italic: {
      type: Boolean,
      default: false,
    },
    none: {
      type: Boolean,
      default: false,
    },
    overline: {
      type: Boolean,
      default: false,
    },
    underline: {
      type: Boolean,
      default: false,
    },
    lineThrough: {
      type: Boolean,
      default: false,
    },
    opacity: {
      type: String,
    },
    transform: {
      type: String,
    },
    elevate: {
      type: Boolean,
      default: false,
    },
    align: {
      type: String,
      validator: (value) => ["left", "center", "right"].includes(value),
    },
    text: {
      type: String,
    },
  },

  computed: {
    mapSize() {
      const classes = {
        xs: "caption",
        sm: "body-2",
        md: "body-1",
        lg: "h6",
        xl: "h5",
        xxl: "h4",
        sl: "h3",
        sxl: "h2",
        sxxl: "h2",
      };
      return {
        [`text-${classes[this.size] || this.size}`]: this.size,
        [`text-sm-${classes[this.sizeSm] || this.sizeSm}`]: this.sizeSm,
        [`text-md-${classes[this.sizeMd] || this.sizeMd}`]: classes[
          this.sizeMd
        ],
        [`text-lg-${classes[this.sizeLg] || this.sizeLg}`]: this.sizeLg,
        [`text-xl-${classes[this.sizeXl] || this.sizeXl}`]: this.sizeXl,
      };
    },
    styleClasses() {
      return {
        elevate: this.elevate,
      };
    },
    alignClasses() {
      return this.align ? `text-${this.align}` : "";
    },
    colorClasses() {
      return this.color ? `${this.color}--text` : "";
    },
    mediaClasses() {
      return {
        ...this.mapSize,
        [`font-weight-${this.weight}`]: this.weight,
        [`text-${this.opacity}`]: this.opacity,
        [`text-${this.transform}`]: this.transform,

        [`primary--text`]: this.primary,
        [`secondary--text`]: this.secondary,
        [`tertairy--text`]: this.tertairy,

        "text-decoration-none": this.none,
        "text-decoration-underline": this.underline,
        "text-decoration-overline": this.overline,
        "text-decoration-line-through": this.lineThrough,

        "font-weight-black": this.black,
        "font-weight-bold": this.bold,
        "font-weight-medium": this.medium,
        "font-weight-regular": this.regular,
        "font-weight-light": this.light,
        "font-weight-thin": this.thin,
        "font-italic": this.italic,
      };
    },
  },
};
</script>

<style lang="scss" scoped>
.elevate {
  text-shadow: 2px 2px rgba(0, 0, 0, 0.3);
}
.block {
  display: block;
}
</style>
