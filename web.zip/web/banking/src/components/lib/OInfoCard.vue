<template>
  <div class="info-card">
    <div class="info-card__title">
      <OText size="sm" bold>{{ title }}</OText>
    </div>
    <div class="info-card__body">
      <slot />
    </div>
  </div>
</template>
<script>
import OText from "./OText.vue";
export default {
  name: "OInfoCard",
  components: {
    OText,
  },
  props: {
    title: {
      type: String,
      require: true,
    },
    color: {
      type: String,
      default: "primary",
    },
  },
};
</script>
<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";

.info-card {
  display: flex;
  flex-direction: column;
  &__title {
    display: flex;
    width: 100%;
    padding: 15px;
    color: white;
    background-color: var(--v-primary-base);
  }
  &__body {
    padding: 15px;
    border: 1px solid var(--v-border-base);
  }
}
</style>
