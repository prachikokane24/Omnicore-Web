<template>
  <router-link :to="to" v-if="to"
    >{{
    <slot />
    }}</router-link
  >
  <a
    :href="href"
    v-bind="$attrs"
    :class="linkColor ? `text--${linkColor}` : ''"
    v-else
    ><slot
  /></a>
</template>

<script>
export default {
  inheritAttrs: false,
  props: {
    to: {
      type: String,
    },
    href: {
      type: String,
    },
    linkColor: {
      type: Boolean,
      default: false,
    },
  },
};
</script>
