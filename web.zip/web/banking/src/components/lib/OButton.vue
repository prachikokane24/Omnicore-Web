<template>
  <div>
    <v-btn
      v-bind="[$attrs]"
      :id="id"
      :data-id="dataId"
      :color="color"
      :depressed="depressed"
      :elevated="elevated"
      :block="block"
      :disabled="disabled"
      :x-small="xSmall"
      :small="small"
      :large="large"
      :x-large="xLarge"
      :outlined="outlined"
      :fab="fab"
      :rounded="rounded"
      :icon="iconOnly ? true : false"
      :ripple="ripple"
      :dark="dark"
      @click="handleClick"
      class="btn"
    >
      <span :class="bold === true ? 'font-weight-bold' : ''"><slot /></span>
      <OIcon
        :icon="icon"
        v-if="icon"
        :class="icon && $slots.default ? 'ml-1' : ''"
        :x-small="iconSize == 'xSmall'"
        :small="iconSize == 'small'"
        :large="iconSize == 'large'"
        :x-large="iconSize == 'xLarge'"
      />
    </v-btn>
  </div>
</template>

<script>
import OIcon from "./OIcon.vue";
export default {
  name: "OButton",
  inheritAttrs: false,
  components: {
    OIcon,
  },
  props: {
    id: {
      type: String,
      default: undefined,
    },
    dataId: {
      type: String,
      default: undefined,
    },
    icon: {
      type: String,
    },
    iconOnly: {
      type: Boolean,
      default: false,
    },
    iconSize: {
      type: String,
       validator: function (value) {
        return [ 'xSmall', 'small', 'large', 'xLarge'].indexOf(value) !== -1
      }
    },
    color: {
      type: String,
      default: "primary",
    },
    dark: {
      type: Boolean,
      default: false,
    },
    bold: {
      type: Boolean,
      default: false,
    },
    xSmall: {
      type: Boolean,
      default: false,
    },
    small: {
      type: Boolean,
      default: false,
    },
    large: {
      type: Boolean,
      default: false,
    },
    xLarge: {
      type: Boolean,
      default: false,
    },
    depressed: {
      type: Boolean,
      default: true,
    },
    disabled: {
      type: Boolean,
      default: false,
    },
    elevated: {
      type: Boolean,
      default: false,
    },
    outlined: {
      type: Boolean,
      default: false,
    },
    rounded: {
      type: Boolean,
      default: false,
    },
    fab: {
      type: Boolean,
      default: false,
    },
    block: {
      type: Boolean,
      default: false,
    },
    ripple: {
      type: Boolean,
      default: true,
    },
  },
  methods: {
    handleClick() {
      this.$emit("click");
    },
  },
};
</script>
<style lang="scss" scoped>
.secondary {
  background-color: var(--v-secondarybutton-base) !important;
  border-color: var(--v-secondarybutton-base) !important;
  color: var(--v-secondarybuttontext-base) !important;
}
</style>
