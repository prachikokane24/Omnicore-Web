<template>
  <div>
    <ODataTableCaption v-if="heading">
      <div class="d-flex">
        <span class="mr-3">{{ heading }}</span>
        <slot name="actions" />
      </div>
      <template slot="filter">
        <slot name="filter" />
      </template>
    </ODataTableCaption>
    <table>
      <thead>
        <tr>
          <th v-if="checkboxes" width="70">
            <OFormCheckbox
              name="selectAll"
              dark
              hide-details
              v-model="selectAll"
            />
          </th>
          <template v-for="(header, i) in headers">
            <th scope="col" :key="i">
              <OText :size="headerSize" medium>{{ header.text }}</OText>
            </th>
          </template>
        </tr>
      </thead>
      <tbody>
        <tr v-if="$scopedSlots['bodyPrepend']">
          <slot name="bodyPrepend" :headers="headers" :rows="items" />
        </tr>
      </tbody>
      <template v-if="$scopedSlots['summary']">
        <slot name="summary" :headers="headers" :rows="items" />
      </template>
      <tbody :class="{ dim: loading }">
        <ODot v-if="loading" class="loader" aria-role="presentation" />
        <template v-if="items.length > 0">
          <tr
            v-for="(row, j) in items"
            :key="`row_${j}`"
            v-bind="tableRowProps"
            @click="handleRowClick(row)"
            @keypress.enter="handleRowClick(row)"
          >
            <td v-if="checkboxes">
              <OFormCheckbox
                hide-details
                no-margin
                @input="toggleCheckbox(j, $event)"
                :preSelected="selectAll.value"
              />
            </td>
            <template v-for="(header, k) in headers">
              <td
                :key="k"
                class="data-table-cell body-2"
                :class="`data-table-cell-${header.key}`"
                @click="handleCellClick(row[header.key])"
              >
                <slot
                  v-if="$scopedSlots[header.key]"
                  :name="`${header.key}`"
                  :cell="row[header.key]"
                  :row="row"
                  :headers="headers"
                  :index="j"
                />
                <template v-else>
                  {{ row[header.key] || header.default }}</template
                >
              </td>
            </template>
          </tr>
        </template>
        <template>
          <tr v-if="items.length <= 0">
            <td :colspan="headers.length" align="center">
              <OText
                type="span"
                align="center"
                class="mt-2 mb-2"
                v-visible="items.length <= 0 && !loading"
                >{{ $t("table.noResultsText") }}</OText
              >
            </td>
          </tr>
        </template>
        <tr v-if="$scopedSlots['bodyAppend']">
          <slot name="bodyAppend" :headers="headers" :rows="items" />
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import Vue from "vue";
import ODataTableCaption from "../../ODataTableCaption.vue";
import OText from "../../../OText.vue";
import ODot from "../../../Loader/ODot.vue";
import OFormCheckbox from "../../../Form/OFormCheckbox.vue";

Vue.directive("visible", function (el, binding) {
  el.style.visibility = binding.value ? "visible" : "hidden";
});

export default {
  name: "ODataTableLayoutDefaultLg",
  components: {
    ODataTableCaption,
    OText,
    ODot,
    OFormCheckbox,
  },
  props: {
    items: {
      type: Array,
      default: () => [],
    },
    headers: {
      type: Array,
      default: () => [],
    },
    heading: {
      type: String,
      default: "",
    },
    headerSize: {
      type: String,
      default: "sm",
    },
    loading: {
      type: Boolean,
      default: true,
    },
    checkboxes: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      headerSort: {},
      selected: [],
      selectAll: {},
    };
  },
  // watch: {
  //   mapCheckboxItems() {
  //     alert("dfdf");
  //     this.handleCheckboxClick();
  //   },
  // },
  computed: {
    tableRowProps() {
      if (this.hover) {
        return {
          tabIndex: 0,
        };
      }
      return {};
    },
    mapCheckboxItems() {
      return this.selected
        .filter((item) => item.value == true)
        .map((item, index) => {
          if (item.value == true) {
            return this.items[index];
          }
        });
    },
  },
  mounted() {
    this.mapSortableHeaders();
  },
  methods: {
    mapSortableHeaders() {
      this.headerSort = this.headers
        .filter((header) => header.sortable)
        .reduce((obj, item) => {
          obj[item.key] = item.sortDirection || null;
          return obj;
        }, {});
    },
    getSortIcon(header) {
      const sortType = this.headerSort[header.key];
      if (!sortType) {
        return "sort";
      } else if (sortType === "desc") {
        return "sort-descending";
      } else if (sortType === "asc") {
        return "sort-ascending";
      }
    },
    handleSort(header) {
      const { key } = header;
      if (!this.headerSort[key] || this.headerSort[key] === "desc") {
        this.headerSort[key] = "asc";
      } else {
        this.headerSort[key] = "desc";
      }
      this.$emit("sort", this.headerSort);
    },
    handleRowClick(row) {
      this.$emit("rowClick", row);
    },
    handleCellClick(cell) {
      this.$emit("cellClick", cell);
    },
    handleRowCheckboxClick() {
      this.$emit("rowCheckboxClick", this.mapCheckboxItems);
    },
    toggleCheckbox(j, row) {
      this.$set(this.selected, j, row);
      this.handleRowCheckboxClick();
    },
  },
};
</script>
<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";
table {
  position: relative;
  //table-layout: fixed;
  margin: 0 auto;
  width: 100%;
  border-collapse: collapse;
  thead {
    color: white;
    background-color: var(--v-primary-base);
    padding: 15px 0 15px 40px;
  }
  tbody {
    position: relative;
  }
  tbody tr:nth-child(odd) {
    background-color: var(--v-tablerow-base);
  }
  tbody .loader {
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    z-index: 1;
    margin: 20px;
    margin-top: -10px;
  }
  tbody .spacer {
    //height: 100px;
    background: white;
  }
  tbody {
    tr td {
      transition: all 0.25s ease;
    }
  }
  tbody.dim {
    tr td {
      will-change: filter;
      filter: opacity(20%);
    }
  }
  tr:last-child th:first-child {
    padding-left: 10px;
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      padding-left: 20px;
    }
    @media #{map-get($display-breakpoints, 'lg-and-up')} {
      padding-left: 30px;
    }
  }
  tr:last-child th:last-child {
    padding-left: 10px;
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      padding-left: 20px;
    }
    @media #{map-get($display-breakpoints, 'lg-and-up')} {
      padding-left: 30px;
    }
  }
  td:first-child {
    padding-left: 10px;
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      padding-left: 20px;
    }
    @media #{map-get($display-breakpoints, 'lg-and-up')} {
      padding-left: 30px;
    }
  }
  td:last-child {
    padding-left: 10px;
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      padding-left: 20px;
    }
    @media #{map-get($display-breakpoints, 'lg-and-up')} {
      padding-left: 30px;
    }
  }
  td {
    padding: 8px 10px;
    width: 5%;
    vertical-align: top;
  }
  th {
    padding: 8px 10px;
    text-align: left;
    font-size: 10px;
  }
}
</style>
