<template>
  <table>
    <ODataTableCaption v-if="heading">
      <span>
        {{ heading }}
        <slot name="actions" />
      </span>
      <template slot="filter">
        <slot name="filter" />
      </template>
    </ODataTableCaption>
    <thead>
      <tr>
        <th v-if="checkboxes">
          <OFormCheckbox
            name="selectAll"
            dark
            hide-details
            v-model="selectAll"
          />
        </th>
        <th scope="col" v-for="({ text }, i) in headers" :key="i">
          {{ text }}
        </th>
      </tr>
    </thead>
    <tbody>
      <tr v-if="$scopedSlots['bodyPrepend']">
        <slot name="bodyPrepend" :headers="headers" :rows="items" />
      </tr>
    </tbody>
    <template v-if="$scopedSlots['summary']">
      <slot name="summary" :headers="headers" :rows="items" />
    </template>
    <tbody class="rows" v-if="items">
      <template v-if="items.length > 0 && !loading">
        <tr
          v-for="(row, j) in items"
          :key="`row_${j}`"
          v-bind="tableRowProps"
          @click="handleRowClick(row)"
          @keypress.enter="handleRowClick(row)"
        >
          <template v-for="(header, k) in headers">
            <td
              :key="k"
              class="data-table-cell body-2"
              :class="`data-table-cell-${header.key}`"
              @click="handleCellClick(row[header.key])"
              :data-label="header.text"
              v-if="!header.hideMobile"
            >
              <slot
                v-if="$scopedSlots[header.key]"
                :name="`${header.key}`"
                :cell="row[header.key]"
                :row="row"
                :headers="headers"
                :index="j"
              />
              <template v-else>{{
                row[header.key] || header.default
              }}</template>
            </td>
          </template>
          <td v-if="checkboxes">
            <OFormCheckbox
              hide-details
              no-margin
              @input="toggleCheckbox(j, $event)"
              :preSelected="selectAll.value"
            />
          </td>
        </tr>
      </template>

      <tr v-if="$scopedSlots['bodyAppend']">
        <slot name="bodyAppend" :headers="headers" :rows="items" />
      </tr>
    </tbody>
    <tfoot>
      <template v-if="items <= 0 && !loading">
        <OText type="span" align="center" class="mt-2 mb-2">{{
          $t("table.noResultsText")
        }}</OText>
      </template>
    </tfoot>
  </table>
</template>

<script>
import ODataTableCaption from "../../ODataTableCaption.vue";
import OText from "../../../OText.vue";
import OFormCheckbox from "../../../Form/OFormCheckbox.vue";

export default {
  name: "ODataTableLayoutDefaultSm",
  components: {
    ODataTableCaption,
    OText,
    OFormCheckbox,
  },
  props: {
    items: {
      type: Array,
      default: () => [],
    },
    summaryItems: {
      type: Array,
      default: () => [],
    },
    summaryTitle: {
      type: String,
    },
    summaryIcon: {
      type: String,
    },
    headers: {
      type: Array,
      default: () => [],
    },
    size: {
      type: String,
      default: "md",
    },
    heading: {
      type: String,
      default: "",
    },
    errorMessage: {
      type: String,
      default: null,
    },
    hover: {
      type: Boolean,
      default: false,
    },
    striped: {
      type: Boolean,
      default: false,
    },
    spaced: {
      type: Boolean,
      default: false,
    },
    gray: {
      type: Boolean,
      default: false,
    },
    headerVariant: {
      type: String,
      default: "blank",
    },
    loading: {
      type: Boolean,
      default: false,
    },
    checkboxes: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      isClosed: false,
      headerSort: {},
      selected: [],
      selectAll: {},
    };
  },
  computed: {
    tableRowProps() {
      if (this.hover) {
        return {
          tabIndex: 0,
        };
      }
      return {};
    },
    mapCheckboxItems() {
      return this.selected
        .filter((item) => item.value == true)
        .map((item, index) => {
          if (item.value == true) {
            return this.items[index];
          }
        });
    },
  },
  mounted() {
    this.mapSortableHeaders();
  },
  methods: {
    toggleSummary() {
      this.isClosed = !this.isClosed;
    },
    mapSortableHeaders() {
      this.headerSort = this.headers
        .filter((header) => header.sortable)
        .reduce((obj, item) => {
          obj[item.key] = item.sortDirection || null;
          return obj;
        }, {});
    },
    getSortIcon(header) {
      const sortType = this.headerSort[header.key];
      if (!sortType) {
        return "sort";
      } else if (sortType === "desc") {
        return "sort-descending";
      } else if (sortType === "asc") {
        return "sort-ascending";
      }
    },
    handleSort(header) {
      const { key } = header;
      if (!this.headerSort[key] || this.headerSort[key] === "desc") {
        this.headerSort[key] = "asc";
      } else {
        this.headerSort[key] = "desc";
      }
      this.$emit("sort", this.headerSort);
    },
    handleRowClick(row) {
      this.$emit("rowClick", row);
    },
    handleCellClick(cell) {
      this.$emit("cellClick", cell);
    },
    handleRowCheckboxClick() {
      this.$emit("rowCheckboxClick", this.mapCheckboxItems);
    },
    toggleCheckbox(j, row) {
      this.$set(this.selected, j, row);
      this.handleRowCheckboxClick();
    },
  },
};
</script>
<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";
table {
  border: 0;
  width: 100%;
  border-collapse: collapse;
  td {
    padding: 0 10px;
  }
  th {
    padding: 8px 5px;
    text-transform: none;
    text-align: left;
  }
  .rows {
    border-top: 1px solid var(--v-border-base);
  }
  thead {
    border: none;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
  }
  tr {
    display: block;
    padding: 20px 0;
    &:nth-child(even) {
      background-color: var(--v-tablerow-base);
    }
  }
  td {
    display: block;
    text-align: right;
    min-height: 13px;
  }
  td::before {
    content: attr(data-label);
    font-weight: bold;
    float: left;
  }
  td:last-child {
    border-bottom: 0;
  }
}
</style>
