<template>
  <div>
    <div :class="{ content: elevated }">
      <slot />
    </div>
    <div
      class="pagination pt-4 pb-4"
      :style="{ backgroundColor: backgroundColor }"
      v-if="pageCount > 1"
    >
      <OPaginatorNav
        v-if="$vuetify.breakpoint.xsOnly"
        v-model="activePageNumber"
        @change="handleChange"
        :page-count="pageCount"
        :disabled="disabled"
        :prevBtnText="`${$t('pagination.prevBtnText')}`"
        :nextBtnText="`${$t('pagination.nextBtnText')}`"
      />
      <OPagination
        v-else
        v-model="activePageNumber"
        @change="handleChange"
        :page-count="pageCount"
        :disabled="disabled"
      />
    </div>
  </div>
</template>
<script>
import OPagination from "../OPagination";
import OPaginatorNav from "../OPaginatorNav";
export default {
  name: "ODataTablePaginatorAsync",
  components: {
    OPaginatorNav,
    OPagination,
  },
  props: {
    pageCount: {
      type: [Number, String],
      default: 0,
    },
    pageNumber: {
      type: [Number],
      default: 0,
    },
    disabled: {
      type: Boolean,
      default: false,
    },
    elevated: {
      type: Boolean,
      default: true,
    },
    backgroundColor: {
      type: String,
      default: "transparent",
    },
  },
  data() {
    return {
      activePageNumber: 0,
    };
  },
  watch: {
    pageNumber() {
      this.setPageIndex();
    },
  },
  mounted() {
    this.setPageIndex();
  },
  methods: {
    handleChange(val) {
      this.$emit("change", val);
    },
    setPageIndex() {
      this.activePageNumber = this.pageNumber;
    },
  },
};
</script>
<style lang="scss" scoped>
.content {
  background: white;
  box-shadow: 0px 2px 5px 0px rgba(0, 0, 0, 0.11);
  z-index: 1;
  position: relative;
}
</style>
