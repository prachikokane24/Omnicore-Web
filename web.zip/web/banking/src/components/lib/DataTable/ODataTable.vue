<template>
  <component
    :is="component"
    v-bind="[$attrs, $props, $scopedSlots]"
    @rowClick="$emit('rowClick', $event)"
    @cellClick="$emit('cellClick', $event)"
    @rowCheckboxClick="$emit('rowCheckboxClick', $event)"
    ><template v-for="(_, slot) of $scopedSlots" v-slot:[slot]="scope"
      ><slot :name="slot" v-bind="scope" /></template
  ></component>
</template>

<script>
import ODataTableLayoutDefaultDesktop from "./Layouts/Desktop/ODataTableLayoutDefaultDesktop.vue";
import ODataTableLayoutDefaultMobile from "./Layouts/Mobile/ODataTableLayoutDefaultMobile.vue";

export default {
  name: "ODataTable",
  props: {
    mobileComponent: {
      type: String,
      default: "ODataTableLayoutDefaultMobile",
    },
  },
  components: {
    ODataTableLayoutDefaultDesktop,
    ODataTableLayoutDefaultMobile,
  },
  computed: {
    component() {
      return this.$vuetify.breakpoint.xsOnly
        ? this.mobileComponent
        : "ODataTableLayoutDefaultDesktop";
    },
  },
};
</script>
