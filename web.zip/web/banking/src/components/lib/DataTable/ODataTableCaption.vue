<template>
  <div class="caption">
    <div class="caption__col1">
      <OText type="h3" size="lg" medium><slot /></OText>
    </div>
    <div class="caption__col2">
      <slot name="filter" />
    </div>
  </div>
</template>
<script>
import OText from "../OText.vue";
export default {
  name: "ODataTableCaption",
  components: {
    OText,
  },
};
</script>
<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";
.caption {
  display: flex;
  width: 100%;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  text-align: left;
  padding: 15px 10px;
  @media #{map-get($display-breakpoints, 'md-and-up')} {
    padding: 15px 10px;
    padding: 15px 20px;
  }
  @media #{map-get($display-breakpoints, 'lg-and-up')} {
    padding: 15px 30px;
  }

  &__col1 {
    flex: 1;
  }
}
</style>
