<template>
  <v-snackbar
    :timeout="-1"
    :value="true"
    color="blue-grey"
    absolute
    right
    rounded="pill"
    top
  >
    Lorem ipsum dolor sit amet consectetur.
  </v-snackbar>
</template>

<script>
export default {
  name: "OSnackBar",
  props: {
    timeout: {
      type: Number,
      default: 2000,
    },
    color: {
      type: String,
      default: "primary",
    },
  },
};
</script>

<style lang="scss" scoped></style>
