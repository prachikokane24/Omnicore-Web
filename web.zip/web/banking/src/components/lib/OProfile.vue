<template>
  <div class="account-profile">
    <div
      class="account-profile__details mr-3"
      :class="this.textColor ? `${this.textColor}--text` : undefined"
    >
      <slot />
    </div>
    <v-avatar
      :color="avatarColor"
      :size="45"
      class="account-profile__avatar"
      :class="
        this.avatarTextColor ? `${this.avatarTextColor}--text` : undefined
      "
    >
      <img :src="avatarImage" v-if="avatarImage" />
      <OIcon icon="account" :dark="dark" large v-else />
    </v-avatar>
  </div>
</template>

<script>
import OIcon from "./OIcon.vue";
export default {
  name: "OProfile",
  components: {
    OIcon,
  },
  props: {
    avatarImage: {
      type: String,
    },
    avatarInitials: {
      type: String,
    },
    avatarAltTag: {
      type: String,
    },
    avatarColor: {
      type: String,
      default: "secondary",
    },
    dark: {
      type: Boolean,
      default: false,
    },
    avatarTextColor: {
      type: String,
      default: "secondary",
    },
    textColor: {
      type: String,
      default: "",
    },
    avatarSize: {
      type: Number || String,
      default: 45,
    },
  },
};
</script>

<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";
.account-profile {
  display: flex;
  justify-content: left;
  align-items: center;

  &__avatar {
    font-weight: bold;
  }
  &__details {
    white-space: nowrap;
    color: #000;
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      text-align: left;
    }
  }
}
</style>
