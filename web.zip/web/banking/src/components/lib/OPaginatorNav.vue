<template>
  <nav v-show="showNav" class="data-table-pagination">
    <template>
      <OButton
        :disabled="previousDisabled || disabled"
        @click="previous"
        fab
        small
        >←
      </OButton>
      <OFormSelect
        @change="handleChange"
        :items="options"
        :disabled="disabled"
        :preSelected="value"
        :filled="false"
        class="data-table-pagination__select"
        dense
        rounded
        solo
        hide-details
      />
      <OButton :disabled="nextDisabled || disabled" @click="next" fab small>
        →</OButton
      >
    </template>
  </nav>
</template>

<script>
import OButton from "./OButton";
import OFormSelect from "./Form/OFormSelect";

export default {
  components: {
    OButton,
    OFormSelect,
  },
  props: {
    pageCount: {
      type: [String, Number],
      default: 0,
    },
    value: {
      type: [String, Number],
      default: 0,
    },
    disabled: {
      type: Boolean,
      default: true,
    },
    prevBtnText: {
      type: String,
      default: "Prev",
    },
    nextBtnText: {
      type: String,
      default: "Next",
    },
  },
  computed: {
    showNav() {
      return parseInt(this.pageCount) > 1;
    },
    options() {
      const options = [];
      const pageCount = parseInt(this.pageCount);
      for (let i = 1; i <= pageCount; i++) {
        options.push({
          value: i,
          label: `Page ${i} of ${pageCount}`,
        });
      }
      return options;
    },
    previousDisabled() {
      return this.value == 1;
    },
    nextDisabled() {
      return this.value === this.pageCount;
    },
  },
  methods: {
    handleChange(change) {
      console.log(change);
      this.$emit("change", change.value);
    },
    previous() {
      this.$emit("change", this.value - 1);
    },
    next() {
      this.$emit("change", this.value + 1);
    },
  },
};
</script>

<style lang="scss" scoped>
.data-table-pagination {
  display: flex;
  flex-direction: row;
  margin: 0 auto;
  width: 100%;
  max-width: 300px;
  &__select {
    margin: 0 10px;
    width: 100%;
  }
}
</style>
