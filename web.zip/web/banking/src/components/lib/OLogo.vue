<template>
  <div style="color: red">
    <img class="logo" :src="logo" :style="style" />
  </div>
</template>

<script>
export default {
  name: "OLogo",
  props: {
    logoDark: {
      type: String,
    },
    logoLight: {
      type: String,
    },
    maxWidth: {
      type: String,
      default: "100px",
    },
    dark: {
      type: Boolean,
      default: false,
    },
  },
  computed: {
    style() {
      return {
        maxWidth: this.maxWidth + "px",
      };
    },
    logo() {
      return this.$vuetify.theme.dark || this.dark
        ? this.logoDark
        : this.logoLight;
    },
  },
};
</script>

<style lang="scss" scoped>
.logo {
  width: 100%;
  display: block;
}
</style>
