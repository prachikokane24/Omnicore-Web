<template>
  <div>
    <v-checkbox
      v-model="checkValue"
      :label="label"
    ></v-checkbox>      
  </div>
</template>

<script>
export default {
  name: "OCheckbox",
  props: {
    value: {
      type: Boolean,
      default: false,
    },
    label: {
      type: String,
      default: "",
    },
  },
  data() {
    return {
      checkValue: this.value,
    };
  },
  watch: {
    async checkValue() {
      this.emitInput();
    }
  },
  methods: {
    async emitInput() {
      this.$emit("input", this.checkValue);
    },    
  }
};
</script>
