<template>
  <div>
    <v-switch
      v-model="switchVal"
      :hint="hint"
      inset
      :label="label"
      :persistent-hint="persistentHint"
      @change="$emit('input', switchVal)"
    ></v-switch>
  </div>
</template>

<script>
export default {
  name: "OSwitch",
  props: {
    value: {
      type: Boolean,
      default: false,
    },
    hint: {
      type: String,
      default: "",
    },
    label: {
      type: String,
      default: "",
    },
    persistentHint: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      switchVal: this.value,
    };
  },
};
</script>
