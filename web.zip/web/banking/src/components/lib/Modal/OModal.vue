<template>
  <v-dialog v-model="dialog" :id="id" :persistent="persistent">
    <slot />
  </v-dialog>
</template>
<script>
export default {
  name: "OModal",
  props: {
    id: {
      type: String,
      required: true,
    },
    persistent: {
      type: Boolean,
      default: true,
    },
  },
  data() {
    return {
      dialog: false,
    };
  },
  mounted() {
    this.listeners();
  },

  methods: {
    listeners() {
      this.$EventBus.$on("modal:show", this.showHandler);
      this.$EventBus.$on("modal:hide", this.hideHandler);
    },
    showHandler(id) {
      if (id === this.id) {
        this.show();
      }
    },
    hideHandler(id) {
      if (id === this.id) {
        this.hide();
      }
    },
    show() {
      this.$emit("show", this.id);
    },
    hide() {
      this.$emit("hide", this.id);
      this.dialog = false;
    },
  },
};
</script>
