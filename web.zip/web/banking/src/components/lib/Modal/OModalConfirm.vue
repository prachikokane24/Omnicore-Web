<template>
  <v-dialog
    v-model="dialog"
    :id="id"
    :persistent="persistent"
    :max-width="maxWidth"
    :hide-overlay="hideOverlay"
  >
    <v-card class="card">
      <v-card-title class="title" :style="{ maxWidth: maxWidth }">
        <OText size="md" medium align="center">{{ message }}</OText>
      </v-card-title>
      <div class="animation-ctn">
        <div class="icon icon--order-success svg">
          <svg xmlns="http://www.w3.org/2000/svg" width="154px" height="154px">
            <g fill="none" :stroke="color" stroke-width="2">
              <circle
                cx="77"
                cy="77"
                r="72"
                style="stroke-dasharray: 480px, 480px; stroke-dashoffset: 960px"
              ></circle>
              <circle
                id="colored"
                :fill="color"
                cx="77"
                cy="77"
                r="72"
                style="stroke-dasharray: 480px, 480px; stroke-dashoffset: 960px"
              ></circle>
              <polyline
                class="st0"
                stroke="#fff"
                stroke-width="10"
                points="43.5,77.8 63.7,97.9 112.2,49.4 "
                style="stroke-dasharray: 100px, 100px; stroke-dashoffset: 200px"
              />
            </g>
          </svg>
        </div>
      </div>
    </v-card>
  </v-dialog>
</template>
<script>
import OText from "../OText";
export default {
  name: "OModalConfirm",
  components: {
    OText,
  },
  props: {
    id: {
      type: String,
      required: true,
    },
    message: {
      type: String,
    },
    maxWidth: {
      type: String,
      default: "300px",
    },
    persistent: {
      type: Boolean,
      default: true,
    },
    enterDelay: {
      type: Number,
      default: 300,
    },
    exitDelay: {
      type: Number,
      default: 2500,
    },
    hideOverlay: {
      type: Boolean,
      default: true,
    },
    color: {
      type: String,
      default: "#E75A7C"
    }
  },
  data() {
    return {
      dialog: false,
    };
  },
  mounted() {
    this.listeners();
  },
  computed: {
    isMobile() {
      return this.$vuetify.breakpoint.smAndDown;
    },
  },
  methods: {
    listeners() {
      this.$EventBus.$on("modal:show", this.showHandler);
      this.$EventBus.$on("modal:hide", this.hideHandler);
    },
    showHandler(id) {
      if (id === this.id) {
        this.show();
      }
    },
    hideHandler(id) {
      if (id === this.id) {
        this.hide();
      }
    },
    show() {
      setTimeout(() => {
        this.dialog = true;
        this.$emit("show", this.id);
      }, this.enterDelay);
      setTimeout(() => {
        this.hide();
      }, this.exitDelay);
    },
    hide() {
      this.$emit("hide", this.id);
      this.dialog = false;
    },
  },
};
</script>
<style lang="scss" scoped>
.card {
  padding: 20px;
}
.title {
  display: block;
  padding: 10px 0 !important;
  margin: 0;
  text-align: center;
}
.animation-ctn {
  text-align: center;
  transform: scale(0.7);
}
@-webkit-keyframes checkmark {
  0% {
    stroke-dashoffset: 100px;
  }

  100% {
    stroke-dashoffset: 200px;
  }
}
@-ms-keyframes checkmark {
  0% {
    stroke-dashoffset: 100px;
  }

  100% {
    stroke-dashoffset: 200px;
  }
}
@keyframes checkmark {
  0% {
    stroke-dashoffset: 100px;
  }

  100% {
    stroke-dashoffset: 0px;
  }
}
@-webkit-keyframes checkmark-circle {
  0% {
    stroke-dashoffset: 480px;
  }

  100% {
    stroke-dashoffset: 960px;
  }
}
@-ms-keyframes checkmark-circle {
  0% {
    stroke-dashoffset: 240px;
  }

  100% {
    stroke-dashoffset: 480px;
  }
}
@keyframes checkmark-circle {
  0% {
    stroke-dashoffset: 480px;
  }

  100% {
    stroke-dashoffset: 960px;
  }
}
@keyframes colored-circle {
  0% {
    opacity: 0;
  }

  100% {
    opacity: 100;
  }
}
.inlinesvg .svg svg {
  display: inline;
}
.icon--order-success svg polyline {
  -webkit-animation: checkmark 0.25s ease-in-out 0.4s backwards;
  animation: checkmark 0.25s ease-in-out 0.7s backwards;
}
.icon--order-success svg circle {
  -webkit-animation: checkmark-circle 0.6s ease-in-out backwards;
  animation: checkmark-circle 0.6s ease-in-out backwards;
}
.icon--order-success svg circle#colored {
  -webkit-animation: colored-circle 0.6s ease-in-out 0.7s backwards;
  animation: colored-circle 0.6s ease-in-out 0.7s backwards;
}
</style>
