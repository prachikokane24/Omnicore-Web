<template>
  <v-dialog
    v-model="dialog"
    :id="id"
    :persistent="persistent"
    :fullscreen="isMobile"
    :max-width="maxWidth"
    :hide-overlay="hideOverlay"
    scrollable
  >
    <v-card :flat="isMobile">
      <v-card-title>
        <OText medium class="header"><slot name="header" /></OText>
      </v-card-title>
      <v-divider v-if="isMobile"></v-divider>
      <v-card-text>
        <div class="mt-3"><slot /></div>
        <OAlert :data-id="dataIdError" type="error" v-if="errorMessage">{{ errorMessage }}</OAlert>
        <OAlert :data-id="dataIdWarning" type="warning" v-if="warningMessage">{{
          warningMessage
        }}</OAlert>
      </v-card-text>
      <v-divider></v-divider>
      <v-card-actions class="d-flex justify-center" v-if="!hideActions">
        <slot name="footer">
          <OButtonGroup class="button-group" fluid spaceBetween>
            <OButton
              :data-id="dataIdCancelBtn"
              size="sm"
              outlined
              :disabled="cancelDisabled"
              @click="handleCancel"
              fluid
              v-if="!hideCancelBtn"
              >{{ cancelText }}</OButton
            >
            <OButton
              :data-id="dataIdConfirmBtn"
              size="sm"
              theme="success"
              :loading="loading"
              :disabled="confirmDisabled || disabled"
              @click="handleConfirm"
              fluid
              v-if="!hideConfirmBtn"
              >{{ confirmText }}</OButton
            >
          </OButtonGroup>
        </slot>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>
<script>
import OButton from "../OButton";
import OAlert from "../OAlert";
import OText from "../OText";
import OButtonGroup from "../OButtonGroup";
export default {
  name: "OModalConfirmCancel",
  components: {
    OButton,
    OText,
    OAlert,
    OButtonGroup,
  },
  props: {
    id: {
      type: String,
      required: true,
    },
    align: {
      default: "center",
      validator: (value) => ["top", "center", "bottom"].indexOf(value) !== -1,
    },
    loading: {
      type: Boolean,
      default: false,
    },
    persistant: {
      type: Boolean,
      default: false,
    },
    disabled: {
      type: Boolean,
      default: false,
    },
    width: {
      type: String,
      default: "100%",
    },
    errorMessage: {
      type: String,
    },
    warningMessage: {
      type: String,
    },
    maxWidth: {
      type: String,
      default: "550px",
    },
    confirmText: {
      type: String,
      default: "Confirm",
    },
    confirmDisabled: {
      type: Boolean,
      default: false,
    },
    cancelText: {
      type: String,
      default: "Cancel",
    },
    cancelDisabled: {
      type: Boolean,
      default: false,
    },
    hideOverlay: {
      type: Boolean,
      default: false,
    },
    transition: {
      type: String,
      default: "dialog-bottom-transition",
    },
    showConfirmationModal: {
      type: Boolean,
      default: false,
    },
    persistent: {
      type: Boolean,
      default: true,
    },
    hideActions: {
      type: Boolean,
      default: false,
    },
    hideCancelBtn: {
      type: Boolean,
      default: false,
    },
    hideConfirmBtn: {
      type: Boolean,
      default: false,
    },
    dataIdCancelBtn: {
      type: String,
      default: ""
    },
    dataIdConfirmBtn: {
      type: String,
      default: ""
    },
    dataIdError: {
      type: String,
      default: ""
    },
    dataIdWarning: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      dialog: false,
    };
  },
  mounted() {
    this.listeners();
  },
  computed: {
    isMobile() {
      return this.$vuetify.breakpoint.smAndDown;
    },
  },
  methods: {
    listeners() {
      this.$EventBus.$on("modal:show", this.showHandler);
      this.$EventBus.$on("modal:hide", this.hideHandler);
    },
    showHandler(id) {
      if (id === this.id) {
        this.show();
      }
    },
    hideHandler(id) {
      if (id === this.id) {
        this.hide();
      }
    },
    show() {
      this.$emit("show", this.id);
      this.dialog = true;
    },
    hide() {
      this.$emit("hide", this.id);
      this.dialog = false;
    },
    handleCancel() {
      this.$emit("cancel", this.id);
      this.$modal.hide(this.id);
    },
    handleConfirm() {
      this.$emit("confirm", this.id);
      // this.$emit("submit", this.id);
    },
  },
};
</script>
<style lang="scss" scoped>
.header {
  word-break: normal;
}
</style>
