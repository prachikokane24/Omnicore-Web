<template>
  <v-list flat class="list">
    <OText v-if="title" class="title" size="sm">{{ title }}</OText>
    <v-list-item-group @change="handleChange" :value="preSelected">
      <v-list-item
        v-for="(item, i) in items"
        :key="i"
        :value="item.cmp"
        class="item"
        active-class="item--active"
      >
        <v-list-item-content>
          <OText
            size="sm"
            :text="item.name"
            :data-id="`${item.cmp}Option`"
            medium
          />
        </v-list-item-content>
        <v-list-item-icon>
          <OIcon :icon="item.icon ? item.icon : icon" medium />
        </v-list-item-icon>
      </v-list-item>
    </v-list-item-group>
  </v-list>
</template>
<script>
import OIcon from "./OIcon";
import OText from "./OText";
export default {
  name: "ONavVertical",
  components: {
    OIcon,
    OText,
  },
  data() {
    return {
      value: ""
    }
  },
  props: {
    items: {
      type: Array,
      required: true,
    },
    icon: {
      type: String,
      default: "chevronRight",
    },
    color: {
      type: String,
      default: "primary",
    },
    preSelected: {
      type: String,
      default: null,
    },
    title: {
      type: String,
    },
  },
  methods: {
    handleChange(val) {
      if(!val) return;
      this.$emit("change", val);
    },
  },
};
</script>
<style lang="scss" scoped>
.list {
  padding: 0;
  margin: 0;
}
.title {
  font-weight: bold;
  padding: 10px 18px;
  margin-bottom: 5px;
  border: 1px solid var(--v-borderdark-base);
}
.item {
  &--active {
    font-weight: bold;
    color: var(--v-primary-base);
    background-color: var(--v-monotone2-base);
  }
}
</style>
