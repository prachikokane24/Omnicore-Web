<template>
  <div class="d-flex fluid" :class="mediaClasses">
    <div><slot /></div>
  </div>
</template>

<script>
export default {
  name: "OAlign",
  props: {
    vertical: {
      type: Boolean,
      default: false,
    },
    align: {
      type: String,
    },
    alignSm: {
      type: String,
    },
    alignMd: {
      type: String,
    },
    alignLg: {
      type: String,
    },
    alignXl: {
      type: String,
    },
  },
  computed: {
    flexProperty() {
      return this.vertical ? "align" : "justify";
    },
    mapAlign() {
      const classes = {
        left: "start",
        center: "center",
        end: "end",
      };
      return {
        [`${this.flexProperty}-${classes[this.align] || this.align}`]: this
          .align,
        [`${this.flexProperty}-sm-${
          classes[this.alignSm] || this.alignSm
        }`]: this.alignSm,
        [`${this.flexProperty}-md-${
          classes[this.alignMd] || this.alignMd
        }`]: classes[this.alignMd],
        [`${this.flexProperty}-lg-${
          classes[this.alignLg] || this.alignLg
        }`]: this.alignLg,
        [`${this.flexProperty}-xl-${
          classes[this.alignXl] || this.alignXl
        }`]: this.alignXl,
      };
    },
    mediaClasses() {
      return {
        ...this.mapAlign,
      };
    },
  },
};
</script>
