<template>
  <div class="main">
    <ONav :isOpen.sync="isOpen" />
    <OContent class="content">
      <OTopBar :isOpen.sync="isOpen" class="rounded-lg mb-5">
        <template #alignLeft>
          <!-- <router-link to="mail" style="text-decoration: none">
            <OBadge bordered color="success" content="2" overlap>
              <OIcon icon="email" />
            </OBadge>
          </router-link> -->
        </template>
        <template #alignRight><AccountProfile dark /></template>
      </OTopBar>
      <slot name="default" />
    </OContent>
  </div>
</template>
<script lang="ts">
import { Component, Vue, Prop } from "vue-property-decorator";
import ONav from "@/components/lib/Layout/ONav.vue";
import OTopBar from "@/components/lib/Layout/OTopBar.vue";
import OContent from "@/components/lib/Layout/OContent.vue";
import OText from "@/components/lib/OText.vue";
import OIcon from "@/components/lib/OIcon.vue";
import OBadge from "@/components/lib/OBadge.vue";
import AccountProfile from "@/components/AccountProfile/AccountProfile.vue";
@Component({
  components: {
    ONav,
    OTopBar,
    OContent,
    OText,
    OIcon,
    OBadge,
    AccountProfile,
  },
})
export default class MainLayout extends Vue {
  private isOpen: boolean = this.$vuetify.breakpoint.mdAndUp ? true : false;

  get isFixed(): boolean {
    return this.$vuetify.breakpoint.smAndDown && this.isOpen ? true : false;
  }
  mounted(): void {
    this.listeners();
  }
  listeners(): void {
    window.addEventListener("resize", this.onResize, {
      passive: true,
    });
  }
  onResize(): void {
    if (this.$vuetify.breakpoint.smAndDown) {
      this.isOpen = this.$vuetify.breakpoint.mdAndDown ? false : true;
    }
  }
}
</script>

<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";
.main {
  height: 100%;
  background-color: var(--v-background-base);
}
.content {
  margin: 10px 10px 0 10px;
  @media #{map-get($display-breakpoints, 'md-and-up')} {
    margin: 20px 30px 0 30px;
  }
  @media #{map-get($display-breakpoints, 'lg-and-up')} {
    margin: 20px 20px 0 60px;
  }
}
</style>
