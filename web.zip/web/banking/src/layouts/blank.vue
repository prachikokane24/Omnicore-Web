<template>
  <div><slot /></div>
</template>
<script lang="ts">
import { Vue } from "vue-property-decorator";
export default class BlankLayout extends Vue {}
</script>
