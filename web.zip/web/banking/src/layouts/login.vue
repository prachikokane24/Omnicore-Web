<template>
  <div class="login-wrapper">
    <slot name="default" />
    <div class="login">
      <div class="login-col1">
        <picture class="login-col1__bg-wrapper">
          <source
            srcset="@tenant/assets/backgrounds/login.webp"
            type="image/webp"
          />
          <source
            srcset="@tenant/assets/backgrounds/login.jpg"
            type="image/jpeg"
          />
          <img
            src="@/assets/backgrounds/login.jpg"
            alt="login background image"
            class="login-col1__bg-image"
          />
        </picture>
        <div class="login-col1__content">
          <v-container>
            <slot name="content-left" />
          </v-container>
        </div>
      </div>
      <div class="login-col2">
        <OHide md-up>
          <OSection class="pt-3 pb-3 mb-5">
            <v-container>
              <OAlign align="center">
                <slot name="content-mobile-header" />
              </OAlign>
            </v-container>
          </OSection>
        </OHide>
        <div class="login-col2__content">
          <v-container>
            <slot name="content-right" />
          </v-container>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

@Component({
  components: {
    OAlign: () => import("@/components/lib/OAlign.vue"),
    OSection: () => import("@/components/lib/OSection.vue"),
    OHide: () => import("@/components/lib/OHide.vue"),
  },
})
export default class LoginLayout extends Vue {}
</script>
<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";
.login-wrapper {
  display: flex;
  align-items: stretch;
  height: 100%;
  width: 100%;
}
.login {
  display: flex;
  width: 100%;

  &-col1 {
    position: relative;
    display: none;
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      display: flex;
      height: 100%;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      flex: 1;
      padding-right: 3%;
    }
  }
  &-col1::before {
    content: "";
    opacity: 0.6;
    position: absolute;
    z-index: 2;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(to bottom, $primary-color, #000000);
  }
  &-col1__bg-image {
    display: block;
    position: absolute;
    top: 0;
    right: 0;
    width: 100%;
    height: 100vh;
    object-fit: cover;
    z-index: 1;
    right: 0;
  }
  &-col2 {
    display: flex;
    flex-direction: column;
    align-items: center;
    flex: 1;
    position: relative;
    background: --v-login-background;
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      flex-direction: row;
      align-items: center;
      padding-left: 3%;
    }
  }
  &-col1__content,
  &-col2__content {
    z-index: 2;
    width: 100%;
  }
  &-col1__content {
    max-width: 560px;
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      display: flex;
      height: 100%;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      flex: 1;
    }
  }
  &-col2__content {
    max-width: 480px;
  }
  &-col1__content > div.container {
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      display: flex;
      height: 100%;
      flex-direction: column;
      align-items: center;
      justify-content: flex-end;
      flex: 1;
      flex-grow: 1;
    }
    text-align: center;
  }

  &-col1__content > div.container > div {
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      display: flex;
      height: 100%;
      flex-direction: column;
      align-items: center;
      justify-content: flex-end;
      flex: 1;
      flex-grow: 1;
    }
    text-align: center;
  }
}
</style>
