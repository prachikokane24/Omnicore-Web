<template>
  <v-app id="app" v-if="layout">
    <!-- <v-progress-linear
      :active="appLoading"
      color="primary"
      :indeterminate="true"
      class="ma-0 v-progress-linear"
      height="6"
    /> -->

    <!-- <component :is="layout"> -->
    <router-view :key="$route.fullPath"></router-view>
    <!-- </component> -->
  </v-app>
</template>

<script>
import { mapState } from "vuex";
// import BlankLayout from "@/layouts/blank.vue";
// import LoginLayout from "@/layouts/login.vue";

export default {
  components: {
    // BlankLayout,
    // LoginLayout,
  },
  data() {
    return {
      loading: false,
    };
  },
  mounted() {
    document.title = "Vox Money";
  }, 
  computed: {
    ...mapState({
      appLoading: (state) => state.helperModule?.appLoading,
    }),
    layout() {
      return `${this.$route.meta.layout || "BlankLayout"}`;
    },
  },
};
</script>

<style lang="scss" scoped>
.v-progress-linear {
  -moz-transform: scale(1, -1);
  -webkit-transform: scale(1, -1);
  -o-transform: scale(1, -1);
  -ms-transform: scale(1, -1);
  transform: scale(1, -1);
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
}
</style>
