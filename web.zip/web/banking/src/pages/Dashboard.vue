<template>
  <component :is="layout">
    <AccountSummaryData v-slot:default="{ getAccountSummary }">
      <div class="wallet-wrapper">
        <div class="wallet-wrapper--col1"><WalletCarousel /></div>
        <div class="wallet-wrapper--col2">
          <AccountDetails @updated="getAccountSummary" />
        </div>
      </div>
      <OTabs :items="items" @clickTab="handleTabClicked" class="tabs-main">
        <template v-slot:default="{ cmp, componentKey }">
          <component
            v-bind:is="cmp"
            :key="componentKey"
            :cmp="cmp"
            :tabClicked="tabClicked"
          />
        </template>
      </OTabs>
    </AccountSummaryData>
  </component>
</template>
<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

@Component({
  components: {
    Transactions: () =>
      import("@/components/TabSections/Transactions/Transactions.vue"),
    StandingOrders: () =>
      import("@/components/TabSections/StandingOrders/StandingOrders.vue"),
    ScheduledTransfers: () =>
      import(
        "@/components/TabSections/ScheduledTransfers/ScheduledTransfers.vue"
      ),
    DirectDebits: () =>
      import("@/components/TabSections/DirectDebits/DirectDebits.vue"),
    ContactCentre: () =>
      import("@/components/TabSections/ContactCentre/ContactCentre.vue"),
    OTabs: () => import("@/components/lib/OTabs.vue"),
    More: () => import("@/components/TabSections/More/Index.vue"),
    AccountSummaryData: () =>
      import("@/components/AccountSummaryData/AccountSummaryData.vue"),
    WalletCarousel: () =>
      import("@/components/WalletCarousel/WalletCarousel.vue"),
    AccountDetails: () =>
      import("@/components/AccountDetails/AccountDetails.vue"),
  },
})
export default class Home extends Vue {
  tabClicked = false;
  private items: {
    name: string;
    cmp: string;
    tabClicked?: boolean;
  }[] = [
    {
      name: "Transactions",
      cmp: "Transactions",
      tabClicked: this.tabClicked,
    },
    { name: "Standing Orders", cmp: "StandingOrders" },
    { name: "Scheduled Transfers", cmp: "ScheduledTransfers" },
    { name: "Direct Debits", cmp: "DirectDebits" },
    // { name: "Contact Centre", cmp: "ContactCentre" },
    { name: "More...", cmp: "More" },
  ];

  handleTabClicked(): void {
    this.tabClicked = true;
  }
}
</script>
<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";
.wallet-wrapper {
  display: flex;
  flex-direction: column;
  margin: 0 -20px;
  margin-bottom: 20px;
  @media #{map-get($display-breakpoints, 'lg-and-up')} {
    flex-direction: row;
  }
  &--col1 {
    background: #fff;
    border-radius: 10px;
    box-sizing: border-box;
    flex: 1;
    margin-left: 20px;
    padding: 0 20px;
    box-shadow: 8px 8px 10px var(--v-primary-base);
    margin-right: 20px;
    margin-bottom: 20px;
    @media #{map-get($display-breakpoints, 'lg-and-up')} {
      margin-right: 0;
      margin-bottom: 0;
    }
  }
  &--col2 {
    flex: 1;
    width: 100%;
    align-self: center;
    padding: 0 20px;
    box-sizing: border-box;
    color: #000;
    @media #{map-get($display-breakpoints, 'lg-and-up')} {
      min-width: 570px;
    }
  }
}

.wallet-wrapper > .wallet-wrapper--col2 > .account-card {
    box-shadow: 8px 8px 10px var(--v-primary-base);
    border-radius: 10px;
}

.tabs-main {
  background: #fff;
  border-radius: 10px;
  padding: 12px;
  box-shadow: 8px 8px 10px var(--v-primary-base);
}
</style>
