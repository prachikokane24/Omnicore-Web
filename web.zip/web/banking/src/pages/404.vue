<template>
  <div>Not Found 404</div>
</template>
<script lang="ts">
import { Vue } from "vue-property-decorator";
export default class Notfound extends Vue {}
</script>
