<template>
  <div>
    <v-dialog ref="dialog" v-model="dialog" hide-overlay="dialog" content-class="v-dialog--custom">
      <div>
        <h1>{{ $t("login.loggedOff") }}</h1>
        <p>
          {{ $t("login.sessionExpired") }}
        </p>
        <OButtonGroup fluid center>
          <OButton id="btn-login" @click="login" fluid block>
            Login
          </OButton>
        </OButtonGroup>
      </div>
    </v-dialog>
  </div>
</template>

<script lang="ts">

import { Component, Vue } from "vue-property-decorator";

@Component({
  components: {
    OButton: () => import("@/components/lib/OButton.vue"),
    OButtonGroup: () => import("@/components/lib/OButtonGroup.vue")
  }
})
export default class Home extends Vue {
  dialog = true;

  mounted() {
    this.$modal.show("sessionExpiredModal");
  }

  login() : void {
    this.$router.push({
      name: "Login",
    });
  }

}
</script>
<style lang="scss">
  .v-dialog--custom {
    border: 5px solid #000;
    width: 30% !important;
  }

  .v-dialog > div { 
    padding: 1em;
  }

  .v-dialog > div > p { 
    font-size: 30px;
    margin: 40px 0 40px 0;
  }

  #btn-login { 
    // AND the CTA button is #4E0B7A VOX Purple outline and text with white background
    background-color: #fff !important;
    border: 3px solid #4E0B7A !important;
    border-radius: 999px;
    color: #4E0B7A !important;
    font-size: 20px;    
    font-weight: bold;
    padding: 5px 50px 0 50px !important;
  }
</style>
