<template>
  <div class="hello">
    <h1>Pages / Onboarding</h1>
    <slot></slot>
    <pre>{{ userApplicationLoading }}</pre>
    <OLogo />
    <OButton @click="handleGetApp" :loading="userApplicationLoading" x-large
      >Get application</OButton
    >
    <v-combobox
      v-model="select"
      :items="items"
      label="Combobox"
      multiple
      outlined
      dense
    ></v-combobox>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from "vue-property-decorator";
import { BaseStateInterface, ActionPayload } from "@/types/store.types";
import { Action, namespace } from "vuex-class";
const applicationModule = namespace("applicationModule");
import { VCombobox } from "vuetify/lib";

@Component({
  components: {
    OButton: () => import("@/components/lib/OButton.vue"),
    OLogo: () => import("@/components/lib/OLogo.vue"),
    VCombobox,
  },
})
export default class Onboarding extends Vue {
  metaInfo(): { title: string; titleTemplate: string } {
    return {
      title: "Default App Title",
      titleTemplate: "%s | vue-meta Example App",
    };
  }

  // props
  @Prop() private msg!: string;

  // data
  public projName = "My project";

  select = ["Vuetify", "Programming"];
  items = ["Programming", "Design", "Vue", "Vuetify"];

  // mapState
  @applicationModule.State
  public userApplication!: BaseStateInterface;

  // Get data
  get userApplicationData(): unknown {
    return this.userApplication.data;
  }

  // Get loading state
  get userApplicationLoading(): boolean {
    return this.userApplication.loading;
  }

  // computed props
  get mapPayload(): ActionPayload {
    return {
      id: 100,
    };
  }

  // actions
  @Action("applicationModule/GET_APPLICATION")
  getUserApplication!: (ActionPayload) => string;
  //life cycle hooks
  beforeRouteEnter(): void {
    this.getUserApplication(this.mapPayload);
  }

  public async handleGetApp(): Promise<void> {
    this.getUserApplication(this.mapPayload);
  }
}
</script>
