<template>
  <component :is="layout">
    <!-- <router-link to="/dashboard">Go to Bar</router-link> -->
    <template #content-left>
      <div>
        <OText type="h3" size="xxl" class="mb-6 white--text" bold elevate>
          {{ $t("login.loginTitle") }}
        </OText>
      </div>
      <OText
        type="p"
        size="md"
        v-if="$t('login.featureText')"
        class="white--text elevate mb-6"
      >
        <span v-html="$t('login.featureText')"></span>
      </OText>
      <!-- <LocaleChanger /> -->
      <div class="d-flex">
        <OText
          type="p"
          size="xs"
          v-if="$te('login.footerText')"
          class="white--text elevate"
        >
          {{ $t("login.footerText") }}
        </OText>
      </div>
    </template>
    <template #content-mobile-header>
      <Logo max-width="250px" dark />
    </template>
    <template #content-right>
      <OHide sm-down>
        <Logo class="mb-8 center" max-width="250" />
      </OHide>
      <OHide md-up>
        <OText
          type="h2"
          size="xl"
          bold
          align="center"
          class="mb-4 primary--text"
          >{{ $t("login.loginTitle") }}
        </OText>
      </OHide>
      <div class="relative">
        <!-- Login Form -->
        <Transition name="fade">
          <LoginForm
            @toggleForm="handleToggleForm"
            v-if="formType == 'LoginForm'"
            class="absolute"
          />
        </Transition>
        <!-- Reset Password Form -->
        <Transition name="fade">
          <ResetForm
            @toggleForm="handleToggleForm"
            v-if="formType == 'ResetPasswordForm'"
            class="absolute"
          />
        </Transition>
        <!-- OTP Form -->
        <Transition name="fade">
          <OtpForm
            @toggleForm="handleToggleForm"
            v-if="formType == 'OtpForm'"
            class="absolute"
          />
        </Transition>
      </div>
      <OHide md-up class="mt-7">
        <OText type="p" v-if="$t('login.featureText')" class="mb-6">
          <span v-html="$t('login.featureText')"></span>
        </OText>
        <OText type="p" size="xs" v-if="$te('login.footerText')">
          {{ $t("login.footerText") }}
        </OText>
      </OHide>
    </template>
  </component>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import LoginForm from "@/components/Form/Login/LoginForm.vue";
import ResetForm from "@/components/Form/Login/ResetForm.vue";
import OtpForm from "@/components/Form/Login/OtpForm.vue";
import Logo from "@/components/Logo.vue";
import OText from "@/components/lib/OText.vue";
import OHide from "@/components/lib/OHide.vue";
//import LocaleChanger from "@/components/Widgets/LocaleChanger.vue";

@Component({
  components: {
    LoginForm,
    Logo,
    OText,
    OHide,
    ResetForm,
    OtpForm,
    //LocaleChanger,
  },
})
export default class Login extends Vue {
  public formType = "LoginForm";
  private langs = ["fr-FR", "en-GB"];

  handleToggleForm(formType: string): void {
    this.formType = formType;
  }
}
</script>

<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";
@media #{map-get($display-breakpoints, 'md-and-up')} {
  .relative {
    display: block;
    position: relative;
    width: 100%;
    height: 350px;
  }
  .absolute {
    display: block;
    position: absolute;
    top: 0;
    width: 100%;
  }
  .fade-enter-active,
  .fade-leave-active {
    transition: all 0.3s;
    //transform: translate3d(0, 0, 0);
    will-change: transform, opacity;
  }

  .fade-enter,
  .fade-leave-to {
    opacity: 0;
    // transform: translate3d(0, 10px, 0);
  }
}
</style>
