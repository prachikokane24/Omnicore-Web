<template>
  <component v-bind:is="openBankingAction" />
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

@Component({
  components: {
    Aisp: () => import("@/components/OpenBanking/Aisp.vue"),
    Pisp: () => import("@/components/OpenBanking/Pisp.vue"),
  },
})
export default class OpenBanking extends Vue {
  get openBankingAction(): string {
    return this.$route.params.openbankingaction;
  }
}
</script>
