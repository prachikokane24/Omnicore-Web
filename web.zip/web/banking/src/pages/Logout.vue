<template>
  <component :is="layout">
    <transition name="fade">
      <v-overlay v-if="loading" v-bind="overlayConfig" class="overlay">
        <v-progress-circular
          indeterminate
          size="64"
          color="primary"
        ></v-progress-circular>
        <OText type="p" color="white" class="mt-4" bold
          >{{ $t("login.loggingOut") }}
        </OText>
      </v-overlay>
    </transition>
  </component>
</template>
<script lang="ts">
import { TokensContext } from "@/omnicore-lib/src/services/http/TenantTokenBasedService";
import { Component, Vue } from "vue-property-decorator";

@Component({
  components: {
    OText: () => import("@/components/lib/OText.vue"),
  },
})
export default class Home extends Vue {
  loading = false;
  get overlayConfig(): {
    value: boolean;
    zIndex: number;
    color: string;
    opacity: number;
  } {
    return {
      value: this.loading,
      zIndex: 10000,
      color: "primary",
      opacity: 0,
    };
  }
  mounted() {
    this.loading = true;
    TokensContext.instance.clearTokens();

    setTimeout(() => {
      this.$router.push({
        name: "Login",
      });
    }, 2200);
  }
}
</script>
<style lang="scss" scoped>
.overlay {
  display: flex;
  flex-direction: column;
  text-align: center;
  background-color: white;
  color: var(--v-primary-base);
  &__text {
    margin-top: 20px;
    color: black;
  }
}
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s ease;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}
</style>
