import { BaseStateInterface, QueryParamInterface } from "@/types/store.types";

const baseState = (): BaseStateInterface => {
  return {
    data: null,
    loading: false,
    errorMessage: null,
    errorStatus: null,
  };
};

const getErrorMessage = (
  e: {
    response: {
      data: any;
    };
    details: string;
    message: string;
    errors: { title: string; detail: string }[];
    errorCode: string;
    errorDescription: string;
  },
  message: string
): string | string[] => {
  if (!e.response) {
    return message;
  }
  const data = e.response.data;
  const eDetails = data?.details;
  const eMessage = data?.message;
  const eErrors = data?.errors;
  const eErrorCode = data?.errorCode;
  const eErrorDescription = data?.errorDescription;
  if (eDetails || eMessage) {
    let str = "";
    str += eDetails || "";
    str += eMessage && eDetails ? " " : "";
    str += eMessage || "";
    return str === "No message available" ? message : str;
  }
  if (eErrors && eErrors.length) {
    return eErrors
      .map((title: boolean, detail: string) => title + " " + detail)
      .join(", ");
  }
  if (eErrorCode && eErrorDescription) {
    return eErrorDescription;
  }
  return "Unknown error occured";
};

const queryString = (payload: QueryParamInterface): string => {
  let str = "";
  for (const [key, value] of Object.entries(payload)) {
    if (value) {
      str += `${key}=${value}&`;
    }
  }
  return str.slice(0, -1);
};

export { getErrorMessage, baseState, queryString };
