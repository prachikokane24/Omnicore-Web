<template>
  <div class="hello">
    <h1>Pages / Onboarding</h1>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from "vue-property-decorator";
import { BaseStateInterface, ActionPayload } from "@/types/store.types";
import { Action, namespace } from "vuex-class";
const applicationModule = namespace("applicationModule");

interface InputConfig {
  rules?: string;
  counter?: number;
  label?: string;
  required?: boolean;
  preSelected?: unknown;
}

@Component({
  components: {
    OButton: () => import("@/components/lib/OButton.vue"),
  },
})
export default class Onboarding extends Vue {
  // props
  @Prop() private msg!: string;
  @Prop({ default: false }) private dark!: boolean;

  // data
  public projName = "My project";

  // mapState
  @applicationModule.State
  public userApplication!: BaseStateInterface;

  // Get data
  get userApplicationData(): unknown {
    return this.userApplication.data;
  }

  // Get loading state
  get userApplicationLoading(): boolean {
    return this.userApplication.loading;
  }

  // computed props
  get mapPayload(): ActionPayload {
    return {
      id: 100,
    };
  }

  // actions
  @Action("applicationModule/GET_APPLICATION")
  getUserApplication!: (ActionPayload) => string;

  // lifecycle
  beforeRouteEnter(): void {
    this.getUserApplication(this.mapPayload);
  }

  // methods
  public async handleGetApp(): Promise<void> {
    await this.getUserApplication(this.mapPayload); // mapAction call
  }
}
</script>
<style lang="scss" scoped>
.hello {
  //background-color: var(--v-yourcustomvariablename-base);
}
</style>
