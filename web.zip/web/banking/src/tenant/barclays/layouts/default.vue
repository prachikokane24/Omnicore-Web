<template>
  <v-main>
    <v-container center>
      This is using Barclays default layout
      <slot />
    </v-container>
  </v-main>
</template>

<script>
export default {
  components: {
    // eslint-disable-next-line
    OSwitch: () => import("@/components/lib/OSwitch.vue"),
    // eslint-disable-next-line
    OLogo: () => import("@/components/lib/OLogo.vue")
  },
};
</script>
