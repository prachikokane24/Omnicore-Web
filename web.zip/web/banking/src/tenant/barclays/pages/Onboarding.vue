<template>
  <div>
    <h1>Hello I am Barclays Onboarding Page</h1>
    <Onboarding>
      <Alert class="mt-5 mb-5" icon="mdi-info" outlined>
        <p>
          We know you may need to call us or visit a branch sometimes, but to
          help us support our most vulnerable customers, please only do so if
          you really need to.
        </p>
        <p>
          We’ve re-opened as many branches as we can, but we’re limiting our
          appointment bookings to help those who need us most. Please contact
          your local branch for details. In line with government guidelines, if
          you’re visiting us in branch you must wear a face covering unless you
          have a valid exemption.
        </p>
        <p>
          Please also maintain safe social distancing. This is to help protect
          you and others. We appreciate it’s a difficult time, so thanks for
          your ongoing support.
        </p></Alert
      >
    </Onboarding>
  </div>
</template>
<script>
import Onboarding from "@/pages/Onboarding";
import Alert from "@/components/lib/Alert";
export default {
  components: {
    Onboarding,
    Alert,
  },
};
</script>
