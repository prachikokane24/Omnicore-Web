<template>
  <div
    class="wrapper"
    :style="`
      background-image: url(${require('@tenantAssets/backgrounds/background.jpg')});
      background-size: cover;
      background-repeat: no-repeat;

      height: 100%
    `"
  >
    <div class="main">
      <ONav v-model="drawer" />
      <OContent class="content">
        <OTopBar
          :isOpen="drawer"
          @change="handleChange"
          class="rounded-lg mb-5"
        >
          <template #alignRight><AccountProfile dark /></template>
        </OTopBar>
        <slot name="default" />
      </OContent>
    </div>
  </div>
</template>
<script lang="ts">
import { Component, Vue, Prop } from "vue-property-decorator";
import ONav from "@/components/lib/Layout/ONav.vue";
import OTopBar from "@/components/lib/Layout/OTopBar.vue";
import OContent from "@/components/lib/Layout/OContent.vue";
import OText from "@/components/lib/OText.vue";
import OIcon from "@/components/lib/OIcon.vue";
import OBadge from "@/components/lib/OBadge.vue";
import AccountProfile from "@/components/AccountProfile/AccountProfile.vue";
@Component({
  components: {
    ONav,
    OTopBar,
    OContent,
    OText,
    OIcon,
    OBadge,
    AccountProfile,
  },
})
export default class MainLayout extends Vue {
  @Prop({ default: false }) private backgroundImage!: boolean | string;

  private drawer: boolean = this.$vuetify.breakpoint.mdAndUp ? true : false;

  // get isFixed(): boolean {
  //   return this.$vuetify.breakpoint.smAndDown && this.drawer ? true : false;
  // }
  mounted(): void {
    this.listeners();
  }
  listeners(): void {
    window.addEventListener("resize", this.onResize, {
      passive: true,
    });
  }
  onResize(): void {
    if (this.$vuetify.breakpoint.smAndDown) {
      this.drawer = this.$vuetify.breakpoint.mdAndDown ? false : true;
    }
  }
  handleChange(val: boolean): void {
    this.drawer = val;
  }
}
</script>

<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";
.wrapper {
  height: 100%;
  background-color: var(--v-primary-base);
  padding: 20px 0;
}

.content {
  margin: 0 10px 0 10px;
  @media #{map-get($display-breakpoints, 'md-and-up')} {
    margin: 0 30px 0 30px;
  }
  @media #{map-get($display-breakpoints, 'lg-and-up')} {
    margin: 0 20px 0 60px;
  }
}
</style>
