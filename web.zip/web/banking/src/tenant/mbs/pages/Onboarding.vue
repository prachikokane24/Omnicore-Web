<template>
  <div>
    <h1>Hello I am MBS Onboarding Page</h1>
  </div>
</template>

<script>
export default {
  name: "Onboarding",
};
</script>
