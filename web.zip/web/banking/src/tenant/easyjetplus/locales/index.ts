// Enabled locales
export const locales = ["en-GB", "fr-FR"];
