export declare const locales: [string];
