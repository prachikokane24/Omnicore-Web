import Vue from "vue";
import i18n from "@/plugins/i18n";

Vue.filter("membershipType", (value) => {
  let type;
  switch (value) {
    case "child":
      type = i18n.t("memberships.membershipTypes.child");
      break;
    case "partner":
      type = i18n.t("memberships.membershipTypes.partner");
      break;
    default:
      type = i18n.t("memberships.membershipTypes.adult");
  }
  return type;
});
