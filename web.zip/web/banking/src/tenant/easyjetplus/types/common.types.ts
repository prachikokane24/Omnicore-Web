export interface navItemType {
  title: string;
  to?: string;
  exact?: boolean;
  link?: boolean;
  icon?: string;
}

export interface MembershipItem {
  id: string;
  membershipId: number;
  membershipType: string;
  title: string;
  firstName: string;
  lastName: string;
  fullName: string;
  dob: string;
  company: string;
  purchaseDate: string;
  expiryDate: string;
  autoRenewal: boolean;
  qr: string;
}

export interface MembershipItemPayload {
  membership: MembershipItem;
  requestId: string;
  processedUtc: string;
}
