<template>
  <v-app id="app" class="dashboard">
    <v-navigation-drawer v-model="drawer" color="secondary" app>
      <NavMenu v-bind="navConfig" @click="toggleDrawer" />
    </v-navigation-drawer>
    <v-app-bar
      elevation="0"
      flat
      tile
      app
      absolute
      color="transparent"
      :height="$vuetify.breakpoint.mdAndUp ? 120 : 68"
    >
      <div
        class="app-bar"
        :style="{
          backgroundImage: `url(${require(`@tenantAssets/backgrounds/app-bar.jpg`)})`,
        }"
      >
        <div class="app-bar--col1">
          <v-app-bar-nav-icon
            @click="drawer = !drawer"
            color="white"
            dark
            style="margin-left: -10px"
          >
            <OIcon icon="menu" />
          </v-app-bar-nav-icon>
        </div>
        <div class="app-bar--col2">
          <AccountProfile v-bind="accountProfileConfig" />
        </div>
      </div>
    </v-app-bar>
    <v-main>
      <div class="main">
        <slot name="default" />
      </div>
    </v-main>
  </v-app>
</template>
<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import NavMenu from "@tenantComponents/NavMenu.vue";
import AccountProfile from "@/components/AccountProfile/AccountProfile.vue";
import OText from "@/components/lib/OText.vue";
import OIcon from "@/components/lib/OIcon.vue";
import { navItemType } from "../types/common.types";

@Component({
  components: {
    NavMenu,
    AccountProfile,
    OText,
    OIcon,
  },
})
export default class MainLayout extends Vue {
  // public bgImageWebP = this.getBgImage("app-bar-bg.webp");
  // public bgImageJpeg = this.getBgImage("app-bar-bg.jpeg");

  drawer: null | boolean = null;

  navItems = [
    {
      title: "Home",
      icon: "mdi-home",
      to: "Dashboard",
      exact: true,
    },
    {
      title: "Benefits",
      icon: "mdi-comment-outline",
      to: "Benefits",
      exact: true,
    },
    {
      title: "FAQs",
      icon: "mdi-checkbox-multiple-marked",
      to: "Faqs",
      exact: true,
    },
    {
      title: "Contact Us",
      icon: "mdi-view-grid-outline",
      to: "Contact",
      exact: true,
    },
    { title: "Logout", to: "Logout", icon: "mdi-exit-to-app", exact: true },
  ];

  get navConfig(): {
    title?: string;
    subtitle?: string;
    items: navItemType[];
  } {
    return {
      subtitle: "Menu",
      items: this.navItems,
    };
  }

  get accountProfileConfig(): {
    textColor: string;
    avatarColor: string;
    avatarTextColor: string;
  } {
    return {
      textColor: "white",
      avatarColor: "white",
      avatarTextColor: "secondary",
    };
  }

  toggleDrawer(): void {
    this.drawer = !this.drawer;
  }
}
</script>

<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";
.dashboard {
  height: 100%;
  background-color: var(--v-background-base);
}
.app-bar {
  max-width: 1200px;
  @media #{map-get($display-breakpoints, 'md-and-up')} {
    margin: 0 40px;
  }
}
.main {
  max-width: 1200px;
  margin-top: 20px;
  @media #{map-get($display-breakpoints, 'md-and-up')} {
    margin: 0 40px;
  }
}
.app-bar {
  display: flex;
  justify-content: flex-end;
  position: relative;
  align-items: center;
  width: 100%;
  padding: 0 20px;
  height: 68px;
  box-sizing: border-box;
  background-color: var(--v-primary-base);
  background-size: cover;

  &--col1 {
    flex: 1;
    display: flex;
    align-items: center;
    button {
      width: auto;
      height: auto;
    }
  }
}
.v-list-item,
.v-list-item--link {
  color: white;
}
.v-item--active,
.v-list-item--active {
  color: var(--v-primary-base) !important;
  cursor: default;
  &::before {
    background-color: transparent;
  }
}
</style>
