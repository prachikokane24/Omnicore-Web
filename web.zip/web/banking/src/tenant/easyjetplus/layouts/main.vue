<template>
  <div class="container">
    <v-navigation-drawer
      class="login-nav"
      v-model="login"
      absolute
      temporary
      right
      color="secondary"
      width="700"
    >
      <div class="login-container">
        <OHide md-up>
          <OSection class="logo pt-1 pb-1 mb-5">
            <v-container>
              <OAlign align="center">
                <Logo max-width="170px" logo="logo-plus" dark />
              </OAlign>
            </v-container>
          </OSection>
        </OHide>

        <div class="login">
          <div class="title">
            <OAlign align="center" align-md="left">
              <OText
                type="h3"
                class="mb-8"
                :text="$t('login.loginTitle')"
                color="white"
              />
            </OAlign>
          </div>
          <div class="login-forms">
            <!-- Login Form -->
            <LoginForm
              v-show="formType == 'LoginForm'"
              @toggleForm="handleToggleForm"
              v-bind="config.loginForm"
              class="absolute"
            >
              <template v-slot:actions="{ loading, invalid }">
                <OButtonGroup :fluid="true" :fill="true">
                  <OButton
                    large
                    block
                    type="button"
                    color="white"
                    :data-id="`loginFormCancelButton`"
                    @click="login = false"
                    >{{ $t("login.cancelBtnText") }}</OButton
                  >
                  <OButton
                    block
                    :loading="loading"
                    :disabled="loading || invalid"
                    :data-id="`loginFormSubmitButton`"
                    large
                    type="submit"
                    dark
                    >{{ $t("login.proceedBtnText") }}</OButton
                  >
                </OButtonGroup>
              </template>
            </LoginForm>
            <!-- Reset Password Form -->
            <ResetForm
              v-show="formType == 'ResetPasswordForm'"
              @toggleForm="handleToggleForm"
              v-bind="config.resetForm"
              class="absolute"
            >
              <template v-slot:actions="{ loading, invalid }">
                <OButtonGroup :fluid="true" :fill="true">
                  <OButton
                    large
                    block
                    type="button"
                    color="white"
                    :data-id="`resetFormCancelButton`"
                    @click="formType = 'LoginForm'"
                    >{{ $t("resetPassword.cancelBtnText") }}</OButton
                  >
                  <OButton
                    block
                    :loading="loading"
                    :disabled="loading || invalid"
                    :data-id="`resetFormSubmitButton`"
                    large
                    type="submit"
                    dark
                    >{{ $t("resetPassword.resetPasswordBtn") }}</OButton
                  >
                </OButtonGroup>
              </template>
            </ResetForm>
            <!-- OTP Form -->
            <OtpForm
              v-show="formType == 'OtpForm'"
              @toggleForm="handleToggleForm"
              v-bind="config.otpForm"
              class="absolute"
            >
              <template v-slot:actions="{ loading, invalid }">
                <OButtonGroup :fluid="true" :fill="true">
                  <OButton
                    large
                    block
                    type="button"
                    color="white"
                    :data-id="`otpFormCancelButton`"
                    @click="formType = 'LoginForm'"
                    >{{ $t("Otp.cancelBtnText") }}</OButton
                  >
                  <OButton
                    block
                    :loading="loading"
                    :disabled="loading || invalid"
                    :data-id="`otpFormSubmitButton`"
                    large
                    type="submit"
                    dark
                    >{{ $t("Otp.submitBtnText") }}</OButton
                  >
                </OButtonGroup>
              </template>
            </OtpForm>
          </div>
        </div>
      </div>
    </v-navigation-drawer>
    <v-main>
      <v-container class="fill-height">
        <v-row>
          <v-btn color="primary" @click.stop="login = !login">
            Toggle Login
          </v-btn>
        </v-row>
        <slot name="default" />
      </v-container>
    </v-main>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

interface loginConfigProps {
  inputColor?: string;
  textColor?: string;
  messageBold?: boolean;
  outsideLabel?: boolean;
  loginIdLength?: number;
  labelColor?: string;
}
interface loginConfig {
  loginForm: loginConfigProps;
  resetForm: loginConfigProps;
  otpForm: loginConfigProps;
}

@Component({
  components: {
    Logo: () => import("@/components/Logo.vue"),
    OHide: () => import("@/components/lib/OHide.vue"),
    OSection: () => import("@/components/lib/OSection.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OAlign: () => import("@/components/lib/OAlign.vue"),
    OButtonGroup: () => import("@/components/lib/OButtonGroup.vue"),
    OButton: () => import("@/components/lib/OButton.vue"),
    LoginForm: () => import("@/components/Form/Login/LoginForm.vue"),
    ResetForm: () => import("@/components/Form/Login/ResetForm.vue"),
    OtpForm: () => import("@/components/Form/Login/OtpForm.vue"),
  },
})
export default class LoginLayout extends Vue {
  private login = null;

  public formType = "LoginForm";

  get config(): loginConfig {
    return {
      loginForm: {
        inputColor: "white",
        textColor: "white",
        messageBold: true,
        outsideLabel: true,
        loginIdLength: 10,
        labelColor: "white",
      },
      resetForm: {
        inputColor: "white",
        textColor: "white",
        messageBold: true,
        outsideLabel: true,
        labelColor: "white",
      },
      otpForm: {
        inputColor: "white",
        textColor: "white",
        messageBold: true,
        outsideLabel: true,
        labelColor: "white",
      },
    };
  }

  handleToggleForm(formType: string): void {
    this.formType = formType;
  }
}
</script>
<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";

.logo {
  display: flex;
  flex-direction: column;
  align-items: center;
  flex: 1;
  position: relative;
  background-color: --v-login-background;
  background-position: center center;
  background-size: 100%;
  background-image: url("~@tenantAssets/backgrounds/logo-background.webp"),
    url("~@tenantAssets/backgrounds/logo-background.jpg");
}

.login-container {
  width: 100%;
  height: 100%;
}

.login {
  padding: 20px;
  position: relative;
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  flex-direction: column;
  @media #{map-get($display-breakpoints, 'md-and-up')} {
    justify-content: center;
  }
}

.login-forms,
.title {
  position: relative;
  width: 100%;
  max-width: 420px;
  max-height: 400px;
}

.login-forms {
  height: 100%;
}

.absolute {
  display: block;
  width: 100%;
}

@media #{map-get($display-breakpoints, 'md-and-up')} {
  .absolute {
    position: absolute;
    top: 0;
  }
}
</style>
