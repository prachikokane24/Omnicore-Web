<template>
  <div>
    <carousel-3d
      @after-slide-change="onAfterSlideChange"
      :perspective="0"
      :display="3"
      :width="size.width"
      :height="size.height"
      :controls-visible="mapItems.length > 1"
      :border="0"
      :count="mapItems.length"
      ref="carousel"
      v-if="mapItems.length > 0"
    >
      <slide
        v-for="({ src, membershipId, qr }, i) in mapItems"
        :index="i"
        :key="i"
      >
        <template slot-scope="{ index, isCurrent, leftIndex, rightIndex }">
          <MembershipCard
            :data-index="index"
            :class="{
              current: isCurrent,
              onLeft: leftIndex >= 0,
              onRight: rightIndex >= 0,
            }"
            :src="require(`@tenantAssets/cards/${src}.png`)"
            :width="size.width"
            :height="size.height"
            :qr="qr"
            :membershipId="membershipId"
            @cardClick="handleShowCard"
          />
        </template>
      </slide>
    </carousel-3d>

    <OModal :loading="false" id="imageModal">
      www
      <!-- <MembershipCard
        :data-index="index"
        :class="{
          current: isCurrent,
          onLeft: leftIndex >= 0,
          onRight: rightIndex >= 0,
        }"
        :src="require(`@tenantAssets/cards/${src}.png`)"
        :width="size.width"
        :height="size.height"
      /> -->
    </OModal>
  </div>
</template>

<script lang="ts">
import { Carousel3d, Slide } from "vue-carousel-3d";
import { Component, Vue } from "vue-property-decorator";
import { Action, namespace } from "vuex-class";
import { BaseStateInterface } from "@/types/store.types";
import { MembershipItemPayload } from "../types/common.types";

const membershipModule = namespace("membershipModule");

interface MembershipItem {
  membershipId: number;
  qr: string;
  data: MembershipItemPayload;
}

@Component({
  components: {
    OText: () => import("@/components/lib/OText.vue"),
    OAlign: () => import("@/components/lib/OAlign.vue"),
    OIcon: () => import("@/components/lib/OIcon.vue"),
    OModal: () => import("@/components/lib/Modal/OModal.vue"),
    MembershipCardCarousel: () =>
      import("@tenantComponents/MembershipCardCarousel.vue"),
    MembershipCard: () => import("@tenantComponents/MembershipCard.vue"),
    Carousel3d,
    Slide,
  },
})
export default class MembershipCardCarousel extends Vue {
  @membershipModule.State
  private memberships!: BaseStateInterface;

  @membershipModule.State
  private selectedMembershipCard!: BaseStateInterface;

  @Action("membershipModule/UPDATE_SELECTED_MEMBERSHIP_CARD")
  updateSelectedMembershipCard!: (payload) => string;

  get size(): { width: number; height: number } {
    return {
      width: this.$vuetify.breakpoint.xs ? 250 : 300,
      height: this.$vuetify.breakpoint.xs ? 150 : 180,
    };
  }

  get mapItems(): MembershipItem[] {
    return (
      this.memberships?.data?.memberships?.map((item) => {
        return {
          membershipId: item.membershipId,
          qr: item.qr || null,
          src: "easyjetPlusCard",
          data: item,
        };
      }) || []
    );
  }

  onAfterSlideChange(index: number): void {
    try {
      this.updateSelectedMembershipCard(
        this.memberships?.data?.memberships[index]
      );
      this.$EventBus.$emit("membershipChanged", 0);
    } catch (e) {
      console.log(e);
    }
  }

  goToSlide(index: number): void {
    (this.$refs.carousel as Vue & { goSlide: (index) => void }).goSlide(index);
  }

  handleShowCard(): void {
    this.$modal.show("imageModal");
  }
}
</script>

<style lang="scss" scoped>
.carousel-3d-slide {
  background-color: transparent;
  border-width: 0;
  transition: opacity none !important;
  &.left-1 {
    opacity: 0.3 !important;
    filter: blur(3px);
  }
  &.right-1 {
    opacity: 0.3 !important;
    filter: blur(3px);
  }
  &.current {
    opacity: 1 !important;
    visibility: visible;
  }
}
</style>
