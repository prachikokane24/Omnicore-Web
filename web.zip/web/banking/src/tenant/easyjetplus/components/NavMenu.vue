<template>
  <div class="nav">
    <div class="logo-wrapper">
      <Logo logo="logo-plus" max-width="110" dark />
    </div>
    <v-list-item :class="{ hide: $vuetify.breakpoint.lgAndUp }">
      <v-list-item-content>
        <v-list-item-title @click.prevent="handleHide">
          <OAlign align="end">
            <OLink>
              <OText color="white">&#x3c; Hide</OText>
            </OLink>
          </OAlign>
        </v-list-item-title>
      </v-list-item-content>
    </v-list-item>
    <v-list-item v-if="title">
      <v-list-item-content>
        <v-list-item-title>
          <OText type="h6" size="h6" color="white">{{ title }}</OText>
        </v-list-item-title>
      </v-list-item-content>
    </v-list-item>
    <v-divider></v-divider>
    <v-list nav>
      <v-list-item-subtitle class="white--text mb-1 ml-3" v-if="subtitle">
        <OText color="white">{{ subtitle }}</OText>
      </v-list-item-subtitle>
      <v-list-item-group dark>
        <v-list-item
          v-for="item in items"
          :key="item.title"
          :to="item.to"
          :exact="item.exact"
          link
        >
          <v-icon class="mr-5">{{ item.icon }}</v-icon>
          <v-list-item-content>
            <v-list-item-title v-text="item.title" />
          </v-list-item-content>
        </v-list-item>
      </v-list-item-group>
    </v-list>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from "vue-property-decorator";
import { navItemType } from "../types/common.types";

@Component({
  components: {
    OText: () => import("@/components/lib/OText.vue"),
    OAlign: () => import("@/components/lib/OAlign.vue"),
    OLink: () => import("@/components/lib/OLink.vue"),
    Logo: () => import("@/components/Logo.vue"),
  },
})
export default class NavMenu extends Vue {
  @Prop() title!: string;
  @Prop() subtitle!: string;
  @Prop() items!: navItemType[];

  handleHide(): void {
    this.$emit("click");
  }
}
</script>

<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";
.nav {
  margin-top: 32px;
}
.logo-wrapper {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 52px;
  background-image: url("~@tenantAssets/backgrounds/app-bar.jpg");
  background-size: cover;
  background-position: center;
}
.v-list-item,
.v-list-item--link {
  color: white;
}
.v-item--active,
.v-list-item--active {
  color: var(--v-primary-base) !important;
  cursor: default;
  &::before {
    background-color: transparent;
  }
}
.hide {
  visibility: hidden;
}
</style>
