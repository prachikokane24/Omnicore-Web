<template>
  <div class="account-info">
    <div class="account-info-row">
      <div class="account-info--col1">
        <table class="account-info-details">
          <tr>
            <th>
              <OText color="primary" size="sm" bold>{{
                $t("accountInfo.accountHolder")
              }}</OText>
            </th>
            <td>
              <OText size="xl" bold>{{ accountDetails.accountHolder }}</OText>
            </td>
          </tr>
        </table>
      </div>
      <div class="account-info--col2">
        <table class="account-info-details" role="presentation"></table>
      </div>
    </div>
    <div class="account-info-row">
      <div class="account-info--col1">
        <table class="account-info-details">
          <tr>
            <th>
              <OText color="primary" size="sm" bold>{{
                $t("accountInfo.dateOfBirth")
              }}</OText>
            </th>
            <td>
              <OText bold>{{
                accountDetails.dob | date("forwardslash")
              }}</OText>
            </td>
          </tr>
        </table>
      </div>
      <div class="account-info--col2">
        <table class="account-info-details">
          <tr>
            <th>
              <OText color="primary" size="sm" bold>{{
                $t("accountInfo.purchaseDate")
              }}</OText>
            </th>
            <td>
              <OText bold>{{
                accountDetails.purchaseDate | date("forwardslash")
              }}</OText>
            </td>
          </tr>
        </table>
      </div>
    </div>
    <div class="account-info-row">
      <div class="account-info--col1">
        <table class="account-info-details">
          <tr>
            <th>
              <OText color="primary" size="sm" bold>{{
                $t("accountInfo.expiryDate")
              }}</OText>
            </th>
            <td>
              <OText bold>{{
                accountDetails.expiryDate | date("forwardslash")
              }}</OText>
            </td>
          </tr>
        </table>
      </div>
      <div class="account-info--col2">
        <table class="account-info-details" v-if="accountDetails.companyName">
          <tr>
            <th>
              <OText color="primary" size="sm" bold>{{
                $t("accountInfo.companyName")
              }}</OText>
            </th>
            <td>
              <OText bold>{{ accountDetails.companyName }}</OText>
            </td>
          </tr>
        </table>
        <table class="account-info-details" role="presentation" v-else></table>
      </div>
    </div>
    <div class="account-info-row">
      <div class="account-info-actions">
        <OButtonGroup fluid space-between>
          <OButton block large bold @click="handleShowWallet('edit')">{{
            $t("accountInfo.viewCardBtn")
          }}</OButton>
          <OButton
            block
            large
            color="background"
            @click="handleShowWallet('add')"
            >{{ $t("accountInfo.actionsBtn") }}</OButton
          >
        </OButtonGroup>
      </div>
    </div>
    <!-- <OModalManageCard />
    <OModalConfirmCancel
      :loading="false"
      @confirm="handleSaveWallet"
      :confirmDisabled="formWalletInvalid"
      :confirmText="
        editWallet
          ? $t('editWallet.modalSubmitBtn')
          : $t('addWallet.modalSubmitBtn')
      "
      id="walletModal"
    >
      <template v-slot:header>{{
        editWallet ? $t("editWallet.modalTitle") : $t("addWallet.modalTitle")
      }}</template>
      <OForm
        :loading="false"
        :data-id="editWallet ? 'editWallet' : 'addWallet'"
        :confirmDisabled="formWalletInvalid"
        @invalid="formWalletInvalid = $event"
        hide-actions
        ref="form"
      >
        <OFormInput
          data-id="walletName"
          v-bind="formConfig.walletName"
          v-model="formItems.walletName"
        />
        <OFormRadioTab
          data-id="walletColor"
          v-bind="formConfig.walletColor"
          v-model="formItems.walletColor"
        />
        <OFormRadioTab
          data-id="walletIcon"
          v-bind="formConfig.walletIcon"
          v-model="formItems.walletIcon"
        />
        <OText>{{ $t("addWallet.setGoalLabel") }}:</OText>
        <OFormInput
          data-id="walletTargetAmount"
          v-bind="formConfig.walletTargetAmount"
          v-model.number="formItems.walletTargetAmount"
        />
        <OFormDatePicker
          data-id="walletTargetDate"
          v-bind="formConfig.walletTargetDate"
          v-model="formItems.walletTargetDate"
        />
      </OForm>
    </OModalConfirmCancel>
    <OModalConfirm
      id="walletModalConfirmed"
      :message="
        editWallet
          ? $t('editWallet.editWalletSuccess')
          : $t('addWallet.addWalletSuccess')
      "
    /> -->
  </div>
</template>

<script lang="ts">
import { mapGetters } from "vuex";
import { Component, Prop, Vue } from "vue-property-decorator";
import { BaseStateInterface } from "@/types/store.types";
import { Action, namespace } from "vuex-class";
import { MembershipItem } from "../types/common.types";

// const summaryModule = namespace("summaryModule");
// const walletModule = namespace("walletModule");

const membershipModule = namespace("membershipModule");

interface AnyObject {
  [key: string]: any;
}

@Component({
  components: {
    OText: () => import("@/components/lib/OText.vue"),
    OAlign: () => import("@/components/lib/OAlign.vue"),
    // OForm: () => import("@/components/lib/Form/OForm.vue"),
    // OFormRadioTab: () => import("@/components/lib/Form/OFormRadioTab.vue"),
    // OFormInput: () => import("@/components/lib/Form/OFormInput.vue"),
    // OFormDatePicker: () => import("@/components/lib/Form/OFormDatePicker.vue"),
    OButtonGroup: () => import("@/components/lib/OButtonGroup.vue"),
    // OModalConfirmCancel: () =>
    //   import("@/components/lib/Modal/OModalConfirmCancel.vue"),
    // OModalConfirm: () => import("@/components/lib/Modal/OModalConfirm.vue"),
    // OModalManageCard: () =>
    //   import("@/components/AccountDetails/Modals/ModalManageCard.vue"),
    OButton: () => import("@/components/lib/OButton.vue"),
  },
  // computed: {
  //   ...mapGetters("summaryModule", {
  //     getAccountDetails: "getAccountDetails",
  //   }),
  // },
})
export default class AccountDetails extends Vue {
  @Prop({ default: false }) private loading!: boolean;

  @membershipModule.State
  private selectedMembershipCard!: MembershipItem;

  // @walletModule.State
  // private walletDetails!: BaseStateInterface;

  // @Action("membershipModule/GET_WALLET")
  // getWalletDetails!: () => string;

  // getAccountDetails!: any;
  //   formWalletInvalid = false;
  //   editWallet = false;

  formItems: AnyObject = {
    //walletName: {},
  };

  //   get isMainWallet(): boolean {
  //     return parseInt(this.selectedWallet?.walletType) == 2;
  //   }

  //   get isSavingsWallet(): boolean {
  //     return parseInt(this.selectedWallet?.walletType) == 8;
  //   }

  //   get formConfig() {
  //     return {
  //       walletName: {
  //         name: "walletName",
  //         rules: "required|min:2",
  //         label: this.$t("addWallet.walletNameLabel"),
  //         hint: this.$t("addWallet.walletNameHint"),
  //         preSelected: this.editWallet
  //           ? this.walletDetails?.data?.walletName
  //           : undefined,
  //       },
  //       walletColor: {
  //         name: "color",
  //         rules: "required",
  //         label: this.$t("addWallet.chooseColorLabel"),
  //         items: [
  //           {
  //             value: this.$vuetify.theme.themes.light.primary,
  //             color: this.$vuetify.theme.themes.light.primary,
  //           },
  //           {
  //             value: this.$vuetify.theme.themes.light.secondary,
  //             color: this.$vuetify.theme.themes.light.secondary,
  //           },
  //         ],
  //         preSelected:
  //           "#" + this.editWallet ? this.walletDetails?.data?.color : undefined,
  //       },
  //       walletTargetAmount: {
  //         name: "targetAmount",
  //         rules: "money",
  //         placeholder: "0.00",
  //         label: this.$t("addWallet.targetAmount"),
  //         preSelected: this.editWallet
  //           ? this.walletDetails?.data?.goal
  //           : undefined,
  //       },
  //       walletTargetDate: {
  //         name: "targetDate",
  //         label: this.$t("addWallet.targetDate"),
  //         preSelected: this.editWallet
  //           ? this.walletDetails?.data?.date
  //           : undefined,
  //       },
  //     };
  //   }

  get accountDetails(): {
    accountHolder: string;
    dob: string;
    purchaseDate: string;
    companyName: string;
    expiryDate: string;
  } {
    return {
      accountHolder: this.selectedMembershipCard?.fullName,
      dob: this.selectedMembershipCard?.dob,
      purchaseDate: this.selectedMembershipCard?.purchaseDate,
      companyName: this.selectedMembershipCard?.company,
      expiryDate: this.selectedMembershipCard?.expiryDate,
    };
  }
  handleSaveWallet(): void {
    this.$modal.hide("walletModal");
    this.$modal.show("walletModalConfirmed");
  }
  handleShowWallet(type: string): void {
    this.formItems = {};
    //this.editWallet = false;
    this.$modal.show("walletModal");
    if (type == "edit") {
      //this.editWallet = true;
      //this.getWalletDetails();
    } else {
      this.$nextTick(() => {
        (this.$refs.form as Vue & { reset: () => void }).reset();
      });
    }
  }
}
</script>

<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";
.account-info {
  display: flex;
  flex-direction: column;
  width: 100%;
  background-color: white;
  border-radius: 10px;
  &-row {
    display: flex;
    flex-direction: column;
    padding: 10px 20px;
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      flex-direction: row;
    }
  }
  &-row:not(:last-child) {
    border-bottom: 1px solid var(--v-border-base);
  }
  &--col1,
  &--col2 {
    display: flex;
  }
  table {
    table-layout: fixed;
    width: 100%;
    th {
      text-align: left;
    }
    &.account-info-details {
      th,
      td {
        vertical-align: middle;
      }
      th {
        min-width: 150px;
      }
    }
  }
  &-actions {
    padding-top: 3px;
    width: 100%;
  }
}
</style>
