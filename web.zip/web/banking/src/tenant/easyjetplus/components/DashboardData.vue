<template>
  <div>
    <v-overlay
      v-if="showOverlayLoader || isLoading"
      v-bind="overlayConfig"
      class="overlay"
    >
      <v-progress-circular
        indeterminate
        size="64"
        color="primary"
      ></v-progress-circular>
    </v-overlay>
    <slot v-else />
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import { BaseStateInterface } from "@/types/store.types";
import { Action, namespace } from "vuex-class";

const membershipModule = namespace("summaryModule");
const userModule = namespace("userModule");

@Component({})
export default class DashboardData extends Vue {
  isLoading = true;

  @membershipModule.State
  private memberships!: BaseStateInterface;

  @userModule.State
  private userDetails!: BaseStateInterface;

  @Action("membershipModule/GET_MEMBERSHIPS")
  getMemberships!: () => string;

  @Action("userModule/GET_USER_DETAILS")
  getUserDetails!: () => number;

  // created() {
  //   this.$EventBus.$on("changeAccount", this.updateSelectedAccountId);
  // }

  get overlayConfig(): {
    value: boolean;
    zIndex: number;
    color: string;
    opacity: number;
  } {
    return {
      value: this.showOverlayLoader,
      zIndex: 10000,
      color: "primary",
      opacity: 0,
    };
  }

  get membershipsLoading(): boolean {
    return this.memberships?.loading;
  }

  get userDetailsLoading(): boolean {
    return this.userDetails?.loading;
  }

  get showOverlayLoader(): boolean {
    return (
      (this.membershipsLoading || this.userDetailsLoading) &&
      this.isLoading == false
    );
  }

  async created(): Promise<void> {
    try {
      await Promise.all([this.getMemberships(), this.getUserDetails()]);
      this.isLoading = false;
    } catch (e) {
      console.log(e);
    }
  }
}
</script>

<style lang="scss" scoped>
.overlay {
  background-color: white;
}
</style>
