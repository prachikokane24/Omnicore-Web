<script lang="ts">
import { Component, Vue, Watch } from "vue-property-decorator";
import { namespace } from "vuex-class";
import { MembershipItem } from "@/tenant/easyjetplus/types/common.types";

const membershipModule = namespace("membershipModule");

@Component({})
export default class MembershipData extends Vue {
  @membershipModule.State
  private selectedMembershipCard!: MembershipItem;

  @Watch("selectedMembershipCard")
  onMembershipCardChange(): void {
    this.emit();
  }
  render(): void {
    return this.$scopedSlots.default!({}) as any;
  }
  created() {
    this.emit();
  }
  emit() {
    this.$emit("change", this.selectedMembershipCard.membershipId);
  }
}
</script>
