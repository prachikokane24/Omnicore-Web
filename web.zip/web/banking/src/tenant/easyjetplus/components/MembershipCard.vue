<template>
  <div class="card" @click="$emit('cardClick')">
    <img
      :data-index="dataIndex"
      :class="{
        current: isCurrent,
        onLeft: leftIndex >= 0,
        onRight: rightIndex >= 0,
      }"
      :src="src"
      :width="size.width"
      :height="size.height"
      class="card__image"
    />
    <img :src="qr" alt="QR code" class="card__qr" />
    <div class="card__text">
      <OText size="sm" color="white" bold>{{
        $t("membership.membershipId")
      }}</OText>
      <OText size="lg" color="white" bold>{{ membershipId }}</OText>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop } from "vue-property-decorator";

@Component({
  components: {
    OText: () => import("@/components/lib/OText.vue"),
  },
})
export default class MembershipCard extends Vue {
  @Prop() dataIndex!: number;
  @Prop() isCurrent!: number;
  @Prop() leftIndex!: number;
  @Prop() rightIndex!: number;
  @Prop() membershipId!: number | string;
  @Prop() src!: string;
  @Prop() qr!: string;

  get size(): { width: number; height: number } {
    return {
      width: this.$vuetify.breakpoint.xs ? 250 : 300,
      height: this.$vuetify.breakpoint.xs ? 150 : 180,
    };
  }
}
</script>

<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";

.card {
  position: relative;
  &__title {
    color: white;
    position: absolute;
    bottom: 50px;
    width: 100%;
    padding: 10px;
    text-align: center;
    z-index: 100;
  }
  &__image {
    display: block;
  }
  &__icon {
    width: 100%;
    max-width: 70px;
  }
  &__text {
    color: white;
    position: absolute;
    left: 20px;
    bottom: 20px;
  }
  &__qr {
    background: white;
    width: auto;
    position: absolute;
    top: 15px;
    right: 15px;
    border-radius: 5px;
    width: 80px;
    height: 80px;
    @media #{map-get($display-breakpoints, 'sm-and-up')} {
      width: 100px;
      height: 100px;
    }
  }
}
</style>
