<template>
  <OInfoCard title="Card Details"> </OInfoCard>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

interface AnyObject {
  [key: string]: any;
}

@Component({
  components: {
    OInfoCard: () => import("@/components/lib/OInfoCard.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OIcon: () => import("@/components/lib/OIcon.vue"),
    OButton: () => import("@/components/lib/OButton.vue"),
  },
})
export default class PersonalDetails extends Vue {
  formItems: AnyObject = {};
}
</script>

<style lang="scss" scoped></style>
