<template>
  <OTabsVertical
    v-model="selectedTab"
    title="Select View"
    icon="pointerRight"
    :items="items"
    @change="handleChange"
  >
    <template v-slot:default>
      <component :is="selectedTab" />
    </template>
  </OTabsVertical>
</template>
<script lang="ts">
import { Vue, Component } from "vue-property-decorator";
@Component({
  components: {
    OTabsVertical: () => import("@/components/lib/OTabsVertical.vue"),
    // PersonalDetails: () =>
    //   import("@tenantComponents/TabSections/More/PersonalDetailsMariusz.vue"),
    CardDetails: () =>
      import("@tenantComponents/TabSections/More/CardDetails.vue"),
    UpdatePassword: () =>
      import("@tenantComponents/TabSections/More/UpdatePassword.vue"),
  },
})
export default class More extends Vue {
  selectedTab = "PersonalDetails";
  items = [
    // {
    //   name: "Personal Details",
    //   cmp: "PersonalDetails",
    // },
    {
      name: "Card Details",
      cmp: "CardDetails",
    },
    {
      name: "Update Password",
      cmp: "UpdatePassword",
    },
  ];
  handleChange(selectedTab: {
    type: string;
    value: string;
    tabName: string;
  }): void {
    this.selectedTab = selectedTab.value;
  }
}
</script>
