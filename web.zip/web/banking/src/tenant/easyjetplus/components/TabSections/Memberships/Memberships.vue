<template>
  <div>
    <ODataTablePaginatorAsync
      :page-count="pageCount"
      :page-index="pageParams.pageNumber"
      :disabled="memberships.loading"
      @change="handlePageChange"
    >
      <ODataTable
        v-bind="tableConfig"
        @cellClick="handleCellClick"
        @rowClick="handleRowClick"
        @rowCheckboxClick="handleRowCheckboxClick"
        :loading="memberships.loading"
        class="memberships"
      >
        <!-- <template #filter>
          <OFilter @change="handleFilterChange" :filterConfig="filterConfig" />
        </template> -->
        <template v-slot:purchaseDate="{ cell }">
          {{ cell | date("forwardslash") }}
        </template>
        <template v-slot:expiryDate="{ cell }">
          {{ cell | date("forwardslash") }}
        </template>
        <template v-slot:membershipType="{ cell }">
          {{ cell | membershipType(cell) }}
        </template>
        <template v-slot:status="{ cell }">
          {{ cell | capsFirstLetter }}
        </template>
        <template v-slot:virtualCard="{ cell }">
          {{
            cell
              ? $t("memberships.rows.virtualCardYes")
              : $t("memberships.rows.virtualCardNo")
          }}
        </template>
        <template v-slot:autoRenewal>
          <OFormSwitch hide-details dense no-margin name="test" />
        </template>
        <!-- <template v-slot:autoRenewal="{ cell }">
          {{
            cell
              ? $t("memberships.rows.autoRenewYes")
              : $t("memberships.rows.autoRenewNo")
          }}
        </template> -->
        <!--
        <template v-slot:payee="{ cell }">
          <OText medium>
            {{ cell }}
          </OText>
        </template>
        <template v-slot:amount="{ cell }">
          <OText medium>
            {{ cell | currency }}
          </OText>
        </template> -->
        <!-- <template v-slot:action="{ row }">
          <OButton @click="handleCancel(row)" outlined x-small>
            {{ $t("standingorders.cancelBtn") }}
          </OButton>
        </template> -->
      </ODataTable>
    </ODataTablePaginatorAsync>
    <!-- <ModalCancelStandingOrder
      id="cancelStandingOrder"
      :loading="userDeleteStandingOrder.loading"
      :error="userDeleteStandingOrder.error"
      @confirm="handleConfirm"
      :cancelText="$t('standingorders.cancelBtnModal')"
    />
    <OModalConfirm
      id="cancelStandingOrderConfirmed"
      :message="$t('standingorders.cancelMessage')"
    /> -->
    <div class="actions">
      <div class="actions--col1">
        <OButton large outlined>Add a new member</OButton>
      </div>
      <div class="actions--col2">
        <OText size="md" bold
          >Cost of Selected Renewal:
          <span class="actions__cost">{{ reduceTotalCost | currency }}</span>
        </OText>
        <OAlign align-sm="start" align-md="end">
          <OButton class="mt-5" large>Renew now</OButton>
        </OAlign>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import "@tenant/filters";
import { Component, Vue } from "vue-property-decorator";
import { BaseStateInterface } from "@/types/store.types";
import { Action, namespace } from "vuex-class";
import OButton from "@/components/lib/OButton.vue";
const membershipModule = namespace("membershipModule");

interface FormConfig {
  autoRenewal: {
    name: string;
    rules?: string;
  };
}

interface TableConfig {
  heading: any;
  headers: {
    text: any;
    key: string;
  }[];
  items: string[];
}

@Component({
  components: {
    ODataTable: () => import("@/components/lib/DataTable/ODataTable.vue"),
    ODataTablePaginatorAsync: () =>
      import("@/components/lib/DataTable/ODataTablePaginatorAsync.vue"),
    OText: () => import("@/components/lib/OText.vue"),
    OAlign: () => import("@/components/lib/OAlign.vue"),
    //OFilter: () => import("@/components/lib/OFilter.vue"),
    OIcon: () => import("@/components/lib/OIcon.vue"),
    OFormSelect: () => import("@/components/lib/Form/OFormSelect.vue"),
    OFormSwitch: () => import("@/components/lib/Form/OFormSwitch.vue"),
    // OModalConfirm: () => import("@/components/lib/Modal/OModalConfirm.vue"),
    // ModalCancelStandingOrder: () =>
    //   import("./Modals/ModalCancelStandingOrder.vue"),
    OButton,
  },
})
export default class Memberships extends Vue {
  //filterItems: any = {};
  pageParams = {
    pageNumber: 0,
    pageSize: 5,
  };
  membershipsSelected = [];
  headers = [
    {
      text: this.$t("memberships.columns.memberName"),
      key: "fullName",
    },
    {
      text: this.$t("memberships.columns.membershipType"),
      key: "membershipType",
    },
    {
      text: this.$t("memberships.columns.purchaseDate"),
      key: "purchaseDate",
    },
    {
      text: this.$t("memberships.columns.expiryDate"),
      key: "expiryDate",
    },
    {
      text: this.$t("memberships.columns.status"),
      key: "status",
    },
    {
      text: this.$t("memberships.columns.virtualCard"),
      key: "virtualCard",
    },
    {
      text: this.$t("memberships.columns.autoRenewal"),
      key: "autoRenewal",
    },
  ];

  // mapState
  @membershipModule.State
  public memberships!: BaseStateInterface;

  // mapActions
  @Action("membershipModule/GET_MEMBERSHIPS")
  getMemberships!: (payload) => string;

  // get filterConfig() {
  //   return [
  //     {
  //       name: "wallet",
  //       type: "select",
  //       label: "From",
  //       preSelected: "all",
  //       items: [
  //         {
  //           id: 1,
  //           label: "All Wallets",
  //           value: "all",
  //         },
  //         {
  //           id: 2,
  //           label: "Wallet 1",
  //           value: 1,
  //         },
  //         {
  //           id: 3,
  //           label: "Wallet 2",
  //           value: 2,
  //         },
  //       ],
  //     },
  //   ];
  // }

  get reduceTotalCost() {
    return this.membershipsSelected.reduce(
      (prevVal, item: any) => prevVal + item.membershipCost,
      0
    );
  }

  get mapMemberships() {
    return this.memberships?.data?.memberships.map((item) => {
      // TODO ...do a check on membershipType to get it's cost, or ask BE to include it in the payload
      item.membershipCost = 50;
      return item;
    });
  }

  get formConfig(): FormConfig {
    return {
      autoRenewal: {
        name: "loginId",
        rules: "required",
      },
    };
  }

  get tableConfig() {
    return {
      heading: this.$t("memberships.heading"),
      headers: this.headers,
      items: this.mapMemberships,
      checkboxes: true,
    };
  }

  get pageCount(): number {
    const itemCount: number = this.memberships?.data?.totalCount || 0;
    const { pageSize } = this.pageParams;
    return Math.ceil(itemCount / pageSize);
  }

  get mappedQueryParams(): {
    pageSize: number;
    pageNumber: number;
  } {
    return {
      pageSize: this.pageParams.pageSize,
      pageNumber: this.pageParams.pageNumber,
    };
  }

  created(): void {
    this.getMemberships(this.mappedQueryParams);
  }

  // handleCancel({ id: number }): void {
  //   this.$modal.show("cancelStandingOrder");
  // }

  // async handleConfirm(id: number): Promise<void> {
  //   try {
  //     await this.deleteUserStandingOrder(id);
  //     this.$modal.hide("cancelStandingOrder");
  //     this.$modal.show("cancelStandingOrderConfirmed");
  //   } catch (e) {
  //     throw new Error(e);
  //   }
  // }

  handlePageChange(val: number): void {
    this.pageParams.pageNumber = val;
    this.getMemberships(this.mappedQueryParams);
  }

  // handleFilterChange(val: any): void {
  //   this.pageParams.walletType = val?.walletType?.value;
  //   this.getMemberships(this.mappedQueryParams);
  // }

  handleCellClick(val: unknown): void {
    //console.log("cell", val); // eslint-disable-line
  }

  handleRowClick(val: unknown): void {
    // console.log("row", val); // eslint-disable-line
  }

  handleRowCheckboxClick(val): void {
    // this.$set(this.membershipsSelected, val);
    this.membershipsSelected = val || [];
  }
}
</script>
<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";
.actions {
  display: flex;
  flex-direction: column;
  padding: 15px;
  @media #{map-get($display-breakpoints, 'md-and-up')} {
    padding: 30px;
    flex-direction: row;
  }
  &__cost {
    font-size: 22px;
    color: var(--v-primary-base);
  }
  &--col1 {
    order: 1;
    margin-top: 20px;
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      margin-top: 0;
      order: 0;
      flex: 1;
    }
  }
  &--col2 {
    order: 0;
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      order: 1;
    }
  }
}
.memberships {
  background-color: white;
}
</style>
