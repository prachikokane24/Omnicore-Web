<template>
  <component :is="layout"> Benefits </component>
</template>
<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

@Component({})
export default class Home extends Vue {}
</script>
<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";
</style>
