<template>
  <component :is="layout">
    <h1>Marketing Home Page</h1>
  </component>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped></style>
