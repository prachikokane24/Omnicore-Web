<template>
  <component :is="layout">
    <DashboardData>
      <div class="membership-wrapper">
        <div class="membership-wrapper--col1"><MembershipCardCarousel /></div>
        <div class="membership-wrapper--col2">
          <AccountDetails />
        </div>
      </div>
      <OTabs :items="items">
        <template v-slot:default="{ cmp, componentKey }">
          <component v-bind:is="cmp" :key="componentKey" />
        </template>
      </OTabs>
    </DashboardData>
  </component>
</template>
<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

@Component({
  components: {
    OTabs: () => import("@/components/lib/OTabs.vue"),
    DashboardData: () => import("@tenantComponents/DashboardData.vue"),
    AccountDetails: () => import("@tenantComponents/AccountDetails.vue"),
    Memberships: () =>
      import("@tenantComponents/TabSections/Memberships/Memberships.vue"),
    MembershipCardCarousel: () =>
      import("@tenantComponents/MembershipCardCarousel.vue"),
    More: () => import("@tenantComponents/TabSections/More/Index.vue"),
  },
})
export default class Home extends Vue {
  private items: any[] = [
    { name: "Memberships", cmp: "Memberships" },
    { name: "More...", cmp: "More" },
  ];
}
</script>
<style lang="scss" scoped>
@import "~vuetify/src/styles/settings/_variables";
.membership-wrapper {
  display: flex;
  flex-direction: column;
  margin: 0 -20px;
  margin-bottom: 20px;
  @media #{map-get($display-breakpoints, 'md-and-up')} {
    flex-direction: row;
  }
  &--col1 {
    flex: 1;
    padding: 0 20px;
    box-sizing: border-box;
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      margin-top: 12px;
    }
  }
  &--col2 {
    flex: 1;
    width: 100%;

    align-self: center;
    padding: 0 20px;
    box-sizing: border-box;
    @media #{map-get($display-breakpoints, 'md-and-up')} {
      min-width: 570px;
    }
  }
}
</style>
