import Vue from "vue";
import i18n from "@/plugins/i18n";
import moment from "moment";

Vue.filter("currency", (value) => {
  if (typeof value === "undefined" || value === null) return value;
  value = parseFloat(value / 100); // val must be in cents/pence
  return i18n.n(value, "currency");
});

Vue.filter("currencyFloat", (value) => {
  if (typeof value === "undefined" || value === null) return value;
  value = parseFloat(value / 100); // val must be in cents/pence
  return value;
});

Vue.filter("date", (value, format = null) => {
  if (!value) return value;
  switch (format) {
    case "long":
      format = "Do MMMM YYYY";
      break;
    case "shortmonth":
      format = "Do MMM YYYY";
      break;
    case "longtime":
      format = "HH:mm, Do MMMM YYYY";
      break;
    case "forwardslash":
      format = "DD/MM/YYYY";
      break;
    default:
      format = "Do MMM YY";
  }
  return moment(value).format(format);
});

Vue.filter("capsFirstLetter", (value) => {
  if (!value) return value;
  return value.charAt(0).toUpperCase() + value.slice(1);
});

Vue.filter("titleCase", (value) => {
  if (!value) return value;
  return value.replace(/\b[a-z]/g, (x) => x.toUpperCase());
});

Vue.filter("truncate", function (text, stop, clamp) {
  return text.slice(0, stop) + (stop < text.length ? clamp || "..." : "");
});

Vue.filter("uppercase", function (text, stop, clamp) {
  return text.toUpperCase();
});

var postcodeMatch = /.{1,2}/g;

Vue.filter("formattedBankDetails", (value) => {
  if(!value) return value;
  var parts = value.split(" ");
  var sortcode = (String(parts[1]).match(postcodeMatch) || []).join('-');
  return sortcode + " " + parts[0]; 
});

Vue.filter("formattedSortCode", (value) => {
  if(!value) return value;
  var result = (String(value).match(postcodeMatch) || []).join('-');
  return result;
});
