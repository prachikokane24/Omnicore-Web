import Vue from "vue";

export default {
  install(Vue, options) {
    const methods = () => {
      return {
        show: (id) => {
          Vue.prototype.$EventBus.$emit("modal:show", id);
        },
        hide: (id) => {
          Vue.prototype.$EventBus.$emit("modal:hide", id);
        },
      };
    };
    Vue.$modal = Vue.prototype.$modal = methods();
  },
};
