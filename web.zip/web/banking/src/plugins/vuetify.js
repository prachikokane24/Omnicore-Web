import Vue from "vue";
import colors from "@tenantStyles/colors.js";
import Vuetify from "vuetify/lib/framework";
import minifyTheme from "minify-css-string";

Vue.use(Vuetify);

export default new Vuetify({
  theme: {
    options: {
      customProperties: true,
      minifyTheme,
      // themeCache: {
      //   get: (key) => localStorage.getItem(key),
      //   set: (key, value) => localStorage.setItem(key, value),
      // },
    },
    themes: {
      light: {
        primary: colors.light.primary,
        secondary: colors.light.secondary,
        supporting: colors.light.supporting,
        supportinggrey: colors.light.supportinggrey,
        accent: colors.light.accent,
        error: colors.light.error,
        warning: colors.light.warning,
        info: colors.light.info,
        success: colors.light.success,
        monotone1: colors.light.monotone1,
        monotone2: colors.light.monotone2,
        text: colors.light.text,
        border: colors.light.border,
        borderdark: colors.light.borderdark,
        background: colors.light.background,
        primaryloader: colors.light.primaryloader,
        loginbackground: colors.light.loginbackground,
        logintext: colors.light.logintext,
        tablerow: colors.light.tablerow,
        primarybutton: colors.light.primarybutton,
        secondarybutton: colors.light.secondarybutton,
        primarybuttontext: colors.light.primarybuttontext,
        secondarybuttontext: colors.light.secondarybuttontext,
        carouseltext: colors.light.carouseltext,
      },
      dark: {
        primary: colors.dark.primary,
        secondary: colors.dark.secondary,
        supporting: colors.light.supporting,
        supportinggrey: colors.light.supportinggrey,
        accent: colors.dark.accent,
        error: colors.dark.error,
        warning: colors.dark.warning,
        info: colors.dark.info,
        success: colors.dark.success,
        monotone1: colors.dark.monotone1,
        monotone2: colors.dark.monotone2,
        text: colors.dark.text,
        border: colors.dark.border,
        borderdark: colors.light.borderdark,
        background: colors.dark.background,
        primaryloader: colors.dark.primaryloader,
        loginbackground: colors.light.loginbackground,
        logintext: colors.light.logintext,
      },
    },
  },
});
