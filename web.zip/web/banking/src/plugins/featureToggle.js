import toggles from "@/feature/toggles.json";
import tenantToggles from "@tenant/feature/toggles.json";

export default {
  install(Vue, options) {
    Vue.directive("feature", {
      inserted(el, { arg, value }, vnode) {
        const featureToggles = { ...toggles, ...tenantToggles };
        const val = arg || value;
        const hide = !featureToggles[val] || false;
        if (hide) {
          vnode.elm.parentElement.removeChild(vnode.elm);
        }
      },
    });
  },
};
