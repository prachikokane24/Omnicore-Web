export default {
  "en-GB": {
    currency: {
      style: "currency",
      currency: "GBP",
      currencyDisplay: "symbol",
    },
  },
  "en-US": {
    currency: {
      style: "currency",
      currency: "USD",
      currencyDisplay: "symbol",
    },
  },
};
