import Vue from "vue";
const blankLayout = () => import("@/layouts/blank.vue");
Vue.component("blank-layout", blankLayout);

export default {
  computed: {
    layout() {
      return this.$route.meta.layout || "blank-layout";
    },
  },
};
