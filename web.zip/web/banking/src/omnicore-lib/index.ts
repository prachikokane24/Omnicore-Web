import {HttpClientFactory} from "@/omnicore-lib/src/services/http/HttpClientFactory";
import {LocalCache} from "@/omnicore-lib/src/services/cache/LocalCache";
import {RuntimeConfig} from "@/omnicore-lib/src/config/runtimeConfig";
import {LocalCacheProvider} from "@/omnicore-lib/src/services/cache/LocalCacheProvider";
import {I18NBridge} from "@/omnicore-lib/src/services/i8n/i18n";

export interface Omnicore
{
    httpFactory: HttpClientFactory;
    localCache: LocalCache;
    i18Bridge: I18NBridge;
}

export class OmnicoreImpl implements Omnicore
{
    private static singleton: OmnicoreImpl;
    public static buildOmnicoreImpl(httpFactory: HttpClientFactory, localCache: LocalCache, i18Bridge: I18NBridge) {
        this.singleton = new OmnicoreImpl(httpFactory, localCache, i18Bridge);
    }

    public static getInstance() {
        if (!this.singleton) {
            throw Error("Omnicore has not been built.  Call buildOmnicore");
        }
        return this.singleton;
    }

    private constructor(public httpFactory: HttpClientFactory, public localCache: LocalCache, public i18Bridge: I18NBridge) {
    }
}

/// This is the single composition point for the whole of omnicore
export function buildOmnicore(runtimeConfig: RuntimeConfig, i18Bridge: I18NBridge): Omnicore {
    const localCache = new LocalCacheProvider(runtimeConfig.localCache);
    const httpFactory = new HttpClientFactory(runtimeConfig.http, localCache);
    OmnicoreImpl.buildOmnicoreImpl(httpFactory, localCache, i18Bridge);
    return OmnicoreImpl.getInstance();
}

function ProcessParameter(key: string, value?: string)
{
    return value !== null
        ? key + "=" + value
        : key;    
}

export function loadScript(scriptPath: string, scriptParent: string, parameters?: Map<string,string>, attributes?: Map<string,string>)
{
    const script = document.createElement('script');
    script.async = true;
    let appendPath = "";
    if(parameters !== undefined)
    {
        let cnt = 0;
        for (const [key, value] of parameters) {
            const parameterToAppend = ProcessParameter(key, value);
            appendPath = cnt == 0 
            ? appendPath + '?' + parameterToAppend
            : appendPath + '&' + parameterToAppend;
            cnt++;
        }       
    }
    script.src = scriptPath + appendPath;
    if(attributes !== undefined)
    {
        for (const [key, value] of attributes)
        script.setAttribute(key, value);
    }
    if(scriptParent==='head')
    {document.head.appendChild(script); }
    
    if(scriptParent==='body')
    {document.body.appendChild(script); }
    
}

export async function loadGoogleAnalytics(){
    const parameters = new Map<string,string>([[process.env.VUE_APP_GOOGLE_ID,""]]);
    loadScript('https://www.googletagmanager.com/gtag/js','head', parameters );

    const attributes = new Map<string, string>([["gtag", process.env.VUE_APP_GOOGLE_ID]]);
    loadScript('ga.js','head',undefined, attributes);
  }

export async function loadCookieBot(){
    const attributes = new Map<string, string>([
        ["id", "Cookiebot"],
        ["data-cbid", process.env.VUE_APP_COOKIE_BOT_ID],
        ["data-blockingmode","auto"]
    ]);
    loadScript('https://consent.cookiebot.com/uc.js','head',undefined,attributes);    
}

export const omnicore = () => OmnicoreImpl.getInstance();
//export const omnicoreSymbol = Symbol('omnicore');
