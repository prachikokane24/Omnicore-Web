import {HttpClientConfig} from "../services/http/HttpClientConfig";
import {LocalCacheConfig} from "../services/cache/LocalCacheConfig";

export interface RuntimeConfig {
    http: HttpClientConfig;
    localCache: LocalCacheConfig;
}
