

//  This defines the interface that the actual i18n implementation needs to support to bridge over
export interface I18NBridge
{
    setLocale(local: string): void;
}

export interface I18n
{
    setI18NBridge(bridge: I18NBridge): void;
    setLocale(local: string): void;
}

export class I18NImpl implements I18n
{
    private _bridge!: I18NBridge;

    public setI18NBridge(bridge: I18NBridge): void {
        this._bridge = bridge;
    }

    public setLocale(locale: string): void {
        this._bridge.setLocale(locale);
    }

}
