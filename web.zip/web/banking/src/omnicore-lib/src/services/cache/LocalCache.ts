
import {LocalCacheProvider} from "./LocalCacheProvider";
import {LocalCacheConfig} from "./LocalCacheConfig";


/**
 * Interface for LocalCaching - no "I" prefix to the interfaces, not the done thing in typescript appaprently
 */
export interface LocalCache {
    hasKey(key: string): boolean;
    put<T>(key: string, data: T, ttlSeconds: number): void;
    flush(key: string): void;
    flushAll(): void;
    get<T>(key: string): T;
}

/**
 * Factory method to build a LocalCache implementation supplying it the runtime config
 * @param cacheConfig
 */
export default function makeLocalCache(cacheConfig: LocalCacheConfig) {
    return new LocalCacheProvider(cacheConfig);
}
