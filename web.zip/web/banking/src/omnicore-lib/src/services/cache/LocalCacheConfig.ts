/**
 * Here as a placeholder
 */
export class LocalCacheConfig
{

}
