import { Token, TokensContext } from "./http/TenantTokenBasedService";
import router from "../../../router/index";

export class AuthenticationExpirationChecker {
    public static readonly instance: AuthenticationExpirationChecker = new AuthenticationExpirationChecker();

    _authenticationExpirationCheckTimer: any;

    public initialise(token: Token) {
        if (token) {
            if (this._authenticationExpirationCheckTimer) {
                clearInterval(this._authenticationExpirationCheckTimer);
            }
            this._authenticationExpirationCheckTimer = setInterval(() => {
                if (new Date(token.expires!) < new Date()) {
                    console.log('Authentication token expired');
                    clearInterval(this._authenticationExpirationCheckTimer);
                    TokensContext.instance.clearTokens();
                    router().push({ name: "SessionExpired" });
                }
            }, 30000);
        }
    }
}