import { AuthenticationExpirationChecker } from "../AuthenticationExpirationChecker";

export class Token {
  token?: string;
  expires?: string;
}

export class TokenPair {
  accessToken?: Token;
  refreshToken?: Token;
}

export class TokensContext {
  public static readonly instance: TokensContext = new TokensContext();

  private _accessToken: Token | null = null;
  private _refreshToken: Token | null = null;
  private _isTenantToken = false;

  constructor() {
    this.clearTokens()
  }

  public clearTokens(): void {
    this._accessToken = null;
    this._refreshToken = null;
    this._isTenantToken = false;
  }

  public setTenantToken(accessToken: Token | null, refreshToken: Token | null): void {
    this._accessToken = accessToken;
    this._refreshToken = refreshToken;
    this._isTenantToken = true;
  }

  public setUserToken(accessToken: Token | null, refreshToken: Token | null): void {
    this._accessToken = accessToken;
    this._refreshToken = refreshToken;
    this._isTenantToken = false;
    if (accessToken !== null) {
      AuthenticationExpirationChecker.instance.initialise(accessToken);
    }
  }

  public accessToken(): Token | null {
    return this._accessToken;
  };

  public refreshToken(): Token | null {
    return this._refreshToken;
  };

  public areTokensSet(): boolean {
    return !(this._refreshToken == null || this._refreshToken == undefined || this._accessToken == null || this._accessToken == undefined)
  };

  public get isTenantToken(): boolean {
    return this._isTenantToken;
  };

}

export function TokenRequestTransformer(request) {
  request.headers = request.headers === undefined ? {} : request.headers;
  if (TokensContext.instance.areTokensSet()) {
    request.headers["Authorization"] = `bearer ${ TokensContext.instance?.accessToken()?.token }`;
  }
  return request;
}