export interface HttpResponse<T = any>  {
    data: T;
    status: number;
    headers: any;
    request?: any;
    statusText?: string;
    cacheTTL?: number;
    fromCache: boolean;
}
