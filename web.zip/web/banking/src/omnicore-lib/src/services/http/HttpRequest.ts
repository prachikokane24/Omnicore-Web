import { Dictionary } from "vue-router/types/router";

export type HttpMethod =
    | 'get' | 'GET'
    | 'delete' | 'DELETE'
    | 'head' | 'HEAD'
    | 'options' | 'OPTIONS'
    | 'post' | 'POST'
    | 'put' | 'PUT'
    | 'patch' | 'PATCH'
    | 'purge' | 'PURGE'
    | 'link' | 'LINK'
    | 'unlink' | 'UNLINK'

export type HttpResponseType =
    | 'arraybuffer'
    | 'blob'
    | 'document'
    | 'json'
    | 'text'
    | 'stream'

export interface HttpRequestSpec<T = any> {
    cacheKey?: string;
    forceRefresh?: boolean;
    url?: string;
    method?: HttpMethod;
    baseURL?: string;
    headers?: any;
    params?: any;
    data?: T;
    timeoutSeconds?: number;
    withCredentials?: boolean;
    maxContentLength?: number;
    httpAgent?: any;
    httpsAgent?: any;
}

export class HttpRequest<T> implements HttpRequestSpec<T>
{
    public cacheKey?: string;
    public forceRefresh?: boolean;
    public url?: string;
    public method?: HttpMethod;
    public baseURL?: string;
    public headers?: any;
    public params?: any;
    public data?: T;
    public timeoutSeconds?: number;
    public withCredentials?: boolean;
    public maxContentLength?: number;
    public httpAgent?: any;
    public httpsAgent?: any;
}


