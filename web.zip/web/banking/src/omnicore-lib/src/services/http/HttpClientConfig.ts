export class HttpClientConfig {
    /// baseURL is the baseURL path of the server API for example https://myserver.omnio.global
    public baseURL = ""

    /// default http timeout in milli-seconds
    public timeout = 2500

    /// authToken to be used by this configuration
    public authToken = ""

    /// the name of the http header into which the authToken is going to be placed
    public authTokenName = ""

    public cacheTTLSeconds = 0;

}
