export interface StandingOrderPayload {
  id: number;
  startDate: string;
  nextDate: string;
  endDate: string;
  recipientId: string;
  recipientName: string;
  paymentNote: string;
  fromWalletId;
  fromWalletName: string;
  amount: {
    currency: string;
    minorUnits: number;
    majorUnits: string;
    Scale: number;
  };
  frequency: string;
  account: {
    accountId: string;
    accountHolders: [
      {
        name: string;
        isPrimary: boolean;
      }
    ];
    sortCode: string;
    accountNumber: string;
  };
}

export interface ScheduledTransferPayload {
  id: number;
  startDate: string;
  nextDate: string;
  endDate: string;
  toWalletId: string;
  toWalletName: string;
  fromWalletId: string;
  fromWalletName: string;
  paymentNote: string;
  amount: {
    currency: string;
    minorUnits: number;
    majorUnits: string;
    Scale: number;
  };
  frequency: string;
}

export interface DirectDebitPayload {
  id;
  payeeName;
  fromAccount;
  lastPaidDate;
  amount;
  reference;
  status;
}

export interface DirectDebitModal {
  loading: boolean;
  cancelText: string | any;
  directDebit: null | DirectDebitPayload;
}

export interface StandingOrderModal {
  loading: boolean;
  cancelText: string | any;
  standingOrder: null | StandingOrderPayload;
  isEdit: boolean;
}

export interface ScheduledTransferModal {
  loading: boolean;
  cancelText: string | any;
  scheduledTransfer: null | ScheduledTransferPayload;
  isEdit: boolean;
}

export interface UpdatePasswordPayloadInterface {
  password;
}

export interface Fee {
  feeGroupID: number;
  feeGroupName: string;
  feeAmount: number;
}
