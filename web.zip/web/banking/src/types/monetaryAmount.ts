import i18n from "@/plugins/i18n";

const scaleLookup = {
  BIF: 0,
  CLP: 0,
  DJF: 0,
  GNF: 0,
  ISK: 0,
  JPY: 0,
  KMF: 0,
  KRW: 0,
  PYG: 0,
  RWF: 0,
  UGX: 0,
  UYI: 0,
  VND: 0,
  VUV: 0,
  XAF: 0,
  XOF: 0,
  XPF: 0,
  BHD: 3,
  IQD: 3,
  JOD: 3,
  KWD: 3,
  LYD: 3,
  OMR: 3,
  TND: 3,
  CLF: 4,
  UYW: 4,
};

export function createDefaultMonetaryAmount(): MonetaryAmount {
  const currency = i18n.numberFormats[i18n.locale].currency.currency || "";
  const scale = scaleLookup[currency] || 2;
  const majorUnits = scale == 0 ? "0" : "0." + "00000".substring(0, scale);
  return {
    currency,
    scale,
    majorUnits,
    minorUnits: 0,
  };
}

export function parseMonetaryAmount(
  majorUnits: string,
  currency: string,
  scale: number
): MonetaryAmount {
  const minorUnits = Math.floor(parseFloat(majorUnits) * Math.pow(10, scale));
  return {
    currency,
    scale,
    minorUnits,
    majorUnits,
  };
}

export default interface MonetaryAmount {
  currency: string;
  minorUnits: number;
  scale: number;
  majorUnits: string;
}
