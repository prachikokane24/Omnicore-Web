import MonetaryAmount from "./monetaryAmount";

export interface BaseStateInterface {
  data: null | string | any;
  loading: boolean;
  errorMessage: string | null;
  errorStatus: string | null;
}

export interface StoreRequestPropsInterface {
  client: string;
  action(): Promise<unknown>;
  method: string;
  url: string;
  payload: unknown;
  headers: unknown;
  config: unknown;
  params: unknown;
  responseType: string;
  mutation: string;
  errorMessage: string;
  keepData: boolean;
  loading: boolean;
  isLoginRequest: boolean;
  delay: number;
}

export interface StorePromiseInterface {
  client: string;
  action(): Promise<unknown>;
  method: string;
  url: string;
  payload: unknown;
  headers: unknown;
  config: unknown;
  params: unknown;
  responseType: string;
  mutation: string;
  errorMessage: string;
  keepData: boolean;
  loading: boolean;
  delay: number;
}

export interface ActionPayload {
  id: number;
}

export interface PaginationInterface {
  data: {
    results?: Array<any>;
    totalCount?: number;
  };
  loading: boolean;
  errorMessage: string | null;
  errorStatus: string | null;
}

export interface PersonalDetailsPayloadInterface {
  title?: string;
  personId?: number;
  email: string;
  name?: string;
  dob?: string;
  homePhone?: number;
  mobilePhone: number;
  address?: {
    line1: string;
    line2: string;
    line3: string;
    postalCode: string;
    country: string;
  };
  company?: string;
  passwordForVerification?: string;
  validateOnly? : boolean;
}

export interface PasswordPayloadInterface {
  oldPassword: string;
  newPassword: string;
  validateOnly?: boolean;
}

export interface TransactionPayloadInterface {
  limit?: number;
  offset?: number;
  rangeMonths?: number;
}

export interface StandingOrderPayloadInterface {
  limit?: number;
  offset?: number;
  rangeMonths?: number;
}

export interface StandingOrderCreatePayloadInterface {
  id?: string;
  fromWalletId?: string;
  recipientId: string;
  amount: {
    MinorUnits: number;
    Currency: string;
  };
  frequency: string;
  startDate: string;
  paymentNote: string;
}

export interface InstantPaymentCreatePayloadInterface {
  fromWalletId?: string;
  recipientId: string;
  amount: {
    MinorUnits: number;
    Currency: string;
  };
  paymentNote: string;
}

export interface InstantTransferCreatePayloadInterface {
  fromWalletId?: string;
  toWalletId: string;
  amount: {
    MinorUnits: number;
    Currency: string;
  };
  paymentNote: string;
}

export interface DirectDebitPayloadInterface {
  limit?: number;
  offset?: number;
  rangeMonths?: number;
}

export interface DirectDebitCreatePayloadInterface {
  fromWalletId?: string;
  recipientId: string;
  amount: {
    MinorUnits: number;
    Currency: string;
  };
  frequency: string;
  startDate: string;
  paymentNote: string;
}

export interface ScheduledTransferPayloadInterface {
  limit?: number;
  offset?: number;
  rangeMonths?: number;
}

export interface ScheduledTransferCreatedPayloadInterface {
  id?: string;
  fromWalletId?: string;
  toWalletId: string;
  amount: {
    MinorUnits: number;
    Currency: string;
  };
  frequency: string;
  startDate: string;
  paymentNote: string;
}

export interface UpdateWalletPayloadInterface {
  id: string;
  nickName: string;
  savingsTargetDate: string;
  savingsTargetAmount: MonetaryAmount;
  colourRef: string;
  iconRef: string;
}

export interface CreateWalletPayloadInterface {
  walletType: string;
  currencyCode: string;
  nickName: string;
  savingsTargetDate: string;
  savingsTargetAmount: MonetaryAmount;
  colourRef: string;
  iconRef: string;
}

export interface QueryParamInterface {
  limit?: number;
  offset?: number;
}

export interface AddPayeePayload {
  limit?: number;
  offset?: number;
}

export interface MarketingPreferencesUpdatePayload {
  offersUs: boolean;
  offersOthers: boolean;
}

export interface CustomerPersonalDetailsUpdateInterface {
  email: number;
  phoneNumber: string;
  address?: string;
}

export interface VerifyOtpPayloadInterface {
  sessionId?: string;
  code?: string;
}
