import Vue from "vue";
import VueRouter, { RouteConfig } from "vue-router";
import { TokensContext } from "@/omnicore-lib/src/services/http/TenantTokenBasedService";

Vue.use(VueRouter);

Vue.component("login-layout", () => import("@/layouts/login.vue"));
Vue.component("main-layout", () => import("@tenantLayouts/main.vue"));

const redirect = (name, path, query) => {
  router.push({
    name,
    params: {
      returnTo: path,
      query: query,
    },
  });
};

const routeGuard = (to, from, next) => {
  if (TokensContext.instance.areTokensSet()) {
    next();
    return;
  }
  redirect("Login", to.path, to.query);
};

const checkLoggedIn = (to, from, next) => {
  if (TokensContext.instance.areTokensSet()) {
    redirect("Dashboard", to.path, to.query);
    return;
  }
  next();
};

const routes: Array<RouteConfig> = [
  {
    path: "/",
    name: "Login",
    meta: { layout: "login-layout" },
    component: () =>
      import(/* webpackChunkName: "LoginPage" */ "@/pages/Login.vue"),
    beforeEnter: (to, from, next) => {
      checkLoggedIn(to, from, next);
    },
  },
  {
    path: "/openbanking/:openbankingaction/login/:openbankingid",
    name: "OpenBankingLogin",
    meta: { layout: "login-layout" },
    component: () =>
      import(/* webpackChunkName: "LoginPage" */ "@/pages/Login.vue"),
  },
  {
    path: "/dashboard",
    name: "Dashboard",
    meta: { layout: "main-layout" },
    component: () =>
      import(/* webpackChunkName: "DashboardPage" */ "@/pages/Dashboard.vue"),
    beforeEnter: (to, from, next) => {
      routeGuard(to, from, next);
    },
  },
  {
    path: "/logout",
    name: "Logout",
    meta: { layout: "main-layout" },
    component: () =>
      import(/* webpackChunkName: "LogoutPage" */ "@/pages/Logout.vue"),
  },
  {
    path: "/expired",
    name: "SessionExpired",
    component: () =>
      import(
        /* webpackChunkName: "SessionExpiredPage" */ "@/pages/SessionExpired.vue"
      ),
  },
  {
    path: "/openbanking/:openbankingaction/:openbankingid",
    name: "OpenBanking",
    meta: { layout: "login-layout" },
    component: () =>
      import(
        /* webpackChunkName: "OpenBankingPage" */ "@/pages/OpenBanking.vue"
      ),
  },
  {
    path: "/terms",
    name: "TermsAndConditions",
    component: () =>
      import(
        /* webpackChunkName: "TermsAndConditions" */ "@/pages/TermsAndConditions.vue"
      ),
    beforeEnter: (to, from, next) => {
      routeGuard(to, from, next);
    },
  },
  {
    path: "/:catchAll(.*)",
    name: "NotFound",
    component: () => import(/* webpackChunkName: "404" */ "@/pages/404.vue"),
  },
];

const router = new VueRouter({
  // mode: "history",
  base: process.env.BASE_URL,
  routes,
});

export default router;
