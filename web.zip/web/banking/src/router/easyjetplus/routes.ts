import Vue from "vue";
import VueRouter, { RouteConfig } from "vue-router";

Vue.use(VueRouter);

Vue.component("main-layout", () => import("@tenantLayouts/main.vue"));
Vue.component("dashboard-layout", () => import("@tenantLayouts/dashboard.vue"));

const routes: Array<RouteConfig> = [
  {
    path: "/",
    name: "Index",
    meta: { layout: "main-layout" },
    component: () =>
      import(/* webpackChunkName: "Index" */ "@tenantPages/Index.vue"),
  },
  {
    path: "/dashboard",
    name: "Dashboard",
    meta: { layout: "dashboard-layout" },
    component: () =>
      import(/* webpackChunkName: "Dashboard" */ "@tenantPages/Dashboard.vue"),
  },
  {
    path: "/benefits",
    name: "Benefits",
    meta: { layout: "dashboard-layout" },
    component: () =>
      import(/* webpackChunkName: "Benefits" */ "@tenantPages/Benefits.vue"),
  },
  {
    path: "/faqs",
    name: "Faqs",
    meta: { layout: "dashboard-layout" },
    component: () =>
      import(/* webpackChunkName: "Faqs" */ "@tenantPages/Faqs.vue"),
  },
  {
    path: "/contact",
    name: "Contact",
    meta: { layout: "dashboard-layout" },
    component: () =>
      import(/* webpackChunkName: "Contact" */ "@tenantPages/Contact.vue"),
  },
  {
    path: "/terms",
    name: "TermsAndConditions",
    component: () =>
      import(
        /* webpackChunkName: "TermsAndConditions" */ "@/pages/TermsAndConditions.vue"
      ),
  },
  {
    path: "/:catchAll(.*)",
    name: "NotFound",
    component: () => import(/* webpackChunkName: "404" */ "@/pages/404.vue"),
  },
];

const router = new VueRouter({
  // mode: "history",
  base: process.env.BASE_URL,
  routes,
});

export default router;
