// Required as a js file for @tenantRoutes alias to work for Webpack
import tenantRouter from "@tenantRoutes/routes";
const router = () => tenantRouter;
export default router;
