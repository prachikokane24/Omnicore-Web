import Vue from "vue";
import VueRouter, { RouteConfig } from "vue-router";

Vue.use(VueRouter);

const routes: Array<RouteConfig> = [
  {
    path: "/dashboard",
    name: "Dashboard",
    meta: { layout: "main-layout" },
    component: () =>
      import(/* webpackChunkName: "DashboardPage" */ "@/pages/Dashboard.vue"),
  },
  {
    path: "/terms",
    name: "TermsAndConditions",
    component: () =>
      import(
        /* webpackChunkName: "TermsAndConditions" */ "@/pages/TermsAndConditions.vue"
      ),
  },
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes,
});

export default router;
