import Vue from "vue";
import VueRouter, { RouteConfig } from "vue-router";

Vue.use(VueRouter);

Vue.component("login-layout", () => import("@/layouts/login.vue"));
Vue.component("main-layout", () => import("@/layouts/main.vue"));

const routes: Array<RouteConfig> = [
  {
    path: "/",
    name: "Login",
    meta: { layout: "login-layout" },
    component: () =>
      import(/* webpackChunkName: "LoginPage" */ "@/pages/Login.vue"),
  },
  {
    path: "/dashboard",
    name: "Dashboard",
    meta: { layout: "main-layout" },
    component: () =>
      import(/* webpackChunkName: "DashboardPage" */ "@/pages/Dashboard.vue"),
  },
  {
    path: "/terms",
    name: "TermsAndConditions",
    component: () =>
      import(
        /* webpackChunkName: "TermsAndConditions" */ "@/pages/TermsAndConditions.vue"
      ),
  },
  {
    path: "/:catchAll(.*)",
    name: "NotFound",
    component: () => import(/* webpackChunkName: "404" */ "@/pages/404.vue"),
  },
];

const router = new VueRouter({
  // mode: "history",
  base: process.env.BASE_URL,
  routes,
});

export default router;
