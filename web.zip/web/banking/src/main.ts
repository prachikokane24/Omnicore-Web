import Vue from "vue";
import Vuex from "vuex";
import App from "./App.vue";
import router from "@/router/index";
import vuetify from "./plugins/vuetify";
import "@/filters";
import { ValidationProvider, ValidationObserver } from "vee-validate";
import { loadGoogleAnalytics, loadCookieBot } from "@/omnicore-lib";

import VueMask from "v-mask";

import Layout from "@/mixins/layout";

Vue.mixin(Layout);

import store from "./store";
import HttpClient from "./libs/http";

import i18n from "@/plugins/i18n";
import FeatureToggle from "@/plugins/featureToggle";
import Modal from "@/plugins/modal";
import EventBus from "@/plugins/eventBus";

Vue.component("ValidationProvider", ValidationProvider);
Vue.component("ValidationObserver", ValidationObserver);

Vue.use(Vuex);
Vue.use(EventBus);
Vue.use(FeatureToggle);
Vue.use(Modal);
Vue.use(VueMask);

declare module "vue/types/vue" {
  interface Vue {
    $modal: any;
    $EventBus: any;
  }
}

Vue.directive("credit-debit", (el, binding) => {
  const { amount, creditColor } = binding.value;
  el.style.color = parseInt(amount) > 0 ? creditColor : "inherit";
});

Vue.config.productionTip = false;
Vue.config.performance = process.env.NODE_ENV !== "production";

loadGoogleAnalytics();
loadCookieBot();

// Vee-validate Rules
import "./libs/validationRules";

const http = new HttpClient();
http.inject();

new Vue({
  vuetify,
  store,
  router: router(),
  i18n,
  render: (h) => h(App),
}).$mount("#app");
