// Required as a js file for @tenantStore alias to work for Webpack
import tenantStore from "@tenantStore";
export default tenantStore;
