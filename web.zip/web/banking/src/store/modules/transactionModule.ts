import { VuexModule, Module, Mutation, Action } from "vuex-module-decorators";
import { baseState, queryString } from "@/libs/store.utils";
import {
  BaseStateInterface,
  StorePromiseInterface,
  TransactionPayloadInterface,
} from "@/types/store.types";

@Module({ namespaced: true })
class TransactionModule extends VuexModule {
  userTransactions: BaseStateInterface = baseState();
  exportUserTransactions: BaseStateInterface = baseState();
  noop: BaseStateInterface = baseState();  

  get selectedWallet() {
    return this.context.rootState.summaryModule.selectedWallet;
  } 

  get deviceNumber() {
    return this.context.rootState.summaryModule.deviceNumber;
  } 

  get getTransactionsCsvData() {
    
    return this.exportUserTransactions.data?.transactions?.map((item) => {
      return {
        Date: item.transactionDate,
        Description: item.description,
        Detail: item.detail,
        Value: item.value.majorUnits,
        Balance: item.balance.majorUnits,
      };
    });
  }

  @Action({ rawError: true })
  async GET_USER_TRANSACTIONS(
    payload: TransactionPayloadInterface
  ): Promise<StorePromiseInterface> {
    const qs = queryString(payload);
    //const url = await require(`./mocks/transactions.json`);
    let url = `/webfss/webfss/v1/transactions/${this.selectedWallet.walletId}?${qs}`;
    if (this.selectedWallet.walletType === 'card') {
      url = `/webfss/webfss/v1/transactions/${this.selectedWallet.walletId}/${this.deviceNumber}?${qs}`;
    }
    
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "get",
        url,
        mutation: "transactionModule/SET_USER_TRANSACTIONS",
        errorMessage: "Error getting Transactions",
        keepData: true,
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async GET_EXPORT_USER_TRANSACTIONS(
    payload: TransactionPayloadInterface
  ): Promise<StorePromiseInterface> {
    const qs = queryString(payload);
    //const url = await require(`./mocks/transactions.json`);   
    let url = `/webfss/webfss/v1/transactions/${this.selectedWallet.walletId}?${qs}`;
    if (this.selectedWallet.walletType === 'card') {
      url = `/webfss/webfss/v1/transactions/${this.selectedWallet.walletId}/${this.deviceNumber}?${qs}`;
    }

    return this.context.dispatch(
      "StoreRequest",
      {
        method: "get",
        url,
        mutation: "transactionModule/SET_EXPORT_USER_TRANSACTIONS",
        errorMessage: "Error getting Transactions",
        keepData: true,
      },
      { root: true }
    );
  }

  @Mutation
  SET_EXPORT_USER_TRANSACTIONS(payload: BaseStateInterface): void {    
    this.exportUserTransactions = {
      ...this.exportUserTransactions,
      ...payload,
    };
  }

  @Mutation
  SET_USER_TRANSACTIONS(payload: BaseStateInterface): void {
    this.userTransactions = {
      ...this.userTransactions,
      ...payload,
    };   
  }

  @Mutation
  NOOP(payload: BaseStateInterface): void {
    this.noop = {
      ...this.noop,
      ...payload,
    };
  }
}
export default TransactionModule;
