import { VuexModule, Module, Mutation, Action } from "vuex-module-decorators";
import { baseState } from "@/libs/store.utils";
import { BaseStateInterface, StorePromiseInterface } from "@/types/store.types";
import {
  QueryParamInterface,
  MarketingPreferencesUpdatePayload,
} from "@/types/store.types";

@Module({ namespaced: true })
class MarketingPreferencesModule extends VuexModule {
  marketingPreferences: BaseStateInterface = baseState();
  noop: BaseStateInterface = baseState();

  @Action({ rawError: true })
  async GET_MARKETING_PREFERENCES(): Promise<StorePromiseInterface> {
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "get",
        url: "/webfss/webfss/v1/marketingPreferences",
        mutation: "marketingPreferencesModule/MARKETING_PREFERENCES",
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async UPDATE_MARKETING_PREFERENCES(
    payload: MarketingPreferencesUpdatePayload
  ): Promise<StorePromiseInterface> {
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "post",
        url: "/webfss/webfss/v1/marketingPreferences",
        payload,
        mutation: "marketingPreferencesModule/NOOP",
      },
      { root: true }
    );
  }

  @Mutation
  MARKETING_PREFERENCES(payload: BaseStateInterface): void {
    this.marketingPreferences = {
      ...this.marketingPreferences,
      ...payload,
    };
  }

  @Mutation
  NOOP(payload: BaseStateInterface): void {
    this.noop = {
      ...this.noop,
      ...payload,
    };
  }
}
export default MarketingPreferencesModule;
