import { VuexModule, Module, Mutation, Action } from "vuex-module-decorators";
import { baseState } from "@/libs/store.utils";
import { BaseStateInterface, StorePromiseInterface } from "@/types/store.types";

@Module({ namespaced: true })
class FeesModule extends VuexModule {
  noop: BaseStateInterface = baseState();

  @Action({ rawError: true })
  async GET_FEES(): Promise<StorePromiseInterface> {
    const url = `/webfss/webfss/v1/fees`;
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "get",
        url,
        mutation: "cardModule/NOOP",
        errorMessage: "Error getting fees",
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async CLEAR_NOOP() {
    return this.context.commit("NOOP", baseState());
  }

  @Mutation
  NOOP(payload: BaseStateInterface): void {
    this.noop = {
      ...this.noop,
      ...payload,
    };
  }
}

export default FeesModule;
