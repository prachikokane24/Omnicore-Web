import Vue from "vue";
import { VuexModule, Module, Mutation, Action } from "vuex-module-decorators";
import { baseState } from "@/libs/store.utils";
import { BaseStateInterface, StorePromiseInterface } from "@/types/store.types";
import vuetify from "@/plugins/vuetify";

@Module({ namespaced: true })
class SummaryModule extends VuexModule {
  accountSummary: BaseStateInterface = baseState();
  selectedAccountId: any | null = null;
  selectedWallet: any | null = null;
  deviceNumber: any | null = null;

  @Action({ rawError: true })
  async GET_ACCOUNT_SUMMARY(): Promise<void> {
    const summaryData = await this.context.dispatch(
      "StoreRequest",
      {
        method: "get",
        url: "/webfss/webfss/v1/summaryData?pageNumber=1&pageSize=15",
        mutation: "summaryModule/SET_ACCOUNT_SUMMARY",
        errorMessage: "Error getting account summary data",
        keepData: true,
      },
      { root: true }
    );

    const defaultAccountId = summaryData.data.accounts[0].accountId; // get the first account returned from the list of accounts
    this.context.commit("SET_SELECTED_ACCOUNT_ID", defaultAccountId);

    const deviceNumber = summaryData.data.devices[0].deviceNumber;  
    this.context.commit("SET_DEVICE_NUMBER", deviceNumber);

    // Set user info
    const userDetails = baseState();
    userDetails.data = summaryData.data.user;
    this.context.commit("userModule/SET_USER_DETAILS", userDetails, {
      root: true,
    });

    // Get the main wallet
    const defaultWallet = summaryData.data.wallets.filter((wallet) => {
      return (
        wallet["accountId"] === defaultAccountId &&
        wallet["walletType"] === "card"
      );
    })[0];

    if (!defaultWallet) return;

    // Set the main wallets transactions
    const transactions = baseState();
    transactions.data = defaultWallet["transactions"];
    this.context.commit(
      "transactionModule/SET_USER_TRANSACTIONS",
      transactions,
      { root: true }
    );
  }

  @Action({ rawError: true })
  UPDATE_SELECTED_WALLET(payload: any | null): void {
    this.context.commit("SET_SELECTED_WALLET", payload);
  }

  @Action({ rawError: true })
  UPDATE_SELECTED_ACCOUNT_ID(id: number): void {
    this.context.commit("SET_SELECTED_ACCOUNT_ID", id);
  }

  @Action({ rawError: true })
  UPDATE_SELECTED_WALLET_BALANCE(payload: any | null): void {    
    this.context.commit("SET_SELECTED_WALLET_BALANCE", payload);
  }

  @Mutation
  SET_SELECTED_WALLET(payload: any): void {
    this.selectedWallet = payload;
  }

  @Mutation
  SET_ACCOUNT_SUMMARY(payload: BaseStateInterface): void {
    this.accountSummary = {
      ...this.accountSummary,
      ...payload,
    };
  }

  @Mutation
  SET_SELECTED_ACCOUNT_ID(id: string): void {
    this.selectedAccountId = id;
  }

  @Mutation
  SET_DEVICE_NUMBER(deviceNumber: string): void {
    this.deviceNumber = deviceNumber
  }

  @Mutation
  SET_SELECTED_WALLET_BALANCE(payload: any): void {
    const walletIndex = this.accountSummary.data.wallets.findIndex(wallet => wallet.walletId === payload?.data?.wallet?.walletId);

    if (walletIndex >= 0) {
      const wallet = this.accountSummary.data.wallets[walletIndex];
      wallet.availableBalance = payload?.data?.wallet?.availableBalance;
      wallet.blockedBalance = payload?.data?.wallet?.blockedBalance;
    }
  }

  // Maps all Accounts to its wallets
  get getAllUserAccountWallets() {
    return this.accountSummary?.data?.accounts?.map((account) => {
      const accountId = account.accountId;
      const wallets = this.accountSummary?.data?.wallets?.filter((o) => {
        return o.accountId == accountId;
      });
      return {
        accountId: accountId,
        accountDeviceId: account.deviceId,
        accountCardNoEnding: account.cardNumberEnding,
        accountCardExpiry: account.cardExpiry,
        accountHolders: account.accountHolders,
        accountType: account.accountType,
        accountSort: account.sortCode,
        accountNumber: account.accountNumber,
        accountStatus: account.cardStatus,
        walletCount: wallets.length || 0,
        wallets: wallets,
      };
    });
  }

  // Return wallets only for a particular Account ID
  get getSelectedUserAccountWallets() {
    const foundAccounts = this.getAllUserAccountWallets?.find(
      (account) => account.accountId === this.selectedAccountId
    );
    return foundAccounts || [];
  }

  get getMarketingPreferences() {
    const marketingPrefs = this.accountSummary?.data?.user
      ?.marketingPreferences;
    return marketingPrefs || [];
  }

  get getAccountDetails() {
    return {
      accountId: this.selectedWallet?.accountId,
      accountDeviceId: this.getSelectedUserAccountWallets.accountDeviceId,
      accountCardNoEnding: this.getSelectedUserAccountWallets
        .accountCardNoEnding,
      accountCardExpiry: this.getSelectedUserAccountWallets.accountCardExpiry,
      accountHolders: this.getSelectedUserAccountWallets.accountHolders,
      accountSortCode: this.getSelectedUserAccountWallets.accountSort,
      accountAccountNumber: this.getSelectedUserAccountWallets.accountNumber,
      accountStatus: this.getSelectedUserAccountWallets.accountStatus,
      availableBalance: this.selectedWallet?.availableBalance.minorUnits,
      accountBalance:
        this.selectedWallet?.availableBalance.minorUnits +
        this.selectedWallet?.blockedBalance.minorUnits,
      pendingCredits: this.selectedWallet?.pendingCredits?.minorUnits,
      pendingDebits: this.selectedWallet?.pendingDebits?.minorUnits,
      savingsTargetDate: this.selectedWallet?.savingsTargetDate,
      savingsTargetAmount: this.selectedWallet?.savingsTargetAmount?.minorUnits,
    };
  }
}
export default SummaryModule;
