import Vue from "vue";
import { getErrorMessage, baseState } from "@/libs/store.utils";
import { VuexModule, Module, Mutation, Action } from "vuex-module-decorators";
import router from "@/router/index";
import {
  StorePromiseInterface,
  StoreRequestPropsInterface,
} from "@/types/store.types";

@Module
class HelperModule extends VuexModule {
  appLoading = false;

  @Action({ rawError: true })
  async StoreRequest(
    props: StoreRequestPropsInterface
  ): Promise<StorePromiseInterface> {
    const {
      client = "http",
      action,
      method,
      url,
      payload = {},
      params = {},
      headers = {},
      config = {},
      responseType = "json",
      mutation,
      errorMessage = "",
      keepData = false,
      delay = 0,
      loading = true,
      isLoginRequest = false,
    } = props;

    try {
      const base = baseState();
      if (loading) {
        base.loading = true;
      }
      this.context.commit("SET_APP_LOADING", true);
      if (keepData) {
        delete base.data;
      }
      this.context.commit(mutation, base, { root: true });
      if (delay && client == "mock") {
        await new Promise((resolve) => setTimeout(resolve, delay));
      }
      try {
        let response;
        if (typeof action === "function") {
          response = await action();
        } else {
          if (typeof url !== "string") {
            // it's a mock json file
            if (delay) {
              await new Promise((resolve) => setTimeout(resolve, delay));
            }
            response = url;
          } else {
            response = await Object.freeze(
              Vue.prototype[client].request({
                method,
                url,
                data: payload,
                params,
                headers,
                config,
                responseType,
              })
            );
          }
        }
        this.context.commit(
          mutation,
          {
            data: response?.data,
            loading: false,
            errorMessage: null,
            errorStatus: null,
          },
          { root: true }
        );
        return Promise.resolve(response);
      } catch (e) {
        const errorStatus = e.response ? e.response.status : null;
        const message: string | string[] = getErrorMessage(e, errorMessage);

        const errorCodes = [407, 406, 405, 403, 401];
        if (errorCodes.includes(errorStatus)) {
          if (!isLoginRequest) {
            await this.context.commit(
              "authenticationModule/SERVICE_ERROR",
              {
                data: null,
                loading: false,
                errorMessage: message,
                errorStatus,
              },
              { root: true }
            );
            router().push({
              name: "SessionExpired",
            });
          }
        }
        this.context.commit(
          mutation,
          {
            data: null,
            loading: false,
            errorMessage: message,
            errorStatus,
          },
          { root: true }
        );
        return Promise.reject(e);
      }
    } catch (e) {
      return Promise.reject(e);
    } finally {
      this.context.commit("SET_APP_LOADING", false);
    }
  }
  @Mutation
  SET_APP_LOADING(val: boolean): void {
    this.appLoading = val;
  }
}
export default HelperModule;
