import { VuexModule, Module, Mutation, Action } from "vuex-module-decorators";
import { baseState, queryString } from "@/libs/store.utils";
import { BaseStateInterface, StorePromiseInterface } from "@/types/store.types";

@Module({ namespaced: true })
class CardModule extends VuexModule {
  cardStatus: BaseStateInterface = baseState();
  noop: BaseStateInterface = baseState();

  @Action({ rawError: true })
  async UPDATE_CARD_STATUS({
    cardId,
    cardStatus,
  }): Promise<StorePromiseInterface> {
    const url = `/webfss/webfss/v1/card/status/${cardId}/${cardStatus}`;
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "post",
        url,
        mutation: "cardModule/NOOP",
        errorMessage: "Error upating card information",
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async GET_CARD_PIN({ cardId }): Promise<StorePromiseInterface> {
    const url = `/webfss/webfss/v1/card/pin/${cardId}`;
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "get",
        url,
        mutation: "cardModule/NOOP",
        errorMessage: "Error getting card information",
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async REISSUE_CARD({ cardId }): Promise<StorePromiseInterface> {
    const url = `/webfss/webfss/v1/card/reorder/${cardId}`;
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "post",
        url,
        mutation: "cardModule/NOOP",
        errorMessage: "Error reissuing card information",
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async CLEAR_NOOP() {
    return this.context.commit("NOOP", baseState());
  }

  @Mutation
  NOOP(payload: BaseStateInterface): void {
    this.noop = {
      ...this.noop,
      ...payload,
    };
  }
}
export default CardModule;
