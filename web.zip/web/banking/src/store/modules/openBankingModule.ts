import { VuexModule, Module, Mutation, Action } from "vuex-module-decorators";
import { baseState } from "@/libs/store.utils";
import { BaseStateInterface, StorePromiseInterface } from "@/types/store.types";

@Module({ namespaced: true })
class OpenBankingModule extends VuexModule {
    getOpenBankingAispConsentResponse: BaseStateInterface = baseState();
    getOpenBankingPispConsentResponse: BaseStateInterface = baseState();
    postOpenBankingAispConsentResponse: BaseStateInterface = baseState();
    postOpenBankingConsentErrorResponse: BaseStateInterface = baseState();
    noop: BaseStateInterface = baseState();

    @Action({ rawError: true })
    async GET_OPEN_BANKING_AISP_CONSENT(openBankingId: string): Promise<StorePromiseInterface> {
        return await this.context.dispatch(
            "StoreRequest",
            {
                method: "get",
                url: "/webfss/webfss/v1/openbanking/consent/aisp/" + openBankingId,
                mutation: "openBankingModule/SET_GET_OPEN_BANKING_AISP_CONSENT_RESPONSE",
                errorMessage: "Error getting open banking aisp consent options"
            },
            { root: true }
        );
    }

    @Action({ rawError: true })
    async GET_OPEN_BANKING_PISP_CONSENT(openBankingId: string): Promise<StorePromiseInterface> {
        return await this.context.dispatch(
            "StoreRequest",
            {
                method: "get",
                url: "/webfss/webfss/v1/openbanking/consent/pisp/" + openBankingId,
                mutation: "openBankingModule/SET_GET_OPEN_BANKING_PISP_CONSENT_RESPONSE",
                errorMessage: "Error getting open banking pisp consent options"
            },
            { root: true }
        );
    }

    @Action({ rawError: true })
    async POST_OPEN_BANKING_AISP_CONSENT(payload): Promise<StorePromiseInterface> {
        return await this.context.dispatch(
            "StoreRequest",
            {
                method: "post",
                url: "/webfss/webfss/v1/openbanking/consent/aisp/" + payload.openBankingId,
                payload: payload,
                mutation: "openBankingModule/NOOP",
                errorMessage: "Error posting open banking aisp consent options"
            },
            { root: true }
        );
    }

    @Action({ rawError: true })
    async POST_OPEN_BANKING_CONSENT_ERROR(payload): Promise<StorePromiseInterface> {
        return await this.context.dispatch(
            "StoreRequest",
            {
                method: "post",
                url: "/webfss/webfss/v1/openbanking/consent/error/" + payload.openBankingId,
                payload: payload,
                mutation: "openBankingModule/SET_POST_OPEN_BANKING_CONSENT_ERROR_RESPONSE",
                errorMessage: "Error posting consent error"
            },
            { root: true }
        );
    }

    @Action({ rawError: true })
    async CLEAR_NOOP() {
        return this.context.commit("NOOP", baseState());
    }

    @Mutation
    SET_GET_OPEN_BANKING_AISP_CONSENT_RESPONSE(payload: BaseStateInterface): void {
        this.getOpenBankingAispConsentResponse = payload;
    }

    @Mutation
    SET_GET_OPEN_BANKING_PISP_CONSENT_RESPONSE(payload: BaseStateInterface): void {
        this.getOpenBankingPispConsentResponse = payload;
    }

    @Mutation
    SET_POST_OPEN_BANKING_CONSENT_ERROR_RESPONSE(payload: BaseStateInterface): void {
        this.postOpenBankingConsentErrorResponse = payload;
    }

    @Mutation
    NOOP(payload: BaseStateInterface): void {
        this.noop = {
            ...this.noop,
            ...payload,
        };
    }
}

export default OpenBankingModule;