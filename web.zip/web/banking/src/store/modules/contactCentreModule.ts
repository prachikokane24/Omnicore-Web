import { VuexModule, Module, Mutation, Action } from "vuex-module-decorators";
import { baseState, queryString } from "@/libs/store.utils";
import { BaseStateInterface, StorePromiseInterface } from "@/types/store.types";

@Module({ namespaced: true })
class ContactCentreModule extends VuexModule {
  contactCentreInbox: BaseStateInterface = baseState();

  @Action({ rawError: true })
  async GET_USER_CONTACT_CENTRE_INBOX_MESSAGES(): Promise<StorePromiseInterface> {
    const url = `https://run.mocky.io/v3/90c1b709-9dc6-498b-9a84-3191dd7d4dd4`;
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "get",
        url,
        mutation: "contactCentreModule/SET_USER_CONTACT_CENTRE_INBOX_MESSAGES",
        errorMessage: "Error getting user contact centre inbox messages",
        keepData: true,
        delay: 500,
      },
      { root: true }
    );
  }

  @Mutation
  SET_USER_CONTACT_CENTRE_INBOX_MESSAGES(payload: BaseStateInterface): void {
    this.contactCentreInbox = {
      ...this.contactCentreInbox,
      ...payload,
    };
  }
}
export default ContactCentreModule;
