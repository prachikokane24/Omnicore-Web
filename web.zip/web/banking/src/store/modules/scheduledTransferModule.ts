import { VuexModule, Module, Mutation, Action } from "vuex-module-decorators";
import { baseState, queryString } from "@/libs/store.utils";
import {
  BaseStateInterface,
  StorePromiseInterface,
  ScheduledTransferPayloadInterface,
  ScheduledTransferCreatedPayloadInterface,
} from "@/types/store.types";

@Module({ namespaced: true })
class ScheduledTransferModule extends VuexModule {
  userScheduledTransfers: BaseStateInterface = baseState();
  noop: BaseStateInterface = baseState();

  @Action({ rawError: true })
  async UPDATE_USER_SCHEDULED_TRANSFER(
    payload: ScheduledTransferCreatedPayloadInterface
  ): Promise<StorePromiseInterface> {
    const { id } = payload;
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "put",
        url: `/webfss/webfss/v1/scheduledTransfer/${id}`,
        mutation: "scheduledTransferModule/NOOP",
        errorMessage: "Error updating Scheduled Transfer",
        payload,
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async GET_USER_SCHEDULED_TRANSFERS(
    payload: ScheduledTransferPayloadInterface
  ): Promise<StorePromiseInterface> {
    const qs = queryString(payload);
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "get",
        url: `/webfss/webfss/v1/scheduledTransfers?${qs}`,
        mutation: "scheduledTransferModule/SET_USER_SCHEDULED_TRANSFERS",
        errorMessage: "Error getting Scheduled Transfers",
        keepData: true,
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async CREATE_USER_SCHEDULED_TRANSFER(
    payload: ScheduledTransferCreatedPayloadInterface
  ): Promise<StorePromiseInterface> {
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "post",
        url: `/webfss/webfss/v1/scheduledTransfers`,
        mutation: "scheduledTransferModule/NOOP",
        errorMessage: "Error creating Scheduled Transfer",
        payload,
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async DELETE_USER_SCHEDULED_TRANSFER(
    id: number
  ): Promise<StorePromiseInterface> {
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "delete",
        url: `/webfss/webfss/v1/scheduledTransfer/${id}`,
        mutation: "scheduledTransferModule/NOOP",
        errorMessage: "Error deleting Scheduled Transfer",
        delay: 500,
      },
      { root: true }
    );
  }

  @Mutation
  SET_USER_SCHEDULED_TRANSFERS(payload: BaseStateInterface): void {
    this.userScheduledTransfers = {
      ...this.userScheduledTransfers,
      ...payload,
    };
  }

  @Action({ rawError: true })
  async CLEAR_NOOP() {
    return this.context.commit("NOOP", baseState());
  }

  @Mutation
  NOOP(payload: BaseStateInterface): void {
    this.noop = {
      ...this.noop,
      ...payload,
    };
  }
}
export default ScheduledTransferModule;
