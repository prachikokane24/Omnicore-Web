import Vue from "vue";
import { VuexModule, Module, Mutation, Action } from "vuex-module-decorators";
import { baseState } from "@/libs/store.utils";
import { BaseStateInterface, StorePromiseInterface } from "@/types/store.types";

@Module({ namespaced: true })
class OtpModule extends VuexModule {
  userOtpSession: BaseStateInterface = baseState();
  sendOtp: BaseStateInterface = baseState();
  verifyOtp: BaseStateInterface = baseState();
  userAccessTokenResponse: BaseStateInterface = baseState();
  noop: BaseStateInterface = baseState();

  @Action({ rawError: true })
  async SEND_OTP(): Promise<StorePromiseInterface> {
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "post",
        url: "/fss/fss/v1/otp",
        mutation: "otpModule/SET_SEND_OTP",
        errorMessage: "Error sending OTP to mobile number.",
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async VERIFY_OTP(payload: {
    sessionId: string;
    code: string;
  }): Promise<StorePromiseInterface> {
    const { sessionId, code } = payload;
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "post",
        url: "/fss/fss/v1/otp/" + sessionId,
        payload: {
          code,
        },
        mutation: "otpModule/SET_VERIFY_OTP",
        errorMessage: "Error verifying One Time Passcode. Please try again.",
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async CLEAR_OTP(): Promise<void> {
    this.context.commit("SET_SEND_OTP", baseState());
    this.context.commit("SET_VERIFY_OTP", baseState());
  }

  @Mutation
  SET_SEND_OTP(payload: BaseStateInterface): void {
    this.sendOtp = {
      ...this.sendOtp,
      ...payload,
    };
  }

  @Mutation
  SET_VERIFY_OTP(payload: BaseStateInterface): void {
    this.verifyOtp = {
      ...this.verifyOtp,
      ...payload,
    };
  }

  @Mutation
  NOOP(payload: BaseStateInterface): void {
    this.noop = {
      ...this.noop,
      ...payload,
    };
  }
}
export default OtpModule;
