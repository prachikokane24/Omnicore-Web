import { VuexModule, Module, Mutation, Action } from "vuex-module-decorators";
import { baseState, queryString } from "@/libs/store.utils";
import { createDefaultMonetaryAmount } from "@/types/monetaryAmount";
import {
  BaseStateInterface,
  StorePromiseInterface,
  UpdateWalletPayloadInterface,
  CreateWalletPayloadInterface,
} from "@/types/store.types";

@Module({ namespaced: true })
class WalletModule extends VuexModule {
  walletDetails: BaseStateInterface = baseState();
  noop: BaseStateInterface = baseState();

  @Action({ rawError: true })
  async EMPTY_WALLET(): Promise<void> {
    this.context.commit(
      "walletModule/SET_WALLET",
      {
        data: {
          wallet: {
            savingsTargetAmount: createDefaultMonetaryAmount(),
          },
        },
        loading: false,
        errorMessage: null,
        errorStatus: null,
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async GET_WALLET(id: number): Promise<StorePromiseInterface> {
    const url = `/webfss/webfss/v1/wallet/${id}`;
    return this.context.dispatch(
      "StoreRequest",
      {
        client: "http",
        method: "get",
        url,
        mutation: "walletModule/SET_WALLET",
        errorMessage: "Error getting wallet data",
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async UPDATE_WALLET(
    payload: UpdateWalletPayloadInterface
  ): Promise<StorePromiseInterface> {
    const url = `/webfss/webfss/v1/wallet/${payload.id}`;
    return this.context.dispatch(
      "StoreRequest",
      {
        client: "http",
        method: "put",
        url,
        payload,
        mutation: "walletModule/NOOP",
        errorMessage: "Error updating wallet data",
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async CREATE_WALLET(
    payload: CreateWalletPayloadInterface
  ): Promise<StorePromiseInterface> {
    const url = `/webfss/webfss/v1/wallet`;
    return this.context.dispatch(
      "StoreRequest",
      {
        client: "http",
        method: "post",
        url,
        payload,
        mutation: "walletModule/NOOP",
        errorMessage: "Error creating wallet data",
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async CLEAR_NOOP() {
    return this.context.commit("NOOP", baseState());
  }

  @Mutation
  SET_WALLET(payload: BaseStateInterface): void {
    this.walletDetails = {
      ...this.walletDetails,
      ...payload,
    };
  }

  @Mutation
  NOOP(payload: BaseStateInterface): void {
    this.noop = {
      ...this.noop,
      ...payload,
    };
  }
}
export default WalletModule;
