import { VuexModule, Module, Mutation, Action } from "vuex-module-decorators";
import { baseState } from "@/libs/store.utils";
import {
  BaseStateInterface,
  StorePromiseInterface,
  PersonalDetailsPayloadInterface,
  PasswordPayloadInterface,
} from "@/types/store.types";

@Module({ namespaced: true })
class UserModule extends VuexModule {
  userDetails: BaseStateInterface = baseState();
  personalDetails: BaseStateInterface = baseState();
  resetUserCredentials: BaseStateInterface = baseState();
  noop: BaseStateInterface = baseState();

  @Action({ rawError: true })
  async UPDATE_USER_PASSWORD(
    payload: PasswordPayloadInterface
  ): Promise<StorePromiseInterface> {
    console.log(payload);
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "post",
        url: "/webfss/webfss/v1/userDetails/password",
        mutation: "userModule/NOOP",
        errorMessage: "Error updating user password.",
        payload,
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async GET_PERSONAL_DETAILS(): Promise<StorePromiseInterface> {
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "get",
        url: "/webfss/webfss/v1/userDetails",
        mutation: "userModule/SET_PERSONAL_DETAILS",
        errorMessage: "Error getting personal details",
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async UPDATE_PERSONAL_DETAILS(
    payload: PersonalDetailsPayloadInterface
  ): Promise<StorePromiseInterface> {
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "put",
        url: "/webfss/webfss/v1/userDetails",
        mutation: "userModule/NOOP",
        errorMessage: "Error updating personal details",
        payload,
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async RESET_USER_CREDENTIALS(
    payload: ResetPayload
  ): Promise<StorePromiseInterface> {
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "post",
        url: "/webfss/webfss/v1/resetPassword",
        mutation: "userModule/SET_RESET_USER_CREDENTIALS",
        errorMessage: "Error reseting password",
        payload,
        isLoginRequest: true
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async CLEAR_NOOP() {
    return this.context.commit("NOOP", baseState());
  }

  @Mutation
  SET_USER_DETAILS(payload: BaseStateInterface): void {
    this.userDetails = {
      ...this.userDetails,
      ...payload,
    };
  }

  @Mutation
  SET_PERSONAL_DETAILS(payload: BaseStateInterface): void {
    this.personalDetails = {
      ...this.personalDetails,
      ...payload,
    };
  }

  @Mutation
  SET_RESET_USER_CREDENTIALS(payload: BaseStateInterface): void {
    this.resetUserCredentials = payload;
  }

  @Mutation
  NOOP(payload: BaseStateInterface): void {
    this.noop = {
      ...this.noop,
      ...payload,
    };
  }
}

export interface ResetPayload {
  email: string;
  accountNumber: string;
  tenantName: string;
}

export default UserModule;


