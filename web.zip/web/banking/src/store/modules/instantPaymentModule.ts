import { VuexModule, Module, Mutation, Action } from "vuex-module-decorators";
import { baseState, queryString } from "@/libs/store.utils";
import {
  BaseStateInterface,
  StorePromiseInterface,
  InstantPaymentCreatePayloadInterface,
  InstantTransferCreatePayloadInterface,
} from "@/types/store.types";

@Module({ namespaced: true })
class InstantPaymentModule extends VuexModule {
  noop: BaseStateInterface = baseState();

  @Action({ rawError: true })
  async CREATE_INSTANT_PAYMENT(
    payload: InstantPaymentCreatePayloadInterface
  ): Promise<StorePromiseInterface> {
    console.log(payload);
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "post",
        url: `/webfss/webfss/v1/payment`,
        mutation: "instantPaymentModule/NOOP",
        errorMessage: "Error making a single payment",
        payload,
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async CREATE_INSTANT_TRANSFER(
    payload: InstantPaymentCreatePayloadInterface
  ): Promise<StorePromiseInterface> {
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "post",
        url: `/webfss/webfss/v1/transfer`,
        mutation: "instantPaymentModule/NOOP",
        errorMessage: "Error making a single transfer",
        payload,
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async CLEAR_NOOP() {
    return this.context.commit("NOOP", baseState());
  }

  @Mutation
  NOOP(payload: BaseStateInterface): void {
    this.noop = {
      ...this.noop,
      ...payload,
    };
  }
}
export default InstantPaymentModule;
