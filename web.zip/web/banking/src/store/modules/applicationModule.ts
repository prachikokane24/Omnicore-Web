import { VuexModule, Module, Mutation, Action } from "vuex-module-decorators";
import { baseState } from "@/libs/store.utils";
import { BaseStateInterface, StorePromiseInterface } from "@/types/store.types";

@Module({ namespaced: true })
class ApplicationModule extends VuexModule {
  userApplication: BaseStateInterface = baseState();
  noop: BaseStateInterface = baseState();

  @Action
  async CREATE_APPLICATION(): Promise<StorePromiseInterface> {
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "post",
        url: `/v3/600d4bc6-d2b2-48ef-91a4-0a56934ffd7a`,
        mutation: "applicationModule/SET_APPLICATION",
        errorMessage: "Error creating application",
      },
      { root: true }
    );
  }

  @Action
  async GET_APPLICATION(): Promise<StorePromiseInterface> {
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "get",
        url: `/v3/600d4bc6-d2b2-48ef-91a4-0a56934ffd7a`,
        mutation: "applicationModule/SET_APPLICATION",
        errorMessage: "Error creating application",
        mocked: true,
      },
      { root: true }
    );
    // return this.context.dispatch(
    //   "StoreRequest",
    //   {
    //     action: () => Vue.prototype.twilio.sendOTP("07957386492"),
    //     mutation: "applicationModule/SET_APPLICATION",
    //     errorMessage: "Error getting application",
    //   },
    //   { root: true }
    // );
  }

  @Mutation
  SET_APPLICATION(payload: BaseStateInterface): void {
    this.userApplication = payload;
  }

  @Mutation
  NOOP(payload: BaseStateInterface): void {
    this.noop = {
      ...this.noop,
      ...payload,
    };
  }
}
export default ApplicationModule;
