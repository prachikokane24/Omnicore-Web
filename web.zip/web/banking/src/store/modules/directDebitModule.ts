import { VuexModule, Module, Mutation, Action } from "vuex-module-decorators";
import { baseState, queryString } from "@/libs/store.utils";
import {
  BaseStateInterface,
  StorePromiseInterface,
  DirectDebitPayloadInterface,
  DirectDebitCreatePayloadInterface,
} from "@/types/store.types";

@Module({ namespaced: true })
class DirectDebitModule extends VuexModule {
  userDirectDebits: BaseStateInterface = baseState();
  noop: BaseStateInterface = baseState();

  @Action({ rawError: true })
  async GET_USER_DIRECT_DEBITS(
    payload: DirectDebitPayloadInterface
  ): Promise<StorePromiseInterface> {
    const qs = queryString(payload);
   // const url = await require(`./mocks/directDebits.json`);   
    const url = `/webfss/webfss/v1/directDebits?${qs}`;
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "get",
        url: url,
        mutation: "directDebitModule/SET_USER_DIRECT_DEBITS",
        errorMessage: "Error getting Direct Debits",
        keepData: true,
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async CREATE_USER_DIRECT_DEBIT(
    payload: DirectDebitCreatePayloadInterface
  ): Promise<StorePromiseInterface> {
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "post",
        url: `/webfss/webfss/v1/directDebits`,
        mutation: "directDebitModule/NOOP",
        errorMessage: "Error creating Direct Debit",
        payload,
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async DELETE_USER_DIRECT_DEBIT(id: number): Promise<StorePromiseInterface> {
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "delete",
        url: `/webfss/webfss/v1/directDebit/${id}`,
        mutation: "directDebitModule/NOOP",
        errorMessage: "Error cancelling Direct Debit",
      },
      { root: true }
    );
  }

  @Mutation
  SET_USER_DIRECT_DEBITS(payload: BaseStateInterface): void {
    this.userDirectDebits = {
      ...this.userDirectDebits,
      ...payload,
    };
  }

  @Action({ rawError: true })
  async CLEAR_NOOP() {
    return this.context.commit("NOOP", baseState());
  }

  @Mutation
  NOOP(payload: BaseStateInterface): void {
    this.noop = {
      ...this.noop,
      ...payload,
    };
  }
}
export default DirectDebitModule;
