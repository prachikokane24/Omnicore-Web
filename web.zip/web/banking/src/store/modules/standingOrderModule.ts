import { VuexModule, Module, Mutation, Action } from "vuex-module-decorators";
import { baseState, queryString } from "@/libs/store.utils";
import {
  BaseStateInterface,
  StorePromiseInterface,
  StandingOrderPayloadInterface,
  StandingOrderCreatePayloadInterface,
} from "@/types/store.types";

@Module({ namespaced: true })
class StandingOrderModule extends VuexModule {
  userStandingOrder: BaseStateInterface = baseState();
  userStandingOrders: BaseStateInterface = baseState();
  noop: BaseStateInterface = baseState();

  @Action({ rawError: true })
  async UPDATE_USER_STANDING_ORDER(
    payload: StandingOrderCreatePayloadInterface
  ): Promise<StorePromiseInterface> {
    const { id } = payload;
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "put",
        url: `/webfss/webfss/v1/standingOrder/${id}`,
        mutation: "standingOrderModule/NOOP",
        errorMessage: "Error updating Standing Order",
        payload,
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async GET_USER_STANDING_ORDERS(
    payload: StandingOrderPayloadInterface
  ): Promise<StorePromiseInterface> {
    const qs = queryString(payload);
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "get",
        url: `/webfss/webfss/v1/standingOrders?${qs}`,
        mutation: "standingOrderModule/SET_USER_STANDING_ORDERS",
        errorMessage: "Error getting Standing Orders",
        keepData: true,
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async CREATE_USER_STANDING_ORDER(
    payload: StandingOrderCreatePayloadInterface
  ): Promise<StorePromiseInterface> {
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "post",
        url: `/webfss/webfss/v1/standingOrders`,
        mutation: "standingOrderModule/NOOP",
        errorMessage: "Error creating Standing Order",
        payload,
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async DELETE_USER_STANDING_ORDER(id: number): Promise<StorePromiseInterface> {
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "delete",
        url: `/webfss/webfss/v1/standingOrder/${id}`,
        mutation: "standingOrderModule/NOOP",
        errorMessage: "Error deleting Standing Order",
      },
      { root: true }
    );
  }

  @Mutation
  SET_USER_STANDING_ORDERS(payload: BaseStateInterface): void {
    this.userStandingOrders = {
      ...this.userStandingOrders,
      ...payload,
    };
  }

  @Mutation
  SET_USER_STANDING_ORDER(payload: BaseStateInterface): void {
    this.userStandingOrder = {
      ...this.userStandingOrder,
      ...payload,
    };
  }

  @Action({ rawError: true })
  async CLEAR_NOOP() {
    return this.context.commit("NOOP", baseState());
  }

  @Mutation
  NOOP(payload: BaseStateInterface): void {
    this.noop = {
      ...this.noop,
      ...payload,
    };
  }
}
export default StandingOrderModule;
