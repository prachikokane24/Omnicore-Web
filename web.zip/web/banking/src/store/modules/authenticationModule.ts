import { VuexModule, Module, Mutation, Action } from "vuex-module-decorators";
import { baseState } from "@/libs/store.utils";
import { BaseStateInterface, StorePromiseInterface } from "@/types/store.types";
import { TokensContext } from "@/omnicore-lib/src/services/http/TenantTokenBasedService";

@Module({ namespaced: true })
class AuthenticationModule extends VuexModule {
  userCredentials: BaseStateInterface = baseState();
  userLoginSession: BaseStateInterface = baseState();
  userAccessTokenResponse: BaseStateInterface = baseState();
  serviceError: BaseStateInterface = baseState();
  userOtpSession: BaseStateInterface = baseState();
  sendOtp: BaseStateInterface = baseState();
  verifyOtp: BaseStateInterface = baseState();
  noop: BaseStateInterface = baseState();

  @Action({ rawError: true })
  async GET_USER_LOGIN_SESSION(
    payload: UserLoginRequest
  ): Promise<StorePromiseInterface> {
    this.context.commit("SET_USER_CREDENTIALS", {
      data: payload,
      loading: false,
      errorMessage: null,
      errorStatus: null,
    });
    return await this.context.dispatch(
      "StoreRequest",
      {
        method: "post",
        url: "/fss/fss/v1/authentication/user/login",
        payload: payload,
        mutation: "authenticationModule/SET_USER_LOGIN_SESSION",
        errorMessage: "Error logging in user.",
        isLoginRequest: true,
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async CLEAR_USER_CREDENTIALS(): Promise<void> {
    this.context.commit("SET_USER_CREDENTIALS", baseState());
  }

  @Action({ rawError: true })
  async CLEAR_USER_ACCESS_TOKEN(): Promise<void> {
    this.context.commit("SET_USER_ACCESS_TOKEN", baseState());
  }

  @Action({ rawError: true })
  async VERIFY_OTP(payload: OtpVerifyRequest): Promise<StorePromiseInterface> {
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "post",
        url: "/fss/fss/v1/authentication/otp/verify",
        payload: payload,
        mutation: "authenticationModule/SET_USER_ACCESS_TOKEN",
        errorMessage: "Error verifying One Time Passcode. Please try again.",
        isLoginRequest: true,
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async RESEND_OTP(payload: ResendOtpUserTokenRequest): Promise<StorePromiseInterface> {
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "post",
        url: "/fss/fss/v1/authentication/otp/resendotp",
        payload: payload,
        mutation: "authenticationModule/RESEND_OTP_USER_TOKEN",
        errorMessage: "Error resending One Time Passcode. Please try again.",
        isLoginRequest: true
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async CHECK_FIRST_LOGIN(
    payload: FirstLoginRequest
  ): Promise<StorePromiseInterface> {
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "get",
        url: "/webfss/webfss/v1/account/action",
        // payload: payload,
        mutation: "authenticationModule/NOOP",
        errorMessage: "Error checking first time login",
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async CLEAR_OTP(): Promise<void> {
    this.context.commit("SET_SEND_OTP", baseState());
    this.context.commit("SET_VERIFY_OTP", baseState());
  }

  @Mutation
  SET_SEND_OTP(payload: BaseStateInterface): void {
    this.sendOtp = {
      ...this.sendOtp,
      ...payload,
    };
  }

  @Mutation
  SET_VERIFY_OTP(payload: BaseStateInterface): void {
    this.verifyOtp = {
      ...this.verifyOtp,
      ...payload,
    };
  }
  
  @Mutation
  SET_USER_LOGIN_SESSION(payload: BaseStateInterface): void {
    this.userLoginSession = payload;
    if (payload.loading) {
      return;
    }

    TokensContext.instance.setTenantToken(
      this.userLoginSession.data?.tokens?.accessToken,
      this.userLoginSession.data?.tokens?.refreshToken
    );
  }

  @Mutation
  SET_USER_CREDENTIALS(payload: BaseStateInterface): void {
    this.userCredentials = payload;
  }

  @Mutation
  SET_USER_ACCESS_TOKEN(payload: BaseStateInterface): void {
    this.userAccessTokenResponse = payload;
    if (payload.loading) {
      return;
    }

    if (payload.errorStatus) {
      return;
    }

    if (
      this.userAccessTokenResponse?.data?.tokens === null ||
      this.userAccessTokenResponse?.data?.tokens === undefined
    ) {
      return;
    }

    TokensContext.instance.setUserToken(
      this.userAccessTokenResponse.data?.tokens?.accessToken,
      this.userAccessTokenResponse.data?.tokens?.refreshToken
    );
  }

  @Action({ rawError: true })
  async CLEAR_SERVICE_ERROR() {
    return this.context.commit("SERVICE_ERROR", baseState());
  }

  @Action({ rawError: true })
  async CLEAR_NOOP() {
    return this.context.commit("NOOP", baseState());
  }

  @Mutation
  SERVICE_ERROR(payload: BaseStateInterface): void {
    this.serviceError = {
      ...this.serviceError,
      ...payload,
    };
  }

  @Mutation
  NOOP(payload: BaseStateInterface): void {
    this.noop = {
      ...this.noop,
      ...payload,
    };
  }

  get getUserCredentials() {
    return {
      loginId: this.userCredentials?.data?.credentials?.personId
    };
  }  
}

export interface UserLoginRequest {
  tenantName: string;
  credentials: Credentials;
  context: UserLoginContext;
}

export interface Credentials {
  username: string;
  password: string;
  personId: string;
}

export interface UserLoginContext {
  openBanking: OpenBankingContext | null;
}

export interface OpenBankingContext {
  id: string;
  action: string;
}

export interface Login {
  otpPassCode: string;
  context: OtpVerifyContext;
}

export interface ResendOtpUserTokenRequest {
  sessionId: string;
}

export interface OtpVerifyRequest {
  otpPassCode: string;
  context: OtpVerifyContext;
}

export interface FirstLoginRequest {
  requestId: string;
}

export interface OtpVerifyContext {
  otpSessionId: string;
}

export default AuthenticationModule;
