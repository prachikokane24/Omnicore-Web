import { VuexModule, Module, Mutation, Action } from "vuex-module-decorators";
import { baseState, queryString } from "@/libs/store.utils";
import { BaseStateInterface, StorePromiseInterface } from "@/types/store.types";
import { QueryParamInterface, AddPayeePayload } from "@/types/store.types";

@Module({ namespaced: true })
class PayeeModule extends VuexModule {
  userPayees: BaseStateInterface = baseState();

  noop: BaseStateInterface = baseState();

  get selectedAccountId() {
    return this.context.rootState.summaryModule.selectedAccountId;
  }

  @Action({ rawError: true })
  async GET_USER_PAYEES(
    payload: QueryParamInterface
  ): Promise<StorePromiseInterface> {
    let qs;
    let url;
    if (payload) {
      qs = queryString(payload);
      url = `/webfss/webfss/v1/payees/${this.selectedAccountId}?${qs}`;
    } else {
      url = `/webfss/webfss/v1/payees/${this.selectedAccountId}`;
    }
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "get",
        url,
        mutation: "payeeModule/SET_USER_PAYEES",
        errorMessage: "Error getting Payees",
        payload,
        keepData: true,
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async ADD_USER_PAYEE(
    payload: AddPayeePayload
  ): Promise<StorePromiseInterface> {
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "post",
        url: `/webfss/webfss/v1/payees/${this.selectedAccountId}`,
        mutation: "payeeModule/NOOP",
        errorMessage: "Error adding a new Payee",
        payload,
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async DELETE_USER_PAYEE(id: number): Promise<StorePromiseInterface> {
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "delete",
        url: `/webfss/webfss/v1/payee/${this.selectedAccountId}/${id}`,
        mutation: "payeeModule/NOOP",
        errorMessage: "Error deleting Payee",
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async CLEAR_NOOP() {
    return this.context.commit("NOOP", baseState());
  }

  @Mutation
  SET_USER_PAYEES(payload: BaseStateInterface): void {
    console.log(payload);
    this.userPayees = {
      ...this.userPayees,
      ...payload,
    };
  }

  @Mutation
  NOOP(payload: BaseStateInterface): void {
    this.noop = {
      ...this.noop,
      ...payload,
    };
  }
}
export default PayeeModule;
