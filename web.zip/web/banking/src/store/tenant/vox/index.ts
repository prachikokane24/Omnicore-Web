import Vue from "vue";
import Vuex from "vuex";
import helperModule from "@/store/modules/helperModule";
import applicationModule from "@/store/modules/applicationModule";
import userModule from "@/store/modules/userModule";
import otpModule from "@/store/modules/otpModule";
import transactionModule from "@/store/modules/transactionModule";
import standingOrderModule from "@/store/modules/standingOrderModule";
import payeeModule from "@/store/modules/payeeModule";
import scheduledTransferModule from "@/store/modules/scheduledTransferModule";
import summaryModule from "@/store/modules/summaryModule";
import marketingPreferencesModule from "@/store/modules/marketingPreferencesModule";
import walletModule from "@/store/modules/walletModule";
import contactCentreModule from "@/store/modules/contactCentreModule";
import cardModule from "@/store/modules/cardModule";
import authenticationModule from "@/store/modules/authenticationModule";
import directDebitModule from "@/store/modules/directDebitModule";
import openBankingModule from "@/store/modules/openBankingModule";
import instantPaymentModule from "@/store/modules/instantPaymentModule";
import feesModule from "@/store/modules/feesModule";

Vue.use(Vuex);

export default new Vuex.Store({
  modules: {
    helperModule,
    applicationModule,
    userModule,
    otpModule,
    transactionModule,
    standingOrderModule,
    payeeModule,
    scheduledTransferModule,
    summaryModule,
    marketingPreferencesModule,
    walletModule,
    contactCentreModule,
    cardModule,
    authenticationModule,
    directDebitModule,
    openBankingModule,
    instantPaymentModule,
    feesModule
  },
});
