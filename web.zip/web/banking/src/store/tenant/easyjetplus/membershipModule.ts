import { VuexModule, Module, Mutation, Action } from "vuex-module-decorators";
import { baseState, queryString } from "@/libs/store.utils";
import { BaseStateInterface, StorePromiseInterface } from "@/types/store.types";

@Module({ namespaced: true })
class MembershipModule extends VuexModule {
  memberships: BaseStateInterface = baseState();
  membershipDetails: BaseStateInterface = baseState();
  selectedMembershipCard: any | null = null;
  noop: BaseStateInterface = baseState();

  @Action({ rawError: true })
  async GET_MEMBERSHIPS(): Promise<void> {
    const memberships = await this.context.dispatch(
      "StoreRequest",
      {
        method: "get",
        url: require("./mocks/memberships.json"),
        mutation: "membershipModule/SET_MEMBERSHIPS",
        errorMessage: "Error getting memberships data",
        delay: 500,
      },
      { root: true }
    );
    // Sets default card
    if (!this.selectedMembershipCard) {
      console.log(memberships.data.memberships[0]);
      this.context.dispatch(
        "UPDATE_SELECTED_MEMBERSHIP_CARD",
        memberships.data.memberships[0]
      );
    }
  }

  @Action({ rawError: true })
  async GET_MEMBERSHIP(membershipId: number): Promise<StorePromiseInterface> {
    const url = `/v3/5a1f3a5f-281d-405c-9774-5bf9e8f94bc5`;
    //const url = `/webfss/v1/membership/${id}`;
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "get",
        url,
        mutation: "membershipModule/SET_MEMBERSHIP",
        errorMessage: "Error getting membership data",
        delay: 500,
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  UPDATE_SELECTED_MEMBERSHIP_CARD(payload: any | null): void {
    this.context.commit("SET_SELECTED_MEMBERSHIP_CARD", payload);
  }

  //   @Action({ rawError: true })
  //   UPDATE_SELECTED_MEMBERSHIP_ID(id: number): void {
  //     this.context.commit("SET_SELECTED_MEMBERSHIP_ID", id);
  //   }

  @Mutation
  SET_SELECTED_MEMBERSHIP_CARD(payload: any): void {
    this.selectedMembershipCard = payload;
  }

  //   @Mutation
  //   SET_SELECTED_MEMBERSHIP_ID(payload: any): void {
  //     this.selectedMembershipId = {
  //       ...this.selectedMembershipId,
  //       ...payload,
  //     };
  //   }

  @Mutation
  SET_MEMBERSHIPS(payload: BaseStateInterface): void {
    this.memberships = {
      ...this.memberships,
      ...payload,
    };
  }

  @Mutation
  SET_MEMBERSHIP(payload: BaseStateInterface): void {
    this.membershipDetails = {
      ...this.membershipDetails,
      ...payload,
    };
  }

  @Mutation
  NOOP(payload: BaseStateInterface): void {
    this.noop = {
      ...this.noop,
      ...payload,
    };
  }
}
export default MembershipModule;
