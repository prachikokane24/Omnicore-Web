import Vue from "vue";
import Vuex from "vuex";

// Global modules
import helperModule from "../../modules/helperModule";
import applicationModule from "../../modules/applicationModule";
import userModule from "../../modules/userModule";
import otpModule from "../../modules/otpModule";
import transactionModule from "../../modules/transactionModule";
import standingOrderModule from "../../modules/standingOrderModule";
import payeeModule from "../../modules/payeeModule";
import scheduledTransferModule from "../../modules/scheduledTransferModule";
import marketingPreferencesModule from "../../modules/marketingPreferencesModule";

import contactCentreModule from "../../modules/contactCentreModule";
import cardModule from "../../modules/cardModule";

// Easyjet
import summaryModule from "./summaryModule";
import personalDetailsModule from "./personalDetailsModule";
import membershipModule from "./membershipModule";

Vue.use(Vuex);

export default new Vuex.Store({
  modules: {
    helperModule,
    applicationModule,
    userModule,
    otpModule,
    transactionModule,
    standingOrderModule,
    payeeModule,
    scheduledTransferModule,
    marketingPreferencesModule,
    membershipModule,
    contactCentreModule,
    cardModule,
    summaryModule,
    personalDetailsModule,
  },
});
