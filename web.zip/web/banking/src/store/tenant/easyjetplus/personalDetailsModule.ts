import { VuexModule, Module, Mutation, Action } from "vuex-module-decorators";
import { baseState } from "@/libs/store.utils";
import {
  BaseStateInterface,
  StorePromiseInterface,
  PersonalDetailsPayloadInterface,
} from "@/types/store.types";

@Module({ namespaced: true })
class PersonalDetailsModule extends VuexModule {
  personalDetails: BaseStateInterface = baseState();
  personalDetailsUpdate: BaseStateInterface = baseState();
  noop: BaseStateInterface = baseState();

  @Action({ rawError: true })
  async GET_PERSONAL_DETAILS(
    membershipId: number
  ): Promise<StorePromiseInterface> {
    const url = await require(`./mocks/personalDetails.json`);
    console.log("GET Personal Details for ID:", membershipId);
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "get",
        url,
        mutation: "personalDetailsModule/SET_PERSONAL_DETAILS",
        errorMessage: "Error getting personal details",
        delay: 2000,
      },
      { root: true }
    );
  }

  @Action({ rawError: true })
  async UPDATE_PERSONAL_DETAILS(
    payload: PersonalDetailsPayloadInterface
  ): Promise<StorePromiseInterface> {
    return this.context.dispatch(
      "StoreRequest",
      {
        method: "update",
        url: require("./mocks/personalDetails.json"),
        mutation: "personalDetailsModule/SET_PERSONAL_DETAILS_UPDATE",
        errorMessage: "Error updating personal details",
        delay: 500,
        payload,
      },
      { root: true }
    );
  }

  @Mutation
  SET_PERSONAL_DETAILS(payload: BaseStateInterface): void {
    this.personalDetails = {
      ...this.personalDetails,
      ...payload,
    };
  }

  @Mutation
  SET_PERSONAL_DETAILS_UPDATE(payload: BaseStateInterface): void {
    this.personalDetailsUpdate = {
      ...this.personalDetailsUpdate,
      ...payload,
    };
  }
}
export default PersonalDetailsModule;
