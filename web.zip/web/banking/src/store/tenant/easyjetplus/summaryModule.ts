import Vue from "vue";
import { VuexModule, Module, Mutation, Action } from "vuex-module-decorators";
import { baseState } from "@/libs/store.utils";
import { BaseStateInterface, StorePromiseInterface } from "@/types/store.types";
import vuetify from "@/plugins/vuetify";
import MockClient from "@/libs/clients/mockClient";

@Module({ namespaced: true })
class SummaryModule extends VuexModule {
  accountSummary: BaseStateInterface = baseState();
  selectedAccountId: any | null = null;
  selectedWallet: any | null = null;

  @Action({ rawError: true })
  async GET_ACCOUNT_SUMMARY(): Promise<void> {
    const summaryData = await this.context.dispatch(
      "StoreRequest",
      {
        method: "get",
        url: require("./mocks/summaryData.json"),
        //url: "/webfss/webfss/v1/summaryData",
        mutation: "summaryModule/SET_ACCOUNT_SUMMARY",
        errorMessage: "Error getting account summary data",
        keepData: true,
      },
      { root: true }
    );
    console.log(summaryData);
    this.context.dispatch(
      "UPDATE_SELECTED_ACCOUNT_ID",
      summaryData.data.accounts[0].accountId
    );
  }

  @Action({ rawError: true })
  UPDATE_SELECTED_WALLET(payload: any | null): void {
    this.context.commit("SET_SELECTED_WALLET", payload);
  }

  @Action({ rawError: true })
  UPDATE_SELECTED_ACCOUNT_ID(id: number): void {
    this.context.commit("SET_SELECTED_ACCOUNT_ID", id);
  }

  @Mutation
  SET_SELECTED_WALLET(payload: any): void {
    this.selectedWallet = payload;
  }

  @Mutation
  SET_ACCOUNT_SUMMARY(payload: BaseStateInterface): void {
    this.accountSummary = {
      ...this.accountSummary,
      ...payload,
    };
  }

  @Mutation
  SET_SELECTED_ACCOUNT_ID(id: string): void {
    this.selectedAccountId = id;
  }

  // Maps all Accounts to its wallets
  get getAllUserAccountWallets() {
    return this.accountSummary?.data?.accounts?.map((account) => {
      const accountId = account.accountId;
      const wallets = this.accountSummary?.data?.wallets?.filter((o) => {
        return o.linkedToAccount == accountId;
      });
      return {
        accountId: accountId,
        accountHolders: account.accountHolders,
        accountType: account.accountType,
        accountSort: account.sortCode,
        accountNumber: account.accountNumber,
        wallets: wallets,
      };
    });
  }

  // Return wallets only for a particular Account ID
  get getSelectedUserAccountWallets() {
    const foundAccount = this.getAllUserAccountWallets?.find(
      (account) => account.accountId === this.selectedAccountId
    );
    return foundAccount || [];
  }

  get getMarketingPreferences() {
    const marketingPrefs = this.accountSummary?.data?.user
      ?.marketingPreferences;
    return marketingPrefs || [];
  }

  get getAccountDetails() {
    return {
      accountHolders: this.getSelectedUserAccountWallets.accountHolders,
      accountSortCode: this.getSelectedUserAccountWallets.accountSort,
      accountAccountNumber: this.getSelectedUserAccountWallets.accountNumber,
      availableBalance: this.selectedWallet?.availableBalance.minorUnits,
      accountBalance: this.selectedWallet?.accountBalance.minorUnits,
      pendingCredits: this.selectedWallet?.pendingCredits.minorUnits,
      pendingDebits: this.selectedWallet?.pendingDebits.minorUnits,
    };
  }
}
export default SummaryModule;
