﻿param(
  [string] $azureSubscription = "OMN-DEV-SUB",
  [string] $resourceGroupName = "DEV-ARM-TEST",
  [string] $location = "UK South",
  [string] $version = (Get-Date -Format "yyyyMMddhhmmssfff"),
  [string] $resourceName = "resourceDeploy",
  [string] $sourceRootFolder = ".",
  [string] $parameterFile = ""
)

Write-Output "Set subscription: $azureSubscription"
Set-AzContext -Subscription $azureSubscription

# Create resource group if necessary
Write-Output "Check $resourceGroupName exists"
$rg = Get-AzResourceGroup `
  -Name $resourceGroupName `
  -ErrorAction SilentlyContinue
if ($null -eq $rg) {
  Write-Output "Creating $location $resourceGroupName"
  New-AzResourceGroup `
    -Name $resourceGroupName `
    -Location $location
}

Write-Output "Creating template spec: $version"
New-AzTemplateSpec `
  -Name $resourceName `
  -Version $version `
  -ResourceGroupName $resourceGroupName `
  -Location $location `
  -TemplateFile "$sourceRootFolder\MasterTemplate.json"

$id = (Get-AzTemplateSpec -ResourceGroupName $resourceGroupName -Name $resourceName -Version $version).Versions.Id


if ($parameterFile -eq "") {
  Write-Output "Deploying template spec: $id"
  New-AzResourceGroupDeployment `
    -TemplateSpecId $id `
    -ResourceGroupName $resourceGroupName
}
else {
  Write-Output "Deploying template spec: $id, with parameter file: $parameterFile"
  New-AzResourceGroupDeployment `
    -TemplateSpecId $id `
    -ResourceGroupName $resourceGroupName `
    -TemplateParameterFile $parameterFile -whatif
}
