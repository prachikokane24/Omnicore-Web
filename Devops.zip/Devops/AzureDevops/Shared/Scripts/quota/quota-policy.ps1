
param ($input1, $input2)

Write-Host "$input1 $input2"

$path=$input1
$template=$input2
$File=get-content $path

$servicename=(Select-String -List '^\s*app:(.*)' $path).Matches[0].Groups[1].Value



if($servicename -match "serviceName"){
    Write-Output "Servicename settonull because is token $servicename"
    $servicename = $null
}

if( $null -ne $servicename ){
    Write-Output "Query quota policy for - $servicename"
    $data = Get-Content -Raw -Path  $template | ConvertFrom-Json

    $policies = $data.Policies | where { $_.name -eq $servicename.Trim() }
    Write-Output $policies
    if($null -ne $policies){ #no policies found in template for servicename
        $requestcpu = $policies[0].requests.cpu
        $requestmemory = $policies[0].requests.memory
        $limitcpu = $policies[0].limits.cpu
        $limitmemory = $policies[0].limits.memory

        $File = $File -replace 'cpu: 500m',"cpu: $requestcpu"
        $File = $File -replace 'memory: 500Mi',"memory: $requestmemory"
        $File = $File -replace 'cpu: 1000M',"cpu: $limitcpu"
        $File = $File -replace 'memory: 2Gi',"memory: $limitmemory"

        $File > $path
    }else{
        Write-Output "Criteria not found in policy , ignored"
    }
}else {
    Write-Output "Nothing to patch"
}
