#Requires -Version 3.0
# az login
cd C:\src\DevOps\Omnicore\LogicApp\OmniProcessorBalanceExtract

# the template we will deploy
$templateUri=".\LogicApps.template.json"
$parameterUri=".\LogicApps.parameters.json"

#DEV
$subscriptionId="8e23dffd-ada5-41c5-b121-ebc51bcbf252"
$resourceGroupName="NEU-DEV-RG-OmnicoreLogicApps"
$location="northeurope"
$mySqlPasssword = Read-Host -prompt "Enter password for mysql user"
az account set --subscription $subscriptionId
az group create -l $location -n $resourceGroupName
az deployment group validate `
    --resource-group $resourceGroupName `
    --template-file $templateUri `
    --verbose `
    --parameters `
      resourceGroupName=$resourceGroupName `
      subscriptionId=$subscriptionId `
      environmentName="DEV" `
      regionName="northeurope" `
      storageAccountName="omgneudevvoxsta" `
      sqlServerName="omn-neu-dev-sdb-payments" `
      sqlDatabaseName="omn-neu-dev-db-processor" `
      mysql_connection_server="omg-neu-dev-vox-fs.mysql.database.azure.com" `
      mysql_connection_username="LAP-OMPBalExtract" `
      mysql_connection_password="$mySqlPasssword" `
      mysql_connection_privacySetting="None"

az deployment group create `
    --name TestDeployment `
    --resource-group $resourceGroupName `
    --template-file $templateUri `
    --verbose `
    --parameters `
      resourceGroupName=$resourceGroupName `
      subscriptionId=$subscriptionId `
      environmentName="DEV" `
      regionName="northeurope" `
      storageAccountName="omgneudevvoxsta" `
      sqlServerName="omn-neu-dev-sdb-payments" `
      sqlDatabaseName="omn-neu-dev-db-processor" `
      mysql_connection_server="omg-neu-dev-vox-fs.mysql.database.azure.com" `
      mysql_connection_username="LAP-OMPBalExtract" `
      mysql_connection_password="$mySqlPasssword" `
      mysql_connection_privacySetting="None"


# SIT
$subscriptionId="48768fc5-bd73-437d-919a-7bf6815308d8"
$resourceGroupName="NEU-SIT-RG-OmnicoreLogicApps"
$location="northeurope"
$mySqlPasssword = Read-Host -prompt "Enter password for mysql user"
az account set --subscription $subscriptionId
az group create -l $location -n $resourceGroupName
az deployment group create `
    --name TestDeployment `
    --resource-group $resourceGroupName `
    --template-file $templateUri `
    --mode "incremental" `
    --verbose `
    --parameters `
      resourceGroupName=$resourceGroupName `
      subscriptionId=$subscriptionId `
      environmentName="SIT" `
      regionName="northeurope" `
      storageAccountName="omgneusitvoxsta" `
      sqlServerName="neu-sit-sdb-payments-manual" `
      sqlDatabaseName="omn-neu-sit-db-processor" `
      mysql_connection_server="omg-neu-sit-vox-fs.mysql.database.azure.com" `
      mysql_connection_username="LAP-OMPBalExtract" `
      mysql_connection_password="$mySqlPasssword" `
      mysql_connection_privacySetting="None"

# UAT

# PPD

# PRD
$subscriptionId="71143593-6440-45d9-8091-23f8b1e77a77"
$resourceGroupName="NEU-PRD-RG-OmnicoreLogicApps"
$location="northeurope"
$mySqlPasssword = Read-Host -prompt "Enter password for mysql user"
az account set --subscription $subscriptionId
az group create -l $location -n $resourceGroupName
az deployment group create `
    --name TestDeployment `
    --resource-group $resourceGroupName `
    --template-file $templateUri `
    --mode "incremental" `
    --verbose `
    --parameters `
      resourceGroupName=$resourceGroupName `
      subscriptionId=$subscriptionId `
      environmentName="PRD" `
      regionName="northeurope" `
      storageAccountName="omgneuprdvoxsta" `
      sqlServerName="omn-dev-sdb-omnicore" `
      sqlDatabaseName="NEU-PRD-DB-OmnicoreProcessor" `
      mysql_connection_server="omg-neu-prd-vox-fs.mysql.database.azure.com" `
      mysql_connection_username="LAP-OMPBalExtract" `
      mysql_connection_password="$mySqlPasssword" `
      mysql_connection_privacySetting="None"


# grant managed identity permission on database
# CREATE USER [NEU-SIT-LAP-OMPBalanceExtract] from external provider
# EXEC sp_addrolemember N'db_datareader', N'NEU-SIT-LAP-OMPBalanceExtract'

# grant managed identity RABC role "Storage Blob Contributor" on the CONTAINER in the storage account